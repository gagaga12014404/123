﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using System.Web.Script.Serialization;

namespace Concord.KeyIn.Stock.SendPWDMail
{
    public partial class frmSendPWDMail : Form
    {
        string m_sqlConn = Properties.Settings.Default.strConnection;
        string m_Mail = Properties.Settings.Default.strMail;
        Random rand = new Random();
        int SPWD = 0;
        int EPWD = 0;

        public frmSendPWDMail()
        {
            InitializeComponent();
        }

        private void btn_SendPWDMail_Click(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("更新密碼開始");
            string strErrMsg = "";
            SPWD = rand.Next(10000, 99999);
            EPWD = rand.Next(10000, 99999);
            string From = "emsgsend@concords.com.tw";
            string FromName = "emsgsend";
            string MailTo = m_Mail;
            string MailCC = "";
            string Subject = "萬能強制單的密碼";
            string Body = "<html>" +
                          "<head>" +
                          "<title>萬能強制鍵密碼通知</title>" +
                          "</head>" +
                          "<body>" +
                           "密碼=" + SPWD.ToString() + EPWD.ToString() +
                          "</body>" +
                          "</html>";
            
            string strcomm = "update [KeyIn].[dbo].[SYS_BHNOPWD] set PWD='" + SPWD.ToString() + EPWD.ToString() + "',UpdateCFID='system',UpdateDate=GETDATE() ";
            DBHelper.UpdateData("KeyIn", strcomm, m_sqlConn, ref strErrMsg);
            if (String.IsNullOrEmpty(strErrMsg))
            {
                ConcordLogger.Logger.Info("寄信開始");
                MsgWebService.MsgService MsgService = new MsgWebService.MsgService();
                string[] result = MsgService.SendEMail(From, FromName, MailTo, MailCC, Subject, Body, "html", "", "", "", "KeyIn", "", "", "");
                if (result[0] == "-1")
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Error("SendMail 失敗，" + result[1].ToString());
                    Concord.SDK.Logging.ConcordLogger.Alert("9999", "SendMail 失敗", result[1].ToString());
                }
                else
                {
                    Concord.SDK.Logging.ConcordLogger.Logger.Info("SendMail 成功!");
                }
            }
            else
            {
                ConcordLogger.Alert("9001", strErrMsg);
            }
        }

        private void frmSendPWDMail_Load(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("程式開始");
            btn_SendPWDMail_Click(sender, e);
        }
    }
}
