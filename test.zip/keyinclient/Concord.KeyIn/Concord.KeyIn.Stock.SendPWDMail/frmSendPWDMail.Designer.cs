﻿namespace Concord.KeyIn.Stock.SendPWDMail
{
    partial class frmSendPWDMail
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_SendPWDMail = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_SendPWDMail
            // 
            this.btn_SendPWDMail.Location = new System.Drawing.Point(13, 28);
            this.btn_SendPWDMail.Name = "btn_SendPWDMail";
            this.btn_SendPWDMail.Size = new System.Drawing.Size(117, 23);
            this.btn_SendPWDMail.TabIndex = 0;
            this.btn_SendPWDMail.Text = "重設密碼並送信";
            this.btn_SendPWDMail.UseVisualStyleBackColor = true;
            this.btn_SendPWDMail.Click += new System.EventHandler(this.btn_SendPWDMail_Click);
            // 
            // frmSendPWDMail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 77);
            this.Controls.Add(this.btn_SendPWDMail);
            this.Name = "frmSendPWDMail";
            this.Text = "更新密碼並送信";
            this.Load += new System.EventHandler(this.frmSendPWDMail_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_SendPWDMail;
    }
}

