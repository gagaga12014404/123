﻿using Concord.SDK.IOCPHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace Concord.KeyIn.Client
{
    class SocketSessionHandler : AppClient
    {
        private MemoryStream _MessageBuffer = new MemoryStream();
        private static readonly byte[] _Header = Encoding.GetEncoding("Big5").GetBytes("8=Concords|");

        public SocketSessionHandler(DnsEndPoint EndPoint) : base(EndPoint) { }

        public override void HandleReceive(byte[] data)
        {
            int dataCount, headerEndIndex, bodyEndIndex;
            string headerString, bodyString;
            int headerLength = 18;
            int readEndIndex = -1;
            byte[] dataBytes;

            _MessageBuffer.Write(data, 0, data.Length);
            dataBytes = _MessageBuffer.ToArray();
            dataCount = dataBytes.Length;

            foreach (int index in IndexesOf(dataBytes, 0, _Header))
            {
                headerEndIndex = index + headerLength;
                if (headerEndIndex > dataCount)
                    break;
                headerString = Encoding.GetEncoding("Big5").GetString(dataBytes, index, headerLength);
                Dictionary<int, string> list = ParserMessageToDic(headerString, '|');
                if (list.Count != 2)
                    continue;
                string bodyLengthString;
                if (!list.TryGetValue(9, out bodyLengthString))
                    continue;
                int bodyLength;
                if (!int.TryParse(bodyLengthString, out bodyLength) || bodyLength < 1)
                    continue;
                bodyEndIndex = headerEndIndex + bodyLength;
                if (bodyEndIndex > dataCount)
                    break;
                bodyString = Encoding.GetEncoding("Big5").GetString(dataBytes, headerEndIndex, bodyLength);
                readEndIndex = bodyEndIndex;

                OnReceiveMsg(headerString + bodyString);
            }
            if (readEndIndex != -1)
            {
                _MessageBuffer.SetLength(0);
                int remainLength = dataBytes.Length - readEndIndex;
                if (remainLength > 0)
                {
                    _MessageBuffer.Write(dataBytes, readEndIndex, dataBytes.Length - readEndIndex);
                }
            }
        }

        /// <summary>
        /// 尋找位置
        /// </summary>
        /// <param name="source">比對來源</param>
        /// <param name="start">開始位置</param>
        /// <param name="pattern">比對項目</param>
        /// <returns></returns>
        public static IEnumerable<long> IndexesOf(byte[] source, int start, byte[] pattern)
        {
            long valueLength = source.LongLength;
            long patternLength = pattern.LongLength;

            if ((valueLength == 0) || (patternLength == 0) || (patternLength > valueLength))
            {
                yield break;
            }

            long[] badCharacters = new long[256];
            long lastPatternIndex = patternLength - 1;
            long index = start;

            for (var i = 0; i < 256; i++)
            {
                badCharacters[i] = patternLength;
            }
            for (long i = 0; i < lastPatternIndex; i++)
            {
                badCharacters[pattern[i]] = lastPatternIndex - i;
            }

            while (index <= valueLength - patternLength)
            {
                for (var i = lastPatternIndex; source[index + i] == pattern[i]; i--)
                {
                    if (i == 0)
                    {
                        yield return index;
                        break;
                    }
                }
                index += badCharacters[source[index + lastPatternIndex]];
            }
        }

        /// <summary>
        /// 解析字串電文成Dictionary物件
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fieldSplit"></param>
        /// <returns></returns>
        public static Dictionary<int, string> ParserMessageToDic(string message, char fieldSplit)
        {
            Dictionary<int, string> list = new Dictionary<int, string>();
            var fields = message.Split(new char[] { fieldSplit }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(s => s.Split(new[] { '=' }, 2))
                                .Where(s => s.Length == 2);

            foreach (var field in fields)
            {
                int tag;
                if (!int.TryParse(field[0], out tag))
                    continue;
                try
                {
                    list.Add(tag, field[1]);//電文有重複tag，程式會死掉
                }
                catch (ArgumentException e)
                {
                    continue;
                }
            }
            return list;
        }
        /// <summary>
        /// 組成HearBeat訊息
        /// </summary>
        /// <returns></returns>
        public static string ComposeHeartBeatMessage()
        {
            return "8=Concords|9=00005|35=0";
        }
        /// <summary>
        /// Pusg Server 註冊電文
        /// </summary>
        /// <returns></returns>
        public static string ComposeSubscribeMessage(IEnumerable<string> regCodes)
        {
            string head = "8=Concords|9={0}";
            string body = "|35=r" +
                          "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                          $"|20100={string.Join(",", regCodes)}";
            head = string.Format(head, Encoding.GetEncoding("Big5").GetBytes(body).Length.ToString().PadLeft(5, '0'));
            return head + body;
        }
    }
}
