﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class RiskControlHandler
    {
        /// <summary>
        /// 保留顧客資訊
        /// </summary>
        public static bool _IsKeepCusAccount = false;
        /// <summary>
        /// 客戶帳號風控通過註記
        /// </summary>
        public static bool _CSEQChecked = false;
        /// <summary>
        /// 股票代號風控通過註記
        /// </summary>
        public static bool _StockNoChecked = false;
        /// <summary>
        /// 委託數量風控通過註記
        /// </summary>
        public static bool _OrdQtyChecked = false;
        /// <summary>
        /// 拆單功能開啟註記
        /// </summary>
        public static bool _SplitLotEnable = false;

        /// <summary>
        /// 開啟萬能強制下單視窗
        /// 參數一 : 下單物件
        /// 參數二 : 風控剔退訊息
        /// 參數三 : 是否為萬能強制
        /// </summary>
        public Action<string> _evntForceOrder;

        /// <summary>
        /// 當需強制下單時所暫存之下單物件
        /// </summary>
        private Order _ForceOrderObject = null;

        /// <summary>
        /// 建構子
        /// </summary>
        /// <param name="enable">拆單啟用與否</param>
        public RiskControlHandler()
        {
        }
        /// <summary>
        /// 執行下單風控
        /// </summary>
        /// <param name="cseq"></param>
        /// <param name="stock"></param>
        /// <param name="ordType"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        public bool Execute(OrderTabViewModel info, Side side)
        {
            // 自營版本不控
            if (frmMain._Model == 2)
                return true;

            #region 檢查是否為現沖卻買進
            if ((info.OType == "5" ||
                 info.OType == "6" ||
                 info.OType == "9") && side == Side.BUY)
            {
                MessageBox.Show("該委託類別不可買進", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info("[Order] 委託類為現賣沖，不可買進");
                return false;
            }
            #endregion

            if (!CheckUIControlInputData(info.ECode))
                return false;

            #region 驗證特定帳號和關係企業股票買賣
            if (info.BHNO == "0" && info.CSEQ == "1377737" &&
                STMBStore.CheckRelatedCompanyStock(info.Symbol, side, info.OType))
            {
                MessageBox.Show("關係企業股票不可買進", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info("[Order] 關係企業股票不可買進");
                return false;
            }
            #endregion

            return true;
        }
        /// <summary>
        /// 股票代號欄位風控控制邏輯
        /// 1. STMB檔案是否包含 2.是否為興櫃股票
        /// </summary>
        /// <param name="symbol">股票代號</param>
        /// <param name="info">股票資訊</param>
        /// <returns></returns>
        public bool CheckSymbol(string symbol, out StockInfo info)
        {
            info = null;
            _StockNoChecked = false;
            info = STMBStore.Get_SymbolInfo(symbol);
            if (info == null)
                return false;
            if (info.MTYPE.Equals("E"))
            {
                MessageBox.Show($"{info.CNAME} 興櫃股票不可輸入", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] {info.CNAME} 興櫃股票不可輸入");
                return false;
            }
            _StockNoChecked = true;
            return true;
        }
        /// <summary>
        /// 委託數量欄位風險控制邏輯
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool CheckStockQty(string text, string eCode)
        {
            _OrdQtyChecked = false;
            uint qty = 0;
            if (text.Length > 0 && !uint.TryParse(text.Trim(), out qty))
            {
                MessageBox.Show("委託數量非數字", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Debug($"[Order] CheckStockQty風控:委託數量非數字{text}");
                return false;
            }
            else if (qty == 0)
            {
                MessageBox.Show("委託數量不得為0", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Debug($"[Order] CheckStockQty風控:委託數量不得為0");
                return false;
            }
            else if ((eCode == "2" || eCode == "7") && qty > 999)
            {
                MessageBox.Show("零股委託數量不得超過999股", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Debug($"[Order] CheckStockQty風控:零股委託數量不得超過999股");
                return false;
            }
            else if (qty > 499 && !_SplitLotEnable && (eCode == "0" || eCode == "3"))
            {
                MessageBox.Show("委託數量不得超過499張", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Debug($"[Order] CheckStockQty風控:委託數量不得超過499張");
                return false;
            }
            _OrdQtyChecked = true;
            return true;
        }
        /// <summary>
        /// 委託價格欄位風險控制邏輯
        /// 邏輯: 1.數字格式驗證 2.價格是否可輸入0 3.漲跌幅範圍區間檢查 4.價格Tick區間檢查
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool CheckStockPrice(OrderTabViewModel orderInfo, StockInfo symbolInfo)
        {
            decimal price = 0;
            var decimalPoing = orderInfo.OrderPrice.Split('.');
            if (decimalPoing.Length == 2 && decimalPoing[1].Length > 4)
            {
                MessageBox.Show("小數位數超過4位", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            NumberStyles style = NumberStyles.Number | NumberStyles.AllowDecimalPoint;
            if (!decimal.TryParse(orderInfo.OrderPrice, style, null, out price))
            {
                MessageBox.Show("非正確價格數字格式", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Debug($"[Order] CheckStockPrice風控:非正確價格數字格式 - {orderInfo.OrderPrice}");
                return false;
            }
            orderInfo.OrderPrice = price.ToString("0.####");
            switch (orderInfo.ECode) // 定盤/標借/標購/拍賣不需驗證
            {
                case "0":
                case "2":
                case "7":
                    decimal price_tick = StockInfoHandler.GetStockPriceTick(symbolInfo.STYPE, price);
                    if (price % price_tick != 0)
                    {
                        MessageBox.Show($"價格檔數錯誤，區間應為 {price_tick}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        ConcordLogger.Logger.Debug($"[Order] CheckStockPrice風控:價格檔數錯誤 - {price}");
                        return false;
                    }
                    if (symbolInfo.BPRICE == 9995)
                    {
                        if (price == 0)
                        {
                            MessageBox.Show("無漲跌幅限制股票,價格不可為0", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ConcordLogger.Logger.Debug($"[Order] CheckStockPrice風控:無漲跌幅限制股票,價格不可為0");
                            return false;
                        }
                    }
                    if (orderInfo.OrdType == "2" && (price > symbolInfo.TPRICE || price < symbolInfo.BPRICE))
                    {
                        MessageBox.Show($"價格超出漲跌幅限制 漲停價: {symbolInfo.TPRICE}, 跌停價: {symbolInfo.BPRICE}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        ConcordLogger.Logger.Debug($"[Order] CheckStockPrice風控:價格超出漲跌幅限制 - OrdPrice{price}");
                        return false;
                    }
                    break;
            }
            return true;
        }
        /// <summary>
        /// 客戶帳號後台風控邏輯確認
        /// </summary>
        /// <param name="cseq"></param>
        /// <returns></returns>
        public bool CheckCSEQ(string cseq)
        {
            _CSEQChecked = false;

            if (string.IsNullOrEmpty(cseq) || cseq.Length < 7)
                return false;

            HttpReqData data = new HttpReqData
            {
                bhno = UserInfo._BHNO,
                cseq = cseq.Remove(cseq.Length - 1, 1)
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkCumb", data);

            if (rep[0].errCode == 0)
            {
                _CSEQChecked = true;
                return true;
            }
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }

            return false;
        }
        /// <summary>
        /// 確認使用者下單權限(是否為KeyIn人員)
        /// </summary>
        /// <returns></returns>
        public bool CheckUserOrderAuthority(int enviroment)
        {
            if (enviroment == 2) // 測試環境不檔
                return true;

            if (UserInfo._UserAuthority == UserAuthority.KeyIn || UserInfo._UserAuthority == UserAuthority.KeyInIB)
                return true;
            else
            {
                ConcordLogger.Logger.Info($"[Order] User-{UserInfo._EMNO},Authority-{UserInfo._UserAuthority} : 非KeyIn人員無法操作");
                MessageBox.Show("非KeyIn人員無法操作", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }
        /// <summary>
        /// 後台客戶簽署交易表風控查詢
        /// </summary>
        /// <param name="eCode"></param>
        /// <param name="CSEQ"></param>
        /// <param name="ordType"></param>
        /// <returns></returns>
        public bool CheckOrdType(string BHNO, string Ecode, string OType, string Cseq)
        {
            // 內湖分公司 排除驗證
            if (UserInfo._UserIP == frmMain._richIP)
                return true;

            string TType = Ecode;
            if (TType == "")
            {
                MessageBox.Show($"交易別錯誤: {Ecode}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(Cseq))
            {
                MessageBox.Show($"請輸入正確客戶帳號", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            HttpReqData data = new HttpReqData
            {
                bhno = BHNO,
                // 移除帳號檢碼
                cseq = Cseq.Substring(0, 6),
                otype = OType,
                ecode = TType
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkOcd", data);
            if (rep[0].errCode == 0)
                return true;
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }
            return false;
        }
        /// <summary>
        /// 後台委託下單數量風控查詢
        /// </summary>
        /// <param name="CSEQ"></param>
        /// <param name="ordType"></param>
        /// <param name="eCode"></param>
        /// <param name="symbol"></param>
        /// <param name="qty"></param>
        /// <returns></returns>
        public bool CheckBOSOrdQty(OrderTabViewModel view)
        {
            // 自營不控
            if (frmMain._Model == 2)
                return true;

            string TType = view.ECode;
            if (TType == "")
            {
                MessageBox.Show($"交易別錯誤: {view.ECode}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(view.CSEQ))
            {
                MessageBox.Show($"請輸入正確客戶帳號", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            HttpReqData data = new HttpReqData
            {
                bhno = view.BHNO,
                // 移除帳號檢碼
                cseq = view.CSEQ.Remove(view.CSEQ.Length - 1, 1),
                otype = view.OType,
                ecode = TType,
                stock = view.Symbol,
                qty = view.OrderQty
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkQty", data);
            if (rep[0].errCode == 0)
                return true;
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }
            return false;
        }
        /// <summary>
        /// 後台股票商品風控查詢
        /// </summary>
        /// <returns></returns>
        public bool CheckBOSSymbol(OrderTabViewModel view)
        {
            // 自營不控
            if (frmMain._Model == 2)
                return true;

            string TType = view.ECode;
            if (TType == "")
            {
                MessageBox.Show($"交易別錯誤: {view.ECode}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(view.CSEQ))
            {
                MessageBox.Show($"請輸入正確客戶帳號", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            HttpReqData data = new HttpReqData
            {
                bhno = view.BHNO,
                // 移除帳號檢碼
                cseq = view.CSEQ.Remove(view.CSEQ.Length - 1, 1),
                otype = view.OType,
                ecode = TType,
                stock = view.Symbol
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkStmb", data);
            if (rep[0].errCode == 0)
            {
                return true;
            }
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }
            return false;
        }
        /// <summary>
        /// 委託價格風控查詢
        /// </summary>
        /// <param name="CSEQ"></param>
        /// <param name="ordType"></param>
        /// <param name="eCode"></param>
        /// <param name="symbol"></param>
        /// <param name="qty"></param>
        /// <param name="price"></param>
        /// <returns></returns>
        private bool CheckBOSOrdPrice(Order order)
        {
            // 市價不檢查
            if (order.OrdType == "1")
                return true;
            string TType = order.ECode;
            // 當沖註記
            string ordType = "";
            if (order.DayTradeFlag == "Y")
                ordType = "9";
            else
                ordType = order.OType;
            decimal OrdPrice = 0;
            decimal.TryParse(order.OrdPrice, out OrdPrice);
            HttpReqData data = new HttpReqData
            {
                bhno = order.BHNO,
                // 移除帳號檢碼
                cseq = order.CSEQ.Remove(order.CSEQ.Length - 1, 1),
                otype = ordType,
                ecode = TType,
                stock = order.Symbol,
                qty = order.OrdQty.ToString(),
                price = OrdPrice.ToString("0.0000")
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkPrice", data);
            if (rep[0].errCode == 0)
                return true;
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }
            return false;
        }
        /// <summary>
        /// 查詢庫存以及強制放行確認
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        private bool CheckForcedSendOut(Order order)
        {
            string TType = order.ECode;
            decimal OrdPrice = 0;
            decimal.TryParse(order.OrdPrice, out OrdPrice);
            HttpReqData data = new HttpReqData
            {
                // 移除帳號檢碼
                cseq = order.CSEQ.Remove(order.CSEQ.Length - 1, 1),
                ckno = order.CSEQ.Substring(6, 1),
                qty = order.OrdQty.ToString(),
                OrdType = order.OrdType,
                price = OrdPrice.ToString("0.0000"),
                bhno = $"845{order.BHNO}",
                side = order.Side == Side.BUY ? "1" : "2",
                stock = order.Symbol,
                TimeInforce = order.TimeInForce,
                TransactTime = DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff"),
                TwseIvacnoFlag = "1", // 固定帶 1
                otype = order.OType,
                Sale = order.Sale,
                Ocode = " ",  // 固定帶空白
                Dtrade = order.DayTradeFlag,
                Siplan = "N", // 固定帶N
                ecode = TType,
                BalForceFlag = "N", // 固定帶N
                PriceForceFlag = "N", // 固定帶N
                CrdbqtyForceFlag = "N", // 固定帶N
                AllForceFlag = "N", // 固定帶N
                SeqenceFlag = order.SeqenceFlag,
                seqno = " "
            };
            string BOS_TEXT = "";
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("checkAll", data);
            foreach (var item in rep)
            {
                switch (item.errCode)
                {
                    case 0:
                        return true;
                    case 1027:
                    case 1031:
                        {
                            BOS_TEXT += item.errString + Environment.NewLine; ;
                            order.InsufficientQuota_forced = "Y";
                            break;
                        }
                    case 1073:
                        {
                            BOS_TEXT += item.errString + Environment.NewLine; ;
                            order.PriceErr_forced = "Y";
                            break;
                        }
                    case 1111:
                        {
                            BOS_TEXT += item.errString + Environment.NewLine; ;
                            order.UnderStock_forced = "Y";
                            break;
                        }
                    default:
                        {
                            BOS_TEXT += item.errString + Environment.NewLine; ;
                            order.AllForceFlag = "Y";
                            break;
                        }
                }
            }
            if (BOS_TEXT != "")
            {
                _ForceOrderObject = order;
                _evntForceOrder(BOS_TEXT);
            }
            return false;
        }
        /// <summary>
        /// 確認輸入控制項簡易風控是否完成
        /// </summary>
        /// <returns></returns>
        public bool CheckUIControlInputData(string ECode)
        {
            if (!_CSEQChecked)
            {
                MessageBox.Show("客戶帳號欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info("[Order] 客戶帳號欄位未確認完成");
                return false;
            }
            else if (!_StockNoChecked)
            {
                MessageBox.Show("股票代號欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info("[Order] 股票代號欄位未確認完成");
                return false;
            }
            else if (!_OrdQtyChecked)
            {
                MessageBox.Show("委託數量欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info("[Order] 委託數量欄位未確認完成");
                return false;
            }
            return true;
        }
        /// <summary>
        /// 後台風控 (並在CheckForcedSendOut 檢查是否強制下單)
        /// </summary>
        /// <returns></returns>
        public bool CheckResult(Order order)
        {
            if (UserInfo._UserIP == frmMain._richIP)
                return true;

            //if (!CheckBOSOrdPrice(order))
            //    return false;
            if (!CheckForcedSendOut(order))
                return false;

            return true;
        }
        /// <summary>
        /// 後台風控 (標借,標購,拍賣)
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public bool ChexFunc(Order order)
        {
            string TType = order.ECode;
            if (TType == "")
            {
                MessageBox.Show($"交易別錯誤: {order.ECode}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            HttpReqData data = new HttpReqData
            {
                stock = order.Symbol,
                seqno = order.G_stk_seq_no,
                price = order.OrdPrice,
                qty = order.OrdQty.ToString(),
                ecode = TType
            };
            List<Resault> rep = HttpReqHandler.Get_HttpBOSService("chexFunc", data);
            if (rep[0].errCode == 0)
                return true;
            else
            {
                MessageBox.Show($"[{rep[0].errCode}] {rep[0].errString}", "後台風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] [{rep[0].errCode}] {rep[0].errString}");
            }
            return false;
        }
        /// <summary>
        /// 重新設定風控指標
        /// </summary>
        public void Reset()
        {
            if (!_IsKeepCusAccount)
                _CSEQChecked = false;
            _StockNoChecked = false;
            _OrdQtyChecked = false;
        }
        /// <summary>
        /// 取得當下退回強制單委託資訊
        /// </summary>
        /// <returns></returns>
        public Order GetForceOrderObject()
        {
            return _ForceOrderObject;
        }
        /// <summary>
        /// 擁有分時分量權限的客戶
        /// </summary>
        public bool TimeSharingPermissions(string cseq)
        {
            if (UserInfo._BHNO != "0")
                return false;
            if (cseq == "1375360" ||
                cseq == "1376107" ||
                cseq == "1319494" ||
                cseq == "1363505")
                return true;
            return false;
        }
    }
}
