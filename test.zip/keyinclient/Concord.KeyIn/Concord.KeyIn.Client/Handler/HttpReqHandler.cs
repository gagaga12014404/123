﻿using Concord.KeyIn.Client.Properties;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Xml.Linq;

namespace Concord.KeyIn.Client
{
    public class HttpReqHandler
    {
        private static string _KeyInSvrUrl = "";
        private static string _BOSSvrUrl = "";

        /// <summary>
        /// 設定HTTP Server 連線主機環境
        /// </summary>
        /// <param name="model"></param>
        public static void SetKeyInSvrUrl(int envirm)
        {
            switch (envirm)
            {
                case 1:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl;
                    break;
                case 2:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl_Test;
                    break;
                case 3:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl_Remote;
                    break;
                case 4:
                    _KeyInSvrUrl = Settings.Default.COLO_tradeservice;
                    break;
            }
            ConcordLogger.Logger.Info($"[Login] 連線Gateway資訊: {_KeyInSvrUrl}");
        }
        public static void SetBOSSvrUrl(int envirm, int model)
        {
            switch (envirm)
            {
                case 1:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl : Settings.Default.HttpPropBOSSvrUrl;
                    break;
                case 2:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl_Test : Settings.Default.HttpPropBOSSvrUrl_Test;
                    break;
                case 3:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl_Remote : Settings.Default.HttpPropBOSSvrUrl_Remote;
                    break;
                case 4:
                    _BOSSvrUrl = Settings.Default.COLO_infoserver;
                    break;
            }
            ConcordLogger.Logger.Info($"[Login] 連線後台資訊: {_BOSSvrUrl}");
        }
        /// <summary>
        /// KeyIn Gateway HTTP 服務查詢
        /// </summary>
        /// <param name="token"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static HttpResponse Get_HttpKeyInService(string token, string[] parameters)
        {
            ConcordLogger.Logger.Info($"[HttpReq-KeyIn] {token} 開始");
            ConcordLogger.Logger.Debug($"[HttpReq-KeyIn] {token} 參數: {string.Join(",", parameters)}");

            string content = "", svr_rCode = "-1";
            HttpResponse result = new HttpResponse();
            try
            {
                var response = BillCenterHelper.GetBillData(_KeyInSvrUrl, "KeyIn", token, parameters);
                ConcordLogger.Logger.Debug($"[HttpReq-KeyIn] {token} 取得 result");
                var doc = XDocument.Parse(response);
                svr_rCode = doc.Descendants().FirstOrDefault(node => node.Name.ToString() == "respcode").Value;
                if (svr_rCode.Equals("000"))
                {
                    foreach (var xn in doc.Descendants("l"))
                    {
                        result.Deatils.Add(xn.Value);
                    }
                    ConcordLogger.Logger.Info($"[HttpReq-KeyIn] {token} 完成, 取得資料筆數: {result.Deatils.Count}");
                }
                else
                {
                    content = doc.Descendants().FirstOrDefault(node => node.Name.ToString() == "respmsg").Value;
                    ConcordLogger.Logger.Error($"[HttpReq-KeyIn] {token} 錯誤[{svr_rCode}]: {content}");
                    ConcordLogger.Alert(svr_rCode, $"[HttpReq-KeyIn] {token} 錯誤[{svr_rCode}]", content);
                }
            }
            catch (Exception ex)
            {
                svr_rCode = "999";
                content = ex.ToString();
                ConcordLogger.Logger.Error($"Get_HttpKeyInService Err: {ex}");
                ConcordLogger.Alert(svr_rCode, "Get_HttpKeyInService Err", content);
            }
            finally
            {
                result.StatusCode = (rCode)Enum.Parse(typeof(rCode), svr_rCode);
                result.CodeDesc = $"{result.StatusCode.ToString()} : {content}";
            }
            return result;
        }
        public static List<Resault> Get_HttpBOSService(string token, HttpReqData parameters)
        {
            ConcordLogger.Logger.Info($"[HttpReq-BOS] {token} 開始");
            HttpJSONResult jsonResult = new HttpJSONResult();
            try
            {
                string reqData = JsonConvert.SerializeObject(parameters);
                ConcordLogger.Logger.Debug($"[HttpReq-BOS] {token} 參數: {reqData}");
                HttpClient client = new HttpClient();
                HttpContent post = new StringContent(($"[{reqData}]"), Encoding.UTF8, "application/json");
                client.Timeout = TimeSpan.FromSeconds(3);
                HttpResponseMessage response = client.PostAsync($"{_BOSSvrUrl}POST/{token}", post).Result;
                var tmp = response.Content.ReadAsStringAsync().Result;
                tmp = tmp.TrimStart('[');
                tmp = tmp.TrimEnd('\n');
                tmp = tmp.TrimEnd(']');
                jsonResult = JsonConvert.DeserializeObject<HttpJSONResult>(tmp);
                if (jsonResult != null)
                    ConcordLogger.Logger.Info($"[HttpReq-BOS] {token} 完成, 資料數[{jsonResult.resault.Count}]: {tmp}");
                else
                {
                    Resault r = new Resault();
                    r.errCode = 999;
                    r.errString = "非預期錯誤，無回覆值";
                    jsonResult.resault.Add(r);
                }
            }
            catch (Exception ex)
            {
                Resault r = new Resault();
                r.errCode = 999;
                r.errString = ex.ToString();
                jsonResult.resault.Add(r);
                ConcordLogger.Logger.Error($"[HttpReq-BOS] {token} 錯誤");
                ConcordLogger.Alert("999", "Get_HttpBOSService Err", ex.ToString());
            }
            return jsonResult.resault;
        }
        public static List<CRDB> Get_CRDBQty_Service(HttpReqData parameters)
        {
            ConcordLogger.Logger.Info($"[HttpReq-BOS] getcrdbQty 開始");
            CRDBQtyResult jsonResult = new CRDBQtyResult();
            try
            {
                string reqData = JsonConvert.SerializeObject(parameters);
                ConcordLogger.Logger.Debug($"[HttpReq-BOS] getcrdbQty 參數: {reqData}");
                HttpClient client = new HttpClient();
                HttpContent post = new StringContent(($"[{reqData}]"), Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync($"{_BOSSvrUrl}POST/getcrdbQty", post).Result;
                var tmp = response.Content.ReadAsStringAsync().Result;
                tmp = tmp.TrimStart('[');
                tmp = tmp.TrimEnd('\n');
                tmp = tmp.TrimEnd(']');
                jsonResult = JsonConvert.DeserializeObject<CRDBQtyResult>(tmp);
                ConcordLogger.Logger.Info($"[HttpReq-BOS] getcrdbQty 完成, 資料數[{jsonResult.resault.Count}]: {tmp}");
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error($"[HttpReq-BOS] getcrdbQty 錯誤");
                ConcordLogger.Alert(jsonResult.resault[0].RespCode, "Get_HttpBOSService Err", ex.ToString());
            }

            return jsonResult.resault;
        }
    }
}
