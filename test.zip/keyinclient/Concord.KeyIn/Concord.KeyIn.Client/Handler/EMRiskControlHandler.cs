using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;
/*興櫃的風控做法是:
    客戶、股票、委託數量傳送電文給交易系統檢查，UI不會做太多風控，主要透過交易系統判斷*/
namespace Concord.KeyIn.Client
{
    public class EMRiskControlHandler
    {
        public static bool _IsKeepCusAccount = false;
        /// <summary>
        /// 客戶帳號風控通過註記
        /// </summary>
        public static bool _CSEQChecked = false;
        /// <summary>
        /// 股票代號風控通過註記
        /// </summary>
        public static bool _StockNoChecked = false;
        /// <summary>
        /// 委託數量風控通過註記
        /// </summary>
        public static bool _OrdQtyChecked = false;
        /// <summary>
        /// 當需強制下單時所暫存之下單物件(被風控擋住前)
        /// </summary>
        private Order _ForceOrderObject = null;
        /// <summary>
        /// 建購子
        /// </summary>
        public EMRiskControlHandler() { }
        public bool CheckCseq
        {
            get { return _CSEQChecked; }
            set { _CSEQChecked = value; }
        }
        public bool CheckStock(string stock)
        {
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(stock);
            _StockNoChecked = false;
            if (stockInfo == null)
                return false;
            if (stockInfo.MTYPE != "E")
            {
                MessageBox.Show($"{stock} {stockInfo.CNAME} 非興櫃股票不可輸入", "股票風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] {stock} {stockInfo.CNAME} 非興櫃股票不可輸入");
                return false;
            }
            return true;
        }
        public bool CheckStockPrice(string price)
        {
            var decimalPoing = price.Split('.');//123456.1234
            if (decimalPoing.Length == 2)
            {
                if (decimalPoing[1].Length > 4)
                {
                    MessageBox.Show("小數位數超過4位", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ConcordLogger.Logger.Info($"[Emst] price:{price} 小數位數超過4位");
                    return false;
                }
                if (decimalPoing[0].Length > 6)
                {
                    MessageBox.Show("整數位數超過6位", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ConcordLogger.Logger.Info($"[Emst] price:{price} 整數位數超過6位");
                    return false;
                }
            }
            else if (decimalPoing.Length == 1)
            {
                if (decimalPoing[0].Length > 6)
                {
                    MessageBox.Show("整數位數超過6位", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ConcordLogger.Logger.Info($"[Emst] price:{price} 整數位數超過6位");
                    return false;
                }
            }
            decimal d = 0;
            if (!decimal.TryParse(price, out d))
            {
                MessageBox.Show("委託價錢非數字", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] price:{price} 委託價錢非數字");
                return false;
            }
            if (d <= 0)
            {
                MessageBox.Show("委託價錢不可小於或等於0", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] price:{price} 委託價錢不可小於或等於0");
                return false;
            }
            if (d % 0.01m != 0)
            {
                MessageBox.Show("價格檔數錯誤", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] price:{price} 價格檔數錯誤");
                return false;
            }
            if (d.ToString() != price)
            {
                MessageBox.Show("委託價錢異常", "價格風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] {price} 委託價錢異常");
                return false;
            }
            return true;
        }
        public bool GetStockNoChecked
        {
            get { return _StockNoChecked; }
            set { _StockNoChecked = value; }
        }
        public bool CheckQty(string qty, int ecode)
        {
            uint i = 0;
            if (!uint.TryParse(qty, out i))
            {
                MessageBox.Show("委託數量非正整數", "數量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 委託數量非正整數 qty:{qty}");
                return false;
            }
            if (ecode == 2 && i > 999)
            {
                MessageBox.Show("零股委託數量超過999", "數量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 零股委託數量超過999 qty:{qty}");
                return false;
            }
            if (i <= 0)
            {
                MessageBox.Show("委託股數為0張", "數量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 委託數量為0 qty:{qty}");
                return false;
            }
            return true;
        }
        /// <summary>
        /// 確認是否通過所有欄位
        /// </summary>
        public bool CheckAllIsPassed()
        {
            if (!_CSEQChecked)
            {
                MessageBox.Show("客戶帳號欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 客戶帳號欄位未確認完成");
                return false;
            }
            if (!_StockNoChecked)
            {
                MessageBox.Show("股票代號欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 股票代號欄位未確認完成");
                return false;
            }
            if (!_OrdQtyChecked)
            {
                MessageBox.Show("委託數量欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] 委託數量欄位未確認完成");
                return false;
            }
            return true;
        }
        /// <summary>
        /// 新單委託確認
        /// </summary>
        public bool CheckNewOrder(Order order)
        {
            _ForceOrderObject = order;
            if (!CheckStockPrice(order.OrdPrice))
                return false;
            return true;
        }
        public bool CheckChangeQty(Order order, string reaminQty)
        {
            _ForceOrderObject = order;
            int remain = 0;
            int.TryParse(reaminQty, out remain);
            if (remain <= 0)
            {
                MessageBox.Show("此筆單已無庫存", "改量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] remain:{remain} 此筆單已無庫存");
                return false;
            }
            if (order.OrdQty <= 0)
            {
                MessageBox.Show("數量不能小於或等於0", "改量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] OrdQty:{order.OrdQty} 數量不能小於或等於0");
                return false;
            }
            else if (order.OrdQty > remain)
            {
                MessageBox.Show("改量數量大於剩餘數量", "改量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] OrdQty:{order.OrdQty} > remain:{remain} 委託數量欄位未確認完成");
                return false;
            }
            return true;
        }
        public bool CheckDelete(Order order, int LaveQty)
        {
            _ForceOrderObject = order;
            if (LaveQty <= 0)
            {
                MessageBox.Show("此筆單已無庫存", "刪單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] LaveQty:{LaveQty} 此筆單已無庫存");
                return false;
            }
            return true;
        }
        public bool CheckChangePrice(Order order, int LaveQty)
        {
            _ForceOrderObject = order;
            if (LaveQty <= 0)
            {
                MessageBox.Show("此筆單已無庫存", "改價風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Emst] LaveQty:{LaveQty} 此筆單已無庫存");
                return false;
            }
            if (!CheckStockPrice(order.OrdPrice))
                return false;
            return true;
        }
        public void ResetRiskControl()
        {
            if (!_IsKeepCusAccount)
                _CSEQChecked = false;
            _StockNoChecked = false;
            _OrdQtyChecked = false;
            _ForceOrderObject = null;
        }
        public Order GetForceOrderObject()
        {
            return _ForceOrderObject;
        }
        public bool CheckCanBeForced(string str_code, string f100)
        {
            int code = 0;
            int.TryParse(str_code, out code);
            if ((code >= 1006 && code <= 1008) ||
                (code >= 1402 && code <= 1413) ||
                 code == 1501 || code == 1302 ||
                 code == 1417 || code == 1418)
            {
                _ForceOrderObject.SeqenceFlag = f100;//強制單問答模式，用SeqenceFlag當作過關註記
                return true;
            }
            return false;
        }
        public bool systemError(string errorCode)
        {
            if (errorCode == "8000" ||
                errorCode == "8001" ||
                errorCode == "8002" ||
                errorCode == "8003" ||
                errorCode == "8004" ||
                errorCode == "8005" ||
                errorCode == "8888")
                return true;
            return false;
        }
    }
}