﻿using Concord.SDK.IOCPHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace Concord.KeyIn.Client
{
    public class TradingSystemHandler : AppClient
    {
        private MemoryStream _MessageBuffer = new MemoryStream();
        static char delimiter = '\u0001';

        public bool isConnected = false;
        public TradingSystemHandler(DnsEndPoint EndPoint) : base(EndPoint) { }

        string incomplete_str = "";

        public override void HandleReceive(byte[] data)//將接收到的訊息擷取下來並且送出委託給main
        {
            int read_size = data.Length;
            string recv_str = Encoding.UTF8.GetString(data.ToArray());

            int start_pos = 0;
            int end_pos = 0;

            do
            {
                end_pos = recv_str.IndexOf('\n', start_pos);
                if (end_pos == -1)
                {
                    incomplete_str += recv_str.Substring(start_pos);
                    start_pos = 0;
                }
                else
                {
                    incomplete_str += recv_str.Substring(start_pos, end_pos - start_pos);
                    if (incomplete_str != "")
                        OnReceiveMsg(incomplete_str);
                    incomplete_str = "";
                    start_pos = end_pos + 1;
                }
            }
            while (end_pos != -1 && start_pos < read_size);
        }

        /// <summary>
        /// 尋找位置
        /// </summary>
        /// <param name="source">比對來源</param>
        /// <param name="start">開始位置</param>
        /// <param name="pattern">比對項目</param>
        /// <returns></returns>
        public static IEnumerable<long> IndexesOf(byte[] source, int start, byte[] pattern)
        {
            long valueLength = source.LongLength;
            long patternLength = pattern.LongLength;

            if ((valueLength == 0) || (patternLength == 0) || (patternLength > valueLength))
            {
                yield break;
            }

            long[] badCharacters = new long[256];
            long lastPatternIndex = patternLength - 1;
            long index = start;

            for (var i = 0; i < 256; i++)
            {
                badCharacters[i] = patternLength;
            }
            for (long i = 0; i < lastPatternIndex; i++)
            {
                badCharacters[pattern[i]] = lastPatternIndex - i;
            }

            while (index <= valueLength - patternLength)
            {
                for (var i = lastPatternIndex; source[index + i] == pattern[i]; i--)
                {
                    if (i == 0)
                    {
                        yield return index;
                        break;
                    }
                }
                index += badCharacters[source[index + lastPatternIndex]];
            }
        }

        /// <summary>
        /// 解析字串電文成Dictionary物件
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fieldSplit"></param>
        /// <returns></returns>
        public static Dictionary<int, string> ParserMessageToDic(string message, char fieldSplit)
        {
            Dictionary<int, string> list = new Dictionary<int, string>();
            var fields = message.Split(new char[] { fieldSplit }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(s => s.Split(new[] { '=' }, 2))
                                .Where(s => s.Length == 2);

            foreach (var field in fields)
            {
                int tag;
                if (!int.TryParse(field[0], out tag))
                    continue;
                list.Add(tag, field[1]);
            }
            return list;
        }

        public string CheckAccount(string account_no, string broker_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=200");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.PadLeft(7, '0')); //客戶固定7碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckStock(string stock_no, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=201");
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckOrderQty(string account_no, string broker_id, string stock_no, string qty, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=202");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.PadLeft(7, '0')); //客戶固定7碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("38=" + qty);
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckOrderPrice(string account_no, string broker_id, string stock_no, string qty, string price, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=203");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.Substring(0, account_no.Length - 1)); //風控不使用帳號檢查碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("38=" + qty);
            sb.Append(delimiter);
            sb.Append("44=" + price);
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Login()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=88");
            sb.Append(delimiter);
            sb.Append("1=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("20000=" + UserInfo._UserIP);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Recover(string broker_id, string dseq)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=206");
            sb.Append(delimiter);
            sb.Append("50002=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("117=" + dseq);
            sb.Append(delimiter);
            sb.Append("118=Y");
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Order(Order order)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=1");
            sb.Append(delimiter);
            sb.Append("1=" + order.CSEQ);
            sb.Append(delimiter);
            sb.Append("76=" + order.BHNO);
            sb.Append(delimiter);
            sb.Append("117=" + order.DSEQ);
            sb.Append(delimiter);
            sb.Append("55=" + order.Symbol.PadRight(6));
            sb.Append(delimiter);
            sb.Append("38=");
            sb.Append(order.OrdQty);
            sb.Append(delimiter);
            sb.Append("44=" + order.OrdPrice);
            sb.Append(delimiter);
            string side = order.Side == Side.BUY ? "1" : "2";
            sb.Append("54=" + side);
            sb.Append(delimiter);
            sb.Append("80024=" + DateTime.Now.ToString("yyyyMMddHHmmssfff"));
            sb.Append(delimiter);
            sb.Append("81001=" + order.ECode);
            sb.Append(delimiter);
            sb.Append("81008=" + order.ExecType);
            sb.Append(delimiter);
            sb.Append("20000=" + UserInfo._UserIP);
            sb.Append(delimiter);
            sb.Append("20001=" + order.Sale);
            sb.Append(delimiter);
            sb.Append("50001= "); //興櫃來源別 KEY IN為空白
            sb.Append(delimiter);
            sb.Append("50002=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("60005=" + order.AllForceFlag);
            sb.Append(delimiter);
            sb.Append("20002=" + order.Guid);
            sb.Append(delimiter);
            if (order.SeqenceFlag != "N")//強制單通關用
            {
                sb.Append("100=" + order.SeqenceFlag);
                sb.Append(delimiter);
            }
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckDseq(string broker_id, string dseq)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=206");
            sb.Append(delimiter);
            sb.Append("50002=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("117=" + dseq);
            sb.Append(delimiter);
            sb.Append("118=N");
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public static string ComposeHeartBeatMessage()
        {

            return "35=880714" + delimiter + '\u000a';
        }
    }
}
