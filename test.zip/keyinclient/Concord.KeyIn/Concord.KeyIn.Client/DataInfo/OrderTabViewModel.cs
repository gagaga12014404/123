﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Concord.KeyIn.Client
{
    public class OrderTabViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
          => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        #region 私有值
        private string _TDATE = "";
        private string _BHNO = "";
        private string _TERM = "";
        private string _DSEQ = "";
        private string _CSEQ = "";
        private string _CSEQ_Name = "";
        private string _CCODE_Text = "";
        private string _OType = "0";
        private string _OType_Text = "現";
        private string _OrdType = "2";
        private string _TimeInForce = "0";
        private string _TimeInForce_Text = "ROD";
        private string _Symbol = "";
        private string _SymbolName = "";
        private string _SymbolState = "";
        private string _FinanceState = "";
        private string _SymbolMType = "";
        private string _ECode = "";
        private string _OrderQty = "";
        private string _CancelledQty = "";
        private string _Sale = "";
        private string _OrderPrice = "";
        private bool _ErrAccount_Enable = false;
        private bool _FixedCSEQ_Enable = false;
        private bool _BatchOrder_Enable = false;
        private string _QueryLaveQty = "";
        private string _QueryDealQty = "";
        private string _StockWarnInfo = "";
        private string _OrdInfoText = "";

        private bool _QueryModel = false;
        private bool _ChageQtyModel = false;
        private bool _ChagePriceModel = false;
        private bool _CancelModel = false;
        private bool _ForceBtnVisable = false;
        private string _Unit = "張";
        private string _BasicPrice = "";
        private string _SearchResult = "";
        #endregion

        /// <summary>
        /// 交易日期
        /// </summary>
        public string TDATE
        {
            get
            {
                return _TDATE;
            }
            set
            {
                if (_TDATE != value)
                {
                    _TDATE = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 分公司代號
        /// </summary>
        public string BHNO
        {
            get
            {
                return _BHNO;
            }
            set
            {
                if (_BHNO != value)
                {
                    _BHNO = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 櫃號
        /// </summary>
        public string TERM
        {
            get
            {
                return _TERM;
            }
            set
            {
                if (_TERM != value)
                {
                    _TERM = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託序號
        /// </summary>
        public string DSEQ
        {
            get
            {
                return _DSEQ;
            }
            set
            {
                if (_DSEQ != value)
                {
                    _DSEQ = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 客戶帳號
        /// </summary>
        public string CSEQ
        {
            get
            {
                return _CSEQ;
            }
            set
            {
                if (_CSEQ != value)
                {
                    _CSEQ = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 客戶姓名
        /// </summary>
        public string CSEQ_Name
        {
            get
            {
                return _CSEQ_Name;
            }
            set
            {
                if (_CSEQ_Name != value)
                {
                    _CSEQ_Name = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 銷戶原因
        /// </summary>
        public string CCODE_Text
        {
            get
            {
                return _CCODE_Text;
            }
            set
            {
                if (_CCODE_Text != value)
                {
                    _CCODE_Text = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託類別
        /// </summary>
        public string OType
        {
            get
            {
                return _OType;
            }
            set
            {
                if (_OType != value)
                {
                    _OType = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託類別敘述文字
        /// </summary>
        public string OType_Text
        {
            get
            {
                return _OType_Text;
            }
            set
            {
                if (_OType_Text != value)
                {
                    _OType_Text = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託方式
        /// 1 : 市價
        /// 2 : 限價
        /// </summary>
        public string OrdType
        {
            get
            {
                return _OrdType;
            }
            set
            {
                if (_OrdType != value)
                {
                    _OrdType = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託條件
        /// 0:ROD
        /// 3:IOC
        /// 4:FOK
        /// </summary>
        public string TimeInForce
        {
            get
            {
                return _TimeInForce;
            }
            set
            {
                if (_TimeInForce != value)
                {
                    _TimeInForce = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託條件文字敘述
        /// </summary>
        public string TimeInForce_Text
        {
            get
            {
                return _TimeInForce_Text;
            }
            set
            {
                if (_TimeInForce_Text != value)
                {
                    _TimeInForce_Text = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票名稱
        /// </summary>
        public string Symbol_Name
        {
            get
            {
                return _SymbolName;
            }
            set
            {
                if (_SymbolName != value)
                {
                    _SymbolName = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票信用交易狀態
        /// </summary>
        public string Symbol_State
        {
            get
            {
                return _SymbolState;
            }
            set
            {
                if (_SymbolState != value)
                {
                    _SymbolState = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票資券配額狀態
        /// </summary>
        public string FinanceState
        {
            get
            {
                return _FinanceState;
            }
            set
            {
                if (_FinanceState != value)
                {
                    _FinanceState = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票代號
        /// </summary>
        public string Symbol
        {
            get
            {
                return _Symbol;
            }
            set
            {
                if (_Symbol != value)
                {
                    _Symbol = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票市場
        /// </summary>
        public string Symbol_MType
        {
            get
            {
                return _SymbolMType;
            }
            set
            {
                if (_SymbolMType != value)
                {
                    _SymbolMType = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 交易別
        /// </summary>
        public string ECode
        {
            get
            {
                return _ECode;
            }
            set
            {
                if (_ECode != value)
                {
                    _ECode = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託數量
        /// </summary>
        public string OrderQty
        {
            get
            {
                return _OrderQty;
            }
            set
            {
                if (_OrderQty != value)
                {
                    _OrderQty = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託價格
        /// </summary>
        public string OrderPrice
        {
            get
            {
                return _OrderPrice;
            }
            set
            {
                if (_OrderPrice != value)
                {
                    _OrderPrice = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 取消數量
        /// </summary>
        public string CancelledQty
        {
            get
            {
                return _CancelledQty;
            }
            set
            {
                if (_CancelledQty != value)
                {
                    _CancelledQty = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 營業員
        /// </summary>
        public string Sale
        {
            get
            {
                return _Sale;
            }
            set
            {
                if (_Sale != value)
                {
                    _Sale = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 錯帳專戶開關
        /// </summary>
        public bool ErrAccount_Enable
        {
            get
            {
                return _ErrAccount_Enable;
            }
            set
            {
                if (_ErrAccount_Enable != value)
                {
                    _ErrAccount_Enable = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 固定委託人帳號開關
        /// </summary>
        public bool FixedCSEQ_Enable
        {
            get
            {
                return _FixedCSEQ_Enable;
            }
            set
            {
                if (_FixedCSEQ_Enable != value)
                {
                    _FixedCSEQ_Enable = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 拆單開關
        /// </summary>
        public bool BatchOrder_Enable
        {
            get
            {
                return _BatchOrder_Enable;
            }
            set
            {
                if (_BatchOrder_Enable != value)
                {
                    _BatchOrder_Enable = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 未搓合張數
        /// </summary>
        public string QueryLaveQty
        {
            get
            {
                return _QueryLaveQty;
            }
            set
            {
                if (_QueryLaveQty != value)
                {
                    _QueryLaveQty = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 成交已回報
        /// </summary>
        public string QueryDealQty
        {
            get
            {
                return _QueryDealQty;
            }
            set
            {
                if (_QueryDealQty != value)
                {
                    _QueryDealQty = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 股票警示訊息
        /// </summary>
        public string StockWarnInfo
        {
            get
            {
                return _StockWarnInfo;
            }
            set
            {
                if (_StockWarnInfo != value)
                {
                    _StockWarnInfo = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 委託錯誤揭示訊息
        /// </summary>
        public string OrdInfoText
        {
            get
            {
                return _OrdInfoText;
            }
            set
            {
                if (_OrdInfoText != value)
                {
                    _OrdInfoText = value;
                    NotifyPropertyChanged();
                }
            }
        }
        /// <summary>
        /// 查詢模式與否
        /// </summary>
        public bool QueryModel
        {
            get
            {
                return _QueryModel;
            }
            set
            {
                _QueryModel = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 改變改量模式
        /// </summary>
        public bool ChageQtyModel
        {
            get
            {
                return _ChageQtyModel;
            }
            set
            {
                _ChageQtyModel = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 改變改價模式
        /// </summary>
        public bool ChagePriceModel
        {
            get
            {
                return _ChagePriceModel;
            }
            set
            {
                _ChagePriceModel = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 改變刪單模式
        /// </summary>
        public bool CancelModel
        {
            get
            {
                return _CancelModel;
            }
            set
            {
                _CancelModel = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 強制下單按鈕顯示與否
        /// </summary>
        public bool ForceBtnVisable
        {
            get
            {
                return _ForceBtnVisable;
            }
            set
            {
                _ForceBtnVisable = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 單位顯示(張或股或兩)
        /// </summary>
        public string Unit
        {
            get
            {
                return _Unit;
            }
            set
            {
                _Unit = value;
                NotifyPropertyChanged();
            }
        }
        /// <summary>
        /// 基準價
        /// </summary>
        public string BasicPrice
        {
            get
            {
                return _BasicPrice;
            }
            set
            {
                _BasicPrice = value;
                NotifyPropertyChanged();
            }
        }
        public string SearchResult
        {
            get
            {
                return _SearchResult;
            }
            set
            {
                _SearchResult = value;
                NotifyPropertyChanged();
            }
        }
    }
}
