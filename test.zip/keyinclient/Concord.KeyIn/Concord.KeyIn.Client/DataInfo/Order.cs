﻿namespace Concord.KeyIn.Client
{
    /// <summary>
    /// 委託物件
    /// </summary>
    public class Order
    {
        /// <summary>
        /// 委託種類
        /// </summary>
        public string ExecType = "";
        /// <summary>
        /// 委託Guid
        /// </summary>
        public string Guid = "";
        /// <summary>
        /// 網路單號
        /// </summary>
        public string ClOriNo = "";
        /// <summary>
        /// 原網路單號
        /// </summary>
        public string OrigClOrdID = "";
        /// <summary>
        /// 委託書號
        /// </summary>
        public string DSEQ = "";
        /// <summary>
        /// 商品代號
        /// </summary>
        public string Symbol = "";
        /// <summary>
        /// 客戶分公司代號
        /// </summary>
        public string BHNO = "";
        /// <summary>
        /// 客戶帳號
        /// </summary>
        public string CSEQ = "";
        /// <summary>
        /// 市場別
        /// </summary>
        public string MType = "";
        /// <summary>
        /// 委託類別
        /// </summary>
        public string OType = "";
        /// <summary>
        /// 交易類別
        /// </summary>
        public string ECode = "";
        /// <summary>
        /// 委託數量
        /// </summary>
        public int OrdQty = 0;
        /// <summary>
        /// 委託價格
        /// </summary>
        public string OrdPrice = "";
        /// <summary>
        /// 買賣別
        /// </summary>
        public Side Side = Side.None;
        /// <summary>
        /// 委託方式
        /// 1: 市價
        /// 2: 限價
        /// </summary>
        public string OrdType = "2";
        /// <summary>
        /// 委託條件
        /// 0: ROD
        /// 3: IOC
        /// 4: FOK
        /// </summary>
        public string TimeInForce = "0";
        /// <summary>
        /// 營業員
        /// </summary>
        public string Sale = "";
        /// <summary>
        /// KeyIn 員編
        /// </summary>
        public string KeyIn = "";
        /// <summary>
        /// 現賣沖註記
        /// </summary>
        public string DayTradeFlag = "N";
        /// <summary>
        /// 限價上下檔數設定
        /// </summary>
        public string PriceRange_setting = "";
        /// <summary>
        /// 庫存不足強制單註記
        /// </summary>
        public string UnderStock_forced = "N";
        /// <summary>
        /// 價格錯誤強制單註記
        /// </summary>
        public string PriceErr_forced = "N";
        /// <summary>
        /// 資券配額不足強制單註記
        /// </summary>
        public string InsufficientQuota_forced = "N";
        /// <summary>
        /// 標購序號
        /// </summary>
        public string G_stk_seq_no = "";
        /// <summary>
        /// 萬能強制下單註記
        /// </summary>
        public string AllForceFlag = "N";
        /// <summary>
        /// 拆單註記
        /// </summary>
        public string SeqenceFlag = "N";
    }

    public enum Side
    {
        None = 0,
        BUY = 1,
        SELL = 2,
    }
}
