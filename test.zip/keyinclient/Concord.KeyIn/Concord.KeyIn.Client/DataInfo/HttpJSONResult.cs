﻿using System.Collections.Generic;

namespace Concord.KeyIn.Client
{
    /// <summary>
    /// 資券餘額查詢結果
    /// </summary>
    public class CRDBQtyResult
    {
        public CRDBQtyResult()
        {
            resault = new List<CRDB>();
        }
        public List<CRDB> resault { get; set; }
    }
    /// <summary>
    /// 資券餘額結果內容
    /// </summary>
    public class CRDB
    {
        /// <summary>
        /// 回覆碼
        /// </summary>
        public string RespCode { get; set; }
        /// <summary>
        /// 股票代號
        /// </summary>
        public string Stock { get; set; }
        /// <summary>
        /// 通用flag
        /// </summary>
        public string mark { get; set; }
        /// <summary>
        /// 融資flag
        /// </summary>
        public string crmark { get; set; }
        /// <summary>
        /// 融資成數
        /// </summary>
        public string crmark1 { get; set; }
        /// <summary>
        /// 剩餘可資張數
        /// </summary>
        public string Crqty { get; set; }
        /// <summary>
        /// 融券flag
        /// </summary>
        public string dbmark { get; set; }
        /// <summary>
        /// 融券成數
        /// </summary>
        public string dbmark1 { get; set; }
        /// <summary>
        /// 剩餘可券張數
        /// </summary>
        public string Dbqty { get; set; }
    }

    /// <summary>
    /// 後台風控查詢結果
    /// </summary>
    public class HttpJSONResult
    {
        public HttpJSONResult()
        {
            resault = new List<Resault>();
        }
        public List<Resault> resault { get; set; }
    }
    /// <summary>
    /// 查詢結果內容
    /// </summary>
    public class Resault
    {
        public int errCode { get; set; }
        public string errString { get; set; }
    }

    public class NOKORIResult
    {
        public string RespCode { get; set; }

        public string RespMsg { get; set; }

        List<NOKORI> RespData { get; set; }
    }

    public class NOKORI
    {
        public string Nokori { get; set; }
        public string Cr_Nokori { get; set; }
        public string Db_Nokori { get; set; }
    }
}
