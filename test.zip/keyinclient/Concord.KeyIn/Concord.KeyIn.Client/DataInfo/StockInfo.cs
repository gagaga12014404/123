﻿namespace Concord.KeyIn.Client
{
    public class StockInfo
    {
        /// <summary>
        /// 股票代號
        /// </summary>
        public string STOCK { get; set; }
        /// <summary>
        /// 股票名稱
        /// </summary>
        public string CNAME { get; set; }
        /// <summary>
        /// 市場別
        /// </summary>
        public string MTYPE { get; set; }
        /// <summary>
        /// 股票類別
        /// 0:停止交易 1:第一類 2:第二類 3:全額 4:基金 5:可轉換公司債 6:認股權證 Z:OTC類
        /// </summary>
        public string STYPE { get; set; }
        /// <summary>
        /// 平盤價
        /// </summary>
        public decimal CPRICE { get; set; }
        /// <summary>
        /// 漲停價
        /// </summary>
        public decimal TPRICE { get; set; }
        /// <summary>
        /// 跌停價
        /// </summary>
        public decimal BPRICE { get; set; }
        /// <summary>
        /// 單位股數
        /// </summary>
        public string UNIT { get; set; }
        /// <summary>
        /// 現股當沖註記
        /// 空白: 不可現沖 Y:僅先買後賣 X:可雙向
        /// </summary>
        public string DTCODE { get; set; }
        /// <summary>
        /// 融資註記
        /// O:可融資 空白:不可融資
        /// </summary>
        public string CRMARK { get; set; }
        /// <summary>
        /// 融券註記
        /// X:可融券 空白:不可融券
        /// </summary>
        public string DBMARK { get; set; }
        /// <summary>
        /// 豁免平盤下融券賣出註記
        /// </summary>
        public string TMMARK { get; set; }
        /// <summary>
        /// 信用交易狀態
        /// </summary>
        public string CreditTradeState { get; set; }
        /// <summary>
        /// 資券配額狀態
        /// </summary>
        public string FTState { get; set; }
        /// <summary>
        /// 股票交易狀態
        /// </summary>
        public string StockTradeState { get; set; }
        /// <summary>
        /// 98戶配額成數
        /// </summary>
        public string FT98State { get; set; }

    }
}
