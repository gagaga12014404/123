﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concord.KeyIn.Client
{
    public class SaleInfo
    {
        /// <summary>
        /// 營業員代號
        /// </summary>
        public string SALE { get; set; }
        /// <summary>
        /// 營業員姓名
        /// </summary>
        public string NAME { get; set; }
        /// <summary>
        /// 是否有牌
        /// </summary>
        public string LCN { get; set; }
    }
}
