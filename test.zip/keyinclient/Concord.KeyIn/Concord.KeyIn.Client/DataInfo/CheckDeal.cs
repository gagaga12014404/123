﻿namespace Concord.KeyIn.Client
{
    public class CheckDeal
    {
        /// <summary>
        /// 序號
        /// </summary>
        public int No { get; set; }
        /// <summary>
        /// 分公司
        /// </summary>
        public string BHNO { get; set; }
        /// <summary>
        /// 客戶帳號
        /// </summary>
        public string CSEQ { get; set; }
        /// <summary>
        /// 委託序號
        /// </summary>
        public string DSEQ { get; set; }
        /// <summary>
        /// 盤別
        /// </summary>
        public string ECode { get; set; }
        /// <summary>
        /// 委託條件
        /// </summary>
        public string TimeInForce { get; set; }
        /// <summary>
        /// 委託價
        /// </summary>
        public string PRICE { get; set; }
        /// <summary>
        /// 委託數量
        /// </summary>
        public string OQTY { get; set; }
        /// <summary>
        /// 委託別
        /// </summary>
        public string OTYPE { get; set; }
        /// <summary>
        /// 股票代號
        /// </summary>
        public string STOCK { get; set; }
        /// <summary>
        /// 股票名稱
        /// </summary>
        public string STOCKNAME { get; set; }
        /// <summary>
        /// 買賣別
        /// </summary>
        public string BS { get; set; }
        /// <summary>
        /// 是否勾單
        /// </summary>
        public string CheckStatus { get; set; }
        /// <summary>
        /// 成交價
        /// </summary>
        public string DPRICE { get; set; }
        /// <summary>
        /// 成交數量
        /// </summary>
        public string DQTY { get; set; }
        /// <summary>
        /// 累計成交量
        /// </summary>
        public string AllDQTY { get; set; }
    }
}
