﻿namespace Concord.KeyIn.Client
{
    /// <summary>
    /// BOS主機HTTP Request物件
    /// </summary>
    public class HttpReqData
    {
        /// <summary>
        /// 客戶帳號(不含檢查碼)
        /// </summary>
        public string cseq { get; set; }
        /// <summary>
        /// 客戶帳號檢查碼
        /// </summary>
        public string ckno { get; set; }
        /// <summary>
        /// 委託數量
        /// </summary>
        public string qty { get; set; }
        /// <summary>
        /// 委託單價格種類
        /// 1: 市價
        /// 2: 限價
        /// </summary>
        public string OrdType { get; set; }
        /// <summary>
        /// 委託價格
        /// </summary>
        public string price { get; set; }
        /// <summary>
        /// 分公司代號
        /// </summary>
        public string bhno { get; set; }
        /// <summary>
        /// 買賣別
        /// </summary>
        public string side { get; set; }
        /// <summary>
        /// 股票代號
        /// </summary>
        public string stock { get; set; }
        /// <summary>
        /// 委託有效期間
        /// </summary>
        public string TimeInforce { get; set; }
        /// <summary>
        /// 委託時間
        /// </summary>
        public string TransactTime { get; set; }
        /// <summary>
        /// 委託管道
        /// </summary>
        public string TwseIvacnoFlag { get; set; }
        /// <summary>
        /// 委託別
        /// 0:普通 3:融資 4:融券 9:當沖
        /// </summary>
        public string otype { get; set; }
        /// <summary>
        /// 交易別
        /// C:普通 D:零股 F:定盤
        /// </summary>
        public string ecode { get; set; }
        /// <summary>
        /// 營業員代號
        /// </summary>
        public string Sale { get; set; }
        /// <summary>
        /// 來源別
        /// </summary>
        public string Ocode { get; set; }
        /// <summary>
        /// 現賣沖註記
        /// </summary>
        public string Dtrade { get; set; }
        /// <summary>
        /// 零股定期定額註記
        /// </summary>
        public string Siplan { get; set; }
        /// <summary>
        /// 庫存不足強制下單
        /// </summary>
        public string BalForceFlag { get; set; }
        /// <summary>
        /// 價格強制下單
        /// </summary>
        public string PriceForceFlag { get; set; }
        /// <summary>
        /// 資券配額強制下單
        /// </summary>
        public string CrdbqtyForceFlag { get; set; }
        /// <summary>
        /// 萬能強制下單
        /// </summary>
        public string AllForceFlag { get; set; }
        /// <summary>
        /// 拆單註記
        /// </summary>
        public string SeqenceFlag { get; set; }
        /// <summary>
        /// 標購序號
        /// </summary>
        public string seqno { get; set; }

    }
}
