﻿using System;
using System.Collections.Generic;

namespace Concord.KeyIn.Client
{
    public class UserInfo
    {
        /// <summary>
        /// 員工員編
        /// </summary>
        public static string _EMNO;
        /// <summary>
        /// 使用者端IPv4位址
        /// </summary>
        public static string _UserIP;
        /// <summary>
        /// 分公司代號 (1碼)
        /// </summary>
        public static string _BHNO;
        /// <summary>
        /// 營業員編號
        /// </summary>
        public static string _SALE;
        /// <summary>
        /// 使用者權限
        /// </summary>
        public static UserAuthority _UserAuthority;
        /// <summary>
        /// KeyIn人員櫃號
        /// </summary>
        public static string _TRAM;
        /// <summary>
        /// KeyIn人員櫃號(興櫃)
        /// </summary>
        public static string _EMTERM;
        /// <summary>
        /// 是否有備援權限
        /// </summary>
        public static bool _IsBack = false;
        /// <summary>
        /// 是否有拆單權限
        /// </summary>
        public static bool _IsSplitLot = false;
        /// <summary>
        /// 是否有批次下單權限
        /// </summary>
        public static bool _IsBatchOddLot = false;

        /// <summary>
        /// 解析使用者資訊
        /// </summary>
        /// <param name="deatails"></param>
        public static void Parser(List<string> deatails)
        {
            string[] info = deatails[0].Split('|');
            _BHNO = info[0].Remove(0, 3);
            _UserAuthority = (UserAuthority)Enum.Parse(typeof(UserAuthority), info[2]);
            _TRAM = info[3];
            _IsBack = info[4] == "Y" ? true : false;
            _IsSplitLot = info[5] == "Y" ? true : false;
            _IsBatchOddLot = info[6] == "Y" ? true : false;
        }
    }

    /// <summary>
    /// 使用者權限
    /// </summary>
    public enum UserAuthority
    {
        /// <summary>
        /// KeyIn 人員
        /// </summary>
        KeyIn = 0,
        /// <summary>
        /// KeyIn IB 人員
        /// </summary>
        KeyInIB = 1,
        /// <summary>
        /// 開發人員
        /// </summary>
        Dev = 2,
        /// <summary>
        /// 維運人員
        /// </summary>
        OP = 3
    }
}
