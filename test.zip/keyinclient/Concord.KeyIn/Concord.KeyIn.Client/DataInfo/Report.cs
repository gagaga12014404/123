﻿namespace Concord.KeyIn.Client
{
    public class Report
    {
        /// <summary>
        /// 訊息序號
        /// </summary>
        public string Seq { get; set; }
        /// <summary>
        /// 刪單確認扭
        /// </summary>
        public bool CheckDelete { get; set; }
        /// <summary>
        /// 委託書號 (37)
        /// </summary>
        public string DSEQ { get; set; }
        /// <summary>
        /// 網路單號 (11)
        /// </summary>
        public string ClOrdID { get; set; }
        /// <summary>
        /// 原網路單號 (41)
        /// </summary>
        public string OrigClOrdID { get; set; }
        /// <summary>
        /// 委託執行狀態 (150)
        /// </summary>
        public string ExecType { get; set; }
        /// <summary>
        /// 委託訊息種類
        /// </summary>
        public string MsgType { get; set; }
        /// <summary>
        /// 分公司碼 (50)
        /// </summary>
        public string BHNO { get; set; }
        /// <summary>
        /// 客戶帳號 (1)
        /// </summary>
        public string CSEQ { get; set; }
        /// <summary>
        /// 客戶名稱
        /// </summary>
        public string CusName { get; set; }
        /// <summary>
        /// 市場別 (56)
        /// </summary>
        public string MType { get; set; }
        /// <summary>
        /// 交易別 (57)
        /// 0:整股 1:鉅額 2:零股 3:定價
        /// </summary>
        public string ECode { get; set; }
        /// <summary>
        /// 委託別 (10001)
        /// 0:普通 3:自資 4:自券
        /// </summary>
        public string OType { get; set; }
        /// <summary>
        /// 股票代號 (55)
        /// </summary>
        public string Stock { get; set;}
        /// <summary>
        /// 股票名稱
        /// </summary>
        public string StockName { get; set; }
        /// <summary>
        /// 買賣別 (54)
        /// B:買 S:賣
        /// </summary>
        public string Side { get; set; }
        /// <summary>
        /// 委託方式 (40)
        /// 1:市價 2:限價
        /// </summary>
        public string OrdType { get; set; }
        /// <summary>
        /// 委託條件 (59)
        /// 0:ROD 3:IOC 4:FOK
        /// </summary>
        public string TimeInForce { get; set; }
        /// <summary>
        /// 委託數量 (38)
        /// </summary>
        public int OrdQty { get; set; }
        /// <summary>
        /// 實際有效委託 (20053)
        /// </summary>
        public int EffectiveOrdQty { get; set; }
        /// <summary>
        /// 取消數量
        /// </summary>
        public int CancelQty { get; set; }
        /// <summary>
        /// 改量後張數
        /// </summary>
        public int ChangedQty { get; set; }
        /// <summary>
        /// 委託價格 (44)
        /// </summary>
        public string OrdPrice { get; set; }
        /// <summary>
        /// 成交數量 (32)
        /// </summary>
        public int DealQty { get; set; }
        /// <summary>
        /// 成交價格 (31)
        /// </summary>
        public decimal DealPrice { get; set; }
        /// <summary>
        /// 改量前數量
        /// </summary>
        public int BeforeChangeQty { get; set; }
        /// <summary>
        /// 改量後數量
        /// </summary>
        public int AfterChangeQty { get; set; }
        /// <summary>
        /// 剩餘數量
        /// </summary>
        public int LaveQty { get; set; }
        /// <summary>
        /// 總成交數量
        /// </summary>
        public int TotalDealQty { get; set; }
        /// <summary>
        /// 委託狀態
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 委託錯誤代碼 (103)
        /// </summary>
        public string ErrCode { get; set; }
        /// <summary>
        /// 委託錯誤訊息 (58)
        /// </summary>
        public string Text { get; set; }
        /// <summary>
        /// 委託回報時間 (60)
        /// </summary>
        public string TransactTime { get; set; }
        /// <summary>
        /// 委託來源 (10000)
        /// </summary>
        public string Origin { get; set; }
        /// <summary>
        /// 營業員代號 (20001)
        /// </summary>
        public string Sale { get; set; }
        /// <summary>
        /// 現賣沖註記 (20003)
        /// </summary>
        public string DayTradeFlag { get; set;}
    }
}
