﻿namespace Concord.KeyIn.Client
{
    public class Customer
    {
        /// <summary>
        /// 分公司代號
        /// </summary>
        public string BHNO { get; set; }
        /// <summary>
        /// 客戶帳號(含檢查碼)
        /// </summary>
        public string CSEQ { get; set; }
        /// <summary>
        /// 身分證字號
        /// </summary>
        public string IDNO { get; set; }
        /// <summary>
        /// IB戶
        /// </summary>
        public string IB { get; set; }
        /// <summary>
        /// 客戶姓名
        /// </summary>
        public string SNAME { get; set; }
        /// <summary>
        /// 營業員代號
        /// </summary>
        public string TSALE { get; set; }
        /// <summary>
        /// 開銷戶別
        /// </summary>
        public string OType { get; set; }
        /// <summary>
        /// 信用開戶狀態
        /// </summary>
        public bool CreditAccountState{get;set;}
        /// <summary>
        /// 現沖開戶狀態
        /// </summary>
        public bool DTAccountState { get; set; }
    }
    /// <summary>
    /// 開銷戶類別
    /// </summary>
    public enum OTYPE
    {
        /// <summary>
        /// 有效
        /// </summary>
        Usable = 0,
        /// <summary>
        /// 解約
        /// </summary>
        termination = 1,
        /// <summary>
        /// 死亡
        /// </summary>
        died = 2,
        /// <summary>
        /// 靜止
        /// </summary>
        halt = 3,
        /// <summary>
        /// 凍結
        /// </summary>
        Blocked = 4,
        /// <summary>
        /// 違約
        /// </summary>
        BreachContract = 5
    }
}
