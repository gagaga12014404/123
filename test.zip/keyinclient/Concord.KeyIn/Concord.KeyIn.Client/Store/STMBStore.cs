﻿using Concord.SDK.Logging;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class STMBStore
    {
        private static ConcurrentDictionary<string, StockInfo> _STMB = new ConcurrentDictionary<string, StockInfo>();
        private static ConcurrentDictionary<string, string> _RelatedCompanyStock = new ConcurrentDictionary<string, string>();

        /// <summary>
        /// 解析股票基本資料檔並儲存
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public static void ParserSTMB(List<string> datas)
        {
            foreach (string symbolInfo in datas)
            {
                StockInfo symbol = new StockInfo();
                decimal CPrice = 0, TPrice = 0, BPrice = 0;
                string[] info = symbolInfo.Split('|');
                symbol.STOCK = info[0];
                symbol.CNAME = info[1];
                symbol.MTYPE = info[2];
                symbol.STYPE = info[3];
                decimal.TryParse(info[4], out CPrice);
                symbol.CPRICE = CPrice;
                decimal.TryParse(info[5], out TPrice);
                symbol.TPRICE = TPrice;
                decimal.TryParse(info[6], out BPrice);
                symbol.BPRICE = BPrice;
                symbol.UNIT = info[7];
                symbol.DTCODE = info[8];
                symbol.CRMARK = info[9];
                symbol.DBMARK = info[10];
                symbol.TMMARK = info[11];
                symbol.CreditTradeState = info[12];
                symbol.FTState = info[13];
                symbol.StockTradeState = info[14];
                symbol.FT98State = info[15];

                if (!_STMB.TryAdd(symbol.STOCK, symbol))
                {
                    ConcordLogger.Logger.Error($"新增股票基本資料檔錯誤 STOCK: {symbol.STOCK} {symbol.CNAME}");
                    continue;
                }
                AddRelatedCompanyStock(symbol.STOCK);
            }
        }
        /// <summary>
        /// 加入關係企業股票
        /// </summary>
        /// <param name="stock"></param>
        public static void AddRelatedCompanyStock(string stock)
        {
            switch (stock)
            {
                case "1101":
                case "1409":
                case "1419":
                case "2884":
                case "3483":
                case "4933":
                case "4938":
                case "5703":
                case "9908":
                case "9925":
                case "2850":
                    _RelatedCompanyStock.TryAdd(stock, stock);
                    break;
            }
        }
        /// <summary>
        /// 確認是否為關係企業股票
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public static bool CheckRelatedCompanyStock(string stock, Side side, string ordType)
        {
            if (stock == null)
                return false;

            return ((side == Side.BUY && (ordType == "0" || ordType == "3"))
                || (side == Side.SELL && ordType == "4"))
                && _RelatedCompanyStock.ContainsKey(stock);
        }
        /// <summary>
        /// 取得股票商品資訊
        /// </summary>
        /// <param name="key">股票代號</param>
        /// <returns>股票商品資訊</returns>
        public static StockInfo Get_SymbolInfo(string stock)
        {
            if (string.IsNullOrWhiteSpace(stock))
                return null;

            StockInfo info = new StockInfo();
            if (!_STMB.ContainsKey(stock) || !_STMB.TryGetValue(stock, out info))
                return null;
                
            return info;
        }
        /// <summary>
        /// 取得商品價格
        /// </summary>
        /// <param name="symbol"></param>
        /// <returns></returns>
        public static string Get_Price(string symbol, Side side)
        {
            if (string.IsNullOrWhiteSpace(symbol))
            {
                MessageBox.Show("錯誤之股票代號，請重新輸入");
                return "";
            }
            StockInfo info;
            _STMB.TryGetValue(symbol, out info);
            if (info == null)
            {
                MessageBox.Show("取價錯誤，請手動輸入價格");
                return "";
            }

            return side == Side.BUY ? info.TPRICE.ToString("0.####") : info.BPRICE.ToString("0.####");
        }
        /// <summary>
        /// 確認是否有該股票資訊
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public static bool CheckContains(string stock)
        {
            if (stock == null)
                return false;

            return _STMB.ContainsKey(stock);
        }
    }
}
