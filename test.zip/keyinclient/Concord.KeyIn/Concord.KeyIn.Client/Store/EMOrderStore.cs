﻿using Concord.SDK.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class EMOrderStore
    {
        /// <summary>
        /// KeyIn本身委託明細，primary key:委託書號+訊息序號當
        /// </summary>
        public DataTable _KeyInDetailStore;
        /// <summary>
        /// 委託回報紀錄資料表 (彙總)
        /// </summary>
        public static DataTable _OrdReportStore;
        /// <summary>
        /// 成交回報紀錄資料表 (彙總)
        /// </summary>
        public DataTable _OrdDealDetailStore;
        /// <summary>
        /// KeyIn明細回報儲存序列
        /// </summary>
        public ConcurrentQueue<Report> _KeyInOrderQueue;
        /// <summary>
        /// 委託回報儲存序列
        /// </summary>
        public ConcurrentQueue<Report> _ReportQueue;
        /// <summary>
        /// 新增KeyIn明細資訊事件
        /// </summary>
        public Action<DataRow> _EvntAddKeyInOrder;
        /// <summary>
        /// 更新KeyIn明細回報資訊事件
        /// </summary>
        public Action<Report> _EvntUpdateKeyInOrder;
        /// <summary>
        /// 新增回報資訊事件
        /// </summary>
        public Action<DataRow> _EvntAddReport;
        /// <summary>
        /// 更新回報畫面資訊事件
        /// </summary>
        public Action _EvntUpdateReport;
        /// <summary>
        /// 回補完成通知事件
        /// </summary>
        public Action _EvntRecoverCompleted;
        /// <summary>
        /// 回補完成註記
        /// </summary>
        private bool _RecoverCompleted = false;
        public bool RecoverCompleted { get { return _RecoverCompleted; } set { _RecoverCompleted = value; } }
        private int _RecoverAmount = 0;
        /// <summary>
        /// 更新KeyIn明細委託鎖
        /// </summary>
        public readonly static object _KeyInOrderLock = new object();
        /// <summary>
        /// 紀錄本機送單委託序號，供委託回報mapping使用
        /// Key: DSEQ
        /// Value: ""，string很吃記憶體
        /// </summary>
        public ConcurrentDictionary<string, string> _OrdDSEQ;
        /// <summary>
        /// 記錄當天所有Push Server回報電文(過濾用)
        /// </summary>
        private ConcurrentDictionary<string, string> _PushMessage;
        /// <summary>
        /// 存網路單號用，key:dseq value:insq
        /// </summary>
        public ConcurrentDictionary<string, string> _OrderInsq;
        /// <summary>
        /// 新增成交明細鎖
        /// </summary>
        private readonly static object _DealDetailLock = new object();
        /// <summary>
        /// 更新委託鎖
        /// </summary>
        public readonly static object _Lock = new object();
        private int _OrderNo = 0;
        /// <summary>
        /// 委託序號
        /// </summary>
        public int OrderNo { get { return _OrderNo; } set { _OrderNo = value; } }
        private int _ErrAccountOrderNo = 1;
        /// <summary>
        /// 興櫃錯帳委託序號
        /// </summary>
        public int ErrAccountOrderNo { get { return _ErrAccountOrderNo; } set { _ErrAccountOrderNo = value; } }
        /// <summary>
        /// 計算回補時間
        /// </summary>
        public DateTime dt1, dt2;
        public EMOrderStore()
        {
            _OrdDSEQ = new ConcurrentDictionary<string, string>();
            _PushMessage = new ConcurrentDictionary<string, string>();
            _KeyInOrderQueue = new ConcurrentQueue<Report>();//main插入queue，利用task的while迴圈dequeue
            _ReportQueue = new ConcurrentQueue<Report>();
            _KeyInDetailStore = new DataTable();
            _OrdReportStore = new DataTable();
            _OrdDealDetailStore = new DataTable();
            _OrderInsq = new ConcurrentDictionary<string, string>();
            foreach (PropertyInfo pi in typeof(Report).GetProperties())
            {
                _KeyInDetailStore.Columns.Add(pi.Name, pi.PropertyType);
                _OrdReportStore.Columns.Add(pi.Name, pi.PropertyType);
                _OrdDealDetailStore.Columns.Add(pi.Name, pi.PropertyType);
            }
            //明細:委託書號+訊息序號當primary key
            _KeyInDetailStore.PrimaryKey = new DataColumn[] { _KeyInDetailStore.Columns["DSEQ"],
                                                              _KeyInDetailStore.Columns["ClOrdID"] };
            _KeyInDetailStore.CaseSensitive = true;
            //委託彙總 
            _OrdReportStore.PrimaryKey = new DataColumn[] { _OrdReportStore.Columns["DSEQ"],
                                                            _OrdReportStore.Columns["OrigClOrdID"]};
            _OrdReportStore.CaseSensitive = true;
            //成交彙總 
            _OrdDealDetailStore.PrimaryKey = new DataColumn[] { _OrdDealDetailStore.Columns["DSEQ"],
                                                                _OrdDealDetailStore.Columns["ClOrdID"]};
            _OrdDealDetailStore.CaseSensitive = true;
        }
        /// <summary>
        /// Parse委託回報
        /// </summary>
        public Report ParseReport(string message)
        {
            if (string.IsNullOrEmpty(message))
                return null;
            try
            {
                Report report = new Report();
                Dictionary<int, string> fix_msg = SocketSessionHandler.ParserMessageToDic(message, '\u0001');
                if (_PushMessage.TryAdd(fix_msg[76] + fix_msg[117] + fix_msg[20002], ""))//原本是全電文，但考慮到string很吃記憶體，改用分公司+委託書號+訊息序號
                {
                    int int_bfqty = int.Parse(fix_msg[37]);//改前
                    int int_ordQty = int.Parse(fix_msg[38]);//改後
                    report.OrdQty = int_bfqty != 0 ? int_bfqty : int_ordQty;
                    if (fix_msg[81008] == "P")
                        report.OrdQty = int_bfqty;
                    else if (fix_msg[81008] == "C" || fix_msg[81008] == "D")
                        report.OrdQty = int_bfqty - int_ordQty;//C、D委託 = 刪
                    report.AfterChangeQty = int_ordQty;
                    report.ExecType = fix_msg[81008];
                    report.CSEQ = fix_msg[1];
                    report.BHNO = fix_msg[76];
                    report.DSEQ = fix_msg[117];
                    report.Sale = fix_msg[20001];
                    report.ClOrdID = fix_msg[20002];
                    report.OrigClOrdID = fix_msg[20003];
                    report.Side = fix_msg[54];
                    report.Stock = fix_msg[55].Trim();
                    report.Status = fix_msg[80004];
                    if (report.Status != "0" && report.ExecType == "I" && report.OrdQty != 0)
                    {
                        ConcordLogger.Logger.Error($"DSEQ:{report.DSEQ} ClOrdID:{report.ClOrdID} orderqty:{int_ordQty} 交易所錯誤的委託數量應該要是0");
                        report.OrdQty = 0;
                    }
                    report.OrdPrice = fix_msg[44];
                    report.ECode = fix_msg.ContainsKey(81001) ? fix_msg[81001] : GetEcode(report.OrdQty, report.Stock);
                    report.Text = fix_msg[80014];
                    report.Origin = fix_msg[50002];//委託來源存keyin人員員編
                    string time = fix_msg[80024].PadLeft(17);//避免substring錯誤
                    if (fix_msg[80024] == "")
                        time = fix_msg[80025].PadRight(15);
                    report.TransactTime = time.Substring(8, 2) + ":" + time.Substring(10, 2) + ":" + time.Substring(12, 2);
                    if (fix_msg[76] == "8450" && fix_msg[1] == "0003332" && fix_msg[81008] == "I")
                    {
                        ErrAccountOrderNoAdd1(fix_msg[117]);
                    }
                    return report;
                }
                else
                    ConcordLogger.Logger.Debug("跳過重複委託回報" + message);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error($"ParseReport Err，錯誤原因：{ex}");
                ConcordLogger.Alert("9999", $"{message} ParseReport Err，錯誤原因：{ex}");
            }
            return null;
        }
        /// <summary>
        /// Parse成交回報
        /// </summary>
        public Report ParseDealReport(string message)
        {
            try
            {
                Report report = new Report();
                Dictionary<int, string> fix_msg = SocketSessionHandler.ParserMessageToDic(message, '\u0001');
                if (_PushMessage.TryAdd(fix_msg[76] + fix_msg[117] + fix_msg[20004], ""))//成交回報的交易所序號不會重複
                {
                    report.CSEQ = fix_msg[1];//
                    report.BHNO = fix_msg[76];//
                    report.DSEQ = fix_msg[117];//
                    report.Side = fix_msg[54];//
                    report.Stock = fix_msg[55].Trim();//
                    report.ClOrdID = fix_msg[20003];//這裡是交易所網單
                    report.OrigClOrdID = fix_msg[20003];
                    // report.insq = _OrderInsq[fix_msg[117]];//
                    int int_RemainQty = 0, int_DealQty = 0;
                    int.TryParse(fix_msg[37], out int_RemainQty);
                    int.TryParse(fix_msg[38], out int_DealQty);
                    report.LaveQty = int_RemainQty;//剩餘數量
                    report.DealQty = int_DealQty;//成交數量
                    report.Status = fix_msg[80004];//
                    report.DealPrice = decimal.Parse(fix_msg[44]);//成交價
                    report.Text = fix_msg[80014];//
                    string time = fix_msg[80024].PadLeft(17);//避免substring錯誤
                    report.TransactTime = time.Substring(8, 2) + ":" + time.Substring(10, 2) + ":" + time.Substring(12, 2);
                    report.ExecType = "F";//F代表成交回報，其他是IDCP
                    report.Origin = fix_msg[50002];
                    report.Sale = fix_msg[20001];
                    report.ECode = fix_msg.ContainsKey(81001) ? fix_msg[81001] : GetEcode(report.DealQty, report.Stock);
                    return report;
                }
                else
                    ConcordLogger.Logger.Debug("跳過重複成交回報" + message);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error($"ParseReport Err，錯誤原因：{ex}");
                ConcordLogger.Alert("9999", $"{message} ParseReport Err，錯誤原因：{ex}");
            }
            return null;
        }
        /// <summary>
        /// 開啟KeyIn明細task
        /// </summary>
        public void Start_ProcessReport()
        {
            if (!_RecoverCompleted)
            {
                // 處理KeyIn Detail Task
                Task.Factory.StartNew(() => Task_ProcessKeyInOrder(), TaskCreationOptions.LongRunning);
                // 處理委託回報 Task
                Task.Factory.StartNew(() => Task_ProcessReport(), TaskCreationOptions.LongRunning);
            }
        }
        /// <summary>
        /// KeyIn明細task
        /// </summary>
        private void Task_ProcessKeyInOrder()
        {
            ConcordLogger.Logger.Info("[Emst] 處理KeyIn明細 Task Start");
            Thread.CurrentThread.Name = "Task_ProcessEMKeyInOrder";
            while (true)
            {
                try
                {
                    if (_KeyInOrderQueue.Count > 0)
                    {
                        Report report;
                        if (_KeyInOrderQueue.TryDequeue(out report))
                        {
                            //明細的primary key是用委託書號+訊息序號，只有成交回報會重複
                            object[] key = { report.DSEQ, report.ClOrdID };
                            if (_KeyInDetailStore.Rows.Contains(key))
                            {
                                _EvntUpdateKeyInOrder(report);
                            }
                            else
                            {
                                AddKeyInOrder(report);//委回(包含刪、改單)
                            }
                        }
                    }
                    else
                        SpinWait.SpinUntil(() => false, 1);//等待空轉
                }
                catch (Exception ex)
                {
                    MessageBox.Show("KeyIn明細發生異常無法更新資料，請重登KeyIn來確認新單是否已送出!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ConcordLogger.Logger.Error("Task_ProcessEMKeyInOrder 發生異常: " + ex.ToString());
                    ConcordLogger.Alert("9999", "Client端 Task_ProcessEMKeyInOrder 異常", ex.ToString());
                }
            }
        }
        /// <summary>
        /// 委託回報Task
        /// </summary>
        private void Task_ProcessReport()
        {
            ConcordLogger.Logger.Info("[Emst] 處理委託回報 Task Start");
            Thread.CurrentThread.Name = "Task_ProcessEMOrderReport";
            while (true)
            {
                try
                {
                    if (_ReportQueue.Count > 0)
                    {
                        Report report;
                        if (_ReportQueue.TryDequeue(out report))
                        {
                            if (!_RecoverCompleted)
                            {
                                if (--_RecoverAmount <= 0)
                                {
                                    _RecoverCompleted = true;
                                    _EvntRecoverCompleted();
                                    ConcordLogger.Logger.Info("回補" + (DateTime.Now - dt1).TotalSeconds.ToString() + "秒");
                                }
                            }
                            object[] key = { report.DSEQ, report.OrigClOrdID };
                            if (_OrdReportStore.Rows.Contains(key))
                            {
                                UpdateReport(report);
                            }
                            else
                            {
                                AddReport(report);
                            }
                        }
                    }
                    else
                        SpinWait.SpinUntil(() => false, 1);//等待空轉
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("Task_ProcessEMOrderReport 發生異常: " + ex.ToString());
                    ConcordLogger.Alert("9999", "Client端 Task_ProcessEMOrderReport 異常", ex.ToString());
                }
            }
        }
        /// <summary>
        /// KeyIn明細:委託回報
        /// </summary>
        public void AddKeyInOrder(Report report)
        {
            DataRow dr = _KeyInDetailStore.NewRow();
            dr["ExecType"] = report.ExecType;
            dr["Sale"] = report.Sale;
            dr["DSEQ"] = report.DSEQ;
            dr["BHNO"] = report.BHNO;
            dr["CSEQ"] = report.CSEQ;
            dr["ClOrdID"] = report.ClOrdID;
            dr["OrigClOrdID"] = report.OrigClOrdID;
            dr["Stock"] = report.Stock;
            dr["Side"] = report.Side;
            dr["ECode"] = report.ECode == "0" ? "整股" : "零股";
            dr["OrdQty"] = report.OrdQty;
            dr["OrdPrice"] = report.OrdPrice;
            dr["Status"] = report.Status == "0" ? "成功" : "失敗";
            dr["TransactTime"] = report.TransactTime;
            dr["Text"] = report.Text;
            //dr["CancelQty"] = 0;//新單的刪除數量=0
            _EvntAddKeyInOrder(dr);//frmMain裡面Add明細
        }
        /// <summary>
        /// 彙總:新增委託回報
        /// </summary>
        public void AddReport(Report report)
        {
            DataRow dr = _OrdReportStore.NewRow();
            object[] key = { report.DSEQ, report.OrigClOrdID };
            dr["ExecType"] = report.ExecType;
            dr["Sale"] = report.Sale;
            dr["DSEQ"] = report.DSEQ;
            dr["BHNO"] = report.BHNO;
            dr["CSEQ"] = report.CSEQ;
            dr["ClOrdID"] = report.ClOrdID;
            dr["OrigClOrdID"] = report.OrigClOrdID;
            dr["Stock"] = report.Stock;
            dr["Side"] = report.Side;
            dr["ECode"] = report.ECode == "0" ? "整股" : "零股";
            // dr["BeforeChangeQty"] = report.BeforeChangeQty;
            dr["DealQty"] = report.DealQty;
            if (report.ExecType == "I")//委回只有新單需要ordQty，之後都不會變
                dr["OrdQty"] = report.OrdQty;
            dr["OrdPrice"] = report.OrdPrice;
            dr["LaveQty"] = report.ExecType == "F" ? report.LaveQty : report.OrdQty;//新單remainqty = ordqty
            dr["CancelQty"] = report.ExecType == "C" ? report.OrdQty : 0;//新單的刪除數量=0
            dr["Status"] = report.Status == "0" ? "委託成功" : "委託失敗";
            dr["Text"] = report.Text;
            dr["TransactTime"] = report.TransactTime;
            dr["MType"] = "E";
            Customer customer = CUMBStore.Get_CustomerInfo(report.CSEQ.Trim());
            if (customer != null)
                dr["CusName"] = customer.SNAME;
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(report.Stock.Trim());
            if (stockInfo != null)
                dr["StockName"] = stockInfo.CNAME;
            _EvntAddReport(dr);
            if (_RecoverCompleted) _EvntUpdateReport();
        }
        /// <summary>
        /// 彙總:更新回報
        /// </summary>
        public void UpdateReport(Report report)
        {
            if (report.Status == "0")
            {
                if (report.ExecType == "F")
                    UpdateDealReport(report);//成回
                else
                    UpdateOrdReport(report);//委回
                if (_RecoverCompleted) _EvntUpdateReport();
            }
        }
        /// <summary>
        /// 彙總:更新委託回報
        /// </summary>
        private void UpdateOrdReport(Report report)
        {
            lock (_DealDetailLock)
            {
                object[] key = { report.DSEQ, report.OrigClOrdID };
                DataRow dr = _OrdReportStore.Rows.Find(key);
                dr["ExecType"] = report.ExecType;
                // dr["OrdQty"] = report.OrdQty;刪單、改量、改價不需要更新
                if (report.ExecType == "P" || report.ExecType == "I")
                    dr["OrdPrice"] = report.OrdPrice;
                if (report.ExecType == "I")
                    dr["OrdQty"] = report.OrdQty;
                int ordQty = 0, dealQty = 0, cancelQty = 0;
                int.TryParse(dr["OrdQty"].ToString(), out ordQty);
                int.TryParse(dr["DealQty"].ToString(), out dealQty);
                int.TryParse(dr["CancelQty"].ToString(), out cancelQty);
                if (report.ExecType == "C" || report.ExecType == "D")
                    dr["CancelQty"] = cancelQty + report.OrdQty;//C、D刪除數量 = 委託
                int laveQty = (report.ExecType == "C" || report.ExecType == "D") ? ordQty - (cancelQty + report.OrdQty) - dealQty : ordQty - cancelQty - dealQty;//剩餘數量 = 原委託-已刪-成交
                dr["LaveQty"] = laveQty;
                if (laveQty == 0 && dealQty > 0)
                    dr["Status"] = "完全成交";
                else if (laveQty == 0)
                    dr["Status"] = "刪單成功";
                dr.AcceptChanges();
            }
        }
        /// <summary>
        /// 彙總:更新成交回報
        /// </summary>
        private void UpdateDealReport(Report report)
        {
            lock (_DealDetailLock)
            {
                object[] key = { report.DSEQ, report.ClOrdID };
                DataRow dr = _OrdReportStore.Rows.Find(key);
                // dr["OrdQty"] = report.OrdQty;
                if (dr == null)
                    return;
                int ordQty = 0, dealQty = 0, cancelQty = 0;
                int.TryParse(dr["OrdQty"].ToString(), out ordQty);
                int.TryParse(dr["CancelQty"].ToString(), out cancelQty);
                int.TryParse(dr["DealQty"].ToString(), out dealQty);
                dr["LaveQty"] = ordQty - cancelQty - (dealQty + report.DealQty);
                dr["DealQty"] = dealQty + report.DealQty;
                dr["DealPrice"] = report.DealPrice;
                if (ordQty - cancelQty - (dealQty + report.DealQty) == 0)
                    dr["Status"] = "完全成交";
                else
                    dr["Status"] = "部份成交";
                dr.AcceptChanges();
            }
        }
        /// <summary>
        /// 此筆單下單後通過風控，由系統先送出成功電文
        /// </summary>
        public void AddTmpReportByOrder(string message)
        {
            try
            {
                Dictionary<int, string> fix_msg = SocketSessionHandler.ParserMessageToDic(message, '\u0001');
                DataRow dr = _KeyInDetailStore.NewRow();
                dr["ExecType"] = fix_msg[81008];
                dr["Sale"] = fix_msg[20001];
                dr["DSEQ"] = fix_msg[117];
                dr["BHNO"] = fix_msg[76];
                dr["CSEQ"] = fix_msg[1];
                dr["ClOrdID"] = fix_msg[20002];
                dr["OrigClOrdID"] = fix_msg[20003];
                dr["Stock"] = fix_msg[55];
                dr["Side"] = fix_msg[54];
                dr["OrdQty"] = fix_msg[38];
                dr["OrdPrice"] = fix_msg[44];
                if (fix_msg[81008] != "I")//有原始值填原始值
                {
                    var report = FindEmOrder(fix_msg[117]);
                    if (report != null && report.Count > 0)
                    {
                        if (fix_msg[81008] == "C" || fix_msg[81008] == "D")
                            dr["OrdPrice"] = report[0]["OrdPrice"].ToString();
                        if (fix_msg[81008] == "P" || fix_msg[81008] == "D")
                            dr["OrdQty"] = report[0]["LaveQty"].ToString();
                    }
                }
                dr["Status"] = "送出";
                string time = fix_msg[80024].PadLeft(17);//避免substring錯誤
                if (fix_msg[80024] == "")
                    time = fix_msg[80025].PadRight(15);
                dr["TransactTime"] = time.Substring(8, 2) + ":" + time.Substring(10, 2) + ":" + time.Substring(12, 2);
                dr["Text"] = fix_msg[80014];
                //dr["CancelQty"] = 0;//新單的刪除數量=0
                _OrdDSEQ.TryAdd(fix_msg[117], "");
                object[] key = { fix_msg[117], fix_msg[20002] };//防呆，重複primary key 插入程式會直接死亡
                if (_KeyInDetailStore.Rows.Contains(key))
                {
                    ConcordLogger.Logger.Error($"dseq = {fix_msg[117]}, ClOrdID = {fix_msg[20002]}, OrigClOrdID={fix_msg[20003]} 重複訊息序號會造成程式死掉");
                    return;
                }
                _EvntAddKeyInOrder(dr);
                if (fix_msg[81008] == "I" && fix_msg[1] == "0003332")
                    ErrAccountOrderNoAdd1(fix_msg[117]);
                else if (fix_msg[81008] == "I")
                    _OrderNo++;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("AddTmpReportByOrder 發生異常: " + ex.ToString());
                ConcordLogger.Alert("9999", "Client端 AddTmpReportByOrder 異常", ex.ToString());
            }
        }
        public void ParseSearch(string message)//該筆單的委託、成交數量order:0|trade:0
        {
            var list = message.Split(new string[] { "order:", "|trade:" }, StringSplitOptions.RemoveEmptyEntries);
            int order = 0, trade = 0;
            int.TryParse(list[0], out order);
            int.TryParse(list[1], out trade);
            _RecoverAmount = order + trade;
            if (_RecoverAmount == 0)
            {
                _RecoverCompleted = true;
                _EvntRecoverCompleted();
            }
        }
        public List<DataRow> FindEmOrder(string dseq)
        {
            List<DataRow> result = new List<DataRow>();
            lock (_Lock)
            {
                result = _OrdReportStore.AsEnumerable().Where(r => r.Field<string>("DSEQ").Trim() == dseq.Trim()).ToList();
            }
            return result;//會有null的情況，不能回傳result[0]
        }
        /// <summary>
        /// 全選刪除
        /// </summary>
        public void SetDeleSelectSwitch(bool enable)
        {
            lock (_Lock)
            {
                foreach (DataRow row in _OrdReportStore.AsEnumerable()
                                        .Where(r => (r.Field<string>("Status").Equals("委託成功") ||
                                                     r.Field<string>("Status").Equals("部份成交")) &&
                                                     r.Field<int>("LaveQty") > 0).ToList())
                {
                    row["CheckDelete"] = enable;
                }
            }
        }
        /// <summary>
        /// 將委回的彙總組合成order
        /// </summary>
        public Order DataRowToEMOrder(DataRow dr)
        {
            Order order = new Order();
            order.CSEQ = dr["CSEQ"].ToString();
            order.BHNO = dr["BHNO"].ToString();
            order.DSEQ = dr["DSEQ"].ToString();
            order.Side = dr["Side"].ToString() == "B" ? Side.BUY : Side.SELL;
            order.Symbol = dr["Stock"].ToString();
            int int_orderQty = 0;
            int.TryParse(dr["OrdQty"].ToString(), out int_orderQty);
            order.OrdQty = int_orderQty;
            order.OrdPrice = dr["OrdPrice"].ToString();
            order.ECode = dr["ECode"].ToString() == "零股" ? "2" : "0";
            order.Sale = dr["Sale"].ToString();
            order.Guid = dr["OrigClOrdID"].ToString();//原網單
            return order;
        }
        public void ErrAccountOrderNoAdd1(string orderNo)
        {
            int newErrAccountOrderNo = int.Parse(orderNo.PadRight(5, '0').Substring(1, 4));
            if (newErrAccountOrderNo >= ErrAccountOrderNo)
                ErrAccountOrderNo = newErrAccountOrderNo + 1;
        }
        /// <summary>
        /// 用委託數量和類別判斷Ecode
        /// </summary>
        private string GetEcode(int orderQty, string stock)
        {
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(stock);
            if (stockInfo == null)
            {
                ConcordLogger.Logger.Warn($"找不到Ecode stock:{stock}");
                return orderQty >= 1000 ? "0" : "2";
            }
            int unit = 1000;
            int.TryParse(stockInfo.UNIT, out unit);
            if (stockInfo.STYPE == "9" || orderQty >= unit)
                return "0";
            return "2";
        }
    }
}
