﻿using Concord.SDK.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class OrderStore
    {
        /// <summary>
        /// 新增KeyIn明細資訊事件
        /// </summary>
        public Action<DataRow> _EvntAddKeyInOrder;
        /// <summary>
        /// 更新KeyIn明細回報資訊事件
        /// </summary>
        public Action<Report> _EvntUpdateKeyInOrder;
        /// <summary>
        /// 新增回報資訊事件
        /// </summary>
        public Action<DataRow> _EvntAddReport;
        /// <summary>
        /// 更新回報畫面資訊事件
        /// </summary>
        public Action _EvntUpdateReport;
        /// <summary>
        /// 回補完成通知事件
        /// </summary>
        public Action _EvntRecoverCompleted;

        /// <summary>
        /// KeyIn本身委託明細
        /// </summary>
        public DataTable _KeyInDetailStore;
        /// <summary>
        /// 成交回報明細資料表
        /// </summary>
        private DataTable _OrdDealDetailStore;
        /// <summary>
        /// 委託回報紀錄資料表 (彙總)
        /// </summary>
        public static DataTable _OrdReportStore;
        /// <summary>
        /// 被動委託查詢紀錄資料表
        /// </summary>
        public DataTable _OrdPassiveReportStore;
        /// <summary>
        /// 網單回報儲存序列
        /// </summary>
        public ConcurrentQueue<Report> _KeyInOrderQueue;
        /// <summary>
        /// 網單回報儲存序列
        /// </summary>
        private ConcurrentQueue<Report> _DealDetailQueue;
        /// <summary>
        /// 委託回報儲存序列
        /// </summary>
        public ConcurrentQueue<Report> _ReportQueue;
        /// <summary>
        /// 紀錄下單委託物件，供網單電文回覆mapping使用
        /// Key : Guid
        /// Value : 委託物件
        /// </summary>
        public ConcurrentDictionary<string, Order> _OrdNetNoMap;
        /// <summary>
        /// 紀錄本機送單委託序號，供委託回報mapping使用
        /// Key: DSEQ
        /// Value: DSEQ
        /// </summary>
        public ConcurrentDictionary<string, string> _OrdDSEQ;
        /// <summary>
        /// 記錄當天所有Push Server回報電文(過濾用)
        /// </summary>
        private ConcurrentDictionary<string, string> _PushMessage;
        /// <summary>
        /// 回補完成註記
        /// </summary>
        private bool _RecoverCompleted = false;
        /// <summary>
        /// 更新KeyIn明細委託鎖
        /// </summary>
        public readonly static object _KeyInOrderLock = new object();
        /// <summary>
        /// 更新委託鎖
        /// </summary>
        public readonly static object _Lock = new object();
        /// <summary>
        /// 更新被動委託鎖
        /// </summary>
        public readonly static object _PasLock = new object();
        /// <summary>
        /// 新增成交明細鎖
        /// </summary>
        private readonly static object _DealDetailLock = new object();
        /// <summary>
        /// 回補資料總數
        /// </summary>
        private int _RecoverAmount = 0;

        public OrderStore()
        {
            _OrdNetNoMap = new ConcurrentDictionary<string, Order>();
            _OrdDSEQ = new ConcurrentDictionary<string, string>();
            _PushMessage = new ConcurrentDictionary<string, string>();
            _KeyInOrderQueue = new ConcurrentQueue<Report>();
            _ReportQueue = new ConcurrentQueue<Report>();
            _DealDetailQueue = new ConcurrentQueue<Report>();

            #region 建立並初始化回報紀錄資料表欄位
            _KeyInDetailStore = new DataTable();
            _OrdDealDetailStore = new DataTable();
            _OrdReportStore = new DataTable();
            _OrdPassiveReportStore = new DataTable();
            foreach (PropertyInfo pi in typeof(Report).GetProperties())
            {
                _KeyInDetailStore.Columns.Add(pi.Name, pi.PropertyType);
                _OrdDealDetailStore.Columns.Add(pi.Name, pi.PropertyType);
                _OrdReportStore.Columns.Add(pi.Name, pi.PropertyType);
                _OrdPassiveReportStore.Columns.Add(pi.Name, pi.PropertyType);
            }
            _OrdReportStore.PrimaryKey = new DataColumn[] { _OrdReportStore.Columns["DSEQ"],
                                                            _OrdReportStore.Columns["OrigClOrdID"] };
            _OrdReportStore.CaseSensitive = true;

            _OrdPassiveReportStore.PrimaryKey = new DataColumn[] { _OrdPassiveReportStore.Columns["DSEQ"],
                                                            _OrdPassiveReportStore.Columns["OrigClOrdID"] };
            _OrdPassiveReportStore.CaseSensitive = true;

            _OrdDealDetailStore.PrimaryKey = new DataColumn[] { _OrdDealDetailStore.Columns["Seq"] };
            _OrdDealDetailStore.CaseSensitive = true;

            _KeyInDetailStore.PrimaryKey = new DataColumn[] { _KeyInDetailStore.Columns["DSEQ"],
                                                              _KeyInDetailStore.Columns["ClOrdID"] };
            _KeyInDetailStore.CaseSensitive = true;
            #endregion
        }

        /// <summary>
        /// 解析Push Server委託回報電文
        /// </summary>
        /// <param name="message"></param>
        public Report Parse(string message)
        {
            if (string.IsNullOrEmpty(message))
                return null;

            Report item = new Report();
            // 判斷是否為重複電文
            if (_PushMessage.TryAdd(message, ""))
            {
                Dictionary<int, string> fields = SocketSessionHandler.ParserMessageToDic(message, '^');
                item.CheckDelete = false;
                item.Seq = fields[34].Trim();
                item.ExecType = fields[150].Trim();
                item.MsgType = fields.ContainsKey(10002) ? fields[10002].Trim() : "F";
                item.ClOrdID = fields.ContainsKey(11) ? fields[11].Trim() : fields[41].Trim();
                item.OrigClOrdID = fields[41].Trim();
                item.DSEQ = fields[37].Trim();
                item.BHNO = fields[50].Trim();
                item.CSEQ = fields[1].Trim();
                item.ECode = fields[57].Trim();
                item.OType = fields[10001].Trim();
                item.Stock = fields[55].Trim();
                int unit = 1000;

                StockInfo info = STMBStore.Get_SymbolInfo(item.Stock);
                if (info != null)
                {
                    item.MType = info.MTYPE;
                    item.StockName = info.CNAME;
                    unit = int.Parse(info.UNIT);
                }
                item.Side = fields[54].Trim();
                item.OrdType = fields[40].Trim();
                item.TimeInForce = fields[59].Trim();
                if (fields.ContainsKey(20053))
                {
                    int effectiveQty = 0;
                    if (int.TryParse(fields[20053], out effectiveQty))
                        item.EffectiveOrdQty = (item.ECode == "2" || item.ECode == "7") ? effectiveQty : effectiveQty * unit;
                }
                item.TransactTime = string.Format("{0}:{1}:{2}", fields[60].Substring(9, 2), fields[60].Substring(11, 2), fields[60].Substring(13, 2));
                item.Origin = fields[10000].Trim();
                item.Sale = fields[20001].Trim();
                item.DayTradeFlag = fields[20003].Trim();
                if (fields.ContainsKey(20009)) item.BeforeChangeQty = (item.ECode == "2" || item.ECode == "7") ? int.Parse(fields[20009]) : int.Parse(fields[20009]) * unit;
                if (fields.ContainsKey(20010)) item.AfterChangeQty = (item.ECode == "2" || item.ECode == "7") ? int.Parse(fields[20010]) : int.Parse(fields[20010]) * unit;
                string Errtext = "", ErrCode = "";
                if (fields.ContainsKey(58))
                {
                    Errtext = fields[58];
                    ErrCode = fields[103];
                }
                switch (item.ExecType)
                {
                    case "0":
                    case "8":
                        {
                            #region 委託成功(0) / 委託失敗 (8)
                            int qty = 0;
                            int.TryParse(fields[38], out qty);
                            item.OrdQty = (item.ECode == "2" || item.ECode == "7") ? qty : qty * unit;

                            if (item.OrdType == "1")
                                item.OrdPrice = "市價";
                            else
                            {
                                decimal OrderPrice = 0;
                                decimal.TryParse(fields[44], out OrderPrice);
                                item.OrdPrice = OrderPrice.ToString("0.####");
                            }
                            item.DealQty = 0;
                            if (item.EffectiveOrdQty != item.OrdQty)
                                item.CancelQty = item.OrdQty - item.EffectiveOrdQty;
                            item.Text = Errtext;
                            item.ErrCode = ErrCode;
                            break;
                            #endregion
                        }
                    case "4":
                    case "5":
                        {
                            #region 刪單成功(4) / 改量成功(5)
                            int qty = 0;
                            int.TryParse(fields[38], out qty);
                            if (item.OrdType == "1")
                                item.OrdPrice = "市價";
                            else
                            {
                                decimal OrderPrice = 0;
                                decimal.TryParse(fields[44], out OrderPrice);
                                item.OrdPrice = OrderPrice.ToString("0.####");
                            }
                            item.OrdQty = (item.ECode == "2" || item.ECode == "7") ? qty : qty * unit;
                            int CancelQty = item.BeforeChangeQty - item.AfterChangeQty;
                            item.CancelQty = CancelQty;
                            break;
                            #endregion
                        }
                    case "M":
                        {
                            #region 改價成功
                            int qty = 0;
                            int.TryParse(fields[38], out qty);
                            item.OrdQty = (item.ECode == "2" || item.ECode == "7") ? qty : qty * unit;
                            decimal OrdPrice = 0;
                            decimal.TryParse(fields[44], out OrdPrice);
                            item.OrdPrice = OrdPrice.ToString("0.####");
                            break;
                            #endregion
                        }
                    case "F":
                        {
                            #region 部份成交 / 完全成交
                            int deal_qty = 0;
                            decimal deal_price = 0;
                            int.TryParse(fields[32], out deal_qty);
                            decimal.TryParse(fields[31], out deal_price);
                            item.DealQty = (item.ECode == "2" || item.ECode == "7") ? deal_qty : deal_qty * unit; ;
                            item.DealPrice = deal_price;
                            #endregion
                        }
                        break;
                }
            }
            return item;
        }
        /// <summary>
        /// 更新回補數量並開始接收回報
        /// </summary>
        /// <param name="count"></param>
        public void Start_ProcessReport(string count)
        {
            if (!_RecoverCompleted)
            {
                _RecoverAmount = int.Parse(count);
                // 若當日沒有回補資料時
                if (_RecoverAmount <= 0)
                {
                    _RecoverCompleted = true;
                    _EvntRecoverCompleted();
                }
                // 處理KeyIn Detail Task
                Task.Factory.StartNew(() => Task_ProcessKeyInOrder(), TaskCreationOptions.LongRunning);
                // 處理委託回報 Task
                Task.Factory.StartNew(() => Task_ProcessReport(), TaskCreationOptions.LongRunning);
                // 處理成交明細 Task
                Task.Factory.StartNew(() => Task_ProcessDealDetail(), TaskCreationOptions.LongRunning);
            }
        }

        /// <summary>
        /// 處理委託回報中KeyIn單明細序列資料
        /// </summary>
        private void Task_ProcessKeyInOrder()
        {
            ConcordLogger.Logger.Info("處理KeyIn Order Task Start");
            Thread.CurrentThread.Name = "Task_ProcessKeyInOrder";
            while (true)
            {
                try
                {
                    if (_KeyInOrderQueue.Count > 0)
                    {
                        Report report;
                        if (_KeyInOrderQueue.TryDequeue(out report)) // 不顯示成交資訊
                        {
                            ConcordLogger.Logger.Debug($"task KeyIn明細 收到委託書號：{report.DSEQ}");
                            object[] key = { report.DSEQ, report.ClOrdID };
                            if (_KeyInDetailStore.Rows.Contains(key))
                            {
                                //UpdateKeyInOrder(report);
                                _EvntUpdateKeyInOrder(report);
                            }
                            else
                            {
                                // 防止跨櫃操作後收到成交回報，顯示於畫面上問題
                                if (report.ExecType == "F")
                                    continue;
                                AddKeyInOrder(report);
                            }
                        }
                    }
                    else
                    {
                        SpinWait.SpinUntil(() => false, 1);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("KeyIn明細發生異常無法更新資料，麻煩請重登KeyIn!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ConcordLogger.Logger.Error("Task_ProcessKeyInOrder 發生異常: " + ex.ToString());
                    ConcordLogger.Alert("9999", "Client端 Task_ProcessKeyInOrder 異常", ex.ToString());
                }
            }
            MessageBox.Show("KeyIn明細發生異常無法更新資料，麻煩請重登KeyIn!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        /// <summary>
        /// 處理委託回報序列資料
        /// </summary>
        private void Task_ProcessReport()
        {
            ConcordLogger.Logger.Info("處理委託回報 Task Start");
            Thread.CurrentThread.Name = "Task_ProcessReport";
            while (true)
            {
                try
                {
                    if (_ReportQueue.Count > 0)
                    {
                        #region 回補判斷
                        if (!_RecoverCompleted && --_RecoverAmount <= 0)
                        {
                            _RecoverCompleted = true;
                            _EvntRecoverCompleted();
                        }
                        #endregion

                        Report report;
                        if (_ReportQueue.TryDequeue(out report))
                        {
                            if (report.DSEQ == null || report.OrigClOrdID == null)
                                return;
                            if (report.ExecType == "F")
                                _DealDetailQueue.Enqueue(report);

                            object[] key = { report.DSEQ, report.OrigClOrdID };
                            if (_OrdReportStore.Rows.Contains(key))
                            {
                                UpdateReport(report);
                            }
                            else
                            {
                                AddReport(report);
                            }
                        }
                    }
                    else
                        SpinWait.SpinUntil(() => false, 1);
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("Task_ProcessReport 發生異常: " + ex.ToString());
                    ConcordLogger.Alert("9999", "Client端 Task_ProcessReport 異常", ex.ToString());
                }
            }
            MessageBox.Show("委託回報更新程序發生異常，麻煩請重登KeyIn !", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        /// <summary>
        /// 處理成交明細序列資料
        /// </summary>
        private void Task_ProcessDealDetail()
        {
            ConcordLogger.Logger.Info("處理成交明細 Task Start");
            Thread.CurrentThread.Name = "Task_ProcessDealDetail";
            while (true)
            {
                try
                {
                    if (_DealDetailQueue.Count > 0)
                    {
                        Report report;
                        if (_DealDetailQueue.TryDequeue(out report))
                        {
                            lock (_DealDetailLock)
                            {
                                DataRow dr = _OrdDealDetailStore.NewRow();
                                dr["Seq"] = report.Seq;
                                dr["DSEQ"] = report.DSEQ;
                                dr["CSEQ"] = report.CSEQ;
                                dr["Stock"] = report.Stock;
                                dr["DealQty"] = (report.ECode == "2" || report.ECode == "7") ? report.DealQty : report.DealQty / 1000;
                                dr["DealPrice"] = report.DealPrice;
                                _OrdDealDetailStore.Rows.Add(dr);
                            }
                        }
                    }
                    else
                        SpinWait.SpinUntil(() => false, 1);
                }
                catch (Exception ex)
                {
                    ConcordLogger.Alert("9999", "Client端 Task_ProcessDealDetail 異常", ex.ToString());
                    ConcordLogger.Logger.Error("Task_ProcessDealDetail 發生異常: " + ex.ToString());
                }

            }
            MessageBox.Show("成交明細的更新程序發生異常，麻煩請重登KeyIn !", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>
        /// 新增KeyIn明細  (除了零股,數量為張數)
        /// </summary>
        /// <param name="report"></param>
        private void AddKeyInOrder(Report report)
        {
            try
            {
                ConcordLogger.Logger.Debug($"task KeyIn明細 加入新回報 委託書號：{report.DSEQ} 新刪改：" + report.ExecType + " 數量：" + report.OrdQty + " 狀態：" + report.Status + " 回報時間：" + report.TransactTime);
                int unit = 1000;
                StockInfo info = STMBStore.Get_SymbolInfo(report.Stock);
                if (info != null)
                {
                    unit = int.Parse(info.UNIT);
                }
                DataRow dr = _KeyInDetailStore.NewRow();
                int BefChangQty = (report.ECode != "2" && report.ECode != "7") ? report.BeforeChangeQty / 1000 : report.BeforeChangeQty;
                dr["ExecType"] = report.ExecType != "F" ? report.MsgType : report.ExecType;
                dr["TransactTime"] = report.TransactTime;
                dr["DSEQ"] = report.DSEQ;
                dr["ClOrdID"] = report.ClOrdID;
                dr["OrigClOrdID"] = report.OrigClOrdID;
                dr["BHNO"] = "845" + report.BHNO;
                dr["CSEQ"] = report.CSEQ;
                dr["Stock"] = report.Stock;
                dr["StockName"] = report.StockName;
                dr["Side"] = report.Side;
                dr["ECode"] = report.ECode;
                dr["OType"] = StockInfoHandler.GetOrderTypeText(report.OType);
                dr["BeforeChangeQty"] = BefChangQty;
                dr["OrdQty"] = (report.ECode != "2" && report.ECode != "7") ? report.OrdQty / unit : report.OrdQty;
                dr["DealQty"] = (report.ECode != "2" && report.ECode != "7") ? report.DealQty / unit : report.DealQty;
                dr["OrdPrice"] = report.OrdPrice;
                dr["OrdType"] = StockInfoHandler.GetOrdTypeText(report.OrdType);
                dr["TimeInForce"] = StockInfoHandler.GetTimeInForceText(report.TimeInForce);
                dr["MType"] = report.MType;
                dr["Status"] = report.Status;
                /*
                switch (report.ExecType) // 對應回報先傳來的狀況
                {
                    case "0":  // 委託成功
                    case "4":  // 刪單成功
                    case "5":  // 改量成功
                    case "M":  // 改價成功
                    case "F":  // 成交單
                        dr["Status"] = "成功";
                        break;
                    case "8":  // 失敗單
                        dr["Status"] = "失敗";
                        break;
                }
                */
                dr["Text"] = report.Text;
                _EvntAddKeyInOrder(dr);
            }
            catch (Exception ex)
            {
                MessageBox.Show("KeyIn明細發生異常無法更新資料，請重登KeyIn來確認新單是否已送出!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Error("AddKeyInOrder 發生異常: " + ex.ToString());
                ConcordLogger.Alert("9999", "Client端 AddKeyInOrder 異常", ex.ToString());
            }
        }
        /// <summary>
        /// 更新KeyIn明細回報資訊
        /// </summary>
        /// <param name="report"></param>
        private void UpdateKeyInOrder(Report report)
        {
            //object[] key = { report.DSEQ, report.ClOrdID };
            //lock (_KeyInOrderLock)
            //{
            //    ConcordLogger.Logger.Debug("UpdateKeyInOrder report.ExecType=" + report.ExecType + " report.OrdQty=" + report.OrdQty + " report.Status=" + report.Status + " report.TransactTime=" + report.TransactTime + " report.DSEQ=" + report.DSEQ);
            //    DataRow origRow = _KeyInDetailStore.Rows.Find(key);
            //    origRow["ECode"] = report.ECode;
            //    origRow["Status"] = "成功";
            //    int BefChangQty = (report.ECode != "2" && report.ECode != "7") ? report.BeforeChangeQty / 1000 : report.BeforeChangeQty;
            //    int OrdQty = (report.ECode != "2" && report.ECode != "7") ? report.OrdQty / 1000 : report.OrdQty; ;
            //    switch (report.ExecType)
            //    {
            //        case "0":  // 委託成功
            //            origRow["TransactTime"] = report.TransactTime;
            //            origRow["OrdQty"] = OrdQty;
            //            origRow["OrdPrice"] = report.OrdPrice;
            //            origRow["Text"] = report.Text;
            //            break;
            //        case "4":  // 刪單成功
            //            //origRow["BeforeChangeQty"] = BefChangQty;
            //            origRow["OrdQty"] = OrdQty;
            //            origRow["OrdPrice"] = report.OrdPrice;
            //            break;
            //        case "5":  // 改量成功
            //            origRow["BeforeChangeQty"] = BefChangQty;
            //            origRow["OrdPrice"] = report.OrdPrice;
            //            origRow["OrdQty"] = OrdQty;
            //            break;
            //        case "M":  // 改價成功
            //            origRow["OrdQty"] = BefChangQty; // 改價改為用改前數量放置委託數量欄位
            //            origRow["OrdPrice"] = report.OrdPrice;
            //            break;
            //        case "F":  // 成交單
            //            int deal = (report.ECode != "2" && report.ECode != "7") ? report.DealQty / 1000 : report.DealQty;
            //            int origDeal = 0;
            //            int.TryParse(origRow["DealQty"].ToString(), out origDeal);
            //            origRow["DealQty"] = origDeal + deal;
            //            break;
            //        case "8":  // 失敗單
            //            origRow["BeforeChangeQty"] = BefChangQty;
            //            origRow["OrdQty"] = OrdQty;
            //            origRow["OrdPrice"] = report.OrdPrice;
            //            origRow["Status"] = "失敗";
            //            origRow["Text"] = report.Text;
            //            break;
            //    }
            //    origRow.AcceptChanges();
            //}
            _EvntUpdateKeyInOrder(report);
        }
        /// <summary>
        /// 新增回報資訊
        /// </summary>
        /// <param name="report"></param>
        private void AddReport(Report report)
        {
            ConcordLogger.Logger.Debug("AddReport 開始，report.ExecType=" + report.ExecType + " report.OrdQty=" + report.OrdQty + " report.DSEQ=" + report.DSEQ + " report.Status=" + report.Status);
            try
            {
                Customer cusInfo = CUMBStore.Get_CustomerInfo(report.CSEQ);
                DataRow dr = _OrdReportStore.NewRow();
                lock (_Lock)
                {
                    dr["Seq"] = report.Seq;
                    dr["CheckDelete"] = report.CheckDelete;
                    dr["TransactTime"] = report.TransactTime;
                    dr["DSEQ"] = report.DSEQ;
                    dr["CSEQ"] = report.CSEQ;
                    dr["BHNO"] = report.BHNO;
                    if (cusInfo != null) dr["CusName"] = cusInfo.SNAME;
                    dr["Stock"] = report.Stock;
                    dr["StockName"] = report.StockName;
                    dr["Side"] = report.Side;
                    dr["ECode"] = StockInfoHandler.GetECodeText(report.ECode);
                    dr["OType"] = StockInfoHandler.GetOrderTypeText(report.OType);
                    dr["OrdPrice"] = report.OrdPrice;
                    dr["OrdQty"] = report.OrdQty;
                    dr["CancelQty"] = report.CancelQty;
                    dr["DealPrice"] = report.DealPrice;
                    dr["DealQty"] = report.DealQty;
                    dr["LaveQty"] = report.OrdQty - report.CancelQty - report.DealQty;
                    dr["OrdType"] = StockInfoHandler.GetOrdTypeText(report.OrdType);
                    dr["TimeInForce"] = StockInfoHandler.GetTimeInForceText(report.TimeInForce);
                    dr["MType"] = report.MType;
                    dr["Text"] = report.Text;
                    dr["ClOrdID"] = report.ClOrdID;
                    dr["OrigClOrdID"] = report.OrigClOrdID;
                    dr["Status"] = report.Status;
                    dr["Origin"] = report.Origin;
                    dr["Sale"] = report.Sale;
                    UpdateStatus(dr);
                    //_OrdReportStore.Rows.Add(dr);
                }
                _EvntAddReport(dr);
                if (_RecoverCompleted) _EvntUpdateReport();
            }
            catch (Exception ex)
            {
                ConcordLogger.Alert("9999", "Client端 AddReport 異常", ex.ToString());
                ConcordLogger.Logger.Error("AddReport 發生異常: " + ex.ToString());
            }

        }
        /// <summary>
        /// 新增被動查詢資訊
        /// </summary>
        public void AddReport2(string report)
        {
            Customer cusInfo;

            int count = 1;
            try
            {
                lock (_PasLock)
                {
                    _OrdPassiveReportStore.Clear();
                    string[] row = report.Split('~');
                    ConcordLogger.Logger.Debug("AddReport2 開始存入委託查詢資料到DataTable");
                    foreach (string Temp in row)
                    {
                        string[] strArr = Temp.Split(',');
                        if (strArr[11] == "E") // 不顯示興櫃委託回報
                        {
                            continue;
                        }
                        DataRow dr = _OrdPassiveReportStore.NewRow();

                        dr["Seq"] = count.ToString();
                        dr["CheckDelete"] = false;
                        dr["TransactTime"] = strArr[4] == "" ? strArr[4] : strArr[4].Substring(0, 2) + ":" + strArr[4].Substring(2, 2) + ":" + strArr[4].Substring(4, 2);
                        dr["DSEQ"] = strArr[3];
                        dr["CSEQ"] = strArr[9];
                        dr["BHNO"] = strArr[8];
                        cusInfo = CUMBStore.Get_CustomerInfo(strArr[9]);
                        if (cusInfo != null) dr["CusName"] = cusInfo.SNAME;
                        dr["Stock"] = strArr[14];
                        dr["StockName"] = strArr[15].Trim();
                        dr["Side"] = strArr[17];
                        dr["ECode"] = StockInfoHandler.GetECodeText(strArr[13]);
                        dr["OType"] = strArr[12] == "0" ? "現" : strArr[12] == "3" ? "資" : strArr[12] == "4" ? "券" : strArr[12] == "1" ? "代資" : strArr[12] == "2" ? "代券" : "未知";
                        dr["OrdPrice"] = strArr[22];
                        dr["OrdQty"] = strArr[24] == "8" ? 0 : Int32.Parse(strArr[18]);
                        dr["CancelQty"] = Int32.Parse(strArr[20]);
                        dr["DealPrice"] = decimal.Parse(strArr[23]);
                        dr["DealQty"] = Int32.Parse(strArr[21]);
                        dr["LaveQty"] = Int32.Parse(strArr[19]);
                        dr["OrdType"] = StockInfoHandler.GetOrdTypeText(strArr[32]);
                        dr["TimeInForce"] = StockInfoHandler.GetTimeInForceText(strArr[33]);
                        dr["MType"] = strArr[11];
                        dr["Text"] = strArr[29];
                        dr["ClOrdID"] = strArr[1];
                        dr["OrigClOrdID"] = strArr[1];
                        dr["Status"] = strArr[24] == "0" ? "委託成功" : strArr[24] == "1" ? "部份成交" : strArr[24] == "2" ? "完全成交" : strArr[24] == "4" ? "委託取消" : strArr[24] == "8" ? "委託失敗" : "委託送出";
                        dr["Origin"] = strArr[26];
                        dr["Sale"] = strArr[25];
                        UpdateStatus(dr);
                        _OrdPassiveReportStore.Rows.Add(dr);
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("存入委託查詢資料到DataTable發生錯誤 ", ex);
            }
        }
        /// <summary>
        /// 更新回報資訊
        /// </summary>
        /// <param name="report"></param>
        private void UpdateReport(Report report)
        {
            ConcordLogger.Logger.Debug("UpdateReport 開始，report.ExecType=" + report.ExecType + " report.DSEQ=" + report.DSEQ);
            try
            {
                lock (_Lock)
                {
                    object[] key = { report.DSEQ, report.OrigClOrdID };
                    DataRow origRow = _OrdReportStore.Rows.Find(key);
                    // 為了呈現KeyIn自行敲單畫面，若後續回報為KeyIn敲單需蓋過先前來源別以用來呈現
                    if (!string.IsNullOrWhiteSpace(origRow["Origin"].ToString()))
                        origRow["Origin"] = report.Origin;
                    if (!string.IsNullOrWhiteSpace(report.Sale))
                        origRow["Sale"] = report.Sale;

                    switch (report.ExecType)
                    {
                        case "0": // 委託成功
                            {
                                int origLaveQty = 0;
                                int.TryParse(origRow["LaveQty"].ToString(), out origLaveQty);
                                origRow["DSEQ"] = report.DSEQ;
                                origRow["ClOrdID"] = report.ClOrdID;
                                origRow["OrdQty"] = report.OrdQty;
                                origRow["OrdPrice"] = report.OrdPrice;
                                origRow["LaveQty"] = report.OrdQty + origLaveQty;
                                break;
                            }
                        case "4": // 刪單成功
                            {
                                int origLaveQty = 0;
                                int.TryParse(origRow["LaveQty"].ToString(), out origLaveQty);
                                int origCancelQty = 0;
                                int.TryParse(origRow["CancelQty"].ToString(), out origCancelQty);
                                origRow["CancelQty"] = origCancelQty + report.CancelQty;
                                origRow["LaveQty"] = origLaveQty - report.CancelQty;
                                break;
                            }
                        case "5": // 改量成功
                            {
                                int origLaveQty = 0, origCancelQty = 0;
                                int.TryParse(origRow["LaveQty"].ToString(), out origLaveQty);
                                int.TryParse(origRow["CancelQty"].ToString(), out origCancelQty);
                                origRow["CancelQty"] = origCancelQty + report.CancelQty;
                                origRow["LaveQty"] = origLaveQty - report.CancelQty;
                                break;
                            }
                        case "M": // 改價成功
                            origRow["OrdPrice"] = report.OrdPrice;
                            break;
                        case "F": // 成交回報
                            {
                                int origLaveQty = 0, origDealQty = 0;
                                int.TryParse(origRow["LaveQty"].ToString(), out origLaveQty);
                                int.TryParse(origRow["DealQty"].ToString(), out origDealQty);
                                origRow["DealQty"] = origDealQty + report.DealQty;
                                origRow["DealPrice"] = report.DealPrice;
                                origRow["LaveQty"] = origLaveQty - report.DealQty;
                                break;
                            }
                        case "8": // 失敗單
                            if (origRow["Status"].ToString() == "委託送出")
                            {
                                origRow["DSEQ"] = report.DSEQ;
                                origRow["ClOrdID"] = report.ClOrdID;
                                origRow["OrdPrice"] = report.OrdPrice;
                                origRow["LaveQty"] = "0";
                                origRow["Text"] = report.Text;
                            }
                            break;
                    }
                    UpdateStatus(origRow);
                    origRow.AcceptChanges();
                }
                if (_RecoverCompleted) _EvntUpdateReport();
            }
            catch (Exception ex)
            {
                ConcordLogger.Alert("9999", "Client端 UpdateReport 異常", ex.ToString());
                ConcordLogger.Logger.Error("UpdateReport 發生異常: ", ex);
            }

        }
        /// <summary>
        /// 更新委託狀態
        /// </summary>
        private void UpdateStatus(DataRow row)
        {
            string Status = "";

            int Ord_Qty = 0, Deal_Qty = 0, Cancel_Qty = 0;
            int.TryParse(row["OrdQty"].ToString(), out Ord_Qty);
            int.TryParse(row["DealQty"].ToString(), out Deal_Qty);
            int.TryParse(row["CancelQty"].ToString(), out Cancel_Qty);

            if (Deal_Qty == 0 && Cancel_Qty == 0)
            {
                if (!string.IsNullOrEmpty(row["Text"].ToString()))
                    Status = "委託失敗";
                else if (string.IsNullOrEmpty(row["DSEQ"].ToString()) || row["DSEQ"].ToString() == "00000")
                    Status = "委託送出";
                else
                    Status = "委託成功";
            }
            else if (Cancel_Qty > 0 && Cancel_Qty == Ord_Qty)
                Status = "刪單成功";
            else if (Deal_Qty > 0)
            {
                if (Ord_Qty == Deal_Qty + Cancel_Qty)
                    Status = "完全成交";
                else
                    Status = "部份成交";
            }
            else
                Status = "委託成功";


            row["Status"] = Status;
            ConcordLogger.Logger.Debug("Ord_Qty=" + Ord_Qty + " Deal_Qty=" + Deal_Qty + " Cancel_Qty=" + Cancel_Qty + " Status=" + Status + " DSEQ=" + row["DSEQ"].ToString());

        }
        /// <summary>
        /// 啟動與否委託回報畫面選定欄位
        /// </summary>
        /// <param name="enable"></param>
        public void SetDeleSelectSwitch(bool enable)
        {
            lock (_Lock)
            {
                foreach (DataRow row in _OrdReportStore.AsEnumerable()
                                                       .Where(r => (r.Field<string>("Status").Equals("委託成功") ||
                                                                    r.Field<string>("Status").Equals("部份成交")) &&
                                                                    r.Field<string>("TimeInForce").Equals("ROD"))
                                                       .ToList())
                {
                    row["CheckDelete"] = enable;
                }
            }
        }
        /// <summary>
        /// 啟動與否被動查詢畫面選定欄位
        /// </summary>
        /// <param name="enable"></param>
        public void SetPasDeleSelectSwitch(bool enable)
        {
            lock (_PasLock)
            {
                foreach (DataRow row in _OrdPassiveReportStore.AsEnumerable()
                                                   .Where(r => (r.Field<string>("Status").Equals("委託成功") ||
                                                                r.Field<string>("Status").Equals("部份成交")) &&
                                                                r.Field<string>("TimeInForce").Equals("ROD"))
                                                   .ToList())
                {
                    row["CheckDelete"] = enable;
                }
            }
        }
        /// <summary>
        /// 判斷是否含有相符電文
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool ContainsMessage(string key)
        {
            if (key == null)
                return false;

            return _PushMessage.ContainsKey(key);
        }
        /// <summary>
        /// 取得回報資訊 by 委託書號
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        public List<DataRow> GetReportInfoByDSEQ(string DSEQ)
        {
            ConcordLogger.Logger.Debug("GetReportInfoByDSEQ開始");
            List<DataRow> list = new List<DataRow>();
            lock (_Lock)
            {
                list = _OrdReportStore.AsEnumerable()
                                      .Where(r => r.Field<string>("DSEQ").Trim() == DSEQ.Trim())
                                      .ToList();
            }
            return list;
        }
        /// <summary>
        /// 取得被動查詢資訊 by 委託書號
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        public List<DataRow> GetPasReportInfoByDSEQ(string DSEQ)
        {
            List<DataRow> list = new List<DataRow>();
            lock (_PasLock)
            {
                list = _OrdPassiveReportStore.AsEnumerable()
                                      .Where(r => r.Field<string>("DSEQ").Trim() == DSEQ.Trim())
                                      .ToList();
            }
            return list;
        }
        /// <summary>
        /// 勾單作業取得回報數查詢
        /// </summary>
        /// <param name="DSeq"></param>
        /// <returns></returns>
        public List<int> GetChkDealCount(string DSEQ, string DPRICE)
        {
            List<int> list = new List<int>();
            lock (_Lock)
            {
                var result = _OrdDealDetailStore.AsEnumerable()
                                                .Where(r => r.Field<string>("DSEQ").Trim() == DSEQ.Trim() &&
                                                            r.Field<decimal>("DealPrice").ToString("0.00") == DPRICE)
                                                .Select(r => new
                                                {
                                                    DQty = r.Field<int>("DealQty")
                                                })
                                                .ToList();
                foreach (var item in result)
                {
                    list.Add(item.DQty);
                }
            }
            list.Sort((x, y) => { return -x.CompareTo(y); });
            return list;
        }
    }
}
