﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class ViewControlInfoStore
    {
        private Dictionary<string, OrderTabViewModel> _OrderTabViewModel;
        private Dictionary<string, Dictionary<int, Control>> _OrderTabPageControlStore;

        public ViewControlInfoStore()
        {
            _OrderTabViewModel = new Dictionary<string, OrderTabViewModel>();
            _OrderTabPageControlStore = new Dictionary<string, Dictionary<int, Control>>();
        }

        public void AddTabPageInfo(string index, OrderTabViewModel ViewModelObject)
        {
            _OrderTabViewModel.Add(index, ViewModelObject);
        }

        public OrderTabViewModel GetTabPageInfo(string index)
        {
            if (!_OrderTabViewModel.ContainsKey(index))
                return null;

            return _OrderTabViewModel[index];
        }

        public void AddOrderTabPageControlStore(string index, Dictionary<int, Control> pageControl)
        {
            _OrderTabPageControlStore.Add(index, pageControl);
        }

        public Dictionary<int, Control> GetOrderTabPageControlCollection(string pageIndex)
        {
            if (_OrderTabPageControlStore.ContainsKey(pageIndex))
                return _OrderTabPageControlStore[pageIndex];

            return null;
        }

        public Control GetOrderTabPageControl(string pageIndex, int tabIndex)
        {
            if (_OrderTabPageControlStore.ContainsKey(pageIndex) && _OrderTabPageControlStore[pageIndex].ContainsKey(tabIndex))
                return _OrderTabPageControlStore[pageIndex][tabIndex];
            else
                return null;
        }
    }
}
