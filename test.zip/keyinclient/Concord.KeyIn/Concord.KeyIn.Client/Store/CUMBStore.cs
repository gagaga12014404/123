﻿using Concord.SDK.Logging;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Concord.KeyIn.Client
{
    public class CUMBStore
    {
        /// <summary>
        /// 客戶資訊集合
        /// - Key: BHNO + CSEQ
        /// - Value : 客戶資訊物件
        /// </summary>
        private static ConcurrentDictionary<string, Customer> _CustomerStore;
        
        public CUMBStore()
        {
            _CustomerStore = new ConcurrentDictionary<string, Customer>();
        }
        /// <summary>
        /// 解析資料並儲存
        /// </summary>
        /// <param name="CUMB"></param>
        public void Parser(List<string> CUMB)
        {
            foreach (string item in CUMB)
            {
                Customer cusInfo = new Customer();
                string[] info = item.Split('|');
                cusInfo.BHNO = info[0];
                cusInfo.CSEQ = info[1];
                cusInfo.IDNO = info[2];
                cusInfo.IB = info[3];
                cusInfo.SNAME = info[4];
                cusInfo.TSALE = info[5];
                cusInfo.OType = info[6];
                bool creditState = info[7].Equals("已開戶") ? true : false;
                cusInfo.CreditAccountState = creditState;
                bool DTState = info[8].Equals("已開戶") ? true : false;
                cusInfo.DTAccountState = DTState;

                if (!_CustomerStore.TryAdd(cusInfo.CSEQ, cusInfo))
                {
                    ConcordLogger.Logger.Error($"新增客戶基本資料檔錯誤 CSEQ: {cusInfo.CSEQ} {cusInfo.SNAME}");
                    continue;
                }
            }
        }
        /// <summary>
        /// 新增自營交易員帳號
        /// </summary>
        public void AddDealerAccount()
        {
            List<string> accounts = new List<string>
            {
                "0000000",
                "6666667",
                "7777777",
                "8888885",
                "8888888"
            };
            foreach (var account in accounts)
            {
                Customer cus = new Customer();
                cus.BHNO = "845T";
                cus.CSEQ = account;
                cus.CreditAccountState = false;
                cus.DTAccountState = true;
                cus.OType = "";
                _CustomerStore.TryAdd(account, cus);
            }
        }
        /// <summary>
        /// 取得所有客戶帳號
        /// </summary>
        /// <returns></returns>
        public string[] Get_CustomerStoreAll()
        {
            if (_CustomerStore.Count == 0)
                return null;

            return _CustomerStore.Keys.ToArray();
        }
        /// <summary>
        /// 取得客戶資訊物件
        /// </summary>
        /// <param name="bhno">分公司代號</param>
        /// <param name="cseq">客戶編號</param>
        /// <returns>客戶資訊物件</returns>
        public static Customer Get_CustomerInfo(string cseq)
        {
            if (cseq == null)
                return null;
            Customer info = new Customer();
            if (!_CustomerStore.ContainsKey(cseq))
                return null;
            if (!_CustomerStore.TryGetValue(cseq, out info))
                return null;

            return info;
        }

        public string Get_CCODE_Text(string code)
        {
            string CCODE = "";
            switch (code)
            {
                case "1": // 解約
                    CCODE = "[ 解約戶不可做交易 ]";
                    break;
                case "2": // 死亡
                    break;
                case "3": // 靜止
                    CCODE = "[ 靜止戶不可做交易 ]";
                    break;
                case "4": // 凍結
                    CCODE = "[ 凍結戶不可做交易 ]";
                    break;
                case "5": // 違約
                    break;
            }
            return CCODE;
        }
    }
}
