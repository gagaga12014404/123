﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    static class Program
    {
        static Mutex mutexObject = null;
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool is_createdNew ;
            mutexObject = new Mutex(true, "Global\\Concord.KeyIn.Client", out is_createdNew);
            if(!is_createdNew)
            {
                ConcordLogger.Logger.Warn("[Login] 重複啟動程式");
                frmAlert alert = new frmAlert();
                alert.ShowDialog();
                return;
            }
            Application.ThreadException += new ThreadExceptionEventHandler(UIThreadException);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

            Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.AboveNormal;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmLogin());
            GC.KeepAlive(mutexObject);
        }
        static void UIThreadException(object obj, ThreadExceptionEventArgs e)
        {
            // 濾掉當使用Debbug模式時擷取到錯誤
            if (!AppDomain.CurrentDomain.FriendlyName.EndsWith("vshost.exe"))
            {
                ConcordLogger.Logger.Error("ThreadException: " + e.Exception.ToString());
                ConcordLogger.Alert("9999", "ThreadException", e.Exception.ToString());
            }
        }
        static void CurrentDomain_UnhandledException(object obj, UnhandledExceptionEventArgs e)
        {
            ConcordLogger.Logger.Error("UnhandledException: " + (e.ExceptionObject as Exception).ToString());
            ConcordLogger.Alert("9999", "UnhandledException", (e.ExceptionObject as Exception).ToString());
        }
    }
}
