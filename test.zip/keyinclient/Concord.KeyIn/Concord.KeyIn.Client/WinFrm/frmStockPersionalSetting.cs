﻿using System;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmStockPersionalSetting : Form
    {
        /// <summary>
        /// 通知個人設定異動
        /// </summary>
        public Action<PersonalSetting> ChangePersonalSetting;

        public frmStockPersionalSetting()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 初始化個人設定
        /// </summary>
        /// <param name="setting"></param>
        public void Init(PersonalSetting setting)
        {
            chbSP01.Checked = setting.ORDER_SUCCESS_CLEAR;
            chbSP02.Checked = setting.ORDER_PRICE_COVERED_ENABLE;
            TxbOrdPriceRiseTick.Text = setting.ORDER_PRICE_RISE_TICK_VALUE;
            TxbOrdPriceFallTick.Text = setting.ORDER_PRICE_FALL_TICK_VALUE;
            chbSP03.Checked = setting.FIXED_CSEQ_ENABLE;
            chbSP03_rdbOType.Checked = setting.FIXED_CSEQ_INIT_OTYPE;
            chbSP03_rdbStock.Checked = setting.FIXED_CSEQ_INIT_STOCK;
            chbSP05.Checked = setting.STOCK_DETAIL_INFO_ENABLE;
        }
        /// <summary>
        /// 異動個人設定值
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            PersonalSetting setting = new PersonalSetting();
            setting.ORDER_SUCCESS_CLEAR = chbSP01.Checked;
            setting.ORDER_PRICE_COVERED_ENABLE = chbSP02.Checked;
            setting.ORDER_PRICE_RISE_TICK_VALUE = TxbOrdPriceRiseTick.Text;
            setting.ORDER_PRICE_FALL_TICK_VALUE = TxbOrdPriceFallTick.Text;
            setting.FIXED_CSEQ_ENABLE = chbSP03.Checked;
            setting.FIXED_CSEQ_INIT_OTYPE = chbSP03_rdbOType.Checked;
            setting.FIXED_CSEQ_INIT_STOCK = chbSP03_rdbStock.Checked;
            setting.STOCK_DETAIL_INFO_ENABLE = chbSP05.Checked;
            ChangePersonalSetting(setting);
            Hide();
        }
        private void frmStockPersionalSetting_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }

        private void chbSP03_CheckedChanged(object sender, EventArgs e)
        {
            if (chbSP03.Checked && !chbSP03_rdbOType.Checked && !chbSP03_rdbStock.Checked)
                chbSP03_rdbStock.Checked = true;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var form = new frmCrDbQtyHelpPage();
            form.ShowDialog();
        }
    }
}
