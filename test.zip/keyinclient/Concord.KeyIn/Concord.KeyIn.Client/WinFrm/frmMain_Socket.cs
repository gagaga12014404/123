﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Timers;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Socket

        #region Stock Order Gateway Session
        private void OnOrderConnected()
        {
            ConcordLogger.Logger.Info("[SOrdSession] 連線成功");
            Invoke((Action)(() =>
            {
                RL_LabOrdErrMsg.Visible = false;
                OD_LabOrdErrMsg.Visible = false;
                FP_LabOrdErrMsg.Visible = false;
                SB_LabOrdErrMsg.Visible = false;
                tslSOrderSend.Text = "上市櫃下單連線成功";
                tslSOrderSend.ForeColor = Color.Green;
            }));
        }
        private void OnOrderConnectFail(string failMsg)
        {
            ConcordLogger.Logger.Error("[SOrdSession] 連線失敗");
            Invoke((Action)(() =>
            {
                RL_LabOrdErrMsg.Visible = true;
                OD_LabOrdErrMsg.Visible = true;
                FP_LabOrdErrMsg.Visible = true;
                SB_LabOrdErrMsg.Visible = true;
                tslSOrderSend.Text = "上市櫃下單連線失敗";
                tslSOrderSend.ForeColor = Color.Red;
            }));
        }
        private void OnReceveivedOrdSendGW(string message)
        {
            ConcordLogger.Logger.Info($"[SOrdSession] 收到:{message}");
            Dictionary<int, string> SOorderSessionMsg = SocketSessionHandler.ParserMessageToDic(message, '|');
            if (!SOorderSessionMsg.ContainsKey(35))
            {
                ConcordLogger.Logger.Error($"[SOrderSession] 接收錯誤格式訊息: {message}");
                return;
            }


            switch (SOorderSessionMsg[35])
            {
                case "0": // 心跳訊息
                    break;
                case "8": // 網單電文
                    Order order = new Order();
                    if (!_OrderStore._OrdNetNoMap.TryRemove(SOorderSessionMsg[20103], out order))
                    {
                        ConcordLogger.Logger.Error($"收到未符合之網單電文:{message}");
                        return;
                    }
                    ConcordLogger.Logger.Debug($"收到網單電文 委託書號：{order.DSEQ}");
                    Report info = new Report();
                    info.ExecType = order.ExecType;
                    info.MsgType = order.ExecType;
                    info.TransactTime = string.Format("{0}", SOorderSessionMsg[52].Substring(9, 8));
                    info.DSEQ = order.DSEQ;
                    info.ClOrdID = SOorderSessionMsg[11];
                    info.OrigClOrdID = SOorderSessionMsg[11];
                    info.BHNO = UserInfo._BHNO;
                    info.CSEQ = order.CSEQ;
                    info.Stock = order.Symbol;
                    StockInfo stockInfo = STMBStore.Get_SymbolInfo(order.Symbol);
                    if (stockInfo != null)
                        info.StockName = stockInfo.CNAME;
                    info.Side = order.Side.ToString() == "BUY" ? "B" : "S";
                    info.OrdType = order.OrdType;
                    info.TimeInForce = order.TimeInForce;
                    info.ECode = order.ECode;
                    info.OType = order.OType;
                    info.OrdPrice = order.OrdPrice;
                    info.BeforeChangeQty = 0;
                    info.AfterChangeQty = (info.ECode == "2" || info.ECode == "7") ? order.OrdQty : order.OrdQty * 1000;
                    info.Text = SOorderSessionMsg[58];
                    info.Status = "送出";
                    info.Sale = order.Sale;
                    ConcordLogger.Logger.Debug($"網單電文 委託書號：{order.DSEQ}Enqueue");
                    _OrderStore._KeyInOrderQueue.Enqueue(info);
                    break;
                default:
                    ConcordLogger.Logger.Warn($"[SOrderSession] 接收至不明類別訊息: {message}");
                    break;
            }
        }
        private void OnSendToOrdSendGW(string message)
        {
            ConcordLogger.Logger.Info($"[SOrdSession] 送出:{message}");
        }
        private void OnSendToOrdSendGWFail(string message)
        {
            ConcordLogger.Logger.Info($"[SOrdSession] 送出失敗:{message}");
        }
        #endregion

        #region Stock Push Gateway Session
        private void OnPushConnected()
        {
            ConcordLogger.Logger.Info("[PushSvr] 連線成功");
            string[] regCodes = { UserInfo._EMNO, UserInfo._BHNO, _ERRORACCOUNT, "*" };
            // 發出註冊電文
            _PushGWSession.SendMessage(SocketSessionHandler.ComposeSubscribeMessage(regCodes));
            BeginInvoke((Action)(() =>
            {
                tslPushServer.Text = "回報連線成功";
                tslPushServer.ForeColor = Color.Green;
                panel_Recover.Visible = true;
            }));
        }
        private void OnPushConnectFail(string socketErr)
        {
            ConcordLogger.Logger.Error("[PushSvr] 連線失敗");
            BeginInvoke((Action)(() =>
            {
                tslPushServer.Text = "回報連線失敗";
                tslPushServer.ForeColor = Color.Red;
            }));
        }
        private void OnReceivedPushGW(string message)
        {
            Dictionary<int, string> PushMsg = SocketSessionHandler.ParserMessageToDic(message, '|');
            if (!PushMsg.ContainsKey(35))
            {
                ConcordLogger.Logger.Error($"[PushSvr] 接收錯誤格式訊息: {message}");
                return;
            }
            if (message != "8=Concords|9=00005|35=0")
            {
                ConcordLogger.Logger.Info($"[PushSvr] 收到: {message}");
                switch (PushMsg[35])
                {
                    case "0":
                        break;
                    case "OrderReceive": // 委託回報相關電文
                        if (PushMsg.ContainsKey(20102))
                        {
                            Report report = _OrderStore.Parse(PushMsg[20102]);
                            if (report == null)
                                return;
                            if (report.DSEQ == null)  // 重複回報         
                                return;

                            _OrderStore._ReportQueue.Enqueue(report);

                            Report report2 = JsonConvert.DeserializeObject<Report>(JsonConvert.SerializeObject(report));
                            // 將有包含此筆委託序號且非回補之委託回報放入KeyIn明細中
                            if (_OrderStore._OrdDSEQ.ContainsKey(report.DSEQ) && PushMsg[20101] == "N")
                                _OrderStore._KeyInOrderQueue.Enqueue(report);
                        }
                        break;
                    case "LastFill":
                        BeginInvoke((Action)(() => Lab_TodayLastFill.Visible = true));
                        break;
                    case "r":  // 註冊回覆電文
                        if (PushMsg[103] == "0")
                        {
                            #region 發出回補請求
                            string[] parameters = { UserInfo._EMNO, UserInfo._BHNO, _ERRORACCOUNT, "*" };
                            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_SStockOrderRecover", parameters);
                            if (result.StatusCode != rCode.Success)
                            {
                                ConcordLogger.Logger.Error("[Init] 委成回回補請求失敗");
                            }
                            else
                            {
                                _OrderStore.Start_ProcessReport(result.Deatils[0]);
                            }
                            #endregion
                        }
                        break;
                    default:
                        ConcordLogger.Logger.Warn($"[PushSvr] 接收至不明類別訊息: {PushMsg[35]}");
                        break;
                }
            }
        }
        private void OnSendToPushGW(string message)
        {
            if (message != "8=Concords|9=00005|35=0")
                ConcordLogger.Logger.Info($"[PushSvr] 送出: {message}");
        }
        private void OnSendToPushGWFail(string message)
        {
            ConcordLogger.Logger.Info($"[PushSvr] 送出失敗: {message}");
        }
        #endregion



        #region Session Heart Beat(Timer call back event)
        private void SessionHeartbeat(object obj, ElapsedEventArgs e)
        {
            if (_SOrderSession.ClientConnectState == ConnectState.Connected)
            {
                _SOrderSession.SendMessage(SocketSessionHandler.ComposeHeartBeatMessage());
            }
            if (_PushGWSession.ClientConnectState == ConnectState.Connected)
            {
                _PushGWSession.SendMessage(SocketSessionHandler.ComposeHeartBeatMessage());
            }
            if (_TradingSystemSession.ClientConnectState == ConnectState.Connected)
            {
                _TradingSystemSession.SendMessage(TradingSystemHandler.ComposeHeartBeatMessage());
            }
        }
        #endregion

        #region SendMessage Timer
        private void SendMessageTimer(object obj, ElapsedEventArgs e)
        {
            _SendMessage_Timer.Enabled = false;
            // MessageBox.Show("興櫃接收訊息逾時，請通知資訊部", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        #endregion

        #endregion

    }
}
