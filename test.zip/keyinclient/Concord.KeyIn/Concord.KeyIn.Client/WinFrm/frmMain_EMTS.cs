﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Trading System Event
        /// <summary>
        /// 組興櫃新單
        /// </summary>
        private Order ComposeEMNewOrder(OrderTabViewModel otvm, Side side, string orderAction)
        {
            Order order = new Order();
            order.CSEQ = otvm.CSEQ;//客戶帳號
            order.BHNO = otvm.BHNO;//分公司別
            order.DSEQ = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');//委託書號
            order.Side = side;//買or賣
            order.Symbol = otvm.Symbol.Trim();//股票
            // int qty = 0;
            // int.TryParse(EM_TxbStockQty.Text, out qty);
            int ordQty = 0;
            int.TryParse(otvm.OrderQty, out ordQty);
            order.OrdQty = ordQty;//委託數量
            if (otvm.Unit == "股")
                order.ECode = "2";
            else if (otvm.Unit == "兩")
                order.ECode = "0";
            else
            {
                order.ECode = "0";
                int unit = 1000;
                StockInfo stock = STMBStore.Get_SymbolInfo(order.Symbol.Trim());
                if (stock != null)
                {
                    int.TryParse(stock.UNIT, out unit);
                    if (stock.STYPE == "9")
                        unit = 1;
                }
                order.OrdQty *= unit;
            }
            order.Sale = otvm.Sale;//營業員
            order.OrdPrice = otvm.OrderPrice;//委託價
            order.ExecType = orderAction;//新、刪、改
            order.AllForceFlag = "N";//強行Y or N
            return order;
        }
        /// <summary>
        /// 送出興櫃刪單
        /// </summary>
        private void SendEMCancel(string dseq)
        {
            var list = _EMOrderStore.FindEmOrder(dseq);
            if (list.Count <= 0)
            {
                MessageBox.Show($"未找到對應委託單{dseq}", "刪單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Order order = _EMOrderStore.DataRowToEMOrder(list[0]);
            order.ExecType = "D";
            int LaveQty = 0;
            int.TryParse(list[0]["LaveQty"].ToString(), out LaveQty);
            if (!_EMRiskControlHandler.CheckDelete(order, LaveQty))
                return;
            if (!SendEmOrder(order))
                return;
            _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name).CancelModel = true;
        }
        /// <summary>
        /// 送出下單電文
        /// </summary>
        private bool SendEmOrder(Order order)
        {
            return SendToSocket(_TradingSystemSession.Order(order));
        }
        /// <summary>
        /// 確認與交易系統連線後送出委託
        /// </summary>
        private bool SendToSocket(string message)
        {
            if (_TradingSystemSession.ClientConnectState != ConnectState.Connected)
            {
                ConcordLogger.Logger.Error("[TradingSystem] 斷線，送單失敗");
                var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                otvm.OrdInfoText = "後台交易系統連線失敗";
                return false;
            }
            if (!_SendMessage_Timer.Enabled)
                _SendMessage_Timer.Enabled = true;
            _TradingSystemSession.SendMessage(message);
            return true;
        }
        private int EmstSearch()
        {
            int ret = 0;
            var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            string dseq = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');
            ConcordLogger.Logger.Debug($"[Query] 按下 F12查詢- Index: {tab_Order.SelectedTab.Name} DSEQ: {dseq}");
            var report = _EMOrderStore.FindEmOrder(dseq);
            if (report != null && report.Count > 0)
            {
                ConcordLogger.Logger.Debug($"[{tab_Order.SelectedTab.Name}] 查詢{dseq}");
                ShowEMstSearchInfo(report[0]);
            }
            else if (otvm.TERM == UserInfo._EMTERM)//同櫃當作新單、如果有成功下單紀錄，卻沒有回報代表狀態未明
            {
                if (_EMOrderStore._OrdDSEQ.ContainsKey(dseq))
                {
                    FocusTxb("TxbDSEQ");
                    otvm.OrdInfoText = $"未收到{dseq}委託回報(狀態未明)";
                    ConcordLogger.Logger.Debug($"[{tab_Order.SelectedTab.Name}] 未收到{dseq}委託回報(狀態未明)");
                    ret = 1;
                }
                else
                    ConcordLogger.Logger.Debug($"[Emst] 新單");
            }
            else
            {
                EmstSearchNone();
                ret = 1;
            }
            return ret;
        }
        private void OnTradingSystemConnected()
        {
            BeginInvoke((Action)(() =>
            {
                ConcordLogger.Logger.Info($"[TradingSystem] 連線成功 IP:{_TradingSystemIP}");
                _TradingSystemSession.isConnected = true;
                SendToSocket(_TradingSystemSession.Login());
                EmTradingCheck.ForeColor = Color.Green;
                EmTradingCheck.Text = "興櫃連線成功";
                if (_EMOrderStore.RecoverCompleted)
                {
                    label185.ForeColor = Color.Lime;
                    label185.Text = "[登錄正常]";
                }
            }));
        }
        private void OnTradingSystemConnectFail(string socketErr)
        {
            ConcordLogger.Logger.Error($"[TradingSystem] 連線失敗 IP:{_TradingSystemIP}");
            _TradingSystemSession.isConnected = false;
            BeginInvoke((Action)(() =>
            {
                EmTradingCheck.ForeColor = Color.Red;
                EmTradingCheck.Text = "興櫃連線失敗";
                label185.ForeColor = Color.Red;
                label185.Text = "[連線失敗]";
            }));
        }
        private void OnSendToTradingSystem(string message)
        {
            ConcordLogger.Logger.Info($"[TradingSystem] 送出: {message.Remove(message.Length - 1)}");
        }
        private void OnSendToTradingSystemFail(string message)
        {
            ConcordLogger.Logger.Info($"[TradingSystem] 送出失敗: {message}");
        }
        private void OnReceivedTradingSystem(string message)
        {
            _SendMessage_Timer.Enabled = false;//收到就停止timer
            Dictionary<int, string> fix_msg = SocketSessionHandler.ParserMessageToDic(message, '\u0001');
            if (!fix_msg.ContainsKey(35))
            {
                if (message.Substring(0, 5) == "order")
                {
                    ConcordLogger.Logger.Info($"[TradingSystem] 收到: {message}");
                    _EMOrderStore.ParseSearch(message);
                }
                else
                    ConcordLogger.Logger.Error($"[TradingSystem] 接收錯誤格式訊息: {message}");
                return;
            }
            ConcordLogger.Logger.Info($"[TradingSystem] 收到: {message}");
            try
            {
                switch (fix_msg[35])
                {
                    case "20": // 委託回報相關電文
                        {
                            Report report = _EMOrderStore.ParseReport(message);
                            if (report == null)
                                return;
                            if (UserInfo._EMNO == report.Origin)//如果這筆單是我下出去的，把此委託序號加入進去(代表之後的回報都要顯示，不管是誰再更動)
                                _EMOrderStore._OrdDSEQ.TryAdd(report.DSEQ, "");
                            if (_EMOrderStore._OrdDSEQ.ContainsKey(report.DSEQ))//自己下過的單才顯示
                                _EMOrderStore._KeyInOrderQueue.Enqueue(report);
                            _EMOrderStore._ReportQueue.Enqueue(report);
                            break;
                        }
                    case "24":  //成交回報
                        {
                            Report report = _EMOrderStore.ParseDealReport(message);
                            if (report == null)
                                return;
                            //不同櫃的成交，明細不用顯示
                            if (_EMOrderStore._OrdDSEQ.ContainsKey(report.DSEQ) &&
                                 (UserInfo._EMTERM == report.DSEQ.Substring(0, 1) || "X" == report.DSEQ.Substring(0, 1)))
                                _EMOrderStore._KeyInOrderQueue.Enqueue(report);
                            _EMOrderStore._ReportQueue.Enqueue(report);
                            break;
                        }
                    case "2":
                        {
                            _EMOrderStore.AddTmpReportByOrder(message);
                            ResetEMOrder(false);//_Setting.ORDER_SUCCESS_CLEAR
                            BeginInvoke((Action)(() =>
                            {
                                if (EM_CkbFixedCSEQ.Checked && _EMRiskControlHandler.CheckCseq)//固定委託人 && 客戶過風控
                                {
                                    FocusTxb("TxbStockNo");
                                }
                                else if (tab_Order.SelectedTab.Name == "EmstErrAccount")
                                {
                                    FocusTxb("TxbStockNo");
                                }
                                else if (_Setting.ORDER_SUCCESS_CLEAR)
                                {
                                    FocusTxb("TxbDSEQ");
                                }
                            }));
                            break;
                        }
                    case "40":
                        {
                            #region 風控錯誤
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                bool canBeForced = false;
                                canBeForced = _EMRiskControlHandler.CheckCanBeForced(fix_msg[80004], fix_msg[100]);
                                if (_EMRiskControlHandler.systemError(fix_msg[80004]))//系統錯誤，特別處理
                                {
                                    Report report = _EMOrderStore.ParseReport(message);
                                    if (report != null)
                                    {
                                        if (_EMOrderStore._OrdDSEQ.ContainsKey(report.DSEQ))
                                        {
                                            _EMOrderStore._ReportQueue.Enqueue(report);
                                            _EMOrderStore._KeyInOrderQueue.Enqueue(report);
                                        }
                                    }
                                }
                                else if (order_ViewModel.ChageQtyModel)
                                    FocusTxb("TxbStockQty");
                                else
                                    FocusTxb("TxbPrice");
                                order_ViewModel.OrdInfoText = fix_msg[80014] + (canBeForced ? " SF8強行" : "");
                                order_ViewModel.ForceBtnVisable = canBeForced;
                            }));
                            break;
                            #endregion
                        }
                    case "89":
                        {
                            #region 註冊回覆電文
                            bool loginSuccess = false;
                            string term = "";
                            if (fix_msg[80004] == "0")
                            {
                                //開啟回補Task
                                _EMOrderStore.Start_ProcessReport();
                                //117(委託書號)取得櫃號
                                if (fix_msg[117].Length >= 2)
                                {
                                    int dseq = 0;
                                    int.TryParse(fix_msg[117].Substring(1), out dseq);
                                    term = fix_msg[117].Substring(0, 1);
                                    UserInfo._EMTERM = term;
                                    _EMOrderStore.OrderNo = ++dseq;
                                    loginSuccess = true;
                                }
                            }
                            if (!loginSuccess)
                            {
                                BeginInvoke((Action)(() => label185.Text = "[登入失敗]"));
                                return;
                            }
                            SendToSocket(_TradingSystemSession.Recover($"845{UserInfo._BHNO}", term));//送出回補電文
                            BeginInvoke((Action)(() =>
                            {
                                var otvm = _ViewControlInfoStore.GetTabPageInfo("Emst");
                                if (!_EMOrderStore.RecoverCompleted)
                                {
                                    label185.ForeColor = Color.Gold;
                                    label185.Text = "[回補中...]";
                                }
                                otvm.TERM = term;
                                otvm.DSEQ = _EMOrderStore.OrderNo.ToString();
                                string thisVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString();
                                if (string.Compare(fix_msg[10005], thisVersion) == 1)//最新(正式)版本>偵測到的版本
                                {
                                    ConcordLogger.Logger.Warn($"請更新到版本:{fix_msg[10005]}");
                                }
                            }));
                            _EMOrderStore.dt1 = DateTime.Now;
                            break;
                            #endregion
                        }
                    case "300":
                        {
                            #region 客戶委檢
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (fix_msg[80004] != "0")
                                {
                                    otvm.OrdInfoText = fix_msg[80014];
                                    if (fix_msg[80004] == "1006" ||
                                       fix_msg[80004] == "1007" ||
                                       fix_msg[80004] == "1008")
                                        _EMRiskControlHandler.CheckCseq = true;
                                    else
                                        FocusTxb("TxbCSEQ");
                                }
                                else
                                {
                                    otvm.OrdInfoText = "";
                                    _EMRiskControlHandler.CheckCseq = true;
                                }
                            }));
                            break;
                            #endregion
                        }
                    case "301":
                        {
                            #region 股票委檢
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (fix_msg[80004] != "0")
                                {
                                    otvm.OrdInfoText = fix_msg[80014];
                                    FocusTxb("TxbStockNo");
                                }
                                else
                                {
                                    otvm.OrdInfoText = "";
                                    otvm.BasicPrice = fix_msg[67];
                                    _EMRiskControlHandler.GetStockNoChecked = true;
                                }
                            }));
                            break;
                            #endregion
                        }
                    case "302":
                        {
                            #region 數量委檢
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (fix_msg[80004] != "0")
                                {
                                    otvm.OrdInfoText = fix_msg[80014];
                                    FocusTxb("TxbStockQty");
                                }
                                else
                                {
                                    otvm.OrdInfoText = "";
                                    EMRiskControlHandler._OrdQtyChecked = true;
                                }
                            }));
                            break;
                            #endregion
                        }
                    case "303":
                        {
                            #region 價格委檢
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (fix_msg[80004] != "0")
                                {
                                    otvm.OrdInfoText = fix_msg[80014];
                                    FocusTxb("TxbPrice");
                                }
                                else
                                {
                                    otvm.OrdInfoText = "";
                                }
                            }));
                            break;
                            #endregion
                        }
                    default:
                        ConcordLogger.Logger.Warn($"[TradingSystem] 接收至不明類別訊息: {fix_msg[35]}");
                        break;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("興櫃接收電文訊息異常", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Error(message + "興櫃接收電文訊息異常: " + e.ToString());
                ConcordLogger.Alert("9999", message + "興櫃接收電文訊息異常", e.ToString());
            }

        }
        /// <summary>
        /// 選取指定欄位
        /// </summary>
        private void FocusTxb(string fieldName)
        {
            var Txb = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                        .Where(ctrl => ctrl.Value.Name.Contains(fieldName))
                                        .FirstOrDefault();
            Txb.Value.Focus();
            ((TextBox)Txb.Value).SelectAll();
        }
        /// <summary>
        /// 是否在興櫃頁面上
        /// </summary>
        private bool IsAtEmstTab()
        {
            if (tab_Order.SelectedTab.Name == "Emst" ||
                tab_Order.SelectedTab.Name == "EmstErrAccount")
                return true;
            return false;
        }
        /// <summary>
        /// F5清空興櫃畫面
        /// </summary>
        private void ResetEMOrder(bool clearAll)
        {
            BeginInvoke((Action)(() =>
            {
                string tabName = tab_Order.SelectedTab.Name;
                OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tabName);
                order_ViewModel.TERM = tabName == "Emst" ? UserInfo._EMTERM : "X";
                order_ViewModel.DSEQ = tabName == "Emst" ? _EMOrderStore.OrderNo.ToString() : "";
                order_ViewModel.ForceBtnVisable = false;
                order_ViewModel.OrdInfoText = "";//錯誤訊息
                if (order_ViewModel.QueryModel)//刪、改、價完固定全清除
                    clearAll = true;
                if (clearAll || _Setting.ORDER_SUCCESS_CLEAR)
                {
                    order_ViewModel.StockWarnInfo = "";
                    order_ViewModel.CancelModel = false;
                    order_ViewModel.ChagePriceModel = false;
                    order_ViewModel.ChageQtyModel = false;
                    order_ViewModel.QueryModel = false;
                    order_ViewModel.Symbol = "";        //股票代號
                    order_ViewModel.Symbol_Name = "";   //股票名稱
                    order_ViewModel.BasicPrice = "";    //基準價
                    order_ViewModel.OrderQty = "";
                    order_ViewModel.OrderPrice = "";
                    EM_BuySell.Text = "";               //買or賣
                    order_ViewModel.SearchResult = "";   //查詢結果
                    order_ViewModel.Unit = "張";
                    order_ViewModel.CCODE_Text = "";
                    order_ViewModel.QueryLaveQty = "";
                    order_ViewModel.QueryDealQty = "";
                    ChangeOrderInfoVisible(tabName, false, "B", "0");
                    _EMRiskControlHandler.ResetRiskControl();
                }
                #region 固定委託人帳號
                if (order_ViewModel.FixedCSEQ_Enable && !clearAll)//1.固定不清客戶2.F5一定清
                    FocusTxb("TxbStockNo");
                else if (_Setting.ORDER_SUCCESS_CLEAR || clearAll)
                {
                    order_ViewModel.Sale = "";//營業員
                    order_ViewModel.CSEQ = "";//客戶帳號
                    order_ViewModel.CSEQ_Name = "";//客戶名稱
                    FocusTxb(tabName == "Emst" ? "TxbDSEQ" : "TxbStockNo");
                }
                #endregion 固定委託人帳號
            }));
        }
        /// <summary>
        /// 使用DataRow將搜尋到的回報顯示在畫面
        /// </summary>
        private void ShowEMstSearchInfo(DataRow report)
        {
            if (report == null)
                return;
            BeginInvoke((Action)(() =>
            {
                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                otvm.DSEQ = report["DSEQ"].ToString().Substring(1, 4);
                otvm.CSEQ = report["CSEQ"].ToString();
                otvm.CSEQ_Name = report["CusName"].ToString();
                otvm.Symbol = report["Stock"].ToString();
                int stockQty = 0;
                int.TryParse(report["OrdQty"].ToString(), out stockQty);
                int cancelQty = 0;
                int.TryParse(report["CancelQty"].ToString(), out cancelQty);
                StockInfo stockInfo = STMBStore.Get_SymbolInfo(report["Stock"].ToString().Trim());
                int unit = 1000;
                string stype = "";
                string string_unit = "股";
                if (stockInfo != null)
                {
                    int.TryParse(stockInfo.UNIT, out unit);
                    stype = stockInfo.STYPE;
                }
                if (report["ECode"].ToString() == "整股")
                {
                    if (stype == "9")
                    {
                        otvm.Unit = "兩";
                        otvm.CancelledQty = cancelQty.ToString();
                        otvm.OrderQty = stockQty.ToString();
                        string_unit = "兩";
                    }
                    else
                    {
                        otvm.Unit = "張";
                        otvm.CancelledQty = (cancelQty / unit).ToString();
                        otvm.OrderQty = (stockQty / unit).ToString();
                    }
                }
                else
                {
                    otvm.OrderQty = stockQty.ToString();
                    otvm.Unit = "股";
                    otvm.CancelledQty = report["CancelQty"].ToString();
                }
                otvm.OrderPrice = report["OrdPrice"].ToString();
                if (tab_Order.SelectedTab.Name == "Emst")
                    EM_BuySell.Text = report["Side"].ToString();
                int LaveQty = 0, dealQty = 0;
                int.TryParse(report["LaveQty"].ToString(), out LaveQty);
                int.TryParse(report["DealQty"].ToString(), out dealQty);
                if (report["Status"].ToString() == "委託失敗")
                    otvm.OrdInfoText = report["Text"].ToString();
                else if (LaveQty <= 0 && dealQty > 0)
                    otvm.OrdInfoText = "此筆單已完全成交  F5取消  F12再查";
                else if (LaveQty <= 0 && dealQty <= 0)
                    otvm.OrdInfoText = "此筆已刪單  F5取消  F12再查";
                else
                    otvm.OrdInfoText = "[SF4 刪單  F8部份取消  F9改價  F5取消  F12再查]";
                otvm.SearchResult = "[此單已成交" + dealQty.ToString("#,0").PadLeft(10, ' ') + $"{string_unit}, 剩餘" + LaveQty.ToString("#,0").PadLeft(10, ' ') + $"{string_unit}]";
                otvm.QueryModel = true;
                otvm.QueryLaveQty = String.Format("{0:N0}", report["LaveQty"]);
                otvm.QueryDealQty = String.Format("{0:N0}", report["DealQty"]);
                ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, true, report["Side"].ToString(), report["CancelQty"].ToString());
                FocusTxb("TxbDSEQ");
            }));
        }
        /// <summary>
        /// 興櫃沒有查到跨櫃委託書號資訊
        /// </summary>
        private void EmstSearchNone()
        {
            var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            string dseq = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');
            MessageBox.Show($"{dseq}無此單資料", "查詢風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            ConcordLogger.Logger.Info($"[Emst] {dseq}無此單資料");
            BeginInvoke((Action)(() => FocusTxb("TxbDSEQ")));
        }
        #endregion Trading System Event
    }
}
