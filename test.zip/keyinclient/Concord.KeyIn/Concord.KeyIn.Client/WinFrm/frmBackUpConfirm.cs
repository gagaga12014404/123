﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmBackUpConfirm : Form
    {
        public bool _Pass = false;

        public frmBackUpConfirm()
        {
            InitializeComponent();
        }

        private void frmBackUpConfirm_Load(object sender, EventArgs e)
        {
            var response = HttpReqHandler.Get_HttpKeyInService("SYS_GetBHNOList", new string[] { });
            if (response.StatusCode != rCode.Success)
            {
                ConcordLogger.Logger.Error($"備援確認畫面取得分公司服務失敗: {response.CodeDesc}");
            }
            else
            {
                Cob_BHNO.Items.AddRange(response.Deatils.ToArray());
            }
            Cob_BHNO.SelectedIndex = 0;
        }

        private void Btn_OK_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(Cob_BHNO.SelectedItem.ToString()))
            {
                MessageBox.Show("請選擇預備援之分公司");
                return;
            }
            // 改寫原先分公司值
            string bhno = Cob_BHNO.SelectedItem.ToString().Split('|')[0];
            UserInfo._BHNO = bhno.Substring(3,1);
            _Pass = true;
            Hide();
        }

        private void frmBackUpConfirm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
    }
}
