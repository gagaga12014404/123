﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using System;
using System.Data;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region OrderEvent
        private bool DoSend(Order order, OrderTabViewModel order_ViewModel)
        {
            if (_SOrderSession.ClientConnectState != ConnectState.Connected)
            {
                ConcordLogger.Logger.Error("[Order] 和SOrderSend斷線，送單失敗");
                return false;
            }
            switch (order_ViewModel.ECode)
            {
                case "0":
                case "2":
                case "3":
                case "7":
                    if (order_ViewModel.ErrAccount_Enable)
                    {
                        order.DSEQ = _OrderHandler.GetErrAccountOrderDSEQ();
                        if (order.DSEQ == "")
                            return false;
                    }
                    else
                    {
                        order.DSEQ = _OrderHandler.GetNowDSEQ(order_ViewModel.TERM, order_ViewModel.DSEQ);
                        if (order.DSEQ == "")
                        {
                            order_ViewModel.OrdInfoText = $"委託序號: {order_ViewModel.TERM + order_ViewModel.DSEQ.PadLeft(4, '0')} 不同於自動編序號: {order_ViewModel.TERM + _OrderHandler.DSEQ.ToString().PadLeft(4, '0')} 請修正委託序號!!";
                            ShowLabInfo(tab_Order.SelectedTab.Name, true);
                            var TxbDSEQ = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                                               .Where(ctrl => ctrl.Value.Name.Contains("TxbDSEQ"))
                                                               .FirstOrDefault();
                            if (TxbDSEQ.Value != null)
                            {
                                TxbDSEQ.Value.Focus();
                                ((TextBox)TxbDSEQ.Value).SelectAll();
                            }
                            return false;
                        }
                    }
                    break;
                case "4":
                case "5":
                case "6":
                case "8":
                    order.DSEQ = _OrderHandler.GetNowFuncDSEQ(order_ViewModel.TERM, order_ViewModel.DSEQ);
                    break;
            }
            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
            _OrderStore._OrdNetNoMap.TryAdd(order.Guid, order);
            SendOut(OrderHandler.NewOrder(order), true);
            return true;
        }


        private void DoSendTimeSharing(Order order, string price, string qty, string buySell)
        {
            BeginInvoke((Action)(() =>
            {
                if (_SOrderSession.ClientConnectState != ConnectState.Connected)
                {
                    ConcordLogger.Logger.Error("[Order] 和SOrderSend斷線，送單失敗");
                    return;
                }
                Order tmp = ComposeNewOrder(order);//送過來的order還是會被影響，所以用copy constructor
                if (price == "市價")
                {
                    tmp.OrdType = "1";
                    tmp.OrdPrice = "0";
                }
                else
                {
                    tmp.OrdType = "2";
                    tmp.OrdPrice = price;
                }
                tmp.DSEQ = _OrderHandler.GetNowDSEQ();
                tmp.Guid = Guid.NewGuid().ToString();
                tmp.OrdQty = int.Parse(qty);
                tmp.Side = buySell == "買進" ? Side.BUY : Side.SELL;
                _OrderStore._OrdDSEQ.TryAdd(tmp.DSEQ, tmp.DSEQ);
                _OrderStore._OrdNetNoMap.TryAdd(tmp.Guid, tmp);
                ConcordLogger.Logger.Info($"分時分量socket送出 委託書號={tmp.DSEQ} 價={price} 量={tmp.OrdQty} 買賣={buySell}");
                SendOut(OrderHandler.NewOrder(tmp), false);
                OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                order_ViewModel.DSEQ = (int.Parse(tmp.DSEQ.Substring(1, 4)) + 1).ToString();
            }));
        }
        /// <summary>
        /// 送出新/刪單委託
        /// </summary>
        /// <param name="order"></param>
        private void SendOut(string order, bool ClearView)
        {
            _SOrderSession.SendMessage(order);
            if (ClearView)
                OrdControlClear();
        }
        /// <summary>
        /// 送出改量委託
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="ChangeQty"></param>
        private void SendOutChangeQty(DataRow report, int ChangeQty)
        {
            if (IsAtEmstTab())
            {
                Order order = _EMOrderStore.DataRowToEMOrder(report);
                order.ExecType = "C";
                order.OrdPrice = "0";//改量的價格要是0
                StockInfo stockInfo = STMBStore.Get_SymbolInfo(order.Symbol.Trim());
                int unit = 1000;
                string stype = "";
                if (stockInfo != null)
                {
                    int.TryParse(stockInfo.UNIT, out unit);
                    stype = stockInfo.STYPE;
                }
                if (order.ECode == "2" || stype == "9")//零股或黃金
                    order.OrdQty = ChangeQty;
                else
                    order.OrdQty = ChangeQty * unit;
                if (!_EMRiskControlHandler.CheckChangeQty(order, report["LaveQty"].ToString()))
                {
                    BeginInvoke((Action)(() => FocusTxb("TxbStockQty")));
                    return;
                }
                if (!SendEmOrder(order))
                    return;
            }
            else
            {
                Order changeOrd = ComposeChangeQtyObject(report, ChangeQty);
                if (changeOrd != null)
                {
                    _OrderStore._OrdDSEQ.TryAdd(changeOrd.DSEQ, changeOrd.DSEQ);
                    _OrderStore._OrdNetNoMap.TryAdd(changeOrd.Guid, changeOrd);
                    _SOrderSession.SendMessage(OrderHandler.ChangeQtyOrder(changeOrd));
                }
                OrdControlClear();
            }

        }
        /// <summary>
        /// 送出改價委託
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="price"></param>
        private void SendOutChangePrice(DataRow report, decimal price)
        {
            if (IsAtEmstTab())
            {
                Order order = _EMOrderStore.DataRowToEMOrder(report);
                if (order.OrdPrice == price.ToString())
                {
                    MessageBox.Show("改價價格相同", "改價風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                order.OrdPrice = price.ToString();
                order.OrdQty = 0;//改價的數量是0
                order.ExecType = "P";
                if (!_EMRiskControlHandler.CheckChangePrice(order, int.Parse(report["LaveQty"].ToString())))
                {
                    BeginInvoke((Action)(() => FocusTxb("TxbPrice")));
                    return;
                }
                if (!SendEmOrder(order))
                    return;
            }
            else
            {
                Order changePrice = ComposeChangePriceObject(report, price);
                if (changePrice != null)
                {
                    _OrderStore._OrdDSEQ.TryAdd(changePrice.DSEQ, changePrice.DSEQ);
                    _OrderStore._OrdNetNoMap.TryAdd(changePrice.Guid, changePrice);
                    _SOrderSession.SendMessage(OrderHandler.ChangePriceOrder(changePrice));
                }
                OrdControlClear();
            }

        }

        /// <summary>
        /// 被動送出改量委託
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="ChangeQty"></param>
        private void SendOutPasChangeQty(DataRow report, int ChangeQty)
        {
            Order changeOrd = ComposeChangeQtyObject(report, ChangeQty);
            if (changeOrd != null)
            {
                _OrderStore._OrdDSEQ.TryAdd(changeOrd.DSEQ, changeOrd.DSEQ);
                _OrderStore._OrdNetNoMap.TryAdd(changeOrd.Guid, changeOrd);
                _SOrderSession.SendMessage(OrderHandler.ChangeQtyOrder(changeOrd));
                Thread.Sleep(1500);
                PassiveSearch();
            }
            OrdControlClear();
        }
        /// <summary>
        /// 被動送出改價委託
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="price"></param>
        private void SendOutPasChangePrice(DataRow report, decimal price)
        {
            Order changePrice = ComposeChangePriceObject(report, price);
            if (changePrice != null)
            {
                _OrderStore._OrdDSEQ.TryAdd(changePrice.DSEQ, changePrice.DSEQ);
                _OrderStore._OrdNetNoMap.TryAdd(changePrice.Guid, changePrice);
                _SOrderSession.SendMessage(OrderHandler.ChangePriceOrder(changePrice));
                Thread.Sleep(1500);
                PassiveSearch();
            }
            OrdControlClear();
        }
        #endregion

    }
}
