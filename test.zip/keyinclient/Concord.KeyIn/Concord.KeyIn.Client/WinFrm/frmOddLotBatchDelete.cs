﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmOddLotBatchDelete : Form
    {
        public int _Begin = 0;
        public int _End = 0;
        public bool _Result = false;

        private List<string> _DeleteDSEQ = new List<string>();
        private bool _txtBeginParse = false;
        private bool _txtEndParse = false;

        public frmOddLotBatchDelete()
        {
            InitializeComponent();
        }

        private void frmOddLotBatchDelete_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    if (!_txtBeginParse)
                    {
                        MessageBox.Show("起始未輸入正確序號，請重新輸入");
                        txtBegin.Focus();
                        txtBegin.SelectAll();
                        _Result = false;
                        return;
                    }
                    if (!_txtEndParse)
                    {
                        MessageBox.Show("終止未輸入正確序號，請重新輸入");
                        txtBegin.Focus();
                        txtBegin.SelectAll();
                        _Result = false;
                        return;
                    }
                    _Result = true;
                    for (int i = _Begin; i <= _End; i++)
                    {
                        _DeleteDSEQ.Add(i.ToString().PadLeft(4, '0'));
                    }
                    Hide();
                    break;
                case Keys.F5:
                    _Result = false;
                    Hide();
                    break;
            }
        }

        public List<string> GetDeleteDSEQ()
        {
            if (_Result)
                return _DeleteDSEQ;
            else
                return null;
        }

        private void frmOddLotBatchDelete_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }

        private void txtBegin_TextChanged(object sender, System.EventArgs e)
        {
             if(!int.TryParse(txtBegin.Text, out _Begin))
            {
                MessageBox.Show("起始未輸入正確序號，請重新輸入");
                txtBegin.Focus();
                txtBegin.SelectAll();
                _txtBeginParse = false;
                return;
            }
            _txtBeginParse = true;
        }

        private void txtEnd_TextChanged(object sender, System.EventArgs e)
        {
            if (!int.TryParse(txtEnd.Text, out _End))
            {
                MessageBox.Show("終止未輸入正確序號，請重新輸入");
                txtEnd.Focus();
                txtEnd.SelectAll();
                _txtEndParse = false;
                return;
            }
            _txtEndParse = true;
        }

        private void frmOddLotBatchDelete_Shown(object sender, System.EventArgs e)
        {
            txtBegin.Text = "0";
            txtEnd.Text = "0";
            txtBegin.Focus();
            txtBegin.SelectAll();
            _txtBeginParse = false;
            _txtEndParse = false;
            _Result = false;
        }
    }
}
