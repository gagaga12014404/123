﻿namespace Concord.KeyIn.Client
{
    partial class frmTimeSharing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_start = new System.Windows.Forms.TextBox();
            this.txb_totalDivideBySingle = new System.Windows.Forms.TextBox();
            this.txb_each = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_getNow = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_buy = new System.Windows.Forms.Button();
            this.btn_sell = new System.Windows.Forms.Button();
            this.txb_single = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_total = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_cseq = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_cseqName = new System.Windows.Forms.Label();
            this.txb_stock = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_stockName = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txb_ROD = new System.Windows.Forms.TextBox();
            this.txb_otype = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txb_price = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.colCancel = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txb_start
            // 
            this.txb_start.Location = new System.Drawing.Point(498, 87);
            this.txb_start.Margin = new System.Windows.Forms.Padding(4);
            this.txb_start.Name = "txb_start";
            this.txb_start.Size = new System.Drawing.Size(89, 27);
            this.txb_start.TabIndex = 103;
            this.txb_start.Click += new System.EventHandler(this.txb_start_Click);
            this.txb_start.TextChanged += new System.EventHandler(this.txb_start_TextChanged);
            // 
            // txb_totalDivideBySingle
            // 
            this.txb_totalDivideBySingle.Location = new System.Drawing.Point(774, 87);
            this.txb_totalDivideBySingle.Margin = new System.Windows.Forms.Padding(4);
            this.txb_totalDivideBySingle.Name = "txb_totalDivideBySingle";
            this.txb_totalDivideBySingle.ReadOnly = true;
            this.txb_totalDivideBySingle.Size = new System.Drawing.Size(79, 27);
            this.txb_totalDivideBySingle.TabIndex = 0;
            this.txb_totalDivideBySingle.TextChanged += new System.EventHandler(this.txb_totalDivideBySingle_TextChanged);
            // 
            // txb_each
            // 
            this.txb_each.Location = new System.Drawing.Point(642, 87);
            this.txb_each.Margin = new System.Windows.Forms.Padding(4);
            this.txb_each.Name = "txb_each";
            this.txb_each.Size = new System.Drawing.Size(56, 27);
            this.txb_each.TabIndex = 104;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(457, 92);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "開始:";
            // 
            // lbl_getNow
            // 
            this.lbl_getNow.AutoSize = true;
            this.lbl_getNow.Font = new System.Drawing.Font("新細明體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_getNow.Location = new System.Drawing.Point(466, 66);
            this.lbl_getNow.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_getNow.Name = "lbl_getNow";
            this.lbl_getNow.Size = new System.Drawing.Size(134, 16);
            this.lbl_getNow.TabIndex = 1;
            this.lbl_getNow.Text = "時間(HH:MM:SS)";
            this.lbl_getNow.Click += new System.EventHandler(this.lbl_getNow_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(731, 92);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "筆數:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(599, 92);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "間隔:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCancel,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dataGridView1.Location = new System.Drawing.Point(0, 204);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(882, 234);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column22,
            this.Column23,
            this.Column24});
            this.dataGridView2.Location = new System.Drawing.Point(0, 448);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(882, 201);
            this.dataGridView2.TabIndex = 2;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "number";
            this.Column15.HeaderText = "編號";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "buySell";
            this.Column16.HeaderText = "買/賣";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "cseq";
            this.Column17.HeaderText = "客戶帳號";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "cseqName";
            this.Column18.HeaderText = "客戶姓名";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "stock";
            this.Column19.HeaderText = "股票代碼";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "stockName";
            this.Column20.HeaderText = "股票名稱";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "orderPrice";
            this.Column21.HeaderText = "委託價";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "orderQty";
            this.Column22.HeaderText = "委託量";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "orderTime";
            this.Column23.HeaderText = "下單時間";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "status";
            this.Column24.HeaderText = "狀態";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(699, 92);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "秒";
            // 
            // btn_buy
            // 
            this.btn_buy.ForeColor = System.Drawing.Color.Red;
            this.btn_buy.Location = new System.Drawing.Point(17, 146);
            this.btn_buy.Margin = new System.Windows.Forms.Padding(4);
            this.btn_buy.Name = "btn_buy";
            this.btn_buy.Size = new System.Drawing.Size(112, 31);
            this.btn_buy.TabIndex = 105;
            this.btn_buy.Text = "買進";
            this.btn_buy.UseVisualStyleBackColor = true;
            this.btn_buy.Click += new System.EventHandler(this.btn_buy_Click);
            // 
            // btn_sell
            // 
            this.btn_sell.ForeColor = System.Drawing.Color.ForestGreen;
            this.btn_sell.Location = new System.Drawing.Point(741, 146);
            this.btn_sell.Margin = new System.Windows.Forms.Padding(4);
            this.btn_sell.Name = "btn_sell";
            this.btn_sell.Size = new System.Drawing.Size(112, 31);
            this.btn_sell.TabIndex = 106;
            this.btn_sell.Text = "賣出";
            this.btn_sell.UseVisualStyleBackColor = true;
            this.btn_sell.Click += new System.EventHandler(this.btn_sell_Click);
            // 
            // txb_single
            // 
            this.txb_single.Location = new System.Drawing.Point(357, 87);
            this.txb_single.Margin = new System.Windows.Forms.Padding(4);
            this.txb_single.Name = "txb_single";
            this.txb_single.Size = new System.Drawing.Size(79, 27);
            this.txb_single.TabIndex = 102;
            this.txb_single.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(316, 92);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "單量:";
            // 
            // txb_total
            // 
            this.txb_total.Location = new System.Drawing.Point(225, 87);
            this.txb_total.Margin = new System.Windows.Forms.Padding(4);
            this.txb_total.Name = "txb_total";
            this.txb_total.Size = new System.Drawing.Size(79, 27);
            this.txb_total.TabIndex = 101;
            this.txb_total.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(184, 92);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "總量:";
            // 
            // txb_cseq
            // 
            this.txb_cseq.Location = new System.Drawing.Point(67, 21);
            this.txb_cseq.Margin = new System.Windows.Forms.Padding(4);
            this.txb_cseq.Name = "txb_cseq";
            this.txb_cseq.ReadOnly = true;
            this.txb_cseq.Size = new System.Drawing.Size(90, 27);
            this.txb_cseq.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 25);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "帳號：";
            // 
            // lbl_cseqName
            // 
            this.lbl_cseqName.AutoSize = true;
            this.lbl_cseqName.Location = new System.Drawing.Point(160, 25);
            this.lbl_cseqName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cseqName.Name = "lbl_cseqName";
            this.lbl_cseqName.Size = new System.Drawing.Size(72, 16);
            this.lbl_cseqName.TabIndex = 1;
            this.lbl_cseqName.Text = "客戶名稱";
            // 
            // txb_stock
            // 
            this.txb_stock.Location = new System.Drawing.Point(527, 21);
            this.txb_stock.Margin = new System.Windows.Forms.Padding(4);
            this.txb_stock.Name = "txb_stock";
            this.txb_stock.ReadOnly = true;
            this.txb_stock.Size = new System.Drawing.Size(90, 27);
            this.txb_stock.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(439, 25);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "股票代碼：";
            // 
            // lbl_stockName
            // 
            this.lbl_stockName.AutoSize = true;
            this.lbl_stockName.Location = new System.Drawing.Point(621, 25);
            this.lbl_stockName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_stockName.Name = "lbl_stockName";
            this.lbl_stockName.Size = new System.Drawing.Size(72, 16);
            this.lbl_stockName.TabIndex = 1;
            this.lbl_stockName.Text = "股票名稱";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(225, 66);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "委託量(張)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(245, 25);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "委託類別：";
            // 
            // txb_ROD
            // 
            this.txb_ROD.Location = new System.Drawing.Point(330, 21);
            this.txb_ROD.Margin = new System.Windows.Forms.Padding(4);
            this.txb_ROD.Name = "txb_ROD";
            this.txb_ROD.ReadOnly = true;
            this.txb_ROD.Size = new System.Drawing.Size(90, 27);
            this.txb_ROD.TabIndex = 0;
            // 
            // txb_otype
            // 
            this.txb_otype.Location = new System.Drawing.Point(763, 21);
            this.txb_otype.Margin = new System.Windows.Forms.Padding(4);
            this.txb_otype.Name = "txb_otype";
            this.txb_otype.ReadOnly = true;
            this.txb_otype.Size = new System.Drawing.Size(90, 27);
            this.txb_otype.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(709, 25);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "類別：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "委託價:";
            // 
            // txb_price
            // 
            this.txb_price.Location = new System.Drawing.Point(72, 87);
            this.txb_price.Name = "txb_price";
            this.txb_price.Size = new System.Drawing.Size(100, 27);
            this.txb_price.TabIndex = 100;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txb_cseq);
            this.panel1.Controls.Add(this.txb_total);
            this.panel1.Controls.Add(this.txb_single);
            this.panel1.Controls.Add(this.txb_start);
            this.panel1.Controls.Add(this.btn_sell);
            this.panel1.Controls.Add(this.txb_price);
            this.panel1.Controls.Add(this.txb_stock);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txb_otype);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txb_totalDivideBySingle);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txb_each);
            this.panel1.Controls.Add(this.lbl_cseqName);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txb_ROD);
            this.panel1.Controls.Add(this.lbl_stockName);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.btn_buy);
            this.panel1.Controls.Add(this.lbl_getNow);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(882, 195);
            this.panel1.TabIndex = 6;
            // 
            // colCancel
            // 
            this.colCancel.DataPropertyName = "Cancel";
            this.colCancel.HeaderText = "";
            this.colCancel.Name = "colCancel";
            this.colCancel.ReadOnly = true;
            this.colCancel.Width = 70;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "buySell";
            this.Column1.HeaderText = "買/賣";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "cseq";
            this.Column2.HeaderText = "客戶帳號";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "cseqName";
            this.Column3.HeaderText = "客戶姓名";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "stock";
            this.Column4.HeaderText = "股票代碼";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "stockName";
            this.Column5.HeaderText = "股票名稱";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "orderPrice";
            this.Column6.HeaderText = "委託價";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "submitCount";
            this.Column7.HeaderText = "送出量";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "total";
            this.Column8.HeaderText = "總量";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "deleteCount";
            this.Column9.HeaderText = "刪除量";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "start";
            this.Column10.HeaderText = "策略開始時";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "end";
            this.Column11.HeaderText = "策略結束時";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "number";
            this.Column12.HeaderText = "策略編號";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "status";
            this.Column13.HeaderText = "狀態";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "ROD";
            this.Column14.HeaderText = "委託別";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // frmTimeSharing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 653);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmTimeSharing";
            this.Text = "分時分量";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTimeSharing_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txb_start;
        private System.Windows.Forms.TextBox txb_totalDivideBySingle;
        private System.Windows.Forms.TextBox txb_each;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_getNow;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_buy;
        private System.Windows.Forms.Button btn_sell;
        private System.Windows.Forms.TextBox txb_single;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txb_total;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_cseq;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_cseqName;
        private System.Windows.Forms.TextBox txb_stock;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_stockName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txb_ROD;
        private System.Windows.Forms.TextBox txb_otype;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txb_price;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewButtonColumn colCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
    }
}