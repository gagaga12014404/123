﻿namespace Concord.KeyIn.Client
{
    partial class frmOddLotBatchOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtOrdCount = new System.Windows.Forms.TextBox();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "請輸入欲連續下單筆數 ：";
            // 
            // txtOrdCount
            // 
            this.txtOrdCount.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtOrdCount.Location = new System.Drawing.Point(194, 17);
            this.txtOrdCount.MaxLength = 6;
            this.txtOrdCount.Name = "txtOrdCount";
            this.txtOrdCount.Size = new System.Drawing.Size(75, 27);
            this.txtOrdCount.TabIndex = 1;
            this.txtOrdCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrdCount.TextChanged += new System.EventHandler(this.txtOrdCount_TextChanged);
            // 
            // btnCheck
            // 
            this.btnCheck.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCheck.Location = new System.Drawing.Point(16, 57);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(90, 30);
            this.btnCheck.TabIndex = 2;
            this.btnCheck.Text = "確認 (F4)";
            this.btnCheck.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Location = new System.Drawing.Point(165, 57);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(104, 30);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "取消 (F5)";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmOddLotBatchOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 99);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.txtOrdCount);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.Name = "frmOddLotBatchOrder";
            this.Text = "零股批次下單確認";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOddLotBatchOrder_FormClosing);
            this.Shown += new System.EventHandler(this.frmOddLotBatchOrder_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmOddLotBatchOrder_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOrdCount;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnCancel;
    }
}