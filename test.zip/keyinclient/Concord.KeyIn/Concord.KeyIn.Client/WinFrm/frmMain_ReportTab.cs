﻿using Concord.SDK.Logging;
using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region 回報 Tab

        /// <summary>
        /// 切換報頁籤索引事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_Request_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tab_Request.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    if (IsAtEmstTab())
                        DGVEmstRequest_RowsUpdate();
                    else
                        DGVRequest_RowsUpdate();
                    txbFilterCSEQ.Focus();
                    break;
                case 2:
                    Btn_QueryDeal_Click(sender, e); // 查詢
                    rdbRL.Checked = true;
                    DGVCheckDeal.Focus();
                    break;
            }
        }

        #region KeyIn明細畫面控制項

        private void AddKeyInOrd(DataRow dr)
        {
            try
            {
                if (DGVKeyIn.InvokeRequired)
                {
                    var safeDelegate = new dlgAddKeyInReport(AddKeyInOrd);
                    Invoke(safeDelegate, new object[] { dr });
                }
                else
                {
                    lock (OrderStore._KeyInOrderLock)
                    {
                        _OrderStore._KeyInDetailStore.Rows.Add(dr);
                        ConcordLogger.Logger.Debug($"main keyin明細 新增成功 委託書號：{dr["DSEQ"].ToString()}");
                    }
                    //DGVKeyIn.Refresh();
                    if (DGVKeyIn.Rows.Count > 0)//防呆
                        DGVKeyIn.CurrentCell = DGVKeyIn.Rows[0].Cells[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("KeyIn明細發生異常無法更新資料，請重登KeyIn來確認新單是否已送出!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Error("AddKeyInOrd 發生異常: " + ex.ToString());
                ConcordLogger.Alert("9999", "Client端 AddKeyInOrd 異常", ex.ToString());
            }
        }
        private void DGVKeyIn_RowUpdate(Report report)
        {
            try
            {
                if (DGVKeyIn.InvokeRequired)
                {
                    var safeDelegate = new dlgUpdateKeyInReport(DGVKeyIn_RowUpdate);
                    Invoke(safeDelegate, new object[] { report });
                }
                else
                {
                    object[] key = { report.DSEQ, report.ClOrdID };
                    lock (OrderStore._KeyInOrderLock)
                    {
                        ConcordLogger.Logger.Debug($"main KeyIn明細 更新回報 委託書號：{report.DSEQ} 新刪改：" + report.ExecType + " 數量：" + report.OrdQty + " 狀態：" + report.Status + " 回報時間：" + report.TransactTime);
                        DataRow origRow = _OrderStore._KeyInDetailStore.Rows.Find(key);
                        origRow["ECode"] = report.ECode;
                        origRow["Status"] = "成功";
                        int BefChangQty = (report.ECode != "2" && report.ECode != "7") ? report.BeforeChangeQty / 1000 : report.BeforeChangeQty;
                        int OrdQty = (report.ECode != "2" && report.ECode != "7") ? report.OrdQty / 1000 : report.OrdQty; ;
                        switch (report.ExecType)
                        {
                            case "0":  // 委託成功
                                origRow["TransactTime"] = report.TransactTime;
                                origRow["OrdQty"] = OrdQty;
                                origRow["OrdPrice"] = report.OrdPrice;
                                origRow["Text"] = report.Text;
                                break;
                            case "4":  // 刪單成功
                                       //origRow["BeforeChangeQty"] = BefChangQty;
                                origRow["OrdQty"] = OrdQty;
                                origRow["OrdPrice"] = report.OrdPrice;
                                break;
                            case "5":  // 改量成功
                                origRow["BeforeChangeQty"] = BefChangQty;
                                origRow["OrdPrice"] = report.OrdPrice;
                                origRow["OrdQty"] = OrdQty;
                                break;
                            case "M":  // 改價成功
                                origRow["OrdQty"] = BefChangQty; // 改價改為用改前數量放置委託數量欄位
                                origRow["OrdPrice"] = report.OrdPrice;
                                break;
                            case "F":  // 成交單
                                int deal = (report.ECode != "2" && report.ECode != "7") ? report.DealQty / 1000 : report.DealQty;
                                int origDeal = 0;
                                int.TryParse(origRow["DealQty"].ToString(), out origDeal);
                                origRow["DealQty"] = origDeal + deal;
                                break;
                            case "8":  // 失敗單
                                origRow["BeforeChangeQty"] = BefChangQty;
                                origRow["OrdQty"] = OrdQty;
                                origRow["OrdPrice"] = report.OrdPrice;
                                origRow["Status"] = "失敗";
                                origRow["Text"] = report.Text;
                                break;
                        }
                        origRow.AcceptChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("KeyIn明細發生異常無法更新資料，請重登KeyIn來確認委託單狀態!", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Error("DGVKeyIn_RowUpdate 發生異常: " + ex.ToString());
                ConcordLogger.Alert("9999", "Client端 DGVKeyIn_RowUpdate 異常", ex.ToString());
            }

        }
        private void DGVKeyIn_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null)
                e.Value = "";
            switch (DGVKeyIn.Columns[e.ColumnIndex].Name)
            {
                case "colCDI":
                    if (e.Value.ToString() == "I")
                        e.Value = "";
                    break;
                case "colSide_KeyIn":
                    if (e.Value.ToString() == "B")
                    {
                        DGVKeyIn.Rows[e.RowIndex].Cells["colSide_KeyIn"].Style.ForeColor = Color.Red;
                        DGVKeyIn.Rows[e.RowIndex].Cells["colSide_KeyIn"].Style.SelectionForeColor = Color.Red;
                    }
                    break;
                case "colBefChgQty_KeyIn":
                case "colOrdQty_KeyIn":
                    if (e.Value.ToString() == "0")
                        e.Value = "";
                    break;
                case "colDealQty_KeyIn":
                    if (e.Value.ToString() == "0")
                        e.Value = "";
                    else
                        e.Value = $"( {e.Value} )";
                    break;
                case "colStatus_KeyIn":
                    if (e.Value.ToString() == "失敗")
                    {
                        DGVKeyIn.Rows[e.RowIndex].Cells["colStatus_KeyIn"].Style.ForeColor = Color.Red;
                        DGVKeyIn.Rows[e.RowIndex].Cells["colStatus_KeyIn"].Style.SelectionForeColor = Color.Red;
                    }
                    break;
            }
        }
        private void AddEmstKeyInOrder(DataRow dr)
        {
            if (DGVEmstOrder.InvokeRequired)
            {
                Invoke(new EMdlgAddKeyInReport(AddEmstKeyInOrder), new object[] { dr });
            }
            else
            {
                lock (EMOrderStore._KeyInOrderLock)
                {
                    _EMOrderStore._KeyInDetailStore.Rows.InsertAt(dr, 0);
                    if (DGVEmstOrder.RowCount > 0)
                        DGVEmstOrder.CurrentCell = DGVEmstOrder.Rows[0].Cells[0];//讓畫面跳到第0筆
                    ConcordLogger.Logger.Debug($"[Emst] {dr["dseq"]} {dr["ClOrdID"]} 加入明細成功");
                }
            }
        }
        private void DGVEmstOrder_RowUpdate(Report report)
        {
            if (DGVEmstOrder.InvokeRequired)
            {
                var safeDelegate = new EMdlgUpdateKeyInReport(DGVEmstOrder_RowUpdate);
                Invoke(safeDelegate, new object[] { report });
            }
            else
            {
                lock (EMOrderStore._KeyInOrderLock)
                {
                    object[] key = { report.DSEQ, report.ClOrdID };
                    DataRow dr = _EMOrderStore._KeyInDetailStore.Rows.Find(key);
                    if (report.ExecType == "F")
                    {
                        int int_dealQty;
                        int.TryParse(dr["DealQty"].ToString(), out int_dealQty);
                        dr["DealQty"] = int_dealQty + report.DealQty;
                        ConcordLogger.Logger.Debug($"[Emst] {report.DSEQ} 更新KeyIn明細成交回報成功");
                    }
                    else
                    {
                        dr["Side"] = report.Side;
                        dr["ECode"] = report.ECode == "2" ? "零股" : "整股";
                        dr["OrdQty"] = report.OrdQty;
                        dr["OrdPrice"] = report.OrdPrice;
                        dr["Status"] = report.Status == "0" ? "成功" : "失敗";
                        dr["Text"] = report.Text;
                        ConcordLogger.Logger.Debug($"[Emst] {report.DSEQ} 更新KeyIn明細委託回報成功");
                    }
                    dr.AcceptChanges();
                }
            }
        }

        #endregion

        #region 委託回報畫面控制項
        private void AddEmstReport(DataRow dr)
        {
            Invoke((Action)(() =>
            {
                lock (EMOrderStore._Lock)
                {
                    EMOrderStore._OrdReportStore.Rows.Add(dr);
                }
            }));
        }
        /// <summary>
        /// 重繪回報畫面(興櫃)
        /// </summary>
        private void DGVEmstRequest_RowsUpdate()
        {
            Invoke((Action)(() =>
            {
                // 若畫面沒選在"委託回報"、"興櫃"、"興櫃錯帳"頁面時不更新
                if (tab_Request.SelectedIndex != 1 || !IsAtEmstTab())
                    return;
                int OrdQty = 0, outOrdQty = 0, DealQty = 0, outDealQty = 0, outCancelQty = 0;
                decimal OrdPrice = 0, outOrdPrice = 0, DealPrice = 0, outDealPrice = 0;//金額用decimal
                foreach (DataGridViewRow row in DGVEmstRequest.Rows)
                {
                    if (row == null)
                        continue;
                    //利用info存股票名字與客戶名字
                    // row.Cells["colEmStockName"].Value = stock.CNAME;

                    //買賣別顏色
                    if (row.Cells["colEmSide"].EditedFormattedValue.ToString() == "B")
                        row.Cells["colEmSide"].Style.ForeColor = Color.Red;
                    else
                        row.Cells["colEmSide"].Style.ForeColor = Color.DodgerBlue;
                    //轉換筆數、股數、金額給下面計算用
                    if (row.Cells["colEmOrdQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colEmOrdQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out outOrdQty);
                    if (row.Cells["colEmOrdPrice"].EditedFormattedValue != null)
                        decimal.TryParse(row.Cells["colEmOrdPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out outOrdPrice);
                    if (row.Cells["colEmDealQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colEmDealQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out outDealQty);
                    if (row.Cells["colEmDealPrice"].EditedFormattedValue != null)
                        decimal.TryParse(row.Cells["colEmDealPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out outDealPrice);
                    if (row.Cells["colEmCancelQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colEmCancelQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out outCancelQty);
                    //計算筆數、股數、金額
                    OrdQty += outOrdQty - outCancelQty;
                    OrdPrice += outOrdPrice * (outOrdQty - outCancelQty);
                    DealQty += outDealQty;
                    DealPrice += outDealPrice * outDealQty;
                    //刪量價button顯示or隱藏
                    if ((outOrdQty - outCancelQty) - outDealQty <= 0)
                    {
                        row.Cells["colEmDeleteBtn"].Dispose();
                        row.Cells["colEmDeleteBtn"] = new DataGridViewTextBoxCell();
                        row.Cells["colEmChangeQtyBtn"].Dispose();
                        row.Cells["colEmChangeQtyBtn"] = new DataGridViewTextBoxCell();
                        row.Cells["colEmChangePriceBtn"].Dispose();
                        row.Cells["colEmChangePriceBtn"] = new DataGridViewTextBoxCell();
                        row.Cells["colEmCheckDelete"].Value = false;
                        row.Cells["colEmCheckDelete"].ReadOnly = true;
                    }

                }
                labCount.Text = $"筆數：{DGVEmstRequest.Rows.Count.ToString("N0")}";
                labRequestQty.Text = $"委託股數：{OrdQty.ToString("N0")}";
                labRequestAmt.Text = $"委託金額：{OrdPrice.ToString("N0")}";
                labDealQty.Text = $"成交股數：{DealQty.ToString("N0")}";
                labDealAmt.Text = $"成交金額：{DealPrice.ToString("N0")}";
            }));
        }
        /// <summary>
        /// 新增委託回報
        /// </summary>
        /// <param name="dr"></param>
        private void AddReport(DataRow dr)
        {
            Invoke((Action)(() =>
            {

                //DGVRequest.Refresh();

                lock (OrderStore._Lock)
                {
                    OrderStore._OrdReportStore.Rows.Add(dr);
                }
            }));
        }
        /// <summary>
        /// 重繪回報畫面
        /// </summary>
        private void DGVRequest_RowsUpdate()
        {
            Invoke((Action)(() =>
            {
                // 若畫面沒選在"委託回報"、上市櫃頁面時不更新
                if (tab_Request.SelectedIndex != 1 || IsAtEmstTab())
                    return;

                int RequestQty = 0, DealQty = 0, Order = 0, Cancel = 0, Deal = 0;
                decimal RequestAmount = 0, DealAmount = 0, OrdPrice = 0, DealPrice = 0;

                foreach (DataGridViewRow row in DGVRequest.Rows)
                {
                    if (row == null)
                        continue;
                    #region 更新買賣別顏色
                    if (row.Cells["colSide"].EditedFormattedValue.ToString() == "B")
                        row.Cells["colSide"].Style.ForeColor = Color.Red;
                    else
                        row.Cells["colSide"].Style.ForeColor = Color.DodgerBlue;

                    #endregion
                    #region 更新 刪量價 按扭欄位
                    if ((row.Cells["colStatus"].EditedFormattedValue.ToString() != "委託成功" &&
                         row.Cells["colStatus"].EditedFormattedValue.ToString() != "部份成交") ||
                         row.Cells["ColTimeInForce"].EditedFormattedValue.ToString() != "ROD")
                    {
                        row.Cells["colDeleteOrder"].Dispose();
                        row.Cells["colDeleteOrder"] = new DataGridViewTextBoxCell();
                        row.Cells["colChangeOrder"].Dispose();
                        row.Cells["colChangeOrder"] = new DataGridViewTextBoxCell();
                        row.Cells["colChangePrice"].Dispose();
                        row.Cells["colChangePrice"] = new DataGridViewTextBoxCell();
                    }
                    else
                    {
                        row.Cells["colDeleteOrder"].Dispose();
                        row.Cells["colDeleteOrder"] = new DataGridViewButtonCell();
                        row.Cells["colDeleteOrder"].Value = "刪";
                        row.Cells["colChangeOrder"].Dispose();
                        if (row.Cells["ColLaveQty"].EditedFormattedValue.ToString() == "1000" ||
                            row.Cells["ColLaveQty"].EditedFormattedValue.ToString() == "1")
                        {
                            row.Cells["colChangeOrder"].Dispose();
                            row.Cells["colChangeOrder"] = new DataGridViewTextBoxCell();
                        }
                        else
                        {
                            row.Cells["colChangeOrder"] = new DataGridViewButtonCell();
                            row.Cells["colChangeOrder"].Value = "量";
                        }
                        row.Cells["colChangePrice"].Dispose();
                        if (row.Cells["colECODE"].EditedFormattedValue.ToString() == "整股" &&
                            row.Cells["colOrdPrice"].EditedFormattedValue.ToString() != "市價")
                        {
                            row.Cells["colChangePrice"] = new DataGridViewButtonCell();
                            row.Cells["colChangePrice"].Value = "價";
                        }
                        else
                        {
                            row.Cells["colChangePrice"] = new DataGridViewTextBoxCell();
                        }
                    }
                    #endregion
                    if (row.Cells["colSTATUS"].EditedFormattedValue.ToString() == "委託失敗")
                        continue;
                    if (row.Cells["colOrdQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colOrdQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Order);
                    if (row.Cells["colCancelQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colCancelQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Cancel);
                    if (row.Cells["colDealQty"].EditedFormattedValue != null)
                        int.TryParse(row.Cells["colDealQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Deal);
                    if (row.Cells["colOrdPrice"].EditedFormattedValue != null)
                        decimal.TryParse(row.Cells["colOrdPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out OrdPrice);
                    if (row.Cells["colDealPrice"].EditedFormattedValue != null)
                        decimal.TryParse(row.Cells["colDealPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out DealPrice);
                    RequestQty += (Order - Cancel);
                    DealQty += Deal;
                    RequestAmount += (Order - Cancel) * OrdPrice; // RequestQty
                    DealAmount += Deal * DealPrice;
                }
                labCount.Text = $"筆數：{DGVRequest.Rows.Count.ToString("N0")}";
                labRequestQty.Text = $"委託股數：{RequestQty.ToString("N0")}";
                labRequestAmt.Text = $"委託金額：{RequestAmount.ToString("N0")}";
                labDealQty.Text = $"成交股數：{DealQty.ToString("N0")}";
                labDealAmt.Text = $"成交金額：{DealAmount.ToString("N0")}";
            }));
        }
        /// <summary>
        /// 委託畫面欄位點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
                return;
            string DSEQ = DGVRequest.CurrentRow.Cells["colDSEQ"].EditedFormattedValue.ToString();
            if (DSEQ.Trim() == "")
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            switch (e.ColumnIndex)
            {
                case 0: // 勾選欄位
                    bool IsChoice = (bool)DGVRequest.CurrentRow.Cells["colCheckDelete"].EditedFormattedValue;
                    DGVRequest.CurrentRow.Cells["colCheckDelete"].Value = !IsChoice;
                    break;
                case 1:
                    {
                        #region 刪單按鈕
                        ConcordLogger.Logger.Info("[Order] 刪單扭按按下");
                        Order order = ComposeDeleteObject(DSEQ);
                        if (order != null)
                        {
                            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                            _OrderStore._OrdNetNoMap.TryAdd(order.Guid, order);
                            SendOut(OrderHandler.DeleteOrder(order), true);
                        }
                        #endregion
                        break;
                    }
                case 2:
                    {
                        #region 改量按鈕
                        ConcordLogger.Logger.Info("[Order] 改量扭按按下");
                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null && report.Count > 0)
                            _FrmChangeCheck.Init("ChgQty", report[0]);
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改量錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ConcordLogger.Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
                case 3:
                    {
                        #region 改價按扭
                        ConcordLogger.Logger.Info("[Order] 改價扭按按下");
                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null && report.Count > 0)
                            _FrmChangeCheck.Init("ChgPrice", report[0]);
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改價錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ConcordLogger.Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
            }
        }
        /// <summary>
        /// 委託畫面欄位點擊事件(興櫃)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVEmstRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
                return;
            string DSEQ = DGVEmstRequest.CurrentRow.Cells["colEmDSEQ"].EditedFormattedValue.ToString();
            if (DSEQ.Trim() == "")
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            var list = _EMOrderStore.FindEmOrder(DSEQ);
            if (list.Count <= 0)
            {
                MessageBox.Show("未找到對應委託資訊", "委託回報畫面錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                return;
            }
            switch (e.ColumnIndex)
            {
                case 0: // 勾選欄位
                    {
                        if ((int)list[0]["LaveQty"] > 0)//checkbox 是readonly，用此方式強制勾選
                        {
                            bool IsChoice = (bool)DGVEmstRequest.CurrentRow.Cells["colEmCheckDelete"].EditedFormattedValue;
                            DGVEmstRequest.CurrentRow.Cells["colEmCheckDelete"].Value = !IsChoice;
                        }
                        break;
                    }
                case 1:
                    {
                        #region 刪單按鈕
                        ConcordLogger.Logger.Info("[Order] 刪單扭按按下");
                        SendEMCancel(DSEQ);
                        #endregion
                        break;
                    }
                case 2:
                    {
                        #region 改量按鈕
                        ConcordLogger.Logger.Info("[Order] 改量扭按按下");
                        _FrmChangeCheck.Init("ChgQty", list[0]);
                        #endregion
                        break;
                    }
                case 3:
                    {
                        #region 改價按扭
                        ConcordLogger.Logger.Info("[Order] 改價扭按按下");
                        _FrmChangeCheck.Init("ChgPrice", list[0]);
                        #endregion
                        break;
                    }
            }
        }
        private void DGVRequest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.CellStyle.SelectionForeColor != e.CellStyle.ForeColor)
            {
                e.CellStyle.SelectionForeColor = e.CellStyle.ForeColor;
            }
        }
        private void DGVEmstKeyIn_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null)
                e.Value = "";
            switch (DGVEmstOrder.Columns[e.ColumnIndex].Name)
            {
                case "dataGridViewTextBoxColumn2":
                    {
                        if (e.Value.ToString() == "I")
                            e.Value = "";
                        break;
                    }
                case "dataGridViewTextBoxColumn13"://失敗為紅色
                    {
                        if (e.Value.ToString() == "失敗")
                        {
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn13"].Style.ForeColor = Color.Red;
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn13"].Style.SelectionForeColor = Color.Red;
                        }
                        break;
                    }
                case "dataGridViewTextBoxColumn12"://買賣顏色，B紅
                    {
                        if (e.Value.ToString() == "B")
                        {
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn12"].Style.ForeColor = Color.Red;
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn12"].Style.SelectionForeColor = Color.Red;
                        }
                        break;
                    }
                case "colDealQty_EMKeyIn":
                    {
                        if (e.Value.ToString() == "")
                            e.Value = "";
                        else
                            e.Value = $"({String.Format("{0,8:N0}", e.Value)})";
                        break;
                    }
                case "colOrdQty_EMKeyIn":
                    {
                        if (e.Value.ToString() == "0")
                            e.Value = "";
                        break;
                    }
            }
        }
        /// <summary>
        /// 委託回報畫面"篩選"按鈕按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFilterOK_Click(object sender, EventArgs e)
        {
            string cseq = "", symbol = "";

            if (!string.IsNullOrEmpty(txbFilterCSEQ.Text.Trim()))
                cseq = txbFilterCSEQ.Text.PadLeft(7, '0');
            if (!string.IsNullOrEmpty(txbFilterDSEQ.Text.Trim()))
                symbol = txbFilterDSEQ.Text;
            ConcordLogger.Logger.Debug($"[Query] 委託回報查詢-CSEQ: {cseq} Stock: {symbol}");
            if (cseq != "" && symbol != "")
                _DGVRequest_AccountOrStockFilter = $"CSEQ='{cseq}' AND Stock='{symbol}'";
            else
                _DGVRequest_AccountOrStockFilter = $"CSEQ='{cseq}' OR Stock='{symbol}'";

            Update_DGVRequestFilter();
        }
        /// <summary>
        /// 委託回報畫面"清除"按鈕按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFilterClear_Click(object sender, EventArgs e)
        {
            txbFilterCSEQ.Text = "";
            txbFilterDSEQ.Text = "";

            _DGVRequest_AccountOrStockFilter = "CSEQ = ''";
            Update_DGVRequestFilter();
        }
        /// <summary>
        /// 更新委託回報畫面過濾條件
        /// </summary>
        /// <param name="filter"></param>
        private void Update_DGVRequestFilter()
        {
            string and = "";
            if (!string.IsNullOrWhiteSpace(_DGVRequest_AccountOrStockFilter) && !string.IsNullOrWhiteSpace(_DGVRequest_DealStatusFilter))
                and = " AND ";
            if (!string.IsNullOrWhiteSpace(_DGVRequest_AccountOrStockFilter))
                _DGVRequest_AccountOrStockFilter = $"({_DGVRequest_AccountOrStockFilter})";

            if (IsAtEmstTab())
            {
                _EmstRequestView.RowFilter = _DGVRequest_AccountOrStockFilter + and + _DGVRequest_DealStatusFilter;
                DGVEmstRequest_RowsUpdate();
            }
            else
            {
                _RequestView.RowFilter = _DGVRequest_AccountOrStockFilter + and + _DGVRequest_DealStatusFilter;
                DGVRequest_RowsUpdate();
            }
        }
        /// <summary>
        /// 委託回報根據成交資訊過濾條件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rb_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
            if (rbNoDeal.Checked)
            {
                _DGVRequest_DealStatusFilter = "DealQty = '0'";
            }
            else if (rbDeal.Checked)
            {
                _DGVRequest_DealStatusFilter = "DealQty > '0'";
            }
            else
            {
                _DGVRequest_DealStatusFilter = "";
            }
            Update_DGVRequestFilter();
        }
        /// <summary>
        /// 委託回報畫面"全選"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllSelect_Click(object sender, EventArgs e)
        {
            if (IsAtEmstTab())
                _EMOrderStore.SetDeleSelectSwitch(true);
            else
                _OrderStore.SetDeleSelectSwitch(true);
        }
        /// <summary>
        /// 委託回報畫面"取消"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllCancel_Click(object sender, EventArgs e)
        {
            if (IsAtEmstTab())
                _EMOrderStore.SetDeleSelectSwitch(false);
            else
                _OrderStore.SetDeleSelectSwitch(false);
        }
        /// <summary>
        /// 委託回報畫面"多筆刪單"按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllOK_Click(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("[Order] 多筆刪單按鈕按下");
            DialogResult result = MessageBox.Show("確認是否刪除全選委託單", "多筆刪單確認", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                ConcordLogger.Logger.Info("[Order] 多筆刪單確認送出");
                if (IsAtEmstTab())
                {
                    var viewRows = DGVEmstRequest.Rows.Cast<DataGridViewRow>()
                                                 .Where(row => row.Cells["colEmCheckDelete"].EditedFormattedValue.Equals(true));
                    foreach (DataGridViewRow row in viewRows)
                    {
                        string dseq = row.Cells["colEmDSEQ"].EditedFormattedValue.ToString();
                        SendEMCancel(dseq);
                    }
                    _EMOrderStore.SetDeleSelectSwitch(false);
                }
                else
                {
                    var viewRows = DGVRequest.Rows.Cast<DataGridViewRow>()
                                              .Where(row => row.Cells["colCheckDelete"].EditedFormattedValue.Equals(true));
                    foreach (DataGridViewRow row in viewRows)
                    {
                        Order order = ComposeDeleteObject(row.Cells["colDSEQ"].EditedFormattedValue.ToString());
                        if (order != null)
                        {
                            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                            _OrderStore._OrdNetNoMap.TryAdd(order.Guid, order);
                            SendOut(OrderHandler.DeleteOrder(order), true);
                        }
                    }
                    _OrderStore.SetDeleSelectSwitch(false);
                }

            }
            else
                ConcordLogger.Logger.Info("[Order] 多筆刪單取消送出");
        }
        /// <summary>
        /// 委託回報畫面欄位排序改變時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVRequest_Sorted(object sender, EventArgs e)
        {
            if (IsAtEmstTab())
                DGVEmstRequest_RowsUpdate();
            else
                DGVRequest_RowsUpdate();
        }
        /// <summary>
        /// 帳號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbFilterCSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txbFilterDSEQ.Focus();
        }
        /// <summary>
        /// 股票代號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbFilterDSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnFilterOK.Focus();
        }
        #endregion

        #region 成交回報勾單作業
        /// <summary>
        /// 勾單畫面查詢功能
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_QueryDeal_Click(object sender, EventArgs e)
        {
            LabQueryDealTime.Text = $"查詢時間: {DateTime.Now.ToString("HH:mm:ss.fff")}";

            // 清空資料
            DGVCheckDeal.SuspendLayout();
            DGVCheckDeal.DataSource = null;
            _CheckDealDataSore.Clear();

            string[] parameters = { UserInfo._UserIP };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QKeyInTDDEAL", parameters);
            if (result.StatusCode == rCode.Success)
            {
                foreach (var item in result.Deatils)
                {
                    DataRow dr = _CheckDealDataSore.NewRow();
                    string[] info = item.Split('|');
                    int OrdQty, DelQty, AllDQty = 0;
                    int.TryParse(info[5], out OrdQty);
                    int.TryParse(info[15], out DelQty);
                    int.TryParse(info[16], out AllDQty);

                    dr["No"] = info[0];
                    dr["BHNO"] = $"845{info[1]}";
                    dr["CSEQ"] = info[2];
                    dr["ECode"] = StockInfoHandler.GetECodeText(info[3]);
                    if (info[7] == "1") // 判斷限市價
                        dr["PRICE"] = "市價";
                    else
                        dr["PRICE"] = info[4];
                    dr["OQTY"] = (info[3] == "2" || info[3] == "7") ? OrdQty : OrdQty / 1000;
                    dr["OTYPE"] = StockInfoHandler.GetOrderTypeText(info[6]);
                    dr["TimeInForce"] = StockInfoHandler.GetTimeInForceText(info[8]);
                    dr["STOCK"] = info[9];
                    dr["STOCKNAME"] = info[10];
                    dr["BS"] = info[11] == "B" ? "買" : "賣";
                    dr["DSEQ"] = info[12];
                    dr["CheckStatus"] = info[13];
                    dr["DPRICE"] = info[14];
                    dr["DQTY"] = (info[3] == "2" || info[3] == "7") ? DelQty : DelQty / 1000;
                    dr["AllDQTY"] = (info[3] == "2" || info[3] == "7") ? AllDQty : AllDQty / 1000;
                    _CheckDealDataSore.Rows.Add(dr);
                }
                DGVCheckDeal.DataSource = _CheckDealView;
                DGVCheckDeal.ResumeLayout();
                if (DGVCheckDeal.Rows.Count > 0)
                {
                    if (DGVCheckDeal.Rows.Count > 0)//防呆
                        DGVCheckDeal.CurrentCell = DGVCheckDeal.Rows[0].Cells[0];
                    Update_DGVCheckDealView();
                }
            }
        }
        /// <summary>
        /// 勾單畫面DataGridView 按鍵事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVCheckDeal_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Y:
                case Keys.NumPad0:
                    #region Y鍵 / 數字鍵 0 (勾單作業)
                    {
                        DataGridViewRow row = ((DataGridView)sender).CurrentRow;
                        if (row == null)
                            return;
                        if (row.Index < 0)
                            return;
                        if (row.Cells["col_CheckStatus"].EditedFormattedValue.ToString() == "**")
                            return;
                        string dseq = row.Cells["col_DSEQ"].EditedFormattedValue.ToString();
                        string no = row.Cells["col_No"].EditedFormattedValue.ToString();
                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(dseq)).Result;
                        if (report == null || report.Count < 1)
                        {
                            ConcordLogger.Logger.Error($"未查詢到對應委託- DSEQ: {dseq}");
                            return;
                        }
                        // 取得狀態
                        string status = "";
                        if (report[0]["TimeInForce"].ToString() == "ROD")
                        {
                            status = report[0]["Status"].ToString() == "完全成交" ? "**" : "*";
                        }
                        else
                        {
                            status = "**";
                        }
                        ConcordLogger.Logger.Debug("DSEQ=" + dseq + " status=" + report[0]["Status"].ToString());
                        row.Cells["col_CheckStatus"].Value = status;
                        // 資料庫作業
                        string[] parameters = { no, report[0]["BHNO"].ToString(), dseq, status };
                        HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_SCheckOrder", parameters);
                        if (result.StatusCode != rCode.Success)
                        {
                            ConcordLogger.Logger.Error($"勾單作業失敗: [{result.StatusCode}] {result.CodeDesc}");
                            ConcordLogger.Alert("9998", "勾單作業失敗", $"[{result.StatusCode}] {result.CodeDesc}");
                        }
                        Btn_QueryDeal_Click(sender, e);
                        break;
                    }
                #endregion
                case Keys.F1:
                    #region 查詢回報數
                    {
                        ResetLabChkDealQCount();
                        DataGridViewRow row = ((DataGridView)sender).CurrentRow;
                        if (row == null)
                            return;
                        string dseq = row.Cells["col_DSEQ"].EditedFormattedValue.ToString();
                        string dprice = row.Cells["col_DPRICE"].EditedFormattedValue.ToString();
                        LabChkDealQDSEQ.Text = dseq;
                        LabChkDealQDSEQ.Visible = true;
                        LabChkDealQCount.Visible = true;
                        var rowCollection = _OrderStore.GetChkDealCount(dseq, dprice);
                        if (rowCollection.Count == 0)
                        {
                            LabChkDealQCount.Text = "0";
                            return;
                        }
                        LabChkDealQCount.Text = rowCollection.Count.ToString();
                        for (int i = 0; i < rowCollection.Count; i++)
                        {
                            if (i == 5)
                                break;
                            var labList = _ChkDealQueryCountControls[i];
                            labList[0].Visible = true;
                            labList[1].Visible = true;
                            labList[1].Text = rowCollection[i].ToString();
                        }
                        LabCheckFinishInfo.Visible = GetCheckFinishStatus(dseq);
                        break;
                    }
                #endregion
                case Keys.Escape:
                    ResetLabChkDealQCount();
                    break;
            }
        }
        /// <summary>
        /// 勾單作業畫面盤別篩選功能
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVCheckDeal_radioButton_CheckedChanged(object sender, EventArgs e)
        {
            var rbtn = sender as RadioButton;
            if (!rbtn.Checked)
                return;
            string ECODE = rbtn.Text;
            _CheckDealView.RowFilter = $"ECode LIKE '*{ECODE}'";
            Update_DGVCheckDealView();
        }
        /// <summary>
        /// 更新勾單作業畫面
        /// </summary>
        private void Update_DGVCheckDealView()
        {
            foreach (DataGridViewRow row in DGVCheckDeal.Rows)
            {
                Color BackColor = row.Cells["col_BS"].EditedFormattedValue.ToString() == "買" ? Color.Red : Color.Blue;
                row.Cells["col_BS"].Style.BackColor = BackColor;
                row.Cells["col_DSEQ"].Style.BackColor = BackColor;
                row.Cells["col_DPRICE"].Style.BackColor = BackColor;
                row.Cells["col_DQTY"].Style.BackColor = BackColor;
            }
        }
        /// <summary>
        /// 確認勾單作業是否完成
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        private bool GetCheckFinishStatus(string DSEQ)
        {
            var result = _CheckDealDataSore.AsEnumerable()
                                           .Where(r => r.Field<string>("DSEQ") == DSEQ &&
                                                       r.Field<string>("CheckStatus") == "")
                                           .ToList();
            if (result.Count == 0)
                return true;
            else
                return false;
        }
        private void ResetLabChkDealQCount()
        {
            LabChkDealQDSEQ.Visible = false;
            LabChkDealQCount.Visible = false;
            LabChkDealQT1.Visible = false;
            LabChkDealQR1.Visible = false;
            LabChkDealQT2.Visible = false;
            LabChkDealQR2.Visible = false;
            LabChkDealQT3.Visible = false;
            LabChkDealQR3.Visible = false;
            LabChkDealQT4.Visible = false;
            LabChkDealQR4.Visible = false;
            LabChkDealQT5.Visible = false;
            LabChkDealQR5.Visible = false;
            LabCheckFinishInfo.Visible = false;
        }
        #endregion

        #region 被動委託查詢畫面控制項
        public void PassiveSearch()
        {
            string cseq = "", symbol = "";
            Boolean check = false;
            if (!string.IsNullOrEmpty(txbPasFilterCSEQ.Text.Trim()))
                cseq = txbPasFilterCSEQ.Text.PadLeft(7, '0');
            if (!string.IsNullOrEmpty(txbPasFilterDSEQ.Text.Trim()))
                symbol = txbPasFilterDSEQ.Text;

            Customer cusInfo = CUMBStore.Get_CustomerInfo(cseq);
            if (cusInfo != null)
            {
                if ((!STMBStore.CheckContains(symbol)) && symbol != "")
                {
                    MessageBox.Show("無此股票代號");
                }
                else
                {
                    ConcordLogger.Logger.Debug($"[Query] 被動委託查詢-CSEQ: {cseq} Stock: {symbol}");
                    check = true;
                }
            }
            else
            {
                MessageBox.Show("未含有此帳號客戶");
            }

            if (check)
            {
                string[] parameters = { UserInfo._BHNO, cseq, symbol, "0" };
                HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QTOrder2", parameters);

                if (result.StatusCode == rCode.Success)
                {
                    //MessageBox.Show("測試成功");
                    _OrderStore.AddReport2(result.Deatils[0]);
                    DGVPasRequest_RowsUpdate();
                }
                else
                {
                    ConcordLogger.Logger.Error("載入被動委託查詢錯誤");
                }
            }
        }


        private void btnPasFilterOK_Click(object sender, EventArgs e)
        {
            PassiveSearch();
        }

        private void btnPasFilterClear_Click(object sender, EventArgs e)
        {
            txbPasFilterDSEQ.Text = "";
            txbPasFilterCSEQ.Text = "";
            _OrderStore._OrdPassiveReportStore.Clear();
            DGVPasRequest_RowsUpdate();
        }

        /// <summary>
        /// 委託查詢畫面"全選"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllSelect_Click(object sender, EventArgs e)
        {
            _OrderStore.SetPasDeleSelectSwitch(true);
        }
        /// <summary>
        /// 委託查詢畫面"取消"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllCancel_Click(object sender, EventArgs e)
        {
            _OrderStore.SetPasDeleSelectSwitch(false);
        }
        /// <summary>
        /// 帳號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbPasFilterCSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txbPasFilterDSEQ.Focus();
        }
        /// <summary>
        /// 股票代號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbPasFilterDSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnPasFilterOK.Focus();
        }
        /// <summary>
        /// 鎖定打單畫面或KeyIn明細
        /// </summary>
        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F5:
                    {
                        if (currentFocus != 1)
                        {
                            tab_Order.Focus();
                            currentFocus = 1;
                        }
                    }
                    break;
                case Keys.PageUp:
                case Keys.PageDown:
                    {
                        if (currentFocus != 2)
                        {
                            tab_Request.Focus();
                            if (tab_Request.SelectedIndex == 0)
                            {
                                if (IsAtEmstTab())
                                    DGVEmstOrder.Focus();
                                else
                                    DGVKeyIn.Focus();
                            }
                            currentFocus = 2;
                        }
                    }
                    break;
                default:
                    currentFocus = 3;
                    break;
            }
        }
        /// <summary>
        /// 委託查詢畫面"多筆刪單"按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllOK_Click(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("[被動查詢] 多筆刪單按鈕按下");
            DialogResult result = MessageBox.Show("確認是否刪除全選委託單", "多筆刪單確認", MessageBoxButtons.OKCancel);
            Boolean check = false;
            if (result == DialogResult.OK)
            {
                ConcordLogger.Logger.Info("[被動查詢] 多筆刪單確認送出");
                var viewRows = DGVPasRequest.Rows.Cast<DataGridViewRow>()
                                          .Where(row => row.Cells["col_CheckDelete"].EditedFormattedValue.Equals(true));
                foreach (DataGridViewRow row in viewRows)
                {
                    Order order = PasComposeDeleteObject(row.Cells["col__DSEQ"].EditedFormattedValue.ToString());
                    if (order != null)
                    {
                        check = true;
                        _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                        _OrderStore._OrdNetNoMap.TryAdd(order.Guid, order);
                        SendOut(OrderHandler.DeleteOrder(order), true);
                    }
                }
                _OrderStore.SetPasDeleSelectSwitch(false);
                if (check)
                {
                    Thread.Sleep(1500);
                    PassiveSearch();
                }
            }
            else
                ConcordLogger.Logger.Info("[被動查詢] 多筆刪單取消送出");
        }
        /// <summary>
        /// 委託畫面欄位點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVPasRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
                return;
            string DSEQ = DGVPasRequest.CurrentRow.Cells["col__DSEQ"].EditedFormattedValue.ToString();
            if (DSEQ.Trim() == "")
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            switch (e.ColumnIndex)
            {
                case 0: // 勾選欄位
                    bool IsChoice = (bool)DGVPasRequest.CurrentRow.Cells["col_CheckDelete"].EditedFormattedValue;
                    DGVPasRequest.CurrentRow.Cells["col_CheckDelete"].Value = !IsChoice;
                    break;
                case 1:
                    {
                        #region 刪單按鈕
                        ConcordLogger.Logger.Info("[Order] 刪單扭按按下");
                        Order order = PasComposeDeleteObject(DSEQ);
                        if (order != null)
                        {
                            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                            _OrderStore._OrdNetNoMap.TryAdd(order.Guid, order);
                            SendOut(OrderHandler.DeleteOrder(order), true);
                            Thread.Sleep(1500);
                            PassiveSearch();
                        }
                        #endregion
                        break;
                    }
                case 2:
                    {
                        #region 改量按鈕
                        ConcordLogger.Logger.Info("[Order] 改量扭按按下");
                        var report = Task.Run(() => _OrderStore.GetPasReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null && report.Count > 0)
                        {
                            _FrmPasChangeCheck.Init("ChgQty", report[0]);
                        }
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改量錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ConcordLogger.Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
                case 3:
                    {
                        #region 改價按扭
                        ConcordLogger.Logger.Info("[Order] 改價扭按按下");
                        var report = Task.Run(() => _OrderStore.GetPasReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null && report.Count > 0)
                        {
                            _FrmPasChangeCheck.Init("ChgPrice", report[0]);
                        }
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改價錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ConcordLogger.Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
            }
        }

        private void rbPas_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
            if (rbPasNoDeal.Checked)
            {
                _DGVPasRequest_DealStatusFilter = "DealQty = '0'";
            }
            else if (rbPasDeal.Checked)
            {
                _DGVPasRequest_DealStatusFilter = "DealQty > '0'";
            }
            else
            {
                _DGVPasRequest_DealStatusFilter = "";
            }
            _PassiveRequestView.RowFilter = _DGVPasRequest_DealStatusFilter;
            DGVPasRequest_RowsUpdate();
        }

        /// <summary>
        /// 重繪委託查詢畫面
        /// </summary>
        private void DGVPasRequest_RowsUpdate()
        {
            int RequestQty = 0, DealQty = 0, Order = 0, Cancel = 0, Deal = 0;
            decimal RequestAmount = 0, DealAmount = 0, OrdPrice = 0, DealPrice = 0;

            foreach (DataGridViewRow row in DGVPasRequest.Rows)
            {
                if (row == null)
                    continue;
                #region 更新買賣別顏色
                if (row.Cells["col_Side"].EditedFormattedValue.ToString() == "B")
                    row.Cells["col_Side"].Style.ForeColor = Color.Red;
                else
                    row.Cells["col_Side"].Style.ForeColor = Color.DodgerBlue;

                #endregion
                #region 更新 刪量價 按扭欄位
                if ((row.Cells["col_STATUS"].EditedFormattedValue.ToString() != "委託成功" &&
                     row.Cells["col_STATUS"].EditedFormattedValue.ToString() != "部份成交") ||
                     row.Cells["Col__TimeInForce"].EditedFormattedValue.ToString() != "ROD")
                {
                    row.Cells["col_DeleteOrder"].Dispose();
                    row.Cells["col_DeleteOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["col_ChangeOrder"].Dispose();
                    row.Cells["col_ChangeOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["col_ChangePrice"].Dispose();
                    row.Cells["col_ChangePrice"] = new DataGridViewTextBoxCell();
                }
                else
                {
                    row.Cells["col_DeleteOrder"].Dispose();
                    row.Cells["col_DeleteOrder"] = new DataGridViewButtonCell();
                    row.Cells["col_DeleteOrder"].Value = "刪";
                    row.Cells["col_ChangeOrder"].Dispose();
                    if (row.Cells["Col_LaveQty"].EditedFormattedValue.ToString() == "1000" ||
                        row.Cells["Col_LaveQty"].EditedFormattedValue.ToString() == "1")
                    {
                        row.Cells["col_ChangeOrder"].Dispose();
                        row.Cells["col_ChangeOrder"] = new DataGridViewTextBoxCell();
                    }
                    else
                    {
                        row.Cells["col_ChangeOrder"] = new DataGridViewButtonCell();
                        row.Cells["col_ChangeOrder"].Value = "量";
                    }
                    row.Cells["col_ChangePrice"].Dispose();
                    if (row.Cells["col__ECODE"].EditedFormattedValue.ToString() == "整股" &&
                        row.Cells["col_OrdPrice"].EditedFormattedValue.ToString() != "市價")
                    {
                        row.Cells["col_ChangePrice"] = new DataGridViewButtonCell();
                        row.Cells["col_ChangePrice"].Value = "價";
                    }
                    else
                    {
                        row.Cells["col_ChangePrice"] = new DataGridViewTextBoxCell();
                    }
                }
                #endregion
                if (row.Cells["col_STATUS"].EditedFormattedValue.ToString() == "委託失敗")
                    continue;
                if (row.Cells["col_OrdQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_OrdQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Order);
                if (row.Cells["col_CancelQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_CancelQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Cancel);
                if (row.Cells["col_DealQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_DealQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Deal);
                if (row.Cells["col_OrdPrice"].EditedFormattedValue != null)
                    decimal.TryParse(row.Cells["col_OrdPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out OrdPrice);
                if (row.Cells["col_DealPrice"].EditedFormattedValue != null)
                    decimal.TryParse(row.Cells["col_DealPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out DealPrice);
                RequestQty += (Order - Cancel);
                DealQty += Deal;
                RequestAmount += (Order - Cancel) * OrdPrice; // RequestQty
                DealAmount += DealQty * DealPrice;
            }
            labPasCount.Text = $"筆數：{DGVPasRequest.Rows.Count.ToString("N0")}";
            labPasRequestQty.Text = $"委託股數：{RequestQty.ToString("N0")}";
            labPasRequestAmt.Text = $"委託金額：{RequestAmount.ToString("N0")}";
            labPasDealQty.Text = $"成交股數：{DealQty.ToString("N0")}";
            labPasDealAmt.Text = $"成交金額：{DealAmount.ToString("N0")}";
        }

        /// <summary>
        /// 被動委託查詢畫面欄位排序改變時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVPasRequest_Sorted(object sender, EventArgs e)
        {
            DGVPasRequest_RowsUpdate();
        }

        #endregion

        #endregion

    }
}
