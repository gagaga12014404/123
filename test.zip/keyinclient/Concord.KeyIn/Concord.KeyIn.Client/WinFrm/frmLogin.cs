﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using System.Net;
using System.Threading;
using System.Diagnostics;
using System.Reflection;

namespace Concord.KeyIn.Client
{
    public partial class frmLogin : Form
    {
        #region Variable & Field

        /// <summary>
        /// 主程式物件
        /// </summary>
        private frmMain _MainForm;
        /// <summary>
        /// 登入系統選擇模式--系統程式版本模式 1:正式 2:測試
        /// </summary>
        private int _LoginModel = -1;

        #endregion Variable & Field

        #region UI Control Logic

        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            cobModel.Items.Add("測試環境");
            cobModel.Items.Add("總公司環境");
            cobModel.Items.Add("復北環境");
            cobModel.Items.Add("備援環境");
            cobModel.Items.Add("異地環境");
            cobModel.SelectedIndex = 1;

            LabVersion.Text = $"v {FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}";

            #region 取得Client端IP
            IPHostEntry iphostentry = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ipaddress in iphostentry.AddressList)
            {
                // 只取得IPv4的Address
                if (ipaddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    UserInfo._UserIP = ipaddress.ToString();
                    ConcordLogger.Logger.Info($"[Login] -------- 系統偵測 前端IP取得 :{ipaddress.ToString()}");
                    break;
                }
            }
            #endregion
        }

        private void txtPWD_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }
        private void cobModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cobModel.SelectedIndex)
            {
                case 0:
                    _LoginModel = 2;
                    Text = "康和KeyIn系統<測試環境>";
                    BackColor = Color.White;
                    cobModel.ForeColor = Color.Black;
                    break;
                case 1:
                    _LoginModel = 1;
                    Text = "康和KeyIn系統<總公司環境>";
                    BackColor = Color.Orange;
                    break;
                case 2:
                    _LoginModel = 3;
                    Text = "康和KeyIn系統<復北環境>";
                    BackColor = Color.MediumOrchid;
                    break;
                case 3:
                    _LoginModel = 1;
                    Text = "康和KeyIn系統<備援環境>";
                    BackColor = Color.GreenYellow;
                    break;
                case 4:
                    _LoginModel = 4;
                    Text = "康和KeyIn系統<異地環境>";
                    BackColor = Color.Aqua;
                    break;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info(" ========================= 系統Login =========================");
            ConcordLogger.Logger.Info($"[Loing] 登入環境 - {cobModel.SelectedItem}");
            ConcordLogger.Logger.Info($"[Loing] 程式版號 - {FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}");

            btnLogin.Enabled = false;
            HttpReqHandler.SetKeyInSvrUrl(_LoginModel);
            // 員編要是有英文一律轉為大寫
            string emno = txtID.Text.ToUpper();
            if (!CheckUserData() || !IsAuthenticated(emno, txtPWD.Text))
            {
                txtPWD.Text = "";
                btnLogin.Enabled = true;
                return;
            }
            // 平行切換時期暫時不鎖復北環境登入
            if (cobModel.SelectedIndex == 2 && false)
            {
                var form = new frmForceOrder();
                form.Text = "異地備援環境登入";
                form.ShowDialog();
                if (!form._Command)
                {
                    btnLogin.Enabled = true;
                    return;
                }
            }
            else if (cobModel.SelectedIndex == 3) // 當User選擇備援環境時
            {
                if (!UserInfo._IsBack)
                {
                    MessageBox.Show("未具備備援權限，請重新確認登入環境", "權限錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnLogin.Enabled = true;
                    return;
                }
                frmBackUpConfirm frm = new frmBackUpConfirm();
                frm.ShowDialog();
                if (!frm._Pass)
                {
                    btnLogin.Enabled = true;
                    return;
                }
            }
            labLoading.Visible = true;
            Application.DoEvents();
            UserInfo._EMNO = emno;
            if (_MainForm == null)
            {
                _MainForm = new frmMain(_LoginModel);
                _MainForm._CloseMainFormEvent += new dlgCloseMainForm(ClosedfrmLogin);
                _MainForm.LoadingBasicData();
                _MainForm.Intit_DataView();
                _MainForm.Show();
                btnLogin.Enabled = true;
            }
            Hide();
        }
        private void ClosedfrmLogin(object sender, EventArgs e)
        {
            try
            {
                _MainForm.Hide();
                Close();
                ConcordLogger.Logger.Info(" ========================= 系統程式結束  =========================");
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("CloseSYS Error!", ex);
            }
            finally
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }
        }
        #endregion

        #region 資料驗證,認證
        /// <summary>
        /// 使用者帳號/密碼資料檢核
        /// </summary>
        /// <returns></returns>
        private bool CheckUserData()
        {
            if (string.IsNullOrEmpty(txtID.Text))
            {
                MessageBox.Show("使用者帳號必須輸入資料", "輸入資料錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else if (string.IsNullOrEmpty(txtPWD.Text))
            {
                MessageBox.Show("使用者密碼必須輸入資料", "輸入資料錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        /// <summary>
        /// 使用者權限驗證
        /// </summary>
        /// <param name="id">員編</param>
        /// <param name="password">密碼</param>
        /// <returns></returns>
        private bool IsAuthenticated(string id, string password)
        {
            ConcordLogger.Logger.Info($"[Login] User: {id}");

            if (!ADAuthenticate(id, password))
                return false;
            if(!KeyInAuAuthenticate(id))
                return false;

            ConcordLogger.Logger.Info($"[Login] UserData Bhno: {UserInfo._BHNO} Authority: {UserInfo._UserAuthority}");
            return true;
        }
        /// <summary>
        /// 員工AD主機認證
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private bool ADAuthenticate(string id, string password)
        {
            ConcordLogger.Logger.Debug($"[Login] ADAuthenticate 開始 - 使用者[{id}]");
            bool blnTag = false;
            string strMessage = "";
            try
            {
                switch (ADHelper.Login(id, password))
                {
                    case ADHelper.LoginResult.LOGIN_OK:
                        strMessage = "AD認證身分-成功";
                        blnTag = true;
                        break;
                    case ADHelper.LoginResult.LOGIN_USER_DOESNT_EXIST:
                        strMessage = "錯誤的使用者名稱或密碼";
                        MessageBox.Show(strMessage);
                        blnTag = false;
                        break;
                    case ADHelper.LoginResult.LOGIN_USER_ACCOUNT_INACTIVE:
                        strMessage = "您的密碼連續輸入三次錯誤已鎖住(請洽網管)";
                        MessageBox.Show(strMessage);
                        blnTag = false;
                        break;
                    case ADHelper.LoginResult.LOGIN_USER_BAD_PASSWORD:
                        strMessage = "您的密碼錯誤，請重新輸入!";
                        MessageBox.Show(strMessage);
                        blnTag = false;
                        break;
                    default:
                        strMessage = "AD系統異常，無法確認身分(請洽網管)";
                        MessageBox.Show(strMessage);
                        blnTag = false;
                        break;
                }
                ConcordLogger.Logger.Info($"[Login] {strMessage}");
            }
            catch (Exception ex)
            {
                strMessage = "AD主機驗證失敗!請查詢是否網路斷線或洽網管!";
                ConcordLogger.Logger.Error("[Login] ADAuthenticate-AD主機驗證失敗", ex);
                ConcordLogger.Alert("L01", "IsAuthenticated-AD主機驗證失敗", $"User:{id};Err Msg:{ex}");
                MessageBox.Show(strMessage);
            }
            return blnTag;
        }
        /// <summary>
        /// KeyIn 權限認證
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool KeyInAuAuthenticate(string id)
        {
            string[] parameters = { id, UserInfo._UserIP };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_KeyInLogin", parameters);

            if (result.StatusCode != rCode.Success)
            {
                MessageBox.Show(result.CodeDesc);
                return false;
            }
            else
            {
                UserInfo.Parser(result.Deatils);
                return true;
            }
        }
        #endregion
        
    }
}
