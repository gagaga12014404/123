﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using System;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Init Data
        /// <summary>
        /// 執行取得基本資料檔
        /// </summary>
        public void LoadingBasicData()
        {
            bool result = false;
            var task_GetSTMB = Task.Run(() => Get_STMB());
            var task_GetTradeTime = Task.Run(() => Get_TradeTime());
            // 經紀/自營取得客戶帳號以及營業員檔區分
            if (_Model == 1)
            {
                var task_GetCUMB = Task.Run(() => Get_CUMB());
                var task_GetSLAB = Task.Run(() => Get_SLAB());
                Task.WaitAll(task_GetSTMB, task_GetCUMB, task_GetSLAB, task_GetTradeTime);
                result = task_GetSTMB.Result && task_GetCUMB.Result && task_GetSLAB.Result && task_GetTradeTime.Result;
            }
            else
            {
                _CustomerStore.AddDealerAccount();
                Task.WaitAll(task_GetSTMB, task_GetTradeTime);
                result = task_GetSTMB.Result && task_GetTradeTime.Result;
            }
            var task_GetTDORD = Task.Run(() => Get_TDORD());
            if (!result)
            {
                object o = new object();
                EventArgs args = new EventArgs();
                _CloseMainFormEvent(o, args);
            }
            Task.WaitAll(task_GetTDORD);
        }
        /// <summary>
        /// 初始化DataGridView
        /// </summary>
        public void Intit_DataView()
        {
            _EMKeyInOrderDetailView = new DataView(_EMOrderStore._KeyInDetailStore);
            DGVEmstOrder.AutoGenerateColumns = false;
            DGVEmstOrder.Columns["colOrdQty_EMKeyIn"].DefaultCellStyle.Format = "N0";//委託股數是int，設定format N0，千位一個逗號
            DGVEmstOrder.Columns["colDealQty_EMKeyIn"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVEmstOrder, true);

            _EmstRequestView = new DataView(EMOrderStore._OrdReportStore, "CSEQ=''", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);//DESC=descending降序
            DGVEmstRequest.AutoGenerateColumns = false;
            DGVEmstRequest.Columns["colEmOrdPrice"].DefaultCellStyle.Format = "0.####";
            DGVEmstRequest.Columns["colEmDealPrice"].DefaultCellStyle.Format = "0.####";
            DGVEmstRequest.Columns["colEmOrdQty"].DefaultCellStyle.Format = "N0";
            DGVEmstRequest.Columns["colEmCancelQty"].DefaultCellStyle.Format = "N0";
            DGVEmstRequest.Columns["colEmDealQty"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVEmstRequest, true);

            _KeyInOrderDetailView = new DataView(_OrderStore._KeyInDetailStore, "ECode='0'", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            DGVKeyIn.AutoGenerateColumns = false;
            DGVKeyIn.Columns["colBefChgQty_KeyIn"].DefaultCellStyle.Format = "N0";
            DGVKeyIn.Columns["colOrdQty_KeyIn"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVKeyIn, true);

            _RequestView = new DataView(OrderStore._OrdReportStore, "CSEQ=''", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            DGVRequest.AutoGenerateColumns = false;
            DGVRequest.Columns["colOrdPrice"].DefaultCellStyle.Format = "0.####";
            DGVRequest.Columns["colDealPrice"].DefaultCellStyle.Format = "0.####";
            DGVRequest.Columns["colOrdQty"].DefaultCellStyle.Format = "N0";
            DGVRequest.Columns["colCancelQty"].DefaultCellStyle.Format = "N0";
            DGVRequest.Columns["colDealQty"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVRequest, true);

            _CheckDealView = new DataView(_CheckDealDataSore, "", "CheckStatus, DSEQ DESC", DataViewRowState.CurrentRows);
            DGVCheckDeal.AutoGenerateColumns = false;
            DGVCheckDeal.Columns["col_PRICE"].DefaultCellStyle.Format = "0.####";
            DGVCheckDeal.Columns["col_DPRICE"].DefaultCellStyle.Format = "0.####";
            DGVCheckDeal.Columns["col_OQTY"].DefaultCellStyle.Format = "N0";
            DGVCheckDeal.Columns["col_DQTY"].DefaultCellStyle.Format = "N0";
            DGVCheckDeal.Columns["col_AllDQTY"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVCheckDeal, true);

            _PassiveRequestView = new DataView(_OrderStore._OrdPassiveReportStore, "", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            DGVPasRequest.AutoGenerateColumns = false;
            DGVPasRequest.Columns["col_OrdPrice"].DefaultCellStyle.Format = "0.####";
            DGVPasRequest.Columns["col_DealPrice"].DefaultCellStyle.Format = "0.####";
            DGVPasRequest.Columns["col_OrdQty"].DefaultCellStyle.Format = "N0";
            DGVPasRequest.Columns["col_CancelQty"].DefaultCellStyle.Format = "N0";
            DGVPasRequest.Columns["col_DealQty"].DefaultCellStyle.Format = "N0";
            //DoubleBuffered(DGVPasRequest, true);

            DGVEmstOrder.SuspendLayout();
            DGVEmstOrder.DataSource = _EMKeyInOrderDetailView;
            DGVEmstOrder.ResumeLayout();
            DGVEmstRequest.SuspendLayout();
            DGVEmstRequest.DataSource = _EmstRequestView;
            DGVEmstRequest.ResumeLayout();
            DGVKeyIn.SuspendLayout();
            DGVKeyIn.DataSource = _KeyInOrderDetailView;
            DGVKeyIn.ResumeLayout();
            DGVRequest.SuspendLayout();
            DGVRequest.DataSource = _RequestView;
            DGVRequest.ResumeLayout();
            DGVPasRequest.SuspendLayout();
            DGVPasRequest.DataSource = _PassiveRequestView;
            DGVPasRequest.ResumeLayout();
        }
        /// <summary>
        /// 取得當日委託明細資料(By KeyIn主機IP)
        /// </summary>
        /// <returns></returns>
        private bool Get_TDORD()
        {
            string[] parameters = { UserInfo._UserIP };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QKeyInTOrderDetail", parameters);

            if (result.StatusCode == rCode.Success)
            {
                int last_dseq = 0;
                int last_FuncDseq = 0;
                foreach (var row in result.Deatils)
                {
                    DataRow dr = _OrderStore._KeyInDetailStore.NewRow();
                    string[] info = row.Split('|');
                    dr["ClordID"] = info[0];
                    if (info[1].Length >= 6)
                        dr["TransactTime"] = string.Format("{0}:{1}:{2}", info[1].Substring(0, 2), info[1].Substring(2, 2), info[1].Substring(4, 2));
                    else
                        dr["TransactTime"] = "";
                    dr["DSEQ"] = info[2];
                    _OrderStore._OrdDSEQ.TryAdd(info[2], info[2]);
                    int Dseq = 0;
                    string Term = "";
                    if (info[2].Length > 1)
                    {
                        Term = info[2].Substring(0, 1);
                        int.TryParse(info[2].Remove(0, 1), out Dseq); // 移除櫃號
                    }
                    else
                    {
                        Term = " ";
                        Dseq = 0;
                        ConcordLogger.Logger.Error($"[Init] Get_TDORD 錯誤, info: {info[2]}");
                        ConcordLogger.Alert("999", "Get_TDORD 錯誤", $"Parser Term,DSEQ Err ,Info: {info[2]}");
                        continue;
                    }
                    dr["BHNO"] = "845" + info[3];
                    dr["CSEQ"] = info[4];
                    dr["ExecType"] = info[5];
                    dr["MType"] = info[6];
                    dr["OType"] = StockInfoHandler.GetOrderTypeText(info[8]);
                    dr["ECode"] = info[9];
                    switch (info[9])
                    {
                        #region 回補計算委託書號邏輯
                        case "0":
                        case "1":
                        case "2":
                        case "3":
                        case "7":
                            if (Term == UserInfo._TRAM && Dseq > last_dseq) // 取得當日最後一筆委託書號
                                last_dseq = Dseq;
                            break;
                        case "4":
                        case "5":
                        case "6":
                        case "8":
                            if (Term == UserInfo._TRAM && Dseq > last_FuncDseq) // 取得當日最後一筆委託書號
                                last_FuncDseq = Dseq;
                            break;
                            #endregion
                    }
                    dr["TimeInForce"] = StockInfoHandler.GetTimeInForceText(info[11]);
                    dr["Stock"] = info[12];
                    StockInfo symbol = STMBStore.Get_SymbolInfo(info[12]);
                    if (symbol != null)
                        dr["StockName"] = symbol.CNAME;
                    dr["Side"] = info[13];
                    int BefChgeQty = 0, OrdQty = 0, DealQty = 0;
                    int.TryParse(info[14], out BefChgeQty);
                    int.TryParse(info[15], out OrdQty);
                    int.TryParse(info[16], out DealQty);
                    if (info[9] != "2" && info[9] != "7") BefChgeQty = BefChgeQty / 1000;
                    dr["BeforeChangeQty"] = info[5] == "P" ? 0 : BefChgeQty;
                    if (info[9] != "2" && info[9] != "7") OrdQty = OrdQty / 1000;
                    dr["OrdQty"] = info[5] == "P" ? BefChgeQty : OrdQty; // 改價改為用改前數量放置委託數量欄位
                    if (info[9] != "2" && info[9] != "7") DealQty = DealQty / 1000;
                    dr["DealQty"] = DealQty;
                    if (info[10] == "1") // 判斷 限市價
                        dr["OrdPrice"] = "市價";
                    else
                    {
                        decimal OrdPrice = 0;
                        decimal.TryParse(info[17], out OrdPrice);
                        dr["OrdPrice"] = OrdPrice.ToString("0.####");
                    }
                    switch (info[18])
                    {
                        case "9":
                            dr["Status"] = "送出";
                            break;
                        case "0":
                            dr["Status"] = "成功";
                            break;
                        case "8":
                            dr["Status"] = "失敗";
                            break;
                    }
                    dr["Sale"] = info[19];
                    dr["Text"] = info[21];
                    _OrderStore._KeyInDetailStore.Rows.Add(dr);
                }
                // 回補後更新最新委託流水序號
                _OrderHandler.DSEQ = last_dseq + 1;
                _OrderHandler.FuncDSEQ = last_FuncDseq + 1;
                return true;
            }
            else
            {
                ConcordLogger.Logger.Error("[Init] 當日委託明細檔,初始化錯誤");
                MessageBox.Show(this, "當日委託明細檔 初始化錯誤，請立即反應資訊部同仁，系統即將關閉");
                return false;
            }
        }
        /// <summary>
        /// 取得股票商品基本資料檔
        /// </summary>
        /// <returns></returns>
        private bool Get_STMB()
        {
            string[] parameters = { };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QSTMB", parameters);

            if (result.StatusCode == rCode.Success)
            {
                // 將資料解析並放入STMBStore
                STMBStore.ParserSTMB(result.Deatils);
                return true;
            }
            else
            {
                ConcordLogger.Logger.Error("[Init] 股票基本資料檔,初始化錯誤");
                MessageBox.Show("股票基本資料檔 初始化錯誤，請立即反應資訊部同仁，系統即將關閉", "初始化錯誤",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.ServiceNotification);
                return false;
            }
        }
        /// <summary>
        /// 取得該分公司客戶資訊
        /// </summary>
        /// <returns></returns>
        private bool Get_CUMB()
        {
            string[] parameters = { UserInfo._BHNO };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QCUMB", parameters);

            if (result.StatusCode == rCode.Success)
            {
                _CustomerStore.Parser(result.Deatils);
                return true;
            }
            else
            {
                ConcordLogger.Logger.Error("[Init] 客戶基本資料檔,初始化錯誤");
                MessageBox.Show("客戶基本資料檔 初始化錯誤，請立即反應資訊部同仁，系統即將關閉", "初始化錯誤",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.ServiceNotification);
                return false;
            }
        }
        /// <summary>
        /// 取得該分公司營業員資訊
        /// </summary>
        /// <returns></returns>
        private bool Get_SLAB()
        {
            string[] parameters = { UserInfo._BHNO };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QSLAB", parameters);

            if (result.StatusCode == rCode.Success)
            {
                _SLABStore.Parser(result.Deatils);
                return true;
            }
            else
            {
                ConcordLogger.Logger.Error("[Init] 營業員基本資料檔,初始化錯誤");
                MessageBox.Show("營業員資料檔 初始化錯誤，請立即反應資訊部同仁，系統即將關閉", "初始化錯誤",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.ServiceNotification);
                return false;
            }
        }
        /// <summary>
        /// 取得資料庫開收盤時間設定資訊
        /// </summary>
        /// <returns></returns>
        private bool Get_TradeTime()
        {
            string[] parameters = { };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_QOrderSetting", parameters);

            if (result.StatusCode == rCode.Success)
            {
                foreach (var item in result.Deatils)
                {
                    string[] info = item.Split('|');
                    string open_time = info[1].Substring(0, 2) + info[1].Substring(3, 2);
                    string close_time = info[2].Substring(0, 2) + info[2].Substring(3, 2);
                    _OrderHandler.Set_Trade_Time(info[0], open_time, close_time, info[3]);
                }
                return true;
            }
            else
            {
                ConcordLogger.Logger.Error("[Init] 盤別交易時間,初始化錯誤");
                MessageBox.Show("盤別交易時間 初始化錯誤，請立即反應資訊部同仁，系統即將關閉", "初始化錯誤",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.ServiceNotification);
                return false;
            }
        }
        /// <summary>
        /// 執行Gateway連線
        /// </summary>
        public void ConnectGateway()
        {
            if (_SOrderSession.ClientConnectState != ConnectState.Connected || _SOrderSession.ClientConnectState != ConnectState.Connecting)
                _SOrderSession.DoConnect();
            if (_PushGWSession.ClientConnectState != ConnectState.Connected || _PushGWSession.ClientConnectState != ConnectState.Connecting)
                _PushGWSession.DoConnect();
            if ((_TradingSystemSession.ClientConnectState != ConnectState.Connected || _TradingSystemSession.ClientConnectState != ConnectState.Connecting) && _Model != 2)//自營不connect
                _TradingSystemSession.DoConnect();
        }
        /// <summary>
        /// 回補完成通知事件
        /// </summary>
        public void RecoverCompleted()
        {
            Invoke((Action)(() =>
            {
                // 重新回補完後，將之前下單的委託序號加入_OrdDSEQ中，用以比對此台主機下出去之委託單
                // 須等回補是避免回補到兩次資料
                //foreach (DataRow row in _OrderStore._KeyInDetailStore.Rows)
                //{
                //    if (!_OrderStore._OrdDSEQ.ContainsKey(row["DSEQ"].ToString()))
                //        _OrderStore._OrdDSEQ.TryAdd(row["DSEQ"].ToString(), row["DSEQ"].ToString());
                //}
                // 待回補完成後在註冊委託快捷功能
                //tab_Order.KeyUp += new KeyEventHandler(tab_Order_KeyUp);
                panel_Recover.Visible = false;
            }));
        }
        public void EMRecoverCompleted()
        {
            BeginInvoke((Action)(() =>
            {
                label185.ForeColor = Color.Lime;
                label185.Text = "[登錄正常]";
            }));
        }
        #endregion

    }
}
