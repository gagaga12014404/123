﻿namespace Concord.KeyIn.Client
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle65 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle77 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle78 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle67 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle68 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle69 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle70 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle71 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle72 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle73 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle74 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle75 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle76 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tsMainStatus = new System.Windows.Forms.ToolStrip();
            this.tslSOrderSend = new System.Windows.Forms.ToolStripLabel();
            this.tslPushServer = new System.Windows.Forms.ToolStripLabel();
            this.tSLEnvironment = new System.Windows.Forms.ToolStripLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tab_Request = new System.Windows.Forms.TabControl();
            this.tabPagKeyIn = new System.Windows.Forms.TabPage();
            this.DGVEmstOrder = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrdQty_EMKeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDealQty_EMKeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTransactTime_EMKeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGVKeyIn = new System.Windows.Forms.DataGridView();
            this.colBHNO_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCDI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDSEQ_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCSEQ_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOType_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStock_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStockName_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBefChgQty_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrdQty_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrdPrice_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSide_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDealQty_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTimeInForce_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTransTime_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colErrText_KeyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ECode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPagRequest = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.DGVEmstRequest = new System.Windows.Forms.DataGridView();
            this.colEmCheckDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colEmDeleteBtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colEmChangeQtyBtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colEmChangePriceBtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmDSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmCSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmCusName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmStockName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmSide = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmOrdPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmOrdQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmCancelQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmDealQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmDealPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGVRequest = new System.Windows.Forms.DataGridView();
            this.colCheckDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colDeleteOrder = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colChangeOrder = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colChangePrice = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colTransactTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCusName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSTOCK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSTOCKNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colECODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSide = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSTATUS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTimeInForce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrdPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrdQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCancelQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDealQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDealPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClOrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColOrigin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColLaveQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txbFilterCSEQ = new System.Windows.Forms.TextBox();
            this.labDealAmt = new System.Windows.Forms.Label();
            this.labDealQty = new System.Windows.Forms.Label();
            this.labRequestAmt = new System.Windows.Forms.Label();
            this.labRequestQty = new System.Windows.Forms.Label();
            this.labCount = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.rbNoDeal = new System.Windows.Forms.RadioButton();
            this.rbDeal = new System.Windows.Forms.RadioButton();
            this.rbAll = new System.Windows.Forms.RadioButton();
            this.btnFilterClear = new System.Windows.Forms.Button();
            this.btnFilterOK = new System.Windows.Forms.Button();
            this.txbFilterDSEQ = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnMultiDeleAllCancel = new System.Windows.Forms.Button();
            this.btnMultiDeleAllSelect = new System.Windows.Forms.Button();
            this.btnMultiDeleAllOK = new System.Windows.Forms.Button();
            this.tabPagDeal = new System.Windows.Forms.TabPage();
            this.tabLayPanel_DealView = new System.Windows.Forms.TableLayoutPanel();
            this.DGVCheckDeal = new System.Windows.Forms.DataGridView();
            this.col_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_BHNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colum_ECODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TimeInForce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_OQTY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_OTYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_STOCK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_STOCKNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_BS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CheckStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DPRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DQTY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_AllDQTY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabLayPanel_DealQueryControl = new System.Windows.Forms.TableLayoutPanel();
            this.Btn_QueryDeal = new System.Windows.Forms.Button();
            this.LabQueryDealTime = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdbRL = new System.Windows.Forms.RadioButton();
            this.rdbFP = new System.Windows.Forms.RadioButton();
            this.rdbOD = new System.Windows.Forms.RadioButton();
            this.tabLayOutChkQueryInfo = new System.Windows.Forms.TableLayoutPanel();
            this.LabChkDealQR5 = new System.Windows.Forms.Label();
            this.LabChkDealQR4 = new System.Windows.Forms.Label();
            this.LabChkDealQT4 = new System.Windows.Forms.Label();
            this.LabChkDealQR3 = new System.Windows.Forms.Label();
            this.LabChkDealQR2 = new System.Windows.Forms.Label();
            this.LabChkDealQR1 = new System.Windows.Forms.Label();
            this.LabChkDealQT1 = new System.Windows.Forms.Label();
            this.LabChkDealQCount = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.LabChkDealQDSEQ = new System.Windows.Forms.Label();
            this.LabChkDealQT2 = new System.Windows.Forms.Label();
            this.LabChkDealQT3 = new System.Windows.Forms.Label();
            this.LabCheckFinishInfo = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.LabChkDealQT5 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.Lab_TodayLastFill = new System.Windows.Forms.Label();
            this.tabPagPassiveRequest = new System.Windows.Forms.TabPage();
            this.DGVPasRequest = new System.Windows.Forms.DataGridView();
            this.col_CheckDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.col_DeleteOrder = new System.Windows.Forms.DataGridViewButtonColumn();
            this.col_ChangeOrder = new System.Windows.Forms.DataGridViewButtonColumn();
            this.col_ChangePrice = new System.Windows.Forms.DataGridViewButtonColumn();
            this.col_TransactTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__DSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__CSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CusName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__STOCK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__STOCKNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__ECODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col__OType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Side = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_STATUS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col__TimeInForce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_OrdPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_OrdQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_CancelQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DealQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_DealPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Mtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_Text = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ClOrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Origin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_LaveQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbPasFilterCSEQ = new System.Windows.Forms.TextBox();
            this.labPasDealAmt = new System.Windows.Forms.Label();
            this.labPasDealQty = new System.Windows.Forms.Label();
            this.labPasRequestAmt = new System.Windows.Forms.Label();
            this.labPasRequestQty = new System.Windows.Forms.Label();
            this.labPasCount = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rbPasNoDeal = new System.Windows.Forms.RadioButton();
            this.rbPasDeal = new System.Windows.Forms.RadioButton();
            this.rbPasAll = new System.Windows.Forms.RadioButton();
            this.btnPasFilterClear = new System.Windows.Forms.Button();
            this.btnPasFilterOK = new System.Windows.Forms.Button();
            this.txbPasFilterDSEQ = new System.Windows.Forms.TextBox();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.btnPasMultiDeleAllCancel = new System.Windows.Forms.Button();
            this.btnPasMultiDeleAllSelect = new System.Windows.Forms.Button();
            this.btnPasMultiDeleAllOK = new System.Windows.Forms.Button();
            this.tab_Order = new System.Windows.Forms.TabControl();
            this.RoundLot = new System.Windows.Forms.TabPage();
            this.panel_RoundLot = new System.Windows.Forms.Panel();
            this.ChKSplitLot = new System.Windows.Forms.CheckBox();
            this.Lab_OrdTypeInfo = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.RL_LabOrdType = new System.Windows.Forms.Label();
            this.RL_TxbOrdType = new System.Windows.Forms.TextBox();
            this.RL_LabCCodeText = new System.Windows.Forms.Label();
            this.RL_LanWarText = new System.Windows.Forms.Label();
            this.RL_LabCancelQty = new System.Windows.Forms.Label();
            this.RL_BtnForceChangeQty = new System.Windows.Forms.Button();
            this.RL_BtnForceReturn = new System.Windows.Forms.Button();
            this.RL_BtnForceOrder = new System.Windows.Forms.Button();
            this.RL_BtnForceClear = new System.Windows.Forms.Button();
            this.RL_LabInfo = new System.Windows.Forms.Label();
            this.RL_LabOrdErrMsg = new System.Windows.Forms.Label();
            this.RL_TxbTERM = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.RL_BtnChangeTargetNo = new System.Windows.Forms.Button();
            this.RL_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.RL_LabTDate = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.RL_BtnSellFallTick = new System.Windows.Forms.Button();
            this.RL_BtnBuyRiseTick = new System.Windows.Forms.Button();
            this.RL_LabQueryDealQty = new System.Windows.Forms.Label();
            this.RL_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.RL_TxbECode = new System.Windows.Forms.TextBox();
            this.RL_BtnQuery = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RL_LabBHNO = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labECodeUnit = new System.Windows.Forms.Label();
            this.RL_TxbSale = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.RL_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.btn_OpenFrmTimeSharing = new System.Windows.Forms.Button();
            this.RL_BtnChgPrice = new System.Windows.Forms.Button();
            this.RL_BtnOType = new System.Windows.Forms.Button();
            this.RL_BtnChgOrder = new System.Windows.Forms.Button();
            this.RL_BtnDelOrder = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.RL_LabFinanceState = new System.Windows.Forms.Label();
            this.RL_LabStockState = new System.Windows.Forms.Label();
            this.RL_BtnFallPrice = new System.Windows.Forms.Button();
            this.RL_BtnCPrice = new System.Windows.Forms.Button();
            this.RL_BtnRiskPrice = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.RL_LabCSEQName = new System.Windows.Forms.Label();
            this.RL_LabMType = new System.Windows.Forms.Label();
            this.RL_TxbPrice = new System.Windows.Forms.TextBox();
            this.RL_TxbStockQty = new System.Windows.Forms.TextBox();
            this.RL_LabStockName = new System.Windows.Forms.Label();
            this.RL_TxbStockNo = new System.Windows.Forms.TextBox();
            this.RL_LabOType = new System.Windows.Forms.Label();
            this.RL_TxbOType = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.RL_CkbFixedCSEQ = new System.Windows.Forms.CheckBox();
            this.RL_BtnSell = new System.Windows.Forms.Button();
            this.RL_BtnClear = new System.Windows.Forms.Button();
            this.RL_BtnBuy = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.OddLot = new System.Windows.Forms.TabPage();
            this.panel_OddLot = new System.Windows.Forms.Panel();
            this.OD_LabCCodeText = new System.Windows.Forms.Label();
            this.OD_LanWarText = new System.Windows.Forms.Label();
            this.OD_TxbStockQty = new System.Windows.Forms.TextBox();
            this.OD_LabCancelQty = new System.Windows.Forms.Label();
            this.OD_BtnForceChangeQty = new System.Windows.Forms.Button();
            this.OD_BtnForceReturn = new System.Windows.Forms.Button();
            this.OD_BtnForceOrder = new System.Windows.Forms.Button();
            this.OD_BtnForceClear = new System.Windows.Forms.Button();
            this.OD_LabInfo = new System.Windows.Forms.Label();
            this.OD_LabOrdErrMsg = new System.Windows.Forms.Label();
            this.OD_TxbTERM = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.OD_BtnChangeTargetNo = new System.Windows.Forms.Button();
            this.OD_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.button31 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.OD_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.OD_LabTDate = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.OD_TxbECode = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.OD_LabBHNO = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.OD_TxbSale = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.OD_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.OD_LabFinanceState = new System.Windows.Forms.Label();
            this.OD_LabStockState = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.OD_LabCSEQName = new System.Windows.Forms.Label();
            this.OD_LabMType = new System.Windows.Forms.Label();
            this.OD_TxbPrice = new System.Windows.Forms.TextBox();
            this.OD_LabStockName = new System.Windows.Forms.Label();
            this.OD_TxbStockNo = new System.Windows.Forms.TextBox();
            this.OD_CkbFixedCSEQ = new System.Windows.Forms.CheckBox();
            this.label54 = new System.Windows.Forms.Label();
            this.FixedPrice = new System.Windows.Forms.TabPage();
            this.panel_FixedPrice = new System.Windows.Forms.Panel();
            this.FP_LabCCodeText = new System.Windows.Forms.Label();
            this.FP_LanWarText = new System.Windows.Forms.Label();
            this.FP_TxbStockQty = new System.Windows.Forms.TextBox();
            this.FP_LabCancelQty = new System.Windows.Forms.Label();
            this.FP_BtnForceChangeQty = new System.Windows.Forms.Button();
            this.FP_BtnForceReturn = new System.Windows.Forms.Button();
            this.FP_BtnForceOrder = new System.Windows.Forms.Button();
            this.FP_BtnForceClear = new System.Windows.Forms.Button();
            this.FP_LabInfo = new System.Windows.Forms.Label();
            this.FP_LabOrdErrMsg = new System.Windows.Forms.Label();
            this.FP_TxbTERM = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.FP_BtnChangeTargetNo = new System.Windows.Forms.Button();
            this.FP_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.FP_LabQueryDealQty = new System.Windows.Forms.Label();
            this.FP_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.FP_LabTDate = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.FP_TxbECode = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.FP_LabBHNO = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.FP_TxbSale = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.FP_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.FP_BtnOType = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.label73 = new System.Windows.Forms.Label();
            this.FP_LabFinanceState = new System.Windows.Forms.Label();
            this.FP_LabStockState = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.label76 = new System.Windows.Forms.Label();
            this.FP_LabCSEQName = new System.Windows.Forms.Label();
            this.FP_LabMType = new System.Windows.Forms.Label();
            this.FP_TxbPrice = new System.Windows.Forms.TextBox();
            this.FP_LabStockName = new System.Windows.Forms.Label();
            this.FP_TxbStockNo = new System.Windows.Forms.TextBox();
            this.FP_LabOType = new System.Windows.Forms.Label();
            this.FP_TxbOType = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.FP_CkbFixedCSEQ = new System.Windows.Forms.CheckBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.StockBorrow = new System.Windows.Forms.TabPage();
            this.panel_StockBorrow = new System.Windows.Forms.Panel();
            this.SB_LabCSEQName = new System.Windows.Forms.Label();
            this.SB_LabStockName = new System.Windows.Forms.Label();
            this.SB_LabCCodeText = new System.Windows.Forms.Label();
            this.SB_LabCancelQty = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.SB_LabOrdErrMsg = new System.Windows.Forms.Label();
            this.SB_LabBHNO = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.SB_LabTDate = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.label85 = new System.Windows.Forms.Label();
            this.button36 = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.SB_TxbTERM = new System.Windows.Forms.TextBox();
            this.button34 = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.SB_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.SB_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.SB_TxbSale = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.SB_TxbBS = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.SB_TxbPrice = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.SB_TxbStockQty = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.SB_TxbStockNo = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.SB_TxbTDCC = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.SB_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.StockPurchase = new System.Windows.Forms.TabPage();
            this.panel_StockPurchase = new System.Windows.Forms.Panel();
            this.SP_LabCCodeText = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.SP_LabQueryDealQty = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.label110 = new System.Windows.Forms.Label();
            this.SP_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.SP_LabBHNO = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.SP_TxbPrice = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.SP_LabStockName = new System.Windows.Forms.Label();
            this.SP_TxbSerialNum = new System.Windows.Forms.TextBox();
            this.SP_TxbStockNo = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.SP_LabCSEQName = new System.Windows.Forms.Label();
            this.SP_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.SP_LabCancelQty = new System.Windows.Forms.Label();
            this.SP_TxbStockQty = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label104 = new System.Windows.Forms.Label();
            this.SP_TxbTERM = new System.Windows.Forms.TextBox();
            this.SP_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.SP_LabTDate = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.StockPurchase2 = new System.Windows.Forms.TabPage();
            this.panel_StockPurchase2 = new System.Windows.Forms.Panel();
            this.SP2_LabCCodeText = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.SP2_LabQueryDealQty = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.label144 = new System.Windows.Forms.Label();
            this.SP2_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.button58 = new System.Windows.Forms.Button();
            this.SP2_LabBHNO = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.SP2_TxbPrice = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.SP2_LabStockName = new System.Windows.Forms.Label();
            this.SP2_TxbSerialNum = new System.Windows.Forms.TextBox();
            this.SP2_TxbStockNo = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.SP2_LabCSEQName = new System.Windows.Forms.Label();
            this.SP2_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.SP2_LabCancelQty = new System.Windows.Forms.Label();
            this.SP2_TxbStockQty = new System.Windows.Forms.TextBox();
            this.label154 = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.label155 = new System.Windows.Forms.Label();
            this.SP2_TxbTERM = new System.Windows.Forms.TextBox();
            this.SP2_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.SP2_LabTDate = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.StockAuction = new System.Windows.Forms.TabPage();
            this.panel_StockAuction = new System.Windows.Forms.Panel();
            this.SA_LabCSEQName = new System.Windows.Forms.Label();
            this.SA_LabStockName = new System.Windows.Forms.Label();
            this.SA_LabCancelQty = new System.Windows.Forms.Label();
            this.SA_LabCCodeText = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.SA_LabBHNO = new System.Windows.Forms.Label();
            this.SA_LabQueryDealQty = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.SA_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.SA_LabTDate = new System.Windows.Forms.Label();
            this.SA_TxbStockNo = new System.Windows.Forms.TextBox();
            this.label121 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.button50 = new System.Windows.Forms.Button();
            this.SA_TxbTERM = new System.Windows.Forms.TextBox();
            this.button49 = new System.Windows.Forms.Button();
            this.label119 = new System.Windows.Forms.Label();
            this.button48 = new System.Windows.Forms.Button();
            this.SA_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.button46 = new System.Windows.Forms.Button();
            this.label118 = new System.Windows.Forms.Label();
            this.button47 = new System.Windows.Forms.Button();
            this.label122 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.SA_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.label127 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.SA_TxbPrice = new System.Windows.Forms.TextBox();
            this.SA_TxbStockQty = new System.Windows.Forms.TextBox();
            this.label125 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ErrAccount = new System.Windows.Forms.TabPage();
            this.panel_ErrAccout = new System.Windows.Forms.Panel();
            this.ER_BtnForceChangeQty = new System.Windows.Forms.Button();
            this.ER_BtnForceReturn = new System.Windows.Forms.Button();
            this.ER_BtnForceOrder = new System.Windows.Forms.Button();
            this.ER_BtnForceClear = new System.Windows.Forms.Button();
            this.ER_LanWarText = new System.Windows.Forms.Label();
            this.ER_LabInfo = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.ER_TxbTERM = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.ER_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.button43 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.ER_LabQueryDealQty = new System.Windows.Forms.Label();
            this.ER_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label136 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.ER_LabCancelQty = new System.Windows.Forms.Label();
            this.ER_TxbStockQty = new System.Windows.Forms.TextBox();
            this.ER_LabUnit = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.ER_LabECodeText = new System.Windows.Forms.Label();
            this.ER_TxbECode = new System.Windows.Forms.TextBox();
            this.ER_LabErAccount = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.ER_TxbPrice = new System.Windows.Forms.TextBox();
            this.ER_LabOrdQty = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.ER_LabStockName = new System.Windows.Forms.Label();
            this.ER_TxbStockNo = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.ER_LabOrdType = new System.Windows.Forms.Label();
            this.ER_TxbOrdType = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.ER_LabTDate = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.ER_LabBHNO = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.Emst = new System.Windows.Forms.TabPage();
            this.panel_Emst = new System.Windows.Forms.Panel();
            this.EM_Message = new System.Windows.Forms.Label();
            this.EM_LanWarText = new System.Windows.Forms.Label();
            this.EM_LabCCodeText = new System.Windows.Forms.Label();
            this.EM_LabStockState = new System.Windows.Forms.Label();
            this.EM_CkbFixedCSEQ = new System.Windows.Forms.CheckBox();
            this.label161 = new System.Windows.Forms.Label();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.EM_LabCancelQty = new System.Windows.Forms.Label();
            this.EM_Search = new System.Windows.Forms.Label();
            this.EM_BasicPrice = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.EM_BuySell = new System.Windows.Forms.TextBox();
            this.label142 = new System.Windows.Forms.Label();
            this.EM_LabelUnit = new System.Windows.Forms.Label();
            this.EM_TxbTERM = new System.Windows.Forms.TextBox();
            this.label160 = new System.Windows.Forms.Label();
            this.EM_TxbCSEQ = new System.Windows.Forms.TextBox();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.EM_LabTDate = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.EM_LabBHNO = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.EM_Sales = new System.Windows.Forms.TextBox();
            this.label177 = new System.Windows.Forms.Label();
            this.EM_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.button63 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.label178 = new System.Windows.Forms.Label();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.label181 = new System.Windows.Forms.Label();
            this.EM_LabCSEQName = new System.Windows.Forms.Label();
            this.EM_TxbPrice = new System.Windows.Forms.TextBox();
            this.EM_TxbStockQty = new System.Windows.Forms.TextBox();
            this.EM_LabStockName = new System.Windows.Forms.Label();
            this.EM_TxbStockNo = new System.Windows.Forms.TextBox();
            this.label185 = new System.Windows.Forms.Label();
            this.button75 = new System.Windows.Forms.Button();
            this.EmstErrAccount = new System.Windows.Forms.TabPage();
            this.panel_EmstErrAccount = new System.Windows.Forms.Panel();
            this.EMER_LanWarText = new System.Windows.Forms.Label();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.EMER_TxbTERM = new System.Windows.Forms.TextBox();
            this.label151 = new System.Windows.Forms.Label();
            this.EMER_TxbDSEQ = new System.Windows.Forms.TextBox();
            this.label158 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.label168 = new System.Windows.Forms.Label();
            this.EMER_TxbStockQty = new System.Windows.Forms.TextBox();
            this.EMER_LabelUnit = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.EMER_TxbPrice = new System.Windows.Forms.TextBox();
            this.label182 = new System.Windows.Forms.Label();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.EMER_LabStockName = new System.Windows.Forms.Label();
            this.EMER_TxbStockNo = new System.Windows.Forms.TextBox();
            this.label186 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.EMER_BasicPrice = new System.Windows.Forms.TextBox();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.EMER_BtnForceOrder = new System.Windows.Forms.Button();
            this.EMER_BtnForceClear = new System.Windows.Forms.Button();
            this.EMER_LabInfo = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.EMER_LabQueryDealQty = new System.Windows.Forms.Label();
            this.EMER_LabQueryLaveQty = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.EMER_LabTDate = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.EMER_LabBHNO = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.設定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.委託設定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.上傳LogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.panel_Recover = new System.Windows.Forms.Panel();
            this.LabRecoverInfo = new System.Windows.Forms.Label();
            this.EmTradingCheck = new System.Windows.Forms.Label();
            this.tsMainStatus.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tab_Request.SuspendLayout();
            this.tabPagKeyIn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVEmstOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVKeyIn)).BeginInit();
            this.tabPagRequest.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVEmstRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVRequest)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPagDeal.SuspendLayout();
            this.tabLayPanel_DealView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCheckDeal)).BeginInit();
            this.tabLayPanel_DealQueryControl.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabLayOutChkQueryInfo.SuspendLayout();
            this.tabPagPassiveRequest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVPasRequest)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tab_Order.SuspendLayout();
            this.RoundLot.SuspendLayout();
            this.panel_RoundLot.SuspendLayout();
            this.OddLot.SuspendLayout();
            this.panel_OddLot.SuspendLayout();
            this.FixedPrice.SuspendLayout();
            this.panel_FixedPrice.SuspendLayout();
            this.StockBorrow.SuspendLayout();
            this.panel_StockBorrow.SuspendLayout();
            this.StockPurchase.SuspendLayout();
            this.panel_StockPurchase.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.StockPurchase2.SuspendLayout();
            this.panel_StockPurchase2.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.StockAuction.SuspendLayout();
            this.panel_StockAuction.SuspendLayout();
            this.ErrAccount.SuspendLayout();
            this.panel_ErrAccout.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.Emst.SuspendLayout();
            this.panel_Emst.SuspendLayout();
            this.EmstErrAccount.SuspendLayout();
            this.panel_EmstErrAccount.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel_Recover.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsMainStatus
            // 
            this.tsMainStatus.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsMainStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslSOrderSend,
            this.tslPushServer,
            this.tSLEnvironment});
            this.tsMainStatus.Location = new System.Drawing.Point(0, 29);
            this.tsMainStatus.Name = "tsMainStatus";
            this.tsMainStatus.Size = new System.Drawing.Size(1067, 25);
            this.tsMainStatus.TabIndex = 6;
            this.tsMainStatus.Text = "toolStrip1";
            // 
            // tslSOrderSend
            // 
            this.tslSOrderSend.ActiveLinkColor = System.Drawing.Color.Red;
            this.tslSOrderSend.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tslSOrderSend.ForeColor = System.Drawing.Color.Red;
            this.tslSOrderSend.Name = "tslSOrderSend";
            this.tslSOrderSend.Size = new System.Drawing.Size(161, 22);
            this.tslSOrderSend.Text = "上市櫃下單連線失敗";
            // 
            // tslPushServer
            // 
            this.tslPushServer.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tslPushServer.ForeColor = System.Drawing.Color.Red;
            this.tslPushServer.Name = "tslPushServer";
            this.tslPushServer.Size = new System.Drawing.Size(110, 22);
            this.tslPushServer.Text = "回報連線失敗";
            // 
            // tSLEnvironment
            // 
            this.tSLEnvironment.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.tSLEnvironment.BackColor = System.Drawing.SystemColors.Control;
            this.tSLEnvironment.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tSLEnvironment.Margin = new System.Windows.Forms.Padding(400, 1, 0, 2);
            this.tSLEnvironment.Name = "tSLEnvironment";
            this.tSLEnvironment.Size = new System.Drawing.Size(76, 22);
            this.tSLEnvironment.Text = "測試環境";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tab_Request, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tab_Order, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 54);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1067, 620);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // tab_Request
            // 
            this.tab_Request.Controls.Add(this.tabPagKeyIn);
            this.tab_Request.Controls.Add(this.tabPagRequest);
            this.tab_Request.Controls.Add(this.tabPagDeal);
            this.tab_Request.Controls.Add(this.tabPagPassiveRequest);
            this.tab_Request.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Request.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tab_Request.Location = new System.Drawing.Point(0, 400);
            this.tab_Request.Margin = new System.Windows.Forms.Padding(0);
            this.tab_Request.Name = "tab_Request";
            this.tab_Request.Padding = new System.Drawing.Point(0, 0);
            this.tab_Request.SelectedIndex = 0;
            this.tab_Request.Size = new System.Drawing.Size(1067, 220);
            this.tab_Request.TabIndex = 3;
            this.tab_Request.TabStop = false;
            this.tab_Request.SelectedIndexChanged += new System.EventHandler(this.tab_Request_SelectedIndexChanged);
            // 
            // tabPagKeyIn
            // 
            this.tabPagKeyIn.BackColor = System.Drawing.Color.Transparent;
            this.tabPagKeyIn.Controls.Add(this.DGVEmstOrder);
            this.tabPagKeyIn.Controls.Add(this.DGVKeyIn);
            this.tabPagKeyIn.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabPagKeyIn.ForeColor = System.Drawing.Color.Lime;
            this.tabPagKeyIn.Location = new System.Drawing.Point(4, 26);
            this.tabPagKeyIn.Name = "tabPagKeyIn";
            this.tabPagKeyIn.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagKeyIn.Size = new System.Drawing.Size(1059, 190);
            this.tabPagKeyIn.TabIndex = 2;
            this.tabPagKeyIn.Text = "KeyIn明細";
            // 
            // DGVEmstOrder
            // 
            this.DGVEmstOrder.AllowUserToAddRows = false;
            this.DGVEmstOrder.AllowUserToDeleteRows = false;
            this.DGVEmstOrder.AllowUserToResizeRows = false;
            this.DGVEmstOrder.BackgroundColor = System.Drawing.Color.Black;
            this.DGVEmstOrder.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVEmstOrder.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVEmstOrder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DGVEmstOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVEmstOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn7,
            this.colOrdQty_EMKeyIn,
            this.colDealQty_EMKeyIn,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.colTransactTime_EMKeyIn,
            this.dataGridViewTextBoxColumn16});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVEmstOrder.DefaultCellStyle = dataGridViewCellStyle12;
            this.DGVEmstOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVEmstOrder.EnableHeadersVisualStyles = false;
            this.DGVEmstOrder.GridColor = System.Drawing.Color.Black;
            this.DGVEmstOrder.Location = new System.Drawing.Point(3, 3);
            this.DGVEmstOrder.Name = "DGVEmstOrder";
            this.DGVEmstOrder.RowHeadersVisible = false;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Lime;
            this.DGVEmstOrder.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.DGVEmstOrder.RowTemplate.Height = 24;
            this.DGVEmstOrder.Size = new System.Drawing.Size(1053, 184);
            this.DGVEmstOrder.TabIndex = 3;
            this.DGVEmstOrder.TabStop = false;
            this.DGVEmstOrder.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DGVEmstKeyIn_CellFormatting);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ExecType";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn2.HeaderText = "種類";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 55;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "BHNO";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn1.HeaderText = "分公司";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 75;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DSEQ";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn3.HeaderText = "委託序號";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CSEQ";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn4.HeaderText = "客戶帳號";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 95;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Stock";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn7.HeaderText = "商品代號";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 95;
            // 
            // colOrdQty_EMKeyIn
            // 
            this.colOrdQty_EMKeyIn.DataPropertyName = "OrdQty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colOrdQty_EMKeyIn.DefaultCellStyle = dataGridViewCellStyle7;
            this.colOrdQty_EMKeyIn.FillWeight = 90F;
            this.colOrdQty_EMKeyIn.HeaderText = "委託股數";
            this.colOrdQty_EMKeyIn.Name = "colOrdQty_EMKeyIn";
            this.colOrdQty_EMKeyIn.ReadOnly = true;
            this.colOrdQty_EMKeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOrdQty_EMKeyIn.Width = 95;
            // 
            // colDealQty_EMKeyIn
            // 
            this.colDealQty_EMKeyIn.DataPropertyName = "DealQty";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colDealQty_EMKeyIn.DefaultCellStyle = dataGridViewCellStyle8;
            this.colDealQty_EMKeyIn.FillWeight = 90F;
            this.colDealQty_EMKeyIn.HeaderText = "成交股數";
            this.colDealQty_EMKeyIn.Name = "colDealQty_EMKeyIn";
            this.colDealQty_EMKeyIn.ReadOnly = true;
            this.colDealQty_EMKeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDealQty_EMKeyIn.Width = 105;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "OrdPrice";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn11.HeaderText = "價格";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 55;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Side";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn12.HeaderText = "買賣";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 55;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Status";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn13.HeaderText = "狀態";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 65;
            // 
            // colTransactTime_EMKeyIn
            // 
            this.colTransactTime_EMKeyIn.DataPropertyName = "TransactTime";
            this.colTransactTime_EMKeyIn.HeaderText = "交易時間";
            this.colTransactTime_EMKeyIn.Name = "colTransactTime_EMKeyIn";
            this.colTransactTime_EMKeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colTransactTime_EMKeyIn.Width = 95;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Text";
            this.dataGridViewTextBoxColumn16.HeaderText = "敘述";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn16.Width = 350;
            // 
            // DGVKeyIn
            // 
            this.DGVKeyIn.AllowUserToAddRows = false;
            this.DGVKeyIn.AllowUserToDeleteRows = false;
            this.DGVKeyIn.AllowUserToResizeRows = false;
            this.DGVKeyIn.BackgroundColor = System.Drawing.Color.Black;
            this.DGVKeyIn.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVKeyIn.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVKeyIn.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.DGVKeyIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVKeyIn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colBHNO_KeyIn,
            this.colCDI,
            this.colDSEQ_KeyIn,
            this.colCSEQ_KeyIn,
            this.colStatus_KeyIn,
            this.colOType_KeyIn,
            this.colStock_KeyIn,
            this.colStockName_KeyIn,
            this.colBefChgQty_KeyIn,
            this.colOrdQty_KeyIn,
            this.colOrdPrice_KeyIn,
            this.colSide_KeyIn,
            this.colDealQty_KeyIn,
            this.ColTimeInForce_KeyIn,
            this.colTransTime_KeyIn,
            this.colErrText_KeyIn,
            this.col_ECode});
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVKeyIn.DefaultCellStyle = dataGridViewCellStyle29;
            this.DGVKeyIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVKeyIn.EnableHeadersVisualStyles = false;
            this.DGVKeyIn.GridColor = System.Drawing.Color.Black;
            this.DGVKeyIn.Location = new System.Drawing.Point(3, 3);
            this.DGVKeyIn.Name = "DGVKeyIn";
            this.DGVKeyIn.RowHeadersVisible = false;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Lime;
            this.DGVKeyIn.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.DGVKeyIn.RowTemplate.Height = 24;
            this.DGVKeyIn.Size = new System.Drawing.Size(1053, 184);
            this.DGVKeyIn.TabIndex = 0;
            this.DGVKeyIn.TabStop = false;
            this.DGVKeyIn.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DGVKeyIn_CellFormatting);
            this.DGVKeyIn.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.DGVKeyIn_DataError);
            // 
            // colBHNO_KeyIn
            // 
            this.colBHNO_KeyIn.DataPropertyName = "BHNO";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colBHNO_KeyIn.DefaultCellStyle = dataGridViewCellStyle15;
            this.colBHNO_KeyIn.HeaderText = "分公司";
            this.colBHNO_KeyIn.Name = "colBHNO_KeyIn";
            this.colBHNO_KeyIn.ReadOnly = true;
            this.colBHNO_KeyIn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBHNO_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colBHNO_KeyIn.Width = 75;
            // 
            // colCDI
            // 
            this.colCDI.DataPropertyName = "ExecType";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCDI.DefaultCellStyle = dataGridViewCellStyle16;
            this.colCDI.HeaderText = "種類";
            this.colCDI.Name = "colCDI";
            this.colCDI.ReadOnly = true;
            this.colCDI.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCDI.Width = 55;
            // 
            // colDSEQ_KeyIn
            // 
            this.colDSEQ_KeyIn.DataPropertyName = "DSEQ";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDSEQ_KeyIn.DefaultCellStyle = dataGridViewCellStyle17;
            this.colDSEQ_KeyIn.HeaderText = "委託序號";
            this.colDSEQ_KeyIn.Name = "colDSEQ_KeyIn";
            this.colDSEQ_KeyIn.ReadOnly = true;
            this.colDSEQ_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDSEQ_KeyIn.Width = 95;
            // 
            // colCSEQ_KeyIn
            // 
            this.colCSEQ_KeyIn.DataPropertyName = "CSEQ";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCSEQ_KeyIn.DefaultCellStyle = dataGridViewCellStyle18;
            this.colCSEQ_KeyIn.HeaderText = "客戶帳號";
            this.colCSEQ_KeyIn.Name = "colCSEQ_KeyIn";
            this.colCSEQ_KeyIn.ReadOnly = true;
            this.colCSEQ_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCSEQ_KeyIn.Width = 95;
            // 
            // colStatus_KeyIn
            // 
            this.colStatus_KeyIn.DataPropertyName = "Status";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colStatus_KeyIn.DefaultCellStyle = dataGridViewCellStyle19;
            this.colStatus_KeyIn.HeaderText = "狀態";
            this.colStatus_KeyIn.Name = "colStatus_KeyIn";
            this.colStatus_KeyIn.ReadOnly = true;
            this.colStatus_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colStatus_KeyIn.Width = 55;
            // 
            // colOType_KeyIn
            // 
            this.colOType_KeyIn.DataPropertyName = "OType";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colOType_KeyIn.DefaultCellStyle = dataGridViewCellStyle20;
            this.colOType_KeyIn.HeaderText = "類";
            this.colOType_KeyIn.Name = "colOType_KeyIn";
            this.colOType_KeyIn.ReadOnly = true;
            this.colOType_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOType_KeyIn.Width = 30;
            // 
            // colStock_KeyIn
            // 
            this.colStock_KeyIn.DataPropertyName = "Stock";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colStock_KeyIn.DefaultCellStyle = dataGridViewCellStyle21;
            this.colStock_KeyIn.HeaderText = "商品代號";
            this.colStock_KeyIn.Name = "colStock_KeyIn";
            this.colStock_KeyIn.ReadOnly = true;
            this.colStock_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colStock_KeyIn.Width = 95;
            // 
            // colStockName_KeyIn
            // 
            this.colStockName_KeyIn.DataPropertyName = "StockName";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colStockName_KeyIn.DefaultCellStyle = dataGridViewCellStyle22;
            this.colStockName_KeyIn.HeaderText = "名稱";
            this.colStockName_KeyIn.Name = "colStockName_KeyIn";
            this.colStockName_KeyIn.ReadOnly = true;
            this.colStockName_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colStockName_KeyIn.Width = 130;
            // 
            // colBefChgQty_KeyIn
            // 
            this.colBefChgQty_KeyIn.DataPropertyName = "BeforeChangeQty";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colBefChgQty_KeyIn.DefaultCellStyle = dataGridViewCellStyle23;
            this.colBefChgQty_KeyIn.HeaderText = "改前";
            this.colBefChgQty_KeyIn.Name = "colBefChgQty_KeyIn";
            this.colBefChgQty_KeyIn.ReadOnly = true;
            this.colBefChgQty_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colBefChgQty_KeyIn.Width = 55;
            // 
            // colOrdQty_KeyIn
            // 
            this.colOrdQty_KeyIn.DataPropertyName = "OrdQty";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colOrdQty_KeyIn.DefaultCellStyle = dataGridViewCellStyle24;
            this.colOrdQty_KeyIn.HeaderText = "委託";
            this.colOrdQty_KeyIn.Name = "colOrdQty_KeyIn";
            this.colOrdQty_KeyIn.ReadOnly = true;
            this.colOrdQty_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOrdQty_KeyIn.Width = 55;
            // 
            // colOrdPrice_KeyIn
            // 
            this.colOrdPrice_KeyIn.DataPropertyName = "OrdPrice";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colOrdPrice_KeyIn.DefaultCellStyle = dataGridViewCellStyle25;
            this.colOrdPrice_KeyIn.HeaderText = "價格";
            this.colOrdPrice_KeyIn.Name = "colOrdPrice_KeyIn";
            this.colOrdPrice_KeyIn.ReadOnly = true;
            this.colOrdPrice_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOrdPrice_KeyIn.Width = 65;
            // 
            // colSide_KeyIn
            // 
            this.colSide_KeyIn.DataPropertyName = "Side";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colSide_KeyIn.DefaultCellStyle = dataGridViewCellStyle26;
            this.colSide_KeyIn.HeaderText = "買賣";
            this.colSide_KeyIn.Name = "colSide_KeyIn";
            this.colSide_KeyIn.ReadOnly = true;
            this.colSide_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colSide_KeyIn.Width = 55;
            // 
            // colDealQty_KeyIn
            // 
            this.colDealQty_KeyIn.DataPropertyName = "DealQty";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colDealQty_KeyIn.DefaultCellStyle = dataGridViewCellStyle27;
            this.colDealQty_KeyIn.HeaderText = "成交";
            this.colDealQty_KeyIn.Name = "colDealQty_KeyIn";
            this.colDealQty_KeyIn.ReadOnly = true;
            this.colDealQty_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDealQty_KeyIn.Width = 65;
            // 
            // ColTimeInForce_KeyIn
            // 
            this.ColTimeInForce_KeyIn.DataPropertyName = "TimeInForce";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColTimeInForce_KeyIn.DefaultCellStyle = dataGridViewCellStyle28;
            this.ColTimeInForce_KeyIn.HeaderText = "條件";
            this.ColTimeInForce_KeyIn.Name = "ColTimeInForce_KeyIn";
            this.ColTimeInForce_KeyIn.ReadOnly = true;
            this.ColTimeInForce_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColTimeInForce_KeyIn.Width = 55;
            // 
            // colTransTime_KeyIn
            // 
            this.colTransTime_KeyIn.DataPropertyName = "TransactTime";
            this.colTransTime_KeyIn.HeaderText = "交易時間";
            this.colTransTime_KeyIn.Name = "colTransTime_KeyIn";
            this.colTransTime_KeyIn.ReadOnly = true;
            this.colTransTime_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colTransTime_KeyIn.Width = 95;
            // 
            // colErrText_KeyIn
            // 
            this.colErrText_KeyIn.DataPropertyName = "Text";
            this.colErrText_KeyIn.HeaderText = "交易所錯誤敘述";
            this.colErrText_KeyIn.Name = "colErrText_KeyIn";
            this.colErrText_KeyIn.ReadOnly = true;
            this.colErrText_KeyIn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colErrText_KeyIn.Width = 350;
            // 
            // col_ECode
            // 
            this.col_ECode.DataPropertyName = "ECode";
            this.col_ECode.HeaderText = "交易別";
            this.col_ECode.Name = "col_ECode";
            this.col_ECode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_ECode.Visible = false;
            // 
            // tabPagRequest
            // 
            this.tabPagRequest.Controls.Add(this.panel6);
            this.tabPagRequest.Controls.Add(this.panel4);
            this.tabPagRequest.Location = new System.Drawing.Point(4, 26);
            this.tabPagRequest.Margin = new System.Windows.Forms.Padding(0);
            this.tabPagRequest.Name = "tabPagRequest";
            this.tabPagRequest.Size = new System.Drawing.Size(1059, 190);
            this.tabPagRequest.TabIndex = 0;
            this.tabPagRequest.Text = "委託回報";
            this.tabPagRequest.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.DGVEmstRequest);
            this.panel6.Controls.Add(this.DGVRequest);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 67);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1059, 123);
            this.panel6.TabIndex = 1;
            // 
            // DGVEmstRequest
            // 
            this.DGVEmstRequest.AllowUserToAddRows = false;
            this.DGVEmstRequest.AllowUserToDeleteRows = false;
            this.DGVEmstRequest.AllowUserToResizeRows = false;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.DGVEmstRequest.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.DGVEmstRequest.BackgroundColor = System.Drawing.Color.Black;
            this.DGVEmstRequest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVEmstRequest.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVEmstRequest.ColumnHeadersHeight = 25;
            this.DGVEmstRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVEmstRequest.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colEmCheckDelete,
            this.colEmDeleteBtn,
            this.colEmChangeQtyBtn,
            this.colEmChangePriceBtn,
            this.dataGridViewTextBoxColumn5,
            this.colEmDSEQ,
            this.colEmCSEQ,
            this.colEmCusName,
            this.colEmStock,
            this.colEmStockName,
            this.dataGridViewTextBoxColumn15,
            this.colEmSide,
            this.dataGridViewTextBoxColumn19,
            this.colEmOrdPrice,
            this.colEmOrdQty,
            this.colEmCancelQty,
            this.colEmDealQty,
            this.colEmDealPrice,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30});
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVEmstRequest.DefaultCellStyle = dataGridViewCellStyle42;
            this.DGVEmstRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVEmstRequest.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.DGVEmstRequest.Location = new System.Drawing.Point(0, 0);
            this.DGVEmstRequest.Margin = new System.Windows.Forms.Padding(0);
            this.DGVEmstRequest.MultiSelect = false;
            this.DGVEmstRequest.Name = "DGVEmstRequest";
            this.DGVEmstRequest.ReadOnly = true;
            this.DGVEmstRequest.RowHeadersVisible = false;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.Black;
            this.DGVEmstRequest.RowsDefaultCellStyle = dataGridViewCellStyle43;
            this.DGVEmstRequest.RowTemplate.Height = 24;
            this.DGVEmstRequest.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVEmstRequest.ShowCellErrors = false;
            this.DGVEmstRequest.ShowEditingIcon = false;
            this.DGVEmstRequest.Size = new System.Drawing.Size(1059, 123);
            this.DGVEmstRequest.TabIndex = 2;
            this.DGVEmstRequest.TabStop = false;
            this.DGVEmstRequest.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVEmstRequest_CellContentClick);
            this.DGVEmstRequest.Sorted += new System.EventHandler(this.DGVRequest_Sorted);
            // 
            // colEmCheckDelete
            // 
            this.colEmCheckDelete.DataPropertyName = "CheckDelete";
            this.colEmCheckDelete.HeaderText = "";
            this.colEmCheckDelete.Name = "colEmCheckDelete";
            this.colEmCheckDelete.ReadOnly = true;
            this.colEmCheckDelete.Width = 25;
            // 
            // colEmDeleteBtn
            // 
            this.colEmDeleteBtn.DataPropertyName = "DeleteOrder";
            this.colEmDeleteBtn.HeaderText = "刪";
            this.colEmDeleteBtn.Name = "colEmDeleteBtn";
            this.colEmDeleteBtn.ReadOnly = true;
            this.colEmDeleteBtn.Text = "刪";
            this.colEmDeleteBtn.UseColumnTextForButtonValue = true;
            this.colEmDeleteBtn.Width = 30;
            // 
            // colEmChangeQtyBtn
            // 
            this.colEmChangeQtyBtn.DataPropertyName = "ChangeOrder";
            this.colEmChangeQtyBtn.HeaderText = "量";
            this.colEmChangeQtyBtn.Name = "colEmChangeQtyBtn";
            this.colEmChangeQtyBtn.ReadOnly = true;
            this.colEmChangeQtyBtn.Text = "量";
            this.colEmChangeQtyBtn.UseColumnTextForButtonValue = true;
            this.colEmChangeQtyBtn.Width = 30;
            // 
            // colEmChangePriceBtn
            // 
            this.colEmChangePriceBtn.DataPropertyName = "ChangePrice";
            this.colEmChangePriceBtn.HeaderText = "價";
            this.colEmChangePriceBtn.Name = "colEmChangePriceBtn";
            this.colEmChangePriceBtn.ReadOnly = true;
            this.colEmChangePriceBtn.Text = "價";
            this.colEmChangePriceBtn.UseColumnTextForButtonValue = true;
            this.colEmChangePriceBtn.Width = 30;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TransactTime";
            this.dataGridViewTextBoxColumn5.HeaderText = "委託時間";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 90;
            // 
            // colEmDSEQ
            // 
            this.colEmDSEQ.DataPropertyName = "DSEQ";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEmDSEQ.DefaultCellStyle = dataGridViewCellStyle32;
            this.colEmDSEQ.HeaderText = "委託書號";
            this.colEmDSEQ.Name = "colEmDSEQ";
            this.colEmDSEQ.ReadOnly = true;
            this.colEmDSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmDSEQ.Width = 90;
            // 
            // colEmCSEQ
            // 
            this.colEmCSEQ.DataPropertyName = "CSEQ";
            this.colEmCSEQ.HeaderText = "帳號";
            this.colEmCSEQ.Name = "colEmCSEQ";
            this.colEmCSEQ.ReadOnly = true;
            this.colEmCSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmCSEQ.Width = 80;
            // 
            // colEmCusName
            // 
            this.colEmCusName.DataPropertyName = "CusName";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEmCusName.DefaultCellStyle = dataGridViewCellStyle33;
            this.colEmCusName.HeaderText = "姓名";
            this.colEmCusName.Name = "colEmCusName";
            this.colEmCusName.ReadOnly = true;
            this.colEmCusName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmCusName.Width = 70;
            // 
            // colEmStock
            // 
            this.colEmStock.DataPropertyName = "Stock";
            this.colEmStock.HeaderText = "代碼";
            this.colEmStock.Name = "colEmStock";
            this.colEmStock.ReadOnly = true;
            this.colEmStock.Width = 80;
            // 
            // colEmStockName
            // 
            this.colEmStockName.DataPropertyName = "StockName";
            this.colEmStockName.HeaderText = "名稱";
            this.colEmStockName.Name = "colEmStockName";
            this.colEmStockName.ReadOnly = true;
            this.colEmStockName.Width = 80;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "ECode";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn15.HeaderText = "盤";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Width = 45;
            // 
            // colEmSide
            // 
            this.colEmSide.DataPropertyName = "Side";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEmSide.DefaultCellStyle = dataGridViewCellStyle35;
            this.colEmSide.HeaderText = "買賣";
            this.colEmSide.Name = "colEmSide";
            this.colEmSide.ReadOnly = true;
            this.colEmSide.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmSide.Width = 50;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn19.HeaderText = "委託狀態";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // colEmOrdPrice
            // 
            this.colEmOrdPrice.DataPropertyName = "OrdPrice";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle36.Format = "N2";
            dataGridViewCellStyle36.NullValue = null;
            this.colEmOrdPrice.DefaultCellStyle = dataGridViewCellStyle36;
            this.colEmOrdPrice.HeaderText = "委託價";
            this.colEmOrdPrice.Name = "colEmOrdPrice";
            this.colEmOrdPrice.ReadOnly = true;
            this.colEmOrdPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmOrdPrice.Width = 80;
            // 
            // colEmOrdQty
            // 
            this.colEmOrdQty.DataPropertyName = "OrdQty";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colEmOrdQty.DefaultCellStyle = dataGridViewCellStyle37;
            this.colEmOrdQty.HeaderText = "委託股數";
            this.colEmOrdQty.Name = "colEmOrdQty";
            this.colEmOrdQty.ReadOnly = true;
            this.colEmOrdQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmOrdQty.Width = 80;
            // 
            // colEmCancelQty
            // 
            this.colEmCancelQty.DataPropertyName = "CancelQty";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colEmCancelQty.DefaultCellStyle = dataGridViewCellStyle38;
            this.colEmCancelQty.HeaderText = "已刪股數";
            this.colEmCancelQty.Name = "colEmCancelQty";
            this.colEmCancelQty.ReadOnly = true;
            this.colEmCancelQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmCancelQty.Width = 80;
            // 
            // colEmDealQty
            // 
            this.colEmDealQty.DataPropertyName = "DealQty";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colEmDealQty.DefaultCellStyle = dataGridViewCellStyle39;
            this.colEmDealQty.HeaderText = "成交股數";
            this.colEmDealQty.Name = "colEmDealQty";
            this.colEmDealQty.ReadOnly = true;
            this.colEmDealQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmDealQty.Width = 70;
            // 
            // colEmDealPrice
            // 
            this.colEmDealPrice.DataPropertyName = "DealPrice";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle40.NullValue = null;
            this.colEmDealPrice.DefaultCellStyle = dataGridViewCellStyle40;
            this.colEmDealPrice.HeaderText = "成交價";
            this.colEmDealPrice.Name = "colEmDealPrice";
            this.colEmDealPrice.ReadOnly = true;
            this.colEmDealPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colEmDealPrice.Width = 65;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "MType";
            this.dataGridViewTextBoxColumn26.HeaderText = "市場別";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn26.Width = 65;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Text";
            this.dataGridViewTextBoxColumn27.HeaderText = "備註";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "OrigClOrdID";
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn28.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewTextBoxColumn28.HeaderText = "網單";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn28.Width = 75;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Origin";
            this.dataGridViewTextBoxColumn29.HeaderText = "來源別";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn29.Visible = false;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "LaveQty";
            this.dataGridViewTextBoxColumn30.HeaderText = "剩餘量";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Visible = false;
            // 
            // DGVRequest
            // 
            this.DGVRequest.AllowUserToAddRows = false;
            this.DGVRequest.AllowUserToDeleteRows = false;
            this.DGVRequest.AllowUserToResizeRows = false;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.DGVRequest.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle44;
            this.DGVRequest.BackgroundColor = System.Drawing.Color.Black;
            this.DGVRequest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVRequest.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVRequest.ColumnHeadersHeight = 25;
            this.DGVRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVRequest.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCheckDelete,
            this.colDeleteOrder,
            this.colChangeOrder,
            this.colChangePrice,
            this.colTransactTime,
            this.colDSEQ,
            this.colCSEQ,
            this.colCusName,
            this.colSTOCK,
            this.colSTOCKNAME,
            this.colECODE,
            this.colOType,
            this.colSide,
            this.colSTATUS,
            this.ColTimeInForce,
            this.colOrdPrice,
            this.colOrdQty,
            this.colCancelQty,
            this.colDealQty,
            this.colDealPrice,
            this.colMtype,
            this.colText,
            this.colClOrdID,
            this.ColOrigin,
            this.ColLaveQty});
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle55.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle55.ForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle55.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle55.SelectionForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVRequest.DefaultCellStyle = dataGridViewCellStyle55;
            this.DGVRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVRequest.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.DGVRequest.Location = new System.Drawing.Point(0, 0);
            this.DGVRequest.Margin = new System.Windows.Forms.Padding(0);
            this.DGVRequest.MultiSelect = false;
            this.DGVRequest.Name = "DGVRequest";
            this.DGVRequest.ReadOnly = true;
            this.DGVRequest.RowHeadersVisible = false;
            dataGridViewCellStyle56.BackColor = System.Drawing.Color.Black;
            this.DGVRequest.RowsDefaultCellStyle = dataGridViewCellStyle56;
            this.DGVRequest.RowTemplate.Height = 24;
            this.DGVRequest.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVRequest.ShowCellErrors = false;
            this.DGVRequest.ShowEditingIcon = false;
            this.DGVRequest.Size = new System.Drawing.Size(1059, 123);
            this.DGVRequest.TabIndex = 0;
            this.DGVRequest.TabStop = false;
            this.DGVRequest.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVRequest_CellContentClick);
            this.DGVRequest.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DGVRequest_CellFormatting);
            this.DGVRequest.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.DGVRequest_DataError);
            this.DGVRequest.Sorted += new System.EventHandler(this.DGVRequest_Sorted);
            // 
            // colCheckDelete
            // 
            this.colCheckDelete.DataPropertyName = "CheckDelete";
            this.colCheckDelete.HeaderText = "";
            this.colCheckDelete.Name = "colCheckDelete";
            this.colCheckDelete.ReadOnly = true;
            this.colCheckDelete.Width = 25;
            // 
            // colDeleteOrder
            // 
            this.colDeleteOrder.DataPropertyName = "DeleteOrder";
            this.colDeleteOrder.HeaderText = "刪";
            this.colDeleteOrder.Name = "colDeleteOrder";
            this.colDeleteOrder.ReadOnly = true;
            this.colDeleteOrder.Text = "刪";
            this.colDeleteOrder.UseColumnTextForButtonValue = true;
            this.colDeleteOrder.Width = 30;
            // 
            // colChangeOrder
            // 
            this.colChangeOrder.DataPropertyName = "ChangeOrder";
            this.colChangeOrder.HeaderText = "量";
            this.colChangeOrder.Name = "colChangeOrder";
            this.colChangeOrder.ReadOnly = true;
            this.colChangeOrder.Text = "量";
            this.colChangeOrder.UseColumnTextForButtonValue = true;
            this.colChangeOrder.Width = 30;
            // 
            // colChangePrice
            // 
            this.colChangePrice.DataPropertyName = "ChangePrice";
            this.colChangePrice.HeaderText = "價";
            this.colChangePrice.Name = "colChangePrice";
            this.colChangePrice.ReadOnly = true;
            this.colChangePrice.Text = "價";
            this.colChangePrice.UseColumnTextForButtonValue = true;
            this.colChangePrice.Width = 30;
            // 
            // colTransactTime
            // 
            this.colTransactTime.DataPropertyName = "TransactTime";
            this.colTransactTime.HeaderText = "委託時間";
            this.colTransactTime.Name = "colTransactTime";
            this.colTransactTime.ReadOnly = true;
            this.colTransactTime.Width = 90;
            // 
            // colDSEQ
            // 
            this.colDSEQ.DataPropertyName = "DSEQ";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDSEQ.DefaultCellStyle = dataGridViewCellStyle45;
            this.colDSEQ.HeaderText = "委託書號";
            this.colDSEQ.Name = "colDSEQ";
            this.colDSEQ.ReadOnly = true;
            this.colDSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDSEQ.Width = 90;
            // 
            // colCSEQ
            // 
            this.colCSEQ.DataPropertyName = "CSEQ";
            this.colCSEQ.HeaderText = "帳號";
            this.colCSEQ.Name = "colCSEQ";
            this.colCSEQ.ReadOnly = true;
            this.colCSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCSEQ.Width = 80;
            // 
            // colCusName
            // 
            this.colCusName.DataPropertyName = "CusName";
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colCusName.DefaultCellStyle = dataGridViewCellStyle46;
            this.colCusName.HeaderText = "姓名";
            this.colCusName.Name = "colCusName";
            this.colCusName.ReadOnly = true;
            this.colCusName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCusName.Width = 70;
            // 
            // colSTOCK
            // 
            this.colSTOCK.DataPropertyName = "Stock";
            this.colSTOCK.HeaderText = "代碼";
            this.colSTOCK.Name = "colSTOCK";
            this.colSTOCK.ReadOnly = true;
            this.colSTOCK.Width = 80;
            // 
            // colSTOCKNAME
            // 
            this.colSTOCKNAME.DataPropertyName = "StockName";
            this.colSTOCKNAME.HeaderText = "名稱";
            this.colSTOCKNAME.Name = "colSTOCKNAME";
            this.colSTOCKNAME.ReadOnly = true;
            this.colSTOCKNAME.Width = 80;
            // 
            // colECODE
            // 
            this.colECODE.DataPropertyName = "ECode";
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colECODE.DefaultCellStyle = dataGridViewCellStyle47;
            this.colECODE.HeaderText = "盤";
            this.colECODE.Name = "colECODE";
            this.colECODE.ReadOnly = true;
            this.colECODE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colECODE.Width = 45;
            // 
            // colOType
            // 
            this.colOType.DataPropertyName = "OType";
            this.colOType.HeaderText = "類別";
            this.colOType.Name = "colOType";
            this.colOType.ReadOnly = true;
            this.colOType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOType.Width = 60;
            // 
            // colSide
            // 
            this.colSide.DataPropertyName = "Side";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colSide.DefaultCellStyle = dataGridViewCellStyle48;
            this.colSide.HeaderText = "買賣";
            this.colSide.Name = "colSide";
            this.colSide.ReadOnly = true;
            this.colSide.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colSide.Width = 50;
            // 
            // colSTATUS
            // 
            this.colSTATUS.DataPropertyName = "Status";
            this.colSTATUS.HeaderText = "委託狀態";
            this.colSTATUS.Name = "colSTATUS";
            this.colSTATUS.ReadOnly = true;
            // 
            // ColTimeInForce
            // 
            this.ColTimeInForce.DataPropertyName = "TimeInForce";
            this.ColTimeInForce.HeaderText = "條件";
            this.ColTimeInForce.Name = "ColTimeInForce";
            this.ColTimeInForce.ReadOnly = true;
            this.ColTimeInForce.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColTimeInForce.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColTimeInForce.Width = 55;
            // 
            // colOrdPrice
            // 
            this.colOrdPrice.DataPropertyName = "OrdPrice";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle49.Format = "N2";
            dataGridViewCellStyle49.NullValue = null;
            this.colOrdPrice.DefaultCellStyle = dataGridViewCellStyle49;
            this.colOrdPrice.HeaderText = "委託價";
            this.colOrdPrice.Name = "colOrdPrice";
            this.colOrdPrice.ReadOnly = true;
            this.colOrdPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOrdPrice.Width = 80;
            // 
            // colOrdQty
            // 
            this.colOrdQty.DataPropertyName = "OrdQty";
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colOrdQty.DefaultCellStyle = dataGridViewCellStyle50;
            this.colOrdQty.HeaderText = "委託股數";
            this.colOrdQty.Name = "colOrdQty";
            this.colOrdQty.ReadOnly = true;
            this.colOrdQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colOrdQty.Width = 80;
            // 
            // colCancelQty
            // 
            this.colCancelQty.DataPropertyName = "CancelQty";
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colCancelQty.DefaultCellStyle = dataGridViewCellStyle51;
            this.colCancelQty.HeaderText = "已刪股數";
            this.colCancelQty.Name = "colCancelQty";
            this.colCancelQty.ReadOnly = true;
            this.colCancelQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCancelQty.Width = 80;
            // 
            // colDealQty
            // 
            this.colDealQty.DataPropertyName = "DealQty";
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colDealQty.DefaultCellStyle = dataGridViewCellStyle52;
            this.colDealQty.HeaderText = "成交股數";
            this.colDealQty.Name = "colDealQty";
            this.colDealQty.ReadOnly = true;
            this.colDealQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDealQty.Width = 60;
            // 
            // colDealPrice
            // 
            this.colDealPrice.DataPropertyName = "DealPrice";
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle53.NullValue = null;
            this.colDealPrice.DefaultCellStyle = dataGridViewCellStyle53;
            this.colDealPrice.HeaderText = "成交價";
            this.colDealPrice.Name = "colDealPrice";
            this.colDealPrice.ReadOnly = true;
            this.colDealPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colDealPrice.Width = 65;
            // 
            // colMtype
            // 
            this.colMtype.DataPropertyName = "MType";
            this.colMtype.HeaderText = "市場別";
            this.colMtype.Name = "colMtype";
            this.colMtype.ReadOnly = true;
            this.colMtype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colMtype.Width = 75;
            // 
            // colText
            // 
            this.colText.DataPropertyName = "Text";
            this.colText.HeaderText = "備註";
            this.colText.Name = "colText";
            this.colText.ReadOnly = true;
            this.colText.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colText.Width = 200;
            // 
            // colClOrdID
            // 
            this.colClOrdID.DataPropertyName = "ClOrdID";
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colClOrdID.DefaultCellStyle = dataGridViewCellStyle54;
            this.colClOrdID.HeaderText = "網單";
            this.colClOrdID.Name = "colClOrdID";
            this.colClOrdID.ReadOnly = true;
            this.colClOrdID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colClOrdID.Width = 58;
            // 
            // ColOrigin
            // 
            this.ColOrigin.DataPropertyName = "Origin";
            this.ColOrigin.HeaderText = "來源別";
            this.ColOrigin.Name = "ColOrigin";
            this.ColOrigin.ReadOnly = true;
            this.ColOrigin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColOrigin.Visible = false;
            // 
            // ColLaveQty
            // 
            this.ColLaveQty.DataPropertyName = "LaveQty";
            this.ColLaveQty.HeaderText = "剩餘量";
            this.ColLaveQty.Name = "ColLaveQty";
            this.ColLaveQty.ReadOnly = true;
            this.ColLaveQty.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txbFilterCSEQ);
            this.panel4.Controls.Add(this.labDealAmt);
            this.panel4.Controls.Add(this.labDealQty);
            this.panel4.Controls.Add(this.labRequestAmt);
            this.panel4.Controls.Add(this.labRequestQty);
            this.panel4.Controls.Add(this.labCount);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.btnFilterClear);
            this.panel4.Controls.Add(this.btnFilterOK);
            this.panel4.Controls.Add(this.txbFilterDSEQ);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.btnMultiDeleAllCancel);
            this.panel4.Controls.Add(this.btnMultiDeleAllSelect);
            this.panel4.Controls.Add(this.btnMultiDeleAllOK);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1059, 67);
            this.panel4.TabIndex = 0;
            // 
            // txbFilterCSEQ
            // 
            this.txbFilterCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbFilterCSEQ.Location = new System.Drawing.Point(284, 10);
            this.txbFilterCSEQ.Name = "txbFilterCSEQ";
            this.txbFilterCSEQ.Size = new System.Drawing.Size(89, 30);
            this.txbFilterCSEQ.TabIndex = 31;
            this.txbFilterCSEQ.TabStop = false;
            this.txbFilterCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbFilterCSEQ_KeyDown);
            // 
            // labDealAmt
            // 
            this.labDealAmt.AutoSize = true;
            this.labDealAmt.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labDealAmt.Location = new System.Drawing.Point(814, 43);
            this.labDealAmt.Name = "labDealAmt";
            this.labDealAmt.Size = new System.Drawing.Size(109, 19);
            this.labDealAmt.TabIndex = 30;
            this.labDealAmt.Text = "成交金額：";
            // 
            // labDealQty
            // 
            this.labDealQty.AutoSize = true;
            this.labDealQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labDealQty.Location = new System.Drawing.Point(591, 43);
            this.labDealQty.Name = "labDealQty";
            this.labDealQty.Size = new System.Drawing.Size(109, 19);
            this.labDealQty.TabIndex = 29;
            this.labDealQty.Text = "成交股數：";
            // 
            // labRequestAmt
            // 
            this.labRequestAmt.AutoSize = true;
            this.labRequestAmt.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labRequestAmt.Location = new System.Drawing.Point(370, 43);
            this.labRequestAmt.Name = "labRequestAmt";
            this.labRequestAmt.Size = new System.Drawing.Size(109, 19);
            this.labRequestAmt.TabIndex = 28;
            this.labRequestAmt.Text = "委託金額：";
            // 
            // labRequestQty
            // 
            this.labRequestQty.AutoSize = true;
            this.labRequestQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labRequestQty.Location = new System.Drawing.Point(162, 43);
            this.labRequestQty.Name = "labRequestQty";
            this.labRequestQty.Size = new System.Drawing.Size(109, 19);
            this.labRequestQty.TabIndex = 27;
            this.labRequestQty.Text = "委託股數：";
            // 
            // labCount
            // 
            this.labCount.AutoSize = true;
            this.labCount.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labCount.Location = new System.Drawing.Point(8, 43);
            this.labCount.Name = "labCount";
            this.labCount.Size = new System.Drawing.Size(69, 19);
            this.labCount.TabIndex = 26;
            this.labCount.Text = "筆數：";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.rbNoDeal);
            this.panel5.Controls.Add(this.rbDeal);
            this.panel5.Controls.Add(this.rbAll);
            this.panel5.Location = new System.Drawing.Point(809, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(236, 30);
            this.panel5.TabIndex = 24;
            // 
            // rbNoDeal
            // 
            this.rbNoDeal.AutoSize = true;
            this.rbNoDeal.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbNoDeal.Location = new System.Drawing.Point(152, 4);
            this.rbNoDeal.Name = "rbNoDeal";
            this.rbNoDeal.Size = new System.Drawing.Size(74, 20);
            this.rbNoDeal.TabIndex = 2;
            this.rbNoDeal.Text = "未成交";
            this.rbNoDeal.UseVisualStyleBackColor = true;
            this.rbNoDeal.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
            // 
            // rbDeal
            // 
            this.rbDeal.AutoSize = true;
            this.rbDeal.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbDeal.Location = new System.Drawing.Point(72, 4);
            this.rbDeal.Name = "rbDeal";
            this.rbDeal.Size = new System.Drawing.Size(74, 20);
            this.rbDeal.TabIndex = 1;
            this.rbDeal.Text = "已成交";
            this.rbDeal.UseVisualStyleBackColor = true;
            this.rbDeal.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
            // 
            // rbAll
            // 
            this.rbAll.AutoSize = true;
            this.rbAll.Checked = true;
            this.rbAll.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbAll.Location = new System.Drawing.Point(10, 4);
            this.rbAll.Name = "rbAll";
            this.rbAll.Size = new System.Drawing.Size(58, 20);
            this.rbAll.TabIndex = 0;
            this.rbAll.TabStop = true;
            this.rbAll.Text = "全部";
            this.rbAll.UseVisualStyleBackColor = true;
            this.rbAll.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
            // 
            // btnFilterClear
            // 
            this.btnFilterClear.BackColor = System.Drawing.Color.LightCyan;
            this.btnFilterClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnFilterClear.Location = new System.Drawing.Point(687, 10);
            this.btnFilterClear.Name = "btnFilterClear";
            this.btnFilterClear.Size = new System.Drawing.Size(116, 28);
            this.btnFilterClear.TabIndex = 34;
            this.btnFilterClear.TabStop = false;
            this.btnFilterClear.Text = "清除條件";
            this.btnFilterClear.UseVisualStyleBackColor = false;
            this.btnFilterClear.Click += new System.EventHandler(this.btnFilterClear_Click);
            // 
            // btnFilterOK
            // 
            this.btnFilterOK.BackColor = System.Drawing.Color.LightCyan;
            this.btnFilterOK.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnFilterOK.Location = new System.Drawing.Point(561, 10);
            this.btnFilterOK.Name = "btnFilterOK";
            this.btnFilterOK.Size = new System.Drawing.Size(120, 28);
            this.btnFilterOK.TabIndex = 33;
            this.btnFilterOK.TabStop = false;
            this.btnFilterOK.Text = "篩選委託";
            this.btnFilterOK.UseVisualStyleBackColor = false;
            this.btnFilterOK.Click += new System.EventHandler(this.btnFilterOK_Click);
            // 
            // txbFilterDSEQ
            // 
            this.txbFilterDSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbFilterDSEQ.Location = new System.Drawing.Point(474, 10);
            this.txbFilterDSEQ.Name = "txbFilterDSEQ";
            this.txbFilterDSEQ.Size = new System.Drawing.Size(77, 30);
            this.txbFilterDSEQ.TabIndex = 32;
            this.txbFilterDSEQ.TabStop = false;
            this.txbFilterDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbFilterDSEQ_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(378, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 19);
            this.label7.TabIndex = 20;
            this.label7.Text = "股票代號 :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(225, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 19);
            this.label6.TabIndex = 18;
            this.label6.Text = "帳號 :";
            // 
            // btnMultiDeleAllCancel
            // 
            this.btnMultiDeleAllCancel.BackColor = System.Drawing.Color.LightCyan;
            this.btnMultiDeleAllCancel.Location = new System.Drawing.Point(70, 8);
            this.btnMultiDeleAllCancel.Name = "btnMultiDeleAllCancel";
            this.btnMultiDeleAllCancel.Size = new System.Drawing.Size(55, 27);
            this.btnMultiDeleAllCancel.TabIndex = 17;
            this.btnMultiDeleAllCancel.TabStop = false;
            this.btnMultiDeleAllCancel.Text = "取消";
            this.btnMultiDeleAllCancel.UseVisualStyleBackColor = false;
            this.btnMultiDeleAllCancel.Click += new System.EventHandler(this.btnMultiDeleAllCancel_Click);
            // 
            // btnMultiDeleAllSelect
            // 
            this.btnMultiDeleAllSelect.BackColor = System.Drawing.Color.LightCyan;
            this.btnMultiDeleAllSelect.Location = new System.Drawing.Point(6, 7);
            this.btnMultiDeleAllSelect.Name = "btnMultiDeleAllSelect";
            this.btnMultiDeleAllSelect.Size = new System.Drawing.Size(58, 28);
            this.btnMultiDeleAllSelect.TabIndex = 16;
            this.btnMultiDeleAllSelect.TabStop = false;
            this.btnMultiDeleAllSelect.Text = "全選";
            this.btnMultiDeleAllSelect.UseVisualStyleBackColor = false;
            this.btnMultiDeleAllSelect.Click += new System.EventHandler(this.btnMultiDeleAllSelect_Click);
            // 
            // btnMultiDeleAllOK
            // 
            this.btnMultiDeleAllOK.BackColor = System.Drawing.Color.LightCyan;
            this.btnMultiDeleAllOK.Location = new System.Drawing.Point(131, 7);
            this.btnMultiDeleAllOK.Name = "btnMultiDeleAllOK";
            this.btnMultiDeleAllOK.Size = new System.Drawing.Size(88, 28);
            this.btnMultiDeleAllOK.TabIndex = 15;
            this.btnMultiDeleAllOK.TabStop = false;
            this.btnMultiDeleAllOK.Text = "多筆刪單";
            this.btnMultiDeleAllOK.UseVisualStyleBackColor = false;
            this.btnMultiDeleAllOK.Click += new System.EventHandler(this.btnMultiDeleAllOK_Click);
            // 
            // tabPagDeal
            // 
            this.tabPagDeal.Controls.Add(this.tabLayPanel_DealView);
            this.tabPagDeal.Location = new System.Drawing.Point(4, 26);
            this.tabPagDeal.Margin = new System.Windows.Forms.Padding(0);
            this.tabPagDeal.Name = "tabPagDeal";
            this.tabPagDeal.Size = new System.Drawing.Size(1059, 190);
            this.tabPagDeal.TabIndex = 1;
            this.tabPagDeal.Text = "勾單作業";
            this.tabPagDeal.UseVisualStyleBackColor = true;
            // 
            // tabLayPanel_DealView
            // 
            this.tabLayPanel_DealView.BackColor = System.Drawing.Color.Black;
            this.tabLayPanel_DealView.ColumnCount = 1;
            this.tabLayPanel_DealView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tabLayPanel_DealView.Controls.Add(this.DGVCheckDeal, 0, 1);
            this.tabLayPanel_DealView.Controls.Add(this.tabLayPanel_DealQueryControl, 0, 0);
            this.tabLayPanel_DealView.Controls.Add(this.tabLayOutChkQueryInfo, 0, 2);
            this.tabLayPanel_DealView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabLayPanel_DealView.Location = new System.Drawing.Point(0, 0);
            this.tabLayPanel_DealView.Name = "tabLayPanel_DealView";
            this.tabLayPanel_DealView.RowCount = 3;
            this.tabLayPanel_DealView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tabLayPanel_DealView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tabLayPanel_DealView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayPanel_DealView.Size = new System.Drawing.Size(1059, 190);
            this.tabLayPanel_DealView.TabIndex = 1;
            // 
            // DGVCheckDeal
            // 
            this.DGVCheckDeal.AllowUserToAddRows = false;
            this.DGVCheckDeal.AllowUserToDeleteRows = false;
            this.DGVCheckDeal.AllowUserToResizeRows = false;
            this.DGVCheckDeal.BackgroundColor = System.Drawing.Color.Black;
            this.DGVCheckDeal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVCheckDeal.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVCheckDeal.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVCheckDeal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.DGVCheckDeal.ColumnHeadersHeight = 25;
            this.DGVCheckDeal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVCheckDeal.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_No,
            this.col_BHNO,
            this.col_CSEQ,
            this.col_DSEQ,
            this.colum_ECODE,
            this.col_TimeInForce,
            this.col_Price,
            this.Col_OQTY,
            this.col_OTYPE,
            this.col_STOCK,
            this.col_STOCKNAME,
            this.col_BS,
            this.col_CheckStatus,
            this.col_DPRICE,
            this.col_DQTY,
            this.col_AllDQTY});
            dataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle64.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle64.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle64.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle64.SelectionBackColor = System.Drawing.Color.DarkGreen;
            dataGridViewCellStyle64.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVCheckDeal.DefaultCellStyle = dataGridViewCellStyle64;
            this.DGVCheckDeal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVCheckDeal.EnableHeadersVisualStyles = false;
            this.DGVCheckDeal.GridColor = System.Drawing.Color.Black;
            this.DGVCheckDeal.Location = new System.Drawing.Point(0, 37);
            this.DGVCheckDeal.Margin = new System.Windows.Forms.Padding(0);
            this.DGVCheckDeal.MultiSelect = false;
            this.DGVCheckDeal.Name = "DGVCheckDeal";
            dataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle65.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVCheckDeal.RowHeadersDefaultCellStyle = dataGridViewCellStyle65;
            this.DGVCheckDeal.RowHeadersVisible = false;
            this.DGVCheckDeal.RowTemplate.Height = 24;
            this.DGVCheckDeal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVCheckDeal.Size = new System.Drawing.Size(1059, 103);
            this.DGVCheckDeal.TabIndex = 0;
            this.DGVCheckDeal.TabStop = false;
            this.DGVCheckDeal.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.DGVCheckDeal_DataError);
            this.DGVCheckDeal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DGVCheckDeal_KeyDown);
            // 
            // col_No
            // 
            this.col_No.DataPropertyName = "No";
            this.col_No.HeaderText = "";
            this.col_No.Name = "col_No";
            this.col_No.ReadOnly = true;
            this.col_No.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_No.Width = 60;
            // 
            // col_BHNO
            // 
            this.col_BHNO.DataPropertyName = "BHNO";
            this.col_BHNO.HeaderText = "分公司";
            this.col_BHNO.Name = "col_BHNO";
            this.col_BHNO.ReadOnly = true;
            this.col_BHNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_BHNO.Width = 75;
            // 
            // col_CSEQ
            // 
            this.col_CSEQ.DataPropertyName = "CSEQ";
            this.col_CSEQ.HeaderText = "客戶帳號";
            this.col_CSEQ.Name = "col_CSEQ";
            this.col_CSEQ.ReadOnly = true;
            this.col_CSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_DSEQ
            // 
            this.col_DSEQ.DataPropertyName = "DSEQ";
            this.col_DSEQ.HeaderText = "委託序號";
            this.col_DSEQ.Name = "col_DSEQ";
            this.col_DSEQ.ReadOnly = true;
            this.col_DSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colum_ECODE
            // 
            this.colum_ECODE.DataPropertyName = "ECode";
            this.colum_ECODE.HeaderText = "盤";
            this.colum_ECODE.Name = "colum_ECODE";
            this.colum_ECODE.ReadOnly = true;
            this.colum_ECODE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colum_ECODE.Width = 50;
            // 
            // col_TimeInForce
            // 
            this.col_TimeInForce.DataPropertyName = "TimeInForce";
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_TimeInForce.DefaultCellStyle = dataGridViewCellStyle58;
            this.col_TimeInForce.HeaderText = "條件";
            this.col_TimeInForce.Name = "col_TimeInForce";
            this.col_TimeInForce.ReadOnly = true;
            this.col_TimeInForce.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_TimeInForce.Width = 50;
            // 
            // col_Price
            // 
            this.col_Price.DataPropertyName = "PRICE";
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_Price.DefaultCellStyle = dataGridViewCellStyle59;
            this.col_Price.HeaderText = "委託價";
            this.col_Price.Name = "col_Price";
            this.col_Price.ReadOnly = true;
            this.col_Price.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_Price.Width = 80;
            // 
            // Col_OQTY
            // 
            this.Col_OQTY.DataPropertyName = "OQTY";
            this.Col_OQTY.HeaderText = "委託Qty";
            this.Col_OQTY.Name = "Col_OQTY";
            this.Col_OQTY.ReadOnly = true;
            this.Col_OQTY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Col_OQTY.Width = 85;
            // 
            // col_OTYPE
            // 
            this.col_OTYPE.DataPropertyName = "OTYPE";
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_OTYPE.DefaultCellStyle = dataGridViewCellStyle60;
            this.col_OTYPE.HeaderText = "0";
            this.col_OTYPE.Name = "col_OTYPE";
            this.col_OTYPE.ReadOnly = true;
            this.col_OTYPE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_OTYPE.Width = 30;
            // 
            // col_STOCK
            // 
            this.col_STOCK.DataPropertyName = "STOCK";
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_STOCK.DefaultCellStyle = dataGridViewCellStyle61;
            this.col_STOCK.HeaderText = "股票代碼";
            this.col_STOCK.Name = "col_STOCK";
            this.col_STOCK.ReadOnly = true;
            this.col_STOCK.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_STOCK.Width = 95;
            // 
            // col_STOCKNAME
            // 
            this.col_STOCKNAME.DataPropertyName = "STOCKNAME";
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.col_STOCKNAME.DefaultCellStyle = dataGridViewCellStyle62;
            this.col_STOCKNAME.HeaderText = "名稱";
            this.col_STOCKNAME.Name = "col_STOCKNAME";
            this.col_STOCKNAME.ReadOnly = true;
            this.col_STOCKNAME.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_STOCKNAME.Width = 110;
            // 
            // col_BS
            // 
            this.col_BS.DataPropertyName = "BS";
            this.col_BS.HeaderText = "買賣";
            this.col_BS.Name = "col_BS";
            this.col_BS.ReadOnly = true;
            this.col_BS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_BS.Width = 50;
            // 
            // col_CheckStatus
            // 
            this.col_CheckStatus.DataPropertyName = "CheckStatus";
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.col_CheckStatus.DefaultCellStyle = dataGridViewCellStyle63;
            this.col_CheckStatus.HeaderText = "Sale";
            this.col_CheckStatus.Name = "col_CheckStatus";
            this.col_CheckStatus.ReadOnly = true;
            this.col_CheckStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_CheckStatus.Width = 50;
            // 
            // col_DPRICE
            // 
            this.col_DPRICE.DataPropertyName = "DPRICE";
            this.col_DPRICE.HeaderText = "成交價";
            this.col_DPRICE.Name = "col_DPRICE";
            this.col_DPRICE.ReadOnly = true;
            this.col_DPRICE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_DQTY
            // 
            this.col_DQTY.DataPropertyName = "DQTY";
            this.col_DQTY.HeaderText = "成交Qty";
            this.col_DQTY.Name = "col_DQTY";
            this.col_DQTY.ReadOnly = true;
            this.col_DQTY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // col_AllDQTY
            // 
            this.col_AllDQTY.DataPropertyName = "AllDQTY";
            this.col_AllDQTY.HeaderText = "累積量";
            this.col_AllDQTY.Name = "col_AllDQTY";
            this.col_AllDQTY.ReadOnly = true;
            this.col_AllDQTY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tabLayPanel_DealQueryControl
            // 
            this.tabLayPanel_DealQueryControl.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tabLayPanel_DealQueryControl.ColumnCount = 6;
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 192F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 81F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 412F));
            this.tabLayPanel_DealQueryControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tabLayPanel_DealQueryControl.Controls.Add(this.Btn_QueryDeal, 0, 0);
            this.tabLayPanel_DealQueryControl.Controls.Add(this.LabQueryDealTime, 1, 0);
            this.tabLayPanel_DealQueryControl.Controls.Add(this.panel1, 2, 0);
            this.tabLayPanel_DealQueryControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabLayPanel_DealQueryControl.Location = new System.Drawing.Point(3, 3);
            this.tabLayPanel_DealQueryControl.Name = "tabLayPanel_DealQueryControl";
            this.tabLayPanel_DealQueryControl.RowCount = 1;
            this.tabLayPanel_DealQueryControl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tabLayPanel_DealQueryControl.Size = new System.Drawing.Size(1053, 31);
            this.tabLayPanel_DealQueryControl.TabIndex = 1;
            // 
            // Btn_QueryDeal
            // 
            this.Btn_QueryDeal.BackColor = System.Drawing.Color.White;
            this.Btn_QueryDeal.Location = new System.Drawing.Point(3, 3);
            this.Btn_QueryDeal.Name = "Btn_QueryDeal";
            this.Btn_QueryDeal.Size = new System.Drawing.Size(75, 25);
            this.Btn_QueryDeal.TabIndex = 0;
            this.Btn_QueryDeal.Text = "查詢";
            this.Btn_QueryDeal.UseVisualStyleBackColor = false;
            this.Btn_QueryDeal.Click += new System.EventHandler(this.Btn_QueryDeal_Click);
            // 
            // LabQueryDealTime
            // 
            this.LabQueryDealTime.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabQueryDealTime.AutoSize = true;
            this.LabQueryDealTime.Location = new System.Drawing.Point(91, 7);
            this.LabQueryDealTime.Name = "LabQueryDealTime";
            this.LabQueryDealTime.Size = new System.Drawing.Size(86, 16);
            this.LabQueryDealTime.TabIndex = 1;
            this.LabQueryDealTime.Text = "查詢時間: ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdbRL);
            this.panel1.Controls.Add(this.rdbFP);
            this.panel1.Controls.Add(this.rdbOD);
            this.panel1.Location = new System.Drawing.Point(283, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(194, 25);
            this.panel1.TabIndex = 5;
            // 
            // rdbRL
            // 
            this.rdbRL.AutoSize = true;
            this.rdbRL.Location = new System.Drawing.Point(2, 2);
            this.rdbRL.Name = "rdbRL";
            this.rdbRL.Size = new System.Drawing.Size(60, 20);
            this.rdbRL.TabIndex = 2;
            this.rdbRL.TabStop = true;
            this.rdbRL.Text = "整股";
            this.rdbRL.UseVisualStyleBackColor = true;
            this.rdbRL.CheckedChanged += new System.EventHandler(this.DGVCheckDeal_radioButton_CheckedChanged);
            // 
            // rdbFP
            // 
            this.rdbFP.AutoSize = true;
            this.rdbFP.Location = new System.Drawing.Point(134, 2);
            this.rdbFP.Name = "rdbFP";
            this.rdbFP.Size = new System.Drawing.Size(60, 20);
            this.rdbFP.TabIndex = 1;
            this.rdbFP.TabStop = true;
            this.rdbFP.Text = "定價";
            this.rdbFP.UseVisualStyleBackColor = true;
            this.rdbFP.CheckedChanged += new System.EventHandler(this.DGVCheckDeal_radioButton_CheckedChanged);
            // 
            // rdbOD
            // 
            this.rdbOD.AutoSize = true;
            this.rdbOD.Location = new System.Drawing.Point(68, 2);
            this.rdbOD.Name = "rdbOD";
            this.rdbOD.Size = new System.Drawing.Size(60, 20);
            this.rdbOD.TabIndex = 0;
            this.rdbOD.TabStop = true;
            this.rdbOD.Text = "零股";
            this.rdbOD.UseVisualStyleBackColor = true;
            this.rdbOD.CheckedChanged += new System.EventHandler(this.DGVCheckDeal_radioButton_CheckedChanged);
            // 
            // tabLayOutChkQueryInfo
            // 
            this.tabLayOutChkQueryInfo.ColumnCount = 14;
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tabLayOutChkQueryInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 269F));
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQR5, 13, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQR4, 11, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQT4, 10, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQR3, 9, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQR2, 7, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQR1, 5, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQT1, 4, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQCount, 3, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.label133, 0, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.label134, 2, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQDSEQ, 1, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQT2, 6, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQT3, 8, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabCheckFinishInfo, 0, 1);
            this.tabLayOutChkQueryInfo.Controls.Add(this.label138, 13, 1);
            this.tabLayOutChkQueryInfo.Controls.Add(this.LabChkDealQT5, 12, 0);
            this.tabLayOutChkQueryInfo.Controls.Add(this.label139, 10, 1);
            this.tabLayOutChkQueryInfo.Controls.Add(this.Lab_TodayLastFill, 5, 1);
            this.tabLayOutChkQueryInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabLayOutChkQueryInfo.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabLayOutChkQueryInfo.Location = new System.Drawing.Point(3, 143);
            this.tabLayOutChkQueryInfo.Name = "tabLayOutChkQueryInfo";
            this.tabLayOutChkQueryInfo.RowCount = 2;
            this.tabLayOutChkQueryInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tabLayOutChkQueryInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tabLayOutChkQueryInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tabLayOutChkQueryInfo.Size = new System.Drawing.Size(1053, 44);
            this.tabLayOutChkQueryInfo.TabIndex = 2;
            // 
            // LabChkDealQR5
            // 
            this.LabChkDealQR5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQR5.AutoSize = true;
            this.LabChkDealQR5.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQR5.Location = new System.Drawing.Point(796, 1);
            this.LabChkDealQR5.Name = "LabChkDealQR5";
            this.LabChkDealQR5.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQR5.TabIndex = 16;
            this.LabChkDealQR5.Text = "000";
            this.LabChkDealQR5.Visible = false;
            // 
            // LabChkDealQR4
            // 
            this.LabChkDealQR4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQR4.AutoSize = true;
            this.LabChkDealQR4.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQR4.Location = new System.Drawing.Point(696, 1);
            this.LabChkDealQR4.Name = "LabChkDealQR4";
            this.LabChkDealQR4.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQR4.TabIndex = 15;
            this.LabChkDealQR4.Text = "000";
            this.LabChkDealQR4.Visible = false;
            // 
            // LabChkDealQT4
            // 
            this.LabChkDealQT4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQT4.AutoSize = true;
            this.LabChkDealQT4.ForeColor = System.Drawing.Color.Gainsboro;
            this.LabChkDealQT4.Location = new System.Drawing.Point(646, 1);
            this.LabChkDealQT4.Name = "LabChkDealQT4";
            this.LabChkDealQT4.Size = new System.Drawing.Size(33, 19);
            this.LabChkDealQT4.TabIndex = 13;
            this.LabChkDealQT4.Text = "[4]";
            this.LabChkDealQT4.Visible = false;
            // 
            // LabChkDealQR3
            // 
            this.LabChkDealQR3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQR3.AutoSize = true;
            this.LabChkDealQR3.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQR3.Location = new System.Drawing.Point(596, 1);
            this.LabChkDealQR3.Name = "LabChkDealQR3";
            this.LabChkDealQR3.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQR3.TabIndex = 12;
            this.LabChkDealQR3.Text = "000";
            this.LabChkDealQR3.Visible = false;
            // 
            // LabChkDealQR2
            // 
            this.LabChkDealQR2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQR2.AutoSize = true;
            this.LabChkDealQR2.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQR2.Location = new System.Drawing.Point(496, 1);
            this.LabChkDealQR2.Name = "LabChkDealQR2";
            this.LabChkDealQR2.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQR2.TabIndex = 11;
            this.LabChkDealQR2.Text = "000";
            this.LabChkDealQR2.Visible = false;
            // 
            // LabChkDealQR1
            // 
            this.LabChkDealQR1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQR1.AutoSize = true;
            this.LabChkDealQR1.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQR1.Location = new System.Drawing.Point(396, 1);
            this.LabChkDealQR1.Name = "LabChkDealQR1";
            this.LabChkDealQR1.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQR1.TabIndex = 10;
            this.LabChkDealQR1.Text = "000";
            this.LabChkDealQR1.Visible = false;
            // 
            // LabChkDealQT1
            // 
            this.LabChkDealQT1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQT1.AutoSize = true;
            this.LabChkDealQT1.ForeColor = System.Drawing.Color.Gainsboro;
            this.LabChkDealQT1.Location = new System.Drawing.Point(346, 1);
            this.LabChkDealQT1.Name = "LabChkDealQT1";
            this.LabChkDealQT1.Size = new System.Drawing.Size(33, 19);
            this.LabChkDealQT1.TabIndex = 4;
            this.LabChkDealQT1.Text = "[1]";
            this.LabChkDealQT1.Visible = false;
            // 
            // LabChkDealQCount
            // 
            this.LabChkDealQCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQCount.AutoSize = true;
            this.LabChkDealQCount.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQCount.Location = new System.Drawing.Point(296, 1);
            this.LabChkDealQCount.Name = "LabChkDealQCount";
            this.LabChkDealQCount.Size = new System.Drawing.Size(39, 19);
            this.LabChkDealQCount.TabIndex = 3;
            this.LabChkDealQCount.Text = "000";
            this.LabChkDealQCount.Visible = false;
            // 
            // label133
            // 
            this.label133.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label133.AutoSize = true;
            this.label133.ForeColor = System.Drawing.Color.Gainsboro;
            this.label133.Location = new System.Drawing.Point(3, 1);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(95, 19);
            this.label133.TabIndex = 0;
            this.label133.Text = "委託序號:";
            // 
            // label134
            // 
            this.label134.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label134.AutoSize = true;
            this.label134.ForeColor = System.Drawing.Color.Gainsboro;
            this.label134.Location = new System.Drawing.Point(189, 1);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(100, 19);
            this.label134.TabIndex = 1;
            this.label134.Text = "回報筆數=";
            // 
            // LabChkDealQDSEQ
            // 
            this.LabChkDealQDSEQ.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQDSEQ.AutoSize = true;
            this.LabChkDealQDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.LabChkDealQDSEQ.Location = new System.Drawing.Point(112, 0);
            this.LabChkDealQDSEQ.Name = "LabChkDealQDSEQ";
            this.LabChkDealQDSEQ.Size = new System.Drawing.Size(69, 22);
            this.LabChkDealQDSEQ.TabIndex = 2;
            this.LabChkDealQDSEQ.Text = "0000000";
            this.LabChkDealQDSEQ.Visible = false;
            // 
            // LabChkDealQT2
            // 
            this.LabChkDealQT2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQT2.AutoSize = true;
            this.LabChkDealQT2.ForeColor = System.Drawing.Color.Gainsboro;
            this.LabChkDealQT2.Location = new System.Drawing.Point(446, 1);
            this.LabChkDealQT2.Name = "LabChkDealQT2";
            this.LabChkDealQT2.Size = new System.Drawing.Size(33, 19);
            this.LabChkDealQT2.TabIndex = 5;
            this.LabChkDealQT2.Text = "[2]";
            this.LabChkDealQT2.Visible = false;
            // 
            // LabChkDealQT3
            // 
            this.LabChkDealQT3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQT3.AutoSize = true;
            this.LabChkDealQT3.ForeColor = System.Drawing.Color.Gainsboro;
            this.LabChkDealQT3.Location = new System.Drawing.Point(546, 1);
            this.LabChkDealQT3.Name = "LabChkDealQT3";
            this.LabChkDealQT3.Size = new System.Drawing.Size(33, 19);
            this.LabChkDealQT3.TabIndex = 6;
            this.LabChkDealQT3.Text = "[3]";
            this.LabChkDealQT3.Visible = false;
            // 
            // LabCheckFinishInfo
            // 
            this.LabCheckFinishInfo.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabCheckFinishInfo.AutoSize = true;
            this.LabCheckFinishInfo.BackColor = System.Drawing.Color.MediumBlue;
            this.tabLayOutChkQueryInfo.SetColumnSpan(this.LabCheckFinishInfo, 3);
            this.LabCheckFinishInfo.ForeColor = System.Drawing.Color.Gold;
            this.LabCheckFinishInfo.Location = new System.Drawing.Point(3, 23);
            this.LabCheckFinishInfo.Name = "LabCheckFinishInfo";
            this.LabCheckFinishInfo.Size = new System.Drawing.Size(245, 19);
            this.LabCheckFinishInfo.TabIndex = 9;
            this.LabCheckFinishInfo.Text = "<< 尚未有成交回報資料 >>";
            this.LabCheckFinishInfo.Visible = false;
            // 
            // label138
            // 
            this.label138.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label138.AutoSize = true;
            this.label138.ForeColor = System.Drawing.Color.Gainsboro;
            this.label138.Location = new System.Drawing.Point(796, 23);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(91, 19);
            this.label138.TabIndex = 7;
            this.label138.Text = "ESC 結束";
            // 
            // LabChkDealQT5
            // 
            this.LabChkDealQT5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LabChkDealQT5.AutoSize = true;
            this.LabChkDealQT5.ForeColor = System.Drawing.Color.Gainsboro;
            this.LabChkDealQT5.Location = new System.Drawing.Point(746, 1);
            this.LabChkDealQT5.Name = "LabChkDealQT5";
            this.LabChkDealQT5.Size = new System.Drawing.Size(33, 19);
            this.LabChkDealQT5.TabIndex = 14;
            this.LabChkDealQT5.Text = "[5]";
            this.LabChkDealQT5.Visible = false;
            // 
            // label139
            // 
            this.label139.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label139.AutoSize = true;
            this.tabLayOutChkQueryInfo.SetColumnSpan(this.label139, 3);
            this.label139.ForeColor = System.Drawing.Color.Gainsboro;
            this.label139.Location = new System.Drawing.Point(646, 23);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(96, 19);
            this.label139.TabIndex = 8;
            this.label139.Text = "F1 回報數";
            // 
            // Lab_TodayLastFill
            // 
            this.Lab_TodayLastFill.AutoSize = true;
            this.Lab_TodayLastFill.BackColor = System.Drawing.Color.Red;
            this.tabLayOutChkQueryInfo.SetColumnSpan(this.Lab_TodayLastFill, 3);
            this.Lab_TodayLastFill.ForeColor = System.Drawing.Color.Gold;
            this.Lab_TodayLastFill.Location = new System.Drawing.Point(396, 22);
            this.Lab_TodayLastFill.Name = "Lab_TodayLastFill";
            this.Lab_TodayLastFill.Size = new System.Drawing.Size(129, 19);
            this.Lab_TodayLastFill.TabIndex = 17;
            this.Lab_TodayLastFill.Text = "當日回報結束";
            this.Lab_TodayLastFill.Visible = false;
            // 
            // tabPagPassiveRequest
            // 
            this.tabPagPassiveRequest.Controls.Add(this.DGVPasRequest);
            this.tabPagPassiveRequest.Controls.Add(this.panel2);
            this.tabPagPassiveRequest.Location = new System.Drawing.Point(4, 26);
            this.tabPagPassiveRequest.Name = "tabPagPassiveRequest";
            this.tabPagPassiveRequest.Size = new System.Drawing.Size(1059, 190);
            this.tabPagPassiveRequest.TabIndex = 3;
            this.tabPagPassiveRequest.Text = "被動查詢";
            this.tabPagPassiveRequest.UseVisualStyleBackColor = true;
            // 
            // DGVPasRequest
            // 
            this.DGVPasRequest.AllowUserToAddRows = false;
            this.DGVPasRequest.AllowUserToDeleteRows = false;
            this.DGVPasRequest.AllowUserToResizeRows = false;
            dataGridViewCellStyle66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.DGVPasRequest.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle66;
            this.DGVPasRequest.BackgroundColor = System.Drawing.Color.Black;
            this.DGVPasRequest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGVPasRequest.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DGVPasRequest.ColumnHeadersHeight = 25;
            this.DGVPasRequest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVPasRequest.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_CheckDelete,
            this.col_DeleteOrder,
            this.col_ChangeOrder,
            this.col_ChangePrice,
            this.col_TransactTime,
            this.col__DSEQ,
            this.col__CSEQ,
            this.col_CusName,
            this.col__STOCK,
            this.col__STOCKNAME,
            this.col__ECODE,
            this.col__OType,
            this.col_Side,
            this.col_STATUS,
            this.Col__TimeInForce,
            this.col_OrdPrice,
            this.col_OrdQty,
            this.col_CancelQty,
            this.col_DealQty,
            this.col_DealPrice,
            this.col_Mtype,
            this.col_Text,
            this.col_ClOrdID,
            this.Col_Origin,
            this.Col_LaveQty});
            dataGridViewCellStyle77.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle77.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle77.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle77.ForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle77.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle77.SelectionForeColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle77.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVPasRequest.DefaultCellStyle = dataGridViewCellStyle77;
            this.DGVPasRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVPasRequest.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.DGVPasRequest.Location = new System.Drawing.Point(0, 67);
            this.DGVPasRequest.Margin = new System.Windows.Forms.Padding(0);
            this.DGVPasRequest.MultiSelect = false;
            this.DGVPasRequest.Name = "DGVPasRequest";
            this.DGVPasRequest.ReadOnly = true;
            this.DGVPasRequest.RowHeadersVisible = false;
            dataGridViewCellStyle78.BackColor = System.Drawing.Color.Black;
            this.DGVPasRequest.RowsDefaultCellStyle = dataGridViewCellStyle78;
            this.DGVPasRequest.RowTemplate.Height = 24;
            this.DGVPasRequest.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVPasRequest.ShowCellErrors = false;
            this.DGVPasRequest.ShowEditingIcon = false;
            this.DGVPasRequest.Size = new System.Drawing.Size(1059, 123);
            this.DGVPasRequest.TabIndex = 2;
            this.DGVPasRequest.TabStop = false;
            this.DGVPasRequest.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVPasRequest_CellContentClick);
            this.DGVPasRequest.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DGVRequest_CellFormatting);
            this.DGVPasRequest.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.DGVPasRequest_DataError);
            this.DGVPasRequest.Sorted += new System.EventHandler(this.DGVPasRequest_Sorted);
            // 
            // col_CheckDelete
            // 
            this.col_CheckDelete.DataPropertyName = "CheckDelete";
            this.col_CheckDelete.HeaderText = "";
            this.col_CheckDelete.Name = "col_CheckDelete";
            this.col_CheckDelete.ReadOnly = true;
            this.col_CheckDelete.Width = 25;
            // 
            // col_DeleteOrder
            // 
            this.col_DeleteOrder.DataPropertyName = "DeleteOrder";
            this.col_DeleteOrder.HeaderText = "刪";
            this.col_DeleteOrder.Name = "col_DeleteOrder";
            this.col_DeleteOrder.ReadOnly = true;
            this.col_DeleteOrder.Text = "刪";
            this.col_DeleteOrder.UseColumnTextForButtonValue = true;
            this.col_DeleteOrder.Width = 30;
            // 
            // col_ChangeOrder
            // 
            this.col_ChangeOrder.DataPropertyName = "ChangeOrder";
            this.col_ChangeOrder.HeaderText = "量";
            this.col_ChangeOrder.Name = "col_ChangeOrder";
            this.col_ChangeOrder.ReadOnly = true;
            this.col_ChangeOrder.Text = "量";
            this.col_ChangeOrder.UseColumnTextForButtonValue = true;
            this.col_ChangeOrder.Width = 30;
            // 
            // col_ChangePrice
            // 
            this.col_ChangePrice.DataPropertyName = "ChangePrice";
            this.col_ChangePrice.HeaderText = "價";
            this.col_ChangePrice.Name = "col_ChangePrice";
            this.col_ChangePrice.ReadOnly = true;
            this.col_ChangePrice.Text = "價";
            this.col_ChangePrice.UseColumnTextForButtonValue = true;
            this.col_ChangePrice.Width = 30;
            // 
            // col_TransactTime
            // 
            this.col_TransactTime.DataPropertyName = "TransactTime";
            this.col_TransactTime.HeaderText = "委託時間";
            this.col_TransactTime.Name = "col_TransactTime";
            this.col_TransactTime.ReadOnly = true;
            this.col_TransactTime.Width = 90;
            // 
            // col__DSEQ
            // 
            this.col__DSEQ.DataPropertyName = "DSEQ";
            dataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col__DSEQ.DefaultCellStyle = dataGridViewCellStyle67;
            this.col__DSEQ.HeaderText = "委託書號";
            this.col__DSEQ.Name = "col__DSEQ";
            this.col__DSEQ.ReadOnly = true;
            this.col__DSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col__DSEQ.Width = 90;
            // 
            // col__CSEQ
            // 
            this.col__CSEQ.DataPropertyName = "CSEQ";
            this.col__CSEQ.HeaderText = "帳號";
            this.col__CSEQ.Name = "col__CSEQ";
            this.col__CSEQ.ReadOnly = true;
            this.col__CSEQ.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col__CSEQ.Width = 80;
            // 
            // col_CusName
            // 
            this.col_CusName.DataPropertyName = "CusName";
            dataGridViewCellStyle68.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_CusName.DefaultCellStyle = dataGridViewCellStyle68;
            this.col_CusName.HeaderText = "姓名";
            this.col_CusName.Name = "col_CusName";
            this.col_CusName.ReadOnly = true;
            this.col_CusName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_CusName.Width = 70;
            // 
            // col__STOCK
            // 
            this.col__STOCK.DataPropertyName = "Stock";
            this.col__STOCK.HeaderText = "代碼";
            this.col__STOCK.Name = "col__STOCK";
            this.col__STOCK.ReadOnly = true;
            this.col__STOCK.Width = 80;
            // 
            // col__STOCKNAME
            // 
            this.col__STOCKNAME.DataPropertyName = "StockName";
            this.col__STOCKNAME.HeaderText = "名稱";
            this.col__STOCKNAME.Name = "col__STOCKNAME";
            this.col__STOCKNAME.ReadOnly = true;
            this.col__STOCKNAME.Width = 80;
            // 
            // col__ECODE
            // 
            this.col__ECODE.DataPropertyName = "ECode";
            dataGridViewCellStyle69.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col__ECODE.DefaultCellStyle = dataGridViewCellStyle69;
            this.col__ECODE.HeaderText = "盤";
            this.col__ECODE.Name = "col__ECODE";
            this.col__ECODE.ReadOnly = true;
            this.col__ECODE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col__ECODE.Width = 45;
            // 
            // col__OType
            // 
            this.col__OType.DataPropertyName = "OType";
            this.col__OType.HeaderText = "類別";
            this.col__OType.Name = "col__OType";
            this.col__OType.ReadOnly = true;
            this.col__OType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col__OType.Width = 60;
            // 
            // col_Side
            // 
            this.col_Side.DataPropertyName = "Side";
            dataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_Side.DefaultCellStyle = dataGridViewCellStyle70;
            this.col_Side.HeaderText = "買賣";
            this.col_Side.Name = "col_Side";
            this.col_Side.ReadOnly = true;
            this.col_Side.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_Side.Width = 50;
            // 
            // col_STATUS
            // 
            this.col_STATUS.DataPropertyName = "Status";
            this.col_STATUS.HeaderText = "委託狀態";
            this.col_STATUS.Name = "col_STATUS";
            this.col_STATUS.ReadOnly = true;
            // 
            // Col__TimeInForce
            // 
            this.Col__TimeInForce.DataPropertyName = "TimeInForce";
            this.Col__TimeInForce.HeaderText = "條件";
            this.Col__TimeInForce.Name = "Col__TimeInForce";
            this.Col__TimeInForce.ReadOnly = true;
            this.Col__TimeInForce.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Col__TimeInForce.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Col__TimeInForce.Width = 55;
            // 
            // col_OrdPrice
            // 
            this.col_OrdPrice.DataPropertyName = "OrdPrice";
            dataGridViewCellStyle71.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle71.Format = "N2";
            dataGridViewCellStyle71.NullValue = null;
            this.col_OrdPrice.DefaultCellStyle = dataGridViewCellStyle71;
            this.col_OrdPrice.HeaderText = "委託價";
            this.col_OrdPrice.Name = "col_OrdPrice";
            this.col_OrdPrice.ReadOnly = true;
            this.col_OrdPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_OrdPrice.Width = 80;
            // 
            // col_OrdQty
            // 
            this.col_OrdQty.DataPropertyName = "OrdQty";
            dataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_OrdQty.DefaultCellStyle = dataGridViewCellStyle72;
            this.col_OrdQty.HeaderText = "委託股數";
            this.col_OrdQty.Name = "col_OrdQty";
            this.col_OrdQty.ReadOnly = true;
            this.col_OrdQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_OrdQty.Width = 80;
            // 
            // col_CancelQty
            // 
            this.col_CancelQty.DataPropertyName = "CancelQty";
            dataGridViewCellStyle73.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_CancelQty.DefaultCellStyle = dataGridViewCellStyle73;
            this.col_CancelQty.HeaderText = "已刪股數";
            this.col_CancelQty.Name = "col_CancelQty";
            this.col_CancelQty.ReadOnly = true;
            this.col_CancelQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_CancelQty.Width = 80;
            // 
            // col_DealQty
            // 
            this.col_DealQty.DataPropertyName = "DealQty";
            dataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.col_DealQty.DefaultCellStyle = dataGridViewCellStyle74;
            this.col_DealQty.HeaderText = "成交股數";
            this.col_DealQty.Name = "col_DealQty";
            this.col_DealQty.ReadOnly = true;
            this.col_DealQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_DealQty.Width = 60;
            // 
            // col_DealPrice
            // 
            this.col_DealPrice.DataPropertyName = "DealPrice";
            dataGridViewCellStyle75.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle75.NullValue = null;
            this.col_DealPrice.DefaultCellStyle = dataGridViewCellStyle75;
            this.col_DealPrice.HeaderText = "成交價";
            this.col_DealPrice.Name = "col_DealPrice";
            this.col_DealPrice.ReadOnly = true;
            this.col_DealPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_DealPrice.Width = 65;
            // 
            // col_Mtype
            // 
            this.col_Mtype.DataPropertyName = "MType";
            this.col_Mtype.HeaderText = "市場別";
            this.col_Mtype.Name = "col_Mtype";
            this.col_Mtype.ReadOnly = true;
            this.col_Mtype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_Mtype.Width = 75;
            // 
            // col_Text
            // 
            this.col_Text.DataPropertyName = "Text";
            this.col_Text.HeaderText = "備註";
            this.col_Text.Name = "col_Text";
            this.col_Text.ReadOnly = true;
            this.col_Text.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_Text.Width = 200;
            // 
            // col_ClOrdID
            // 
            this.col_ClOrdID.DataPropertyName = "ClOrdID";
            dataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.col_ClOrdID.DefaultCellStyle = dataGridViewCellStyle76;
            this.col_ClOrdID.HeaderText = "網單";
            this.col_ClOrdID.Name = "col_ClOrdID";
            this.col_ClOrdID.ReadOnly = true;
            this.col_ClOrdID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.col_ClOrdID.Width = 58;
            // 
            // Col_Origin
            // 
            this.Col_Origin.DataPropertyName = "Origin";
            this.Col_Origin.HeaderText = "來源別";
            this.Col_Origin.Name = "Col_Origin";
            this.Col_Origin.ReadOnly = true;
            this.Col_Origin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Col_Origin.Visible = false;
            // 
            // Col_LaveQty
            // 
            this.Col_LaveQty.DataPropertyName = "LaveQty";
            this.Col_LaveQty.HeaderText = "剩餘量";
            this.Col_LaveQty.Name = "Col_LaveQty";
            this.Col_LaveQty.ReadOnly = true;
            this.Col_LaveQty.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbPasFilterCSEQ);
            this.panel2.Controls.Add(this.labPasDealAmt);
            this.panel2.Controls.Add(this.labPasDealQty);
            this.panel2.Controls.Add(this.labPasRequestAmt);
            this.panel2.Controls.Add(this.labPasRequestQty);
            this.panel2.Controls.Add(this.labPasCount);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.btnPasFilterClear);
            this.panel2.Controls.Add(this.btnPasFilterOK);
            this.panel2.Controls.Add(this.txbPasFilterDSEQ);
            this.panel2.Controls.Add(this.label152);
            this.panel2.Controls.Add(this.label153);
            this.panel2.Controls.Add(this.btnPasMultiDeleAllCancel);
            this.panel2.Controls.Add(this.btnPasMultiDeleAllSelect);
            this.panel2.Controls.Add(this.btnPasMultiDeleAllOK);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1059, 67);
            this.panel2.TabIndex = 1;
            // 
            // txbPasFilterCSEQ
            // 
            this.txbPasFilterCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbPasFilterCSEQ.Location = new System.Drawing.Point(284, 10);
            this.txbPasFilterCSEQ.Name = "txbPasFilterCSEQ";
            this.txbPasFilterCSEQ.Size = new System.Drawing.Size(89, 30);
            this.txbPasFilterCSEQ.TabIndex = 31;
            this.txbPasFilterCSEQ.TabStop = false;
            this.txbPasFilterCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPasFilterCSEQ_KeyDown);
            // 
            // labPasDealAmt
            // 
            this.labPasDealAmt.AutoSize = true;
            this.labPasDealAmt.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPasDealAmt.Location = new System.Drawing.Point(814, 43);
            this.labPasDealAmt.Name = "labPasDealAmt";
            this.labPasDealAmt.Size = new System.Drawing.Size(119, 19);
            this.labPasDealAmt.TabIndex = 30;
            this.labPasDealAmt.Text = "成交金額：0";
            // 
            // labPasDealQty
            // 
            this.labPasDealQty.AutoSize = true;
            this.labPasDealQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPasDealQty.Location = new System.Drawing.Point(591, 43);
            this.labPasDealQty.Name = "labPasDealQty";
            this.labPasDealQty.Size = new System.Drawing.Size(119, 19);
            this.labPasDealQty.TabIndex = 29;
            this.labPasDealQty.Text = "成交股數：0";
            // 
            // labPasRequestAmt
            // 
            this.labPasRequestAmt.AutoSize = true;
            this.labPasRequestAmt.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPasRequestAmt.Location = new System.Drawing.Point(370, 43);
            this.labPasRequestAmt.Name = "labPasRequestAmt";
            this.labPasRequestAmt.Size = new System.Drawing.Size(119, 19);
            this.labPasRequestAmt.TabIndex = 28;
            this.labPasRequestAmt.Text = "委託金額：0";
            // 
            // labPasRequestQty
            // 
            this.labPasRequestQty.AutoSize = true;
            this.labPasRequestQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPasRequestQty.Location = new System.Drawing.Point(162, 43);
            this.labPasRequestQty.Name = "labPasRequestQty";
            this.labPasRequestQty.Size = new System.Drawing.Size(119, 19);
            this.labPasRequestQty.TabIndex = 27;
            this.labPasRequestQty.Text = "委託股數：0";
            // 
            // labPasCount
            // 
            this.labPasCount.AutoSize = true;
            this.labPasCount.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPasCount.Location = new System.Drawing.Point(8, 43);
            this.labPasCount.Name = "labPasCount";
            this.labPasCount.Size = new System.Drawing.Size(79, 19);
            this.labPasCount.TabIndex = 26;
            this.labPasCount.Text = "筆數：0";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rbPasNoDeal);
            this.panel3.Controls.Add(this.rbPasDeal);
            this.panel3.Controls.Add(this.rbPasAll);
            this.panel3.Location = new System.Drawing.Point(809, 10);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(236, 30);
            this.panel3.TabIndex = 24;
            // 
            // rbPasNoDeal
            // 
            this.rbPasNoDeal.AutoSize = true;
            this.rbPasNoDeal.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbPasNoDeal.Location = new System.Drawing.Point(152, 4);
            this.rbPasNoDeal.Name = "rbPasNoDeal";
            this.rbPasNoDeal.Size = new System.Drawing.Size(74, 20);
            this.rbPasNoDeal.TabIndex = 2;
            this.rbPasNoDeal.Text = "未成交";
            this.rbPasNoDeal.UseVisualStyleBackColor = true;
            this.rbPasNoDeal.CheckedChanged += new System.EventHandler(this.rbPas_CheckedChanged);
            // 
            // rbPasDeal
            // 
            this.rbPasDeal.AutoSize = true;
            this.rbPasDeal.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbPasDeal.Location = new System.Drawing.Point(72, 4);
            this.rbPasDeal.Name = "rbPasDeal";
            this.rbPasDeal.Size = new System.Drawing.Size(74, 20);
            this.rbPasDeal.TabIndex = 1;
            this.rbPasDeal.Text = "已成交";
            this.rbPasDeal.UseVisualStyleBackColor = true;
            this.rbPasDeal.CheckedChanged += new System.EventHandler(this.rbPas_CheckedChanged);
            // 
            // rbPasAll
            // 
            this.rbPasAll.AutoSize = true;
            this.rbPasAll.Checked = true;
            this.rbPasAll.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbPasAll.Location = new System.Drawing.Point(10, 4);
            this.rbPasAll.Name = "rbPasAll";
            this.rbPasAll.Size = new System.Drawing.Size(58, 20);
            this.rbPasAll.TabIndex = 0;
            this.rbPasAll.TabStop = true;
            this.rbPasAll.Text = "全部";
            this.rbPasAll.UseVisualStyleBackColor = true;
            this.rbPasAll.CheckedChanged += new System.EventHandler(this.rbPas_CheckedChanged);
            // 
            // btnPasFilterClear
            // 
            this.btnPasFilterClear.BackColor = System.Drawing.Color.LightCyan;
            this.btnPasFilterClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnPasFilterClear.Location = new System.Drawing.Point(687, 10);
            this.btnPasFilterClear.Name = "btnPasFilterClear";
            this.btnPasFilterClear.Size = new System.Drawing.Size(116, 28);
            this.btnPasFilterClear.TabIndex = 34;
            this.btnPasFilterClear.TabStop = false;
            this.btnPasFilterClear.Text = "清除條件";
            this.btnPasFilterClear.UseVisualStyleBackColor = false;
            this.btnPasFilterClear.Click += new System.EventHandler(this.btnPasFilterClear_Click);
            // 
            // btnPasFilterOK
            // 
            this.btnPasFilterOK.BackColor = System.Drawing.Color.LightCyan;
            this.btnPasFilterOK.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnPasFilterOK.Location = new System.Drawing.Point(561, 10);
            this.btnPasFilterOK.Name = "btnPasFilterOK";
            this.btnPasFilterOK.Size = new System.Drawing.Size(120, 28);
            this.btnPasFilterOK.TabIndex = 33;
            this.btnPasFilterOK.TabStop = false;
            this.btnPasFilterOK.Text = "委託查詢";
            this.btnPasFilterOK.UseVisualStyleBackColor = false;
            this.btnPasFilterOK.Click += new System.EventHandler(this.btnPasFilterOK_Click);
            // 
            // txbPasFilterDSEQ
            // 
            this.txbPasFilterDSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txbPasFilterDSEQ.Location = new System.Drawing.Point(474, 10);
            this.txbPasFilterDSEQ.Name = "txbPasFilterDSEQ";
            this.txbPasFilterDSEQ.Size = new System.Drawing.Size(77, 30);
            this.txbPasFilterDSEQ.TabIndex = 32;
            this.txbPasFilterDSEQ.TabStop = false;
            this.txbPasFilterDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPasFilterDSEQ_KeyDown);
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label152.Location = new System.Drawing.Point(378, 13);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(101, 19);
            this.label152.TabIndex = 20;
            this.label152.Text = "股票代號 :";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label153.Location = new System.Drawing.Point(225, 14);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(61, 19);
            this.label153.TabIndex = 18;
            this.label153.Text = "帳號 :";
            // 
            // btnPasMultiDeleAllCancel
            // 
            this.btnPasMultiDeleAllCancel.BackColor = System.Drawing.Color.LightCyan;
            this.btnPasMultiDeleAllCancel.Location = new System.Drawing.Point(70, 8);
            this.btnPasMultiDeleAllCancel.Name = "btnPasMultiDeleAllCancel";
            this.btnPasMultiDeleAllCancel.Size = new System.Drawing.Size(55, 27);
            this.btnPasMultiDeleAllCancel.TabIndex = 17;
            this.btnPasMultiDeleAllCancel.TabStop = false;
            this.btnPasMultiDeleAllCancel.Text = "取消";
            this.btnPasMultiDeleAllCancel.UseVisualStyleBackColor = false;
            this.btnPasMultiDeleAllCancel.Click += new System.EventHandler(this.btnPasMultiDeleAllCancel_Click);
            // 
            // btnPasMultiDeleAllSelect
            // 
            this.btnPasMultiDeleAllSelect.BackColor = System.Drawing.Color.LightCyan;
            this.btnPasMultiDeleAllSelect.Location = new System.Drawing.Point(6, 7);
            this.btnPasMultiDeleAllSelect.Name = "btnPasMultiDeleAllSelect";
            this.btnPasMultiDeleAllSelect.Size = new System.Drawing.Size(58, 28);
            this.btnPasMultiDeleAllSelect.TabIndex = 16;
            this.btnPasMultiDeleAllSelect.TabStop = false;
            this.btnPasMultiDeleAllSelect.Text = "全選";
            this.btnPasMultiDeleAllSelect.UseVisualStyleBackColor = false;
            this.btnPasMultiDeleAllSelect.Click += new System.EventHandler(this.btnPasMultiDeleAllSelect_Click);
            // 
            // btnPasMultiDeleAllOK
            // 
            this.btnPasMultiDeleAllOK.BackColor = System.Drawing.Color.LightCyan;
            this.btnPasMultiDeleAllOK.Location = new System.Drawing.Point(131, 7);
            this.btnPasMultiDeleAllOK.Name = "btnPasMultiDeleAllOK";
            this.btnPasMultiDeleAllOK.Size = new System.Drawing.Size(88, 28);
            this.btnPasMultiDeleAllOK.TabIndex = 15;
            this.btnPasMultiDeleAllOK.TabStop = false;
            this.btnPasMultiDeleAllOK.Text = "多筆刪單";
            this.btnPasMultiDeleAllOK.UseVisualStyleBackColor = false;
            this.btnPasMultiDeleAllOK.Click += new System.EventHandler(this.btnPasMultiDeleAllOK_Click);
            // 
            // tab_Order
            // 
            this.tab_Order.Controls.Add(this.RoundLot);
            this.tab_Order.Controls.Add(this.OddLot);
            this.tab_Order.Controls.Add(this.FixedPrice);
            this.tab_Order.Controls.Add(this.StockBorrow);
            this.tab_Order.Controls.Add(this.StockPurchase);
            this.tab_Order.Controls.Add(this.StockPurchase2);
            this.tab_Order.Controls.Add(this.StockAuction);
            this.tab_Order.Controls.Add(this.ErrAccount);
            this.tab_Order.Controls.Add(this.Emst);
            this.tab_Order.Controls.Add(this.EmstErrAccount);
            this.tab_Order.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Order.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tab_Order.HotTrack = true;
            this.tab_Order.Location = new System.Drawing.Point(3, 3);
            this.tab_Order.Name = "tab_Order";
            this.tab_Order.SelectedIndex = 0;
            this.tab_Order.Size = new System.Drawing.Size(1061, 394);
            this.tab_Order.TabIndex = 9;
            this.tab_Order.TabStop = false;
            this.tab_Order.SelectedIndexChanged += new System.EventHandler(this.tab_Order_SelectedIndexChanged);
            // 
            // RoundLot
            // 
            this.RoundLot.BackColor = System.Drawing.Color.Black;
            this.RoundLot.Controls.Add(this.panel_RoundLot);
            this.RoundLot.Controls.Add(this.label53);
            this.RoundLot.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RoundLot.ForeColor = System.Drawing.Color.White;
            this.RoundLot.Location = new System.Drawing.Point(4, 26);
            this.RoundLot.Name = "RoundLot";
            this.RoundLot.Padding = new System.Windows.Forms.Padding(3);
            this.RoundLot.Size = new System.Drawing.Size(1053, 364);
            this.RoundLot.TabIndex = 0;
            this.RoundLot.Text = "普通交易";
            // 
            // panel_RoundLot
            // 
            this.panel_RoundLot.BackColor = System.Drawing.Color.Black;
            this.panel_RoundLot.Controls.Add(this.ChKSplitLot);
            this.panel_RoundLot.Controls.Add(this.Lab_OrdTypeInfo);
            this.panel_RoundLot.Controls.Add(this.label135);
            this.panel_RoundLot.Controls.Add(this.RL_LabOrdType);
            this.panel_RoundLot.Controls.Add(this.RL_TxbOrdType);
            this.panel_RoundLot.Controls.Add(this.RL_LabCCodeText);
            this.panel_RoundLot.Controls.Add(this.RL_LanWarText);
            this.panel_RoundLot.Controls.Add(this.RL_LabCancelQty);
            this.panel_RoundLot.Controls.Add(this.RL_BtnForceChangeQty);
            this.panel_RoundLot.Controls.Add(this.RL_BtnForceReturn);
            this.panel_RoundLot.Controls.Add(this.RL_BtnForceOrder);
            this.panel_RoundLot.Controls.Add(this.RL_BtnForceClear);
            this.panel_RoundLot.Controls.Add(this.RL_LabInfo);
            this.panel_RoundLot.Controls.Add(this.RL_LabOrdErrMsg);
            this.panel_RoundLot.Controls.Add(this.RL_TxbTERM);
            this.panel_RoundLot.Controls.Add(this.label56);
            this.panel_RoundLot.Controls.Add(this.RL_BtnChangeTargetNo);
            this.panel_RoundLot.Controls.Add(this.RL_TxbCSEQ);
            this.panel_RoundLot.Controls.Add(this.label13);
            this.panel_RoundLot.Controls.Add(this.label8);
            this.panel_RoundLot.Controls.Add(this.label5);
            this.panel_RoundLot.Controls.Add(this.RL_LabTDate);
            this.panel_RoundLot.Controls.Add(this.label84);
            this.panel_RoundLot.Controls.Add(this.label83);
            this.panel_RoundLot.Controls.Add(this.RL_BtnSellFallTick);
            this.panel_RoundLot.Controls.Add(this.RL_BtnBuyRiseTick);
            this.panel_RoundLot.Controls.Add(this.RL_LabQueryDealQty);
            this.panel_RoundLot.Controls.Add(this.RL_LabQueryLaveQty);
            this.panel_RoundLot.Controls.Add(this.RL_TxbECode);
            this.panel_RoundLot.Controls.Add(this.RL_BtnQuery);
            this.panel_RoundLot.Controls.Add(this.label16);
            this.panel_RoundLot.Controls.Add(this.label15);
            this.panel_RoundLot.Controls.Add(this.label14);
            this.panel_RoundLot.Controls.Add(this.label12);
            this.panel_RoundLot.Controls.Add(this.label1);
            this.panel_RoundLot.Controls.Add(this.RL_LabBHNO);
            this.panel_RoundLot.Controls.Add(this.label10);
            this.panel_RoundLot.Controls.Add(this.labECodeUnit);
            this.panel_RoundLot.Controls.Add(this.RL_TxbSale);
            this.panel_RoundLot.Controls.Add(this.label11);
            this.panel_RoundLot.Controls.Add(this.RL_TxbDSEQ);
            this.panel_RoundLot.Controls.Add(this.btn_OpenFrmTimeSharing);
            this.panel_RoundLot.Controls.Add(this.RL_BtnChgPrice);
            this.panel_RoundLot.Controls.Add(this.RL_BtnOType);
            this.panel_RoundLot.Controls.Add(this.RL_BtnChgOrder);
            this.panel_RoundLot.Controls.Add(this.RL_BtnDelOrder);
            this.panel_RoundLot.Controls.Add(this.label4);
            this.panel_RoundLot.Controls.Add(this.RL_LabFinanceState);
            this.panel_RoundLot.Controls.Add(this.RL_LabStockState);
            this.panel_RoundLot.Controls.Add(this.RL_BtnFallPrice);
            this.panel_RoundLot.Controls.Add(this.RL_BtnCPrice);
            this.panel_RoundLot.Controls.Add(this.RL_BtnRiskPrice);
            this.panel_RoundLot.Controls.Add(this.label2);
            this.panel_RoundLot.Controls.Add(this.RL_LabCSEQName);
            this.panel_RoundLot.Controls.Add(this.RL_LabMType);
            this.panel_RoundLot.Controls.Add(this.RL_TxbPrice);
            this.panel_RoundLot.Controls.Add(this.RL_TxbStockQty);
            this.panel_RoundLot.Controls.Add(this.RL_LabStockName);
            this.panel_RoundLot.Controls.Add(this.RL_TxbStockNo);
            this.panel_RoundLot.Controls.Add(this.RL_LabOType);
            this.panel_RoundLot.Controls.Add(this.RL_TxbOType);
            this.panel_RoundLot.Controls.Add(this.label3);
            this.panel_RoundLot.Controls.Add(this.RL_CkbFixedCSEQ);
            this.panel_RoundLot.Controls.Add(this.RL_BtnSell);
            this.panel_RoundLot.Controls.Add(this.RL_BtnClear);
            this.panel_RoundLot.Controls.Add(this.RL_BtnBuy);
            this.panel_RoundLot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_RoundLot.Font = new System.Drawing.Font("標楷體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_RoundLot.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel_RoundLot.Location = new System.Drawing.Point(3, 3);
            this.panel_RoundLot.Name = "panel_RoundLot";
            this.panel_RoundLot.Size = new System.Drawing.Size(1047, 358);
            this.panel_RoundLot.TabIndex = 2;
            this.panel_RoundLot.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_RoundLot_MouseClick);
            // 
            // ChKSplitLot
            // 
            this.ChKSplitLot.AutoSize = true;
            this.ChKSplitLot.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ChKSplitLot.Location = new System.Drawing.Point(873, 81);
            this.ChKSplitLot.Name = "ChKSplitLot";
            this.ChKSplitLot.Size = new System.Drawing.Size(108, 23);
            this.ChKSplitLot.TabIndex = 1007;
            this.ChKSplitLot.Text = "拆單功能";
            this.ChKSplitLot.UseVisualStyleBackColor = true;
            this.ChKSplitLot.Visible = false;
            this.ChKSplitLot.CheckedChanged += new System.EventHandler(this.ChKSplitLot_CheckedChanged);
            // 
            // Lab_OrdTypeInfo
            // 
            this.Lab_OrdTypeInfo.AutoSize = true;
            this.Lab_OrdTypeInfo.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lab_OrdTypeInfo.ForeColor = System.Drawing.Color.Lime;
            this.Lab_OrdTypeInfo.Location = new System.Drawing.Point(888, 123);
            this.Lab_OrdTypeInfo.Name = "Lab_OrdTypeInfo";
            this.Lab_OrdTypeInfo.Size = new System.Drawing.Size(67, 57);
            this.Lab_OrdTypeInfo.TabIndex = 1006;
            this.Lab_OrdTypeInfo.Text = "0-ROD\r\n3-IOC\r\n4-FOK";
            this.Lab_OrdTypeInfo.Visible = false;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label135.Location = new System.Drawing.Point(757, 123);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(104, 21);
            this.label135.TabIndex = 1005;
            this.label135.Text = "委託 條件";
            // 
            // RL_LabOrdType
            // 
            this.RL_LabOrdType.AutoSize = true;
            this.RL_LabOrdType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabOrdType.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabOrdType.Location = new System.Drawing.Point(791, 152);
            this.RL_LabOrdType.Name = "RL_LabOrdType";
            this.RL_LabOrdType.Size = new System.Drawing.Size(54, 21);
            this.RL_LabOrdType.TabIndex = 1004;
            this.RL_LabOrdType.Text = "ROD";
            // 
            // RL_TxbOrdType
            // 
            this.RL_TxbOrdType.BackColor = System.Drawing.Color.Black;
            this.RL_TxbOrdType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbOrdType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbOrdType.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbOrdType.Location = new System.Drawing.Point(758, 152);
            this.RL_TxbOrdType.Name = "RL_TxbOrdType";
            this.RL_TxbOrdType.Size = new System.Drawing.Size(27, 26);
            this.RL_TxbOrdType.TabIndex = 2;
            this.RL_TxbOrdType.Text = "0";
            this.RL_TxbOrdType.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.RL_TxbOrdType.TextChanged += new System.EventHandler(this.TxbOrdType_TextChanged);
            this.RL_TxbOrdType.Enter += new System.EventHandler(this.RL_TxbOrdType_Enter);
            this.RL_TxbOrdType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbOrdType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbOrdType.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            this.RL_TxbOrdType.Leave += new System.EventHandler(this.RL_TxbOrdType_Leave);
            // 
            // RL_LabCCodeText
            // 
            this.RL_LabCCodeText.AutoSize = true;
            this.RL_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.RL_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.RL_LabCCodeText.Location = new System.Drawing.Point(353, 226);
            this.RL_LabCCodeText.Name = "RL_LabCCodeText";
            this.RL_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.RL_LabCCodeText.TabIndex = 1002;
            this.RL_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // RL_LanWarText
            // 
            this.RL_LanWarText.AutoSize = true;
            this.RL_LanWarText.BackColor = System.Drawing.Color.Red;
            this.RL_LanWarText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.RL_LanWarText.Location = new System.Drawing.Point(2, 179);
            this.RL_LanWarText.Name = "RL_LanWarText";
            this.RL_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.RL_LanWarText.TabIndex = 1001;
            this.RL_LanWarText.Text = "警示訊息";
            // 
            // RL_LabCancelQty
            // 
            this.RL_LabCancelQty.AutoSize = true;
            this.RL_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabCancelQty.Location = new System.Drawing.Point(534, 152);
            this.RL_LabCancelQty.Name = "RL_LabCancelQty";
            this.RL_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.RL_LabCancelQty.TabIndex = 163;
            this.RL_LabCancelQty.Text = "0";
            this.RL_LabCancelQty.Visible = false;
            // 
            // RL_BtnForceChangeQty
            // 
            this.RL_BtnForceChangeQty.BackColor = System.Drawing.Color.Red;
            this.RL_BtnForceChangeQty.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnForceChangeQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnForceChangeQty.ForeColor = System.Drawing.Color.Yellow;
            this.RL_BtnForceChangeQty.Location = new System.Drawing.Point(892, 213);
            this.RL_BtnForceChangeQty.Name = "RL_BtnForceChangeQty";
            this.RL_BtnForceChangeQty.Size = new System.Drawing.Size(89, 34);
            this.RL_BtnForceChangeQty.TabIndex = 141;
            this.RL_BtnForceChangeQty.Text = "F9 改量";
            this.RL_BtnForceChangeQty.UseVisualStyleBackColor = false;
            this.RL_BtnForceChangeQty.Visible = false;
            // 
            // RL_BtnForceReturn
            // 
            this.RL_BtnForceReturn.BackColor = System.Drawing.Color.Red;
            this.RL_BtnForceReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnForceReturn.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnForceReturn.ForeColor = System.Drawing.Color.Yellow;
            this.RL_BtnForceReturn.Location = new System.Drawing.Point(797, 213);
            this.RL_BtnForceReturn.Name = "RL_BtnForceReturn";
            this.RL_BtnForceReturn.Size = new System.Drawing.Size(95, 34);
            this.RL_BtnForceReturn.TabIndex = 140;
            this.RL_BtnForceReturn.Text = "F10 返回";
            this.RL_BtnForceReturn.UseVisualStyleBackColor = false;
            this.RL_BtnForceReturn.Visible = false;
            // 
            // RL_BtnForceOrder
            // 
            this.RL_BtnForceOrder.BackColor = System.Drawing.Color.Red;
            this.RL_BtnForceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnForceOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnForceOrder.ForeColor = System.Drawing.Color.Yellow;
            this.RL_BtnForceOrder.Location = new System.Drawing.Point(702, 213);
            this.RL_BtnForceOrder.Name = "RL_BtnForceOrder";
            this.RL_BtnForceOrder.Size = new System.Drawing.Size(95, 34);
            this.RL_BtnForceOrder.TabIndex = 139;
            this.RL_BtnForceOrder.Text = "SF8 強行";
            this.RL_BtnForceOrder.UseVisualStyleBackColor = false;
            this.RL_BtnForceOrder.Visible = false;
            // 
            // RL_BtnForceClear
            // 
            this.RL_BtnForceClear.BackColor = System.Drawing.Color.Red;
            this.RL_BtnForceClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnForceClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnForceClear.ForeColor = System.Drawing.Color.Yellow;
            this.RL_BtnForceClear.Location = new System.Drawing.Point(613, 213);
            this.RL_BtnForceClear.Name = "RL_BtnForceClear";
            this.RL_BtnForceClear.Size = new System.Drawing.Size(89, 34);
            this.RL_BtnForceClear.TabIndex = 138;
            this.RL_BtnForceClear.Text = "F5 清除";
            this.RL_BtnForceClear.UseVisualStyleBackColor = false;
            this.RL_BtnForceClear.Visible = false;
            // 
            // RL_LabInfo
            // 
            this.RL_LabInfo.AutoSize = true;
            this.RL_LabInfo.BackColor = System.Drawing.Color.Red;
            this.RL_LabInfo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabInfo.ForeColor = System.Drawing.Color.Yellow;
            this.RL_LabInfo.Location = new System.Drawing.Point(2, 211);
            this.RL_LabInfo.Name = "RL_LabInfo";
            this.RL_LabInfo.Size = new System.Drawing.Size(98, 21);
            this.RL_LabInfo.TabIndex = 137;
            this.RL_LabInfo.Text = "相關訊息";
            this.RL_LabInfo.Visible = false;
            // 
            // RL_LabOrdErrMsg
            // 
            this.RL_LabOrdErrMsg.AutoSize = true;
            this.RL_LabOrdErrMsg.BackColor = System.Drawing.Color.Red;
            this.RL_LabOrdErrMsg.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabOrdErrMsg.ForeColor = System.Drawing.Color.Yellow;
            this.RL_LabOrdErrMsg.Location = new System.Drawing.Point(754, 189);
            this.RL_LabOrdErrMsg.Name = "RL_LabOrdErrMsg";
            this.RL_LabOrdErrMsg.Size = new System.Drawing.Size(274, 21);
            this.RL_LabOrdErrMsg.TabIndex = 136;
            this.RL_LabOrdErrMsg.Text = "下單連線異常，請重新下單";
            this.RL_LabOrdErrMsg.Visible = false;
            // 
            // RL_TxbTERM
            // 
            this.RL_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.RL_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbTERM.Location = new System.Drawing.Point(231, 55);
            this.RL_TxbTERM.Name = "RL_TxbTERM";
            this.RL_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.RL_TxbTERM.TabIndex = 9;
            this.RL_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.RL_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label56.Location = new System.Drawing.Point(250, 53);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(18, 21);
            this.label56.TabIndex = 134;
            this.label56.Text = "-";
            // 
            // RL_BtnChangeTargetNo
            // 
            this.RL_BtnChangeTargetNo.BackColor = System.Drawing.Color.Black;
            this.RL_BtnChangeTargetNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnChangeTargetNo.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnChangeTargetNo.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnChangeTargetNo.Location = new System.Drawing.Point(826, 327);
            this.RL_BtnChangeTargetNo.Name = "RL_BtnChangeTargetNo";
            this.RL_BtnChangeTargetNo.Size = new System.Drawing.Size(140, 30);
            this.RL_BtnChangeTargetNo.TabIndex = 133;
            this.RL_BtnChangeTargetNo.TabStop = false;
            this.RL_BtnChangeTargetNo.Text = "SF9更改櫃號";
            this.RL_BtnChangeTargetNo.UseVisualStyleBackColor = false;
            // 
            // RL_TxbCSEQ
            // 
            this.RL_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.RL_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbCSEQ.Location = new System.Drawing.Point(461, 55);
            this.RL_TxbCSEQ.Name = "RL_TxbCSEQ";
            this.RL_TxbCSEQ.Size = new System.Drawing.Size(120, 26);
            this.RL_TxbCSEQ.TabIndex = 7;
            this.RL_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.RL_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(0, 270);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(2072, 16);
            this.label13.TabIndex = 132;
            this.label13.Text = resources.GetString("label13.Text");
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(1, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(2072, 16);
            this.label8.TabIndex = 131;
            this.label8.Text = resources.GetString("label8.Text");
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(1, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(2072, 16);
            this.label5.TabIndex = 130;
            this.label5.Text = resources.GetString("label5.Text");
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // RL_LabTDate
            // 
            this.RL_LabTDate.AutoSize = true;
            this.RL_LabTDate.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabTDate.Location = new System.Drawing.Point(921, 9);
            this.RL_LabTDate.Name = "RL_LabTDate";
            this.RL_LabTDate.Size = new System.Drawing.Size(86, 19);
            this.RL_LabTDate.TabIndex = 129;
            this.RL_LabTDate.Text = "1090107";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label84.ForeColor = System.Drawing.Color.Gold;
            this.label84.Location = new System.Drawing.Point(800, 9);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(115, 19);
            this.label84.TabIndex = 128;
            this.label84.Text = "交易日期 :";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label83.ForeColor = System.Drawing.Color.Gold;
            this.label83.Location = new System.Drawing.Point(24, 9);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(311, 16);
            this.label83.TabIndex = 127;
            this.label83.Text = "<<< 普通交易 委託輸入[集中市場] >>>";
            // 
            // RL_BtnSellFallTick
            // 
            this.RL_BtnSellFallTick.BackColor = System.Drawing.Color.Black;
            this.RL_BtnSellFallTick.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnSellFallTick.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnSellFallTick.ForeColor = System.Drawing.Color.Lime;
            this.RL_BtnSellFallTick.Location = new System.Drawing.Point(367, 327);
            this.RL_BtnSellFallTick.Name = "RL_BtnSellFallTick";
            this.RL_BtnSellFallTick.Size = new System.Drawing.Size(115, 30);
            this.RL_BtnSellFallTick.TabIndex = 126;
            this.RL_BtnSellFallTick.TabStop = false;
            this.RL_BtnSellFallTick.Text = "F15 賣價下";
            this.RL_BtnSellFallTick.UseVisualStyleBackColor = false;
            this.RL_BtnSellFallTick.Visible = false;
            // 
            // RL_BtnBuyRiseTick
            // 
            this.RL_BtnBuyRiseTick.BackColor = System.Drawing.Color.Black;
            this.RL_BtnBuyRiseTick.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnBuyRiseTick.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnBuyRiseTick.ForeColor = System.Drawing.Color.Red;
            this.RL_BtnBuyRiseTick.Location = new System.Drawing.Point(367, 291);
            this.RL_BtnBuyRiseTick.Name = "RL_BtnBuyRiseTick";
            this.RL_BtnBuyRiseTick.Size = new System.Drawing.Size(115, 30);
            this.RL_BtnBuyRiseTick.TabIndex = 125;
            this.RL_BtnBuyRiseTick.TabStop = false;
            this.RL_BtnBuyRiseTick.Text = "F2  買價上";
            this.RL_BtnBuyRiseTick.UseVisualStyleBackColor = false;
            this.RL_BtnBuyRiseTick.Visible = false;
            // 
            // RL_LabQueryDealQty
            // 
            this.RL_LabQueryDealQty.AutoSize = true;
            this.RL_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabQueryDealQty.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabQueryDealQty.Location = new System.Drawing.Point(824, 250);
            this.RL_LabQueryDealQty.Name = "RL_LabQueryDealQty";
            this.RL_LabQueryDealQty.Size = new System.Drawing.Size(34, 21);
            this.RL_LabQueryDealQty.TabIndex = 74;
            this.RL_LabQueryDealQty.Text = "    ";
            // 
            // RL_LabQueryLaveQty
            // 
            this.RL_LabQueryLaveQty.AutoSize = true;
            this.RL_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabQueryLaveQty.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabQueryLaveQty.Location = new System.Drawing.Point(162, 250);
            this.RL_LabQueryLaveQty.Name = "RL_LabQueryLaveQty";
            this.RL_LabQueryLaveQty.Size = new System.Drawing.Size(40, 21);
            this.RL_LabQueryLaveQty.TabIndex = 73;
            this.RL_LabQueryLaveQty.Text = "     ";
            // 
            // RL_TxbECode
            // 
            this.RL_TxbECode.BackColor = System.Drawing.Color.Black;
            this.RL_TxbECode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbECode.CausesValidation = false;
            this.RL_TxbECode.Enabled = false;
            this.RL_TxbECode.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbECode.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbECode.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbECode.Location = new System.Drawing.Point(357, 152);
            this.RL_TxbECode.Name = "RL_TxbECode";
            this.RL_TxbECode.Size = new System.Drawing.Size(59, 26);
            this.RL_TxbECode.TabIndex = 44;
            this.RL_TxbECode.TabStop = false;
            this.RL_TxbECode.Text = "0";
            this.RL_TxbECode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            // 
            // RL_BtnQuery
            // 
            this.RL_BtnQuery.BackColor = System.Drawing.Color.Black;
            this.RL_BtnQuery.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnQuery.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnQuery.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnQuery.Location = new System.Drawing.Point(488, 291);
            this.RL_BtnQuery.Name = "RL_BtnQuery";
            this.RL_BtnQuery.Size = new System.Drawing.Size(100, 30);
            this.RL_BtnQuery.TabIndex = 72;
            this.RL_BtnQuery.TabStop = false;
            this.RL_BtnQuery.Text = "F12查詢";
            this.RL_BtnQuery.UseVisualStyleBackColor = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(686, 250);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 21);
            this.label16.TabIndex = 69;
            this.label16.Text = "成交已回報 :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(24, 250);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 21);
            this.label15.TabIndex = 68;
            this.label15.Text = "未搓合張數 :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(353, 123);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 21);
            this.label14.TabIndex = 67;
            this.label14.Text = "交易別";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(24, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 21);
            this.label12.TabIndex = 65;
            this.label12.Text = "股票代號";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(415, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 21);
            this.label1.TabIndex = 63;
            this.label1.Text = "證券商代號: ";
            // 
            // RL_LabBHNO
            // 
            this.RL_LabBHNO.AutoSize = true;
            this.RL_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabBHNO.Location = new System.Drawing.Point(553, 9);
            this.RL_LabBHNO.Name = "RL_LabBHNO";
            this.RL_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.RL_LabBHNO.TabIndex = 44;
            this.RL_LabBHNO.Text = " 8455";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(118, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 21);
            this.label10.TabIndex = 58;
            this.label10.Text = "委託序號 :";
            // 
            // labECodeUnit
            // 
            this.labECodeUnit.AutoSize = true;
            this.labECodeUnit.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labECodeUnit.Location = new System.Drawing.Point(456, 123);
            this.labECodeUnit.Name = "labECodeUnit";
            this.labECodeUnit.Size = new System.Drawing.Size(104, 21);
            this.labECodeUnit.TabIndex = 62;
            this.labECodeUnit.Text = "委託 張數";
            // 
            // RL_TxbSale
            // 
            this.RL_TxbSale.BackColor = System.Drawing.Color.Black;
            this.RL_TxbSale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbSale.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbSale.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbSale.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbSale.Location = new System.Drawing.Point(441, 250);
            this.RL_TxbSale.Name = "RL_TxbSale";
            this.RL_TxbSale.Size = new System.Drawing.Size(69, 26);
            this.RL_TxbSale.TabIndex = 1;
            this.RL_TxbSale.TabStop = false;
            this.RL_TxbSale.TextChanged += new System.EventHandler(this.TxbSale_TextChanged);
            this.RL_TxbSale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbSale.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(353, 250);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 21);
            this.label11.TabIndex = 60;
            this.label11.Text = "營業員:";
            // 
            // RL_TxbDSEQ
            // 
            this.RL_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.RL_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbDSEQ.Location = new System.Drawing.Point(269, 55);
            this.RL_TxbDSEQ.Name = "RL_TxbDSEQ";
            this.RL_TxbDSEQ.Size = new System.Drawing.Size(55, 26);
            this.RL_TxbDSEQ.TabIndex = 8;
            this.RL_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.RL_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.RL_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // btn_OpenFrmTimeSharing
            // 
            this.btn_OpenFrmTimeSharing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.btn_OpenFrmTimeSharing.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OpenFrmTimeSharing.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_OpenFrmTimeSharing.ForeColor = System.Drawing.Color.Gold;
            this.btn_OpenFrmTimeSharing.Location = new System.Drawing.Point(606, 184);
            this.btn_OpenFrmTimeSharing.Name = "btn_OpenFrmTimeSharing";
            this.btn_OpenFrmTimeSharing.Size = new System.Drawing.Size(100, 30);
            this.btn_OpenFrmTimeSharing.TabIndex = 56;
            this.btn_OpenFrmTimeSharing.TabStop = false;
            this.btn_OpenFrmTimeSharing.Text = "分時分量";
            this.btn_OpenFrmTimeSharing.UseVisualStyleBackColor = false;
            this.btn_OpenFrmTimeSharing.Visible = false;
            this.btn_OpenFrmTimeSharing.Click += new System.EventHandler(this.btn_OpenFrmTimeSharing_Click);
            // 
            // RL_BtnChgPrice
            // 
            this.RL_BtnChgPrice.BackColor = System.Drawing.Color.Black;
            this.RL_BtnChgPrice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnChgPrice.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnChgPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnChgPrice.Location = new System.Drawing.Point(720, 291);
            this.RL_BtnChgPrice.Name = "RL_BtnChgPrice";
            this.RL_BtnChgPrice.Size = new System.Drawing.Size(100, 30);
            this.RL_BtnChgPrice.TabIndex = 56;
            this.RL_BtnChgPrice.TabStop = false;
            this.RL_BtnChgPrice.Text = "F9改價";
            this.RL_BtnChgPrice.UseVisualStyleBackColor = false;
            // 
            // RL_BtnOType
            // 
            this.RL_BtnOType.BackColor = System.Drawing.Color.Black;
            this.RL_BtnOType.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnOType.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnOType.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnOType.Location = new System.Drawing.Point(826, 291);
            this.RL_BtnOType.Name = "RL_BtnOType";
            this.RL_BtnOType.Size = new System.Drawing.Size(140, 30);
            this.RL_BtnOType.TabIndex = 55;
            this.RL_BtnOType.TabStop = false;
            this.RL_BtnOType.Text = "F10委託類別";
            this.RL_BtnOType.UseVisualStyleBackColor = false;
            // 
            // RL_BtnChgOrder
            // 
            this.RL_BtnChgOrder.BackColor = System.Drawing.Color.Black;
            this.RL_BtnChgOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnChgOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnChgOrder.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnChgOrder.Location = new System.Drawing.Point(594, 327);
            this.RL_BtnChgOrder.Name = "RL_BtnChgOrder";
            this.RL_BtnChgOrder.Size = new System.Drawing.Size(120, 30);
            this.RL_BtnChgOrder.TabIndex = 53;
            this.RL_BtnChgOrder.TabStop = false;
            this.RL_BtnChgOrder.Text = "F8部分取消";
            this.RL_BtnChgOrder.UseVisualStyleBackColor = false;
            // 
            // RL_BtnDelOrder
            // 
            this.RL_BtnDelOrder.BackColor = System.Drawing.Color.Black;
            this.RL_BtnDelOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnDelOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnDelOrder.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnDelOrder.Location = new System.Drawing.Point(488, 327);
            this.RL_BtnDelOrder.Name = "RL_BtnDelOrder";
            this.RL_BtnDelOrder.Size = new System.Drawing.Size(100, 30);
            this.RL_BtnDelOrder.TabIndex = 52;
            this.RL_BtnDelOrder.TabStop = false;
            this.RL_BtnDelOrder.Text = "SF4刪單";
            this.RL_BtnDelOrder.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(602, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 21);
            this.label4.TabIndex = 50;
            this.label4.Text = "委託 價格";
            // 
            // RL_LabFinanceState
            // 
            this.RL_LabFinanceState.AutoSize = true;
            this.RL_LabFinanceState.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabFinanceState.ForeColor = System.Drawing.Color.Red;
            this.RL_LabFinanceState.Location = new System.Drawing.Point(351, 181);
            this.RL_LabFinanceState.Name = "RL_LabFinanceState";
            this.RL_LabFinanceState.Size = new System.Drawing.Size(129, 19);
            this.RL_LabFinanceState.TabIndex = 48;
            this.RL_LabFinanceState.Text = "資券配額狀況";
            this.RL_LabFinanceState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RL_LabStockState
            // 
            this.RL_LabStockState.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabStockState.ForeColor = System.Drawing.Color.Red;
            this.RL_LabStockState.Location = new System.Drawing.Point(117, 120);
            this.RL_LabStockState.Name = "RL_LabStockState";
            this.RL_LabStockState.Size = new System.Drawing.Size(232, 26);
            this.RL_LabStockState.TabIndex = 47;
            this.RL_LabStockState.Text = "不可信用交易_可現沖";
            this.RL_LabStockState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RL_BtnFallPrice
            // 
            this.RL_BtnFallPrice.BackColor = System.Drawing.Color.Black;
            this.RL_BtnFallPrice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnFallPrice.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnFallPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnFallPrice.Location = new System.Drawing.Point(27, 327);
            this.RL_BtnFallPrice.Name = "RL_BtnFallPrice";
            this.RL_BtnFallPrice.Size = new System.Drawing.Size(110, 30);
            this.RL_BtnFallPrice.TabIndex = 43;
            this.RL_BtnFallPrice.TabStop = false;
            this.RL_BtnFallPrice.Text = "F14跌停價";
            this.RL_BtnFallPrice.UseVisualStyleBackColor = false;
            // 
            // RL_BtnCPrice
            // 
            this.RL_BtnCPrice.BackColor = System.Drawing.Color.Black;
            this.RL_BtnCPrice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnCPrice.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnCPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnCPrice.Location = new System.Drawing.Point(144, 291);
            this.RL_BtnCPrice.Name = "RL_BtnCPrice";
            this.RL_BtnCPrice.Size = new System.Drawing.Size(110, 30);
            this.RL_BtnCPrice.TabIndex = 42;
            this.RL_BtnCPrice.TabStop = false;
            this.RL_BtnCPrice.Text = "F7平盤價";
            this.RL_BtnCPrice.UseVisualStyleBackColor = false;
            // 
            // RL_BtnRiskPrice
            // 
            this.RL_BtnRiskPrice.BackColor = System.Drawing.Color.Black;
            this.RL_BtnRiskPrice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnRiskPrice.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnRiskPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnRiskPrice.Location = new System.Drawing.Point(27, 291);
            this.RL_BtnRiskPrice.Name = "RL_BtnRiskPrice";
            this.RL_BtnRiskPrice.Size = new System.Drawing.Size(110, 30);
            this.RL_BtnRiskPrice.TabIndex = 41;
            this.RL_BtnRiskPrice.TabStop = false;
            this.RL_BtnRiskPrice.Text = "F3 漲停價";
            this.RL_BtnRiskPrice.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(353, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 21);
            this.label2.TabIndex = 38;
            this.label2.Text = "客戶帳號 :";
            // 
            // RL_LabCSEQName
            // 
            this.RL_LabCSEQName.AutoSize = true;
            this.RL_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabCSEQName.Location = new System.Drawing.Point(587, 56);
            this.RL_LabCSEQName.Name = "RL_LabCSEQName";
            this.RL_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.RL_LabCSEQName.TabIndex = 37;
            this.RL_LabCSEQName.Text = "客戶名稱";
            // 
            // RL_LabMType
            // 
            this.RL_LabMType.AutoSize = true;
            this.RL_LabMType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabMType.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabMType.Location = new System.Drawing.Point(274, 152);
            this.RL_LabMType.Name = "RL_LabMType";
            this.RL_LabMType.Size = new System.Drawing.Size(23, 21);
            this.RL_LabMType.TabIndex = 29;
            this.RL_LabMType.Text = "T";
            // 
            // RL_TxbPrice
            // 
            this.RL_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.RL_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbPrice.Location = new System.Drawing.Point(606, 152);
            this.RL_TxbPrice.Name = "RL_TxbPrice";
            this.RL_TxbPrice.Size = new System.Drawing.Size(85, 26);
            this.RL_TxbPrice.TabIndex = 3;
            this.RL_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.RL_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.RL_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // RL_TxbStockQty
            // 
            this.RL_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.RL_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbStockQty.CausesValidation = false;
            this.RL_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbStockQty.Location = new System.Drawing.Point(466, 152);
            this.RL_TxbStockQty.Name = "RL_TxbStockQty";
            this.RL_TxbStockQty.Size = new System.Drawing.Size(60, 26);
            this.RL_TxbStockQty.TabIndex = 4;
            this.RL_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.RL_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // RL_LabStockName
            // 
            this.RL_LabStockName.AutoSize = true;
            this.RL_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabStockName.Location = new System.Drawing.Point(130, 152);
            this.RL_LabStockName.Name = "RL_LabStockName";
            this.RL_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.RL_LabStockName.TabIndex = 14;
            this.RL_LabStockName.Text = "股票名稱";
            // 
            // RL_TxbStockNo
            // 
            this.RL_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.RL_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbStockNo.Location = new System.Drawing.Point(28, 152);
            this.RL_TxbStockNo.Name = "RL_TxbStockNo";
            this.RL_TxbStockNo.Size = new System.Drawing.Size(85, 26);
            this.RL_TxbStockNo.TabIndex = 5;
            this.RL_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.RL_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // RL_LabOType
            // 
            this.RL_LabOType.AutoSize = true;
            this.RL_LabOType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_LabOType.ForeColor = System.Drawing.Color.Lime;
            this.RL_LabOType.Location = new System.Drawing.Point(829, 55);
            this.RL_LabOType.Name = "RL_LabOType";
            this.RL_LabOType.Size = new System.Drawing.Size(32, 21);
            this.RL_LabOType.TabIndex = 10;
            this.RL_LabOType.Text = "現";
            // 
            // RL_TxbOType
            // 
            this.RL_TxbOType.BackColor = System.Drawing.Color.Black;
            this.RL_TxbOType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RL_TxbOType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_TxbOType.ForeColor = System.Drawing.Color.Lime;
            this.RL_TxbOType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.RL_TxbOType.Location = new System.Drawing.Point(797, 55);
            this.RL_TxbOType.Name = "RL_TxbOType";
            this.RL_TxbOType.Size = new System.Drawing.Size(30, 26);
            this.RL_TxbOType.TabIndex = 6;
            this.RL_TxbOType.Text = "0";
            this.RL_TxbOType.TextChanged += new System.EventHandler(this.TxbOType_TextChanged);
            this.RL_TxbOType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.RL_TxbOType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.RL_TxbOType.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(686, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 21);
            this.label3.TabIndex = 8;
            this.label3.Text = "委託類別 :";
            // 
            // RL_CkbFixedCSEQ
            // 
            this.RL_CkbFixedCSEQ.AutoSize = true;
            this.RL_CkbFixedCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_CkbFixedCSEQ.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_CkbFixedCSEQ.Location = new System.Drawing.Point(873, 52);
            this.RL_CkbFixedCSEQ.Name = "RL_CkbFixedCSEQ";
            this.RL_CkbFixedCSEQ.Size = new System.Drawing.Size(168, 23);
            this.RL_CkbFixedCSEQ.TabIndex = 5;
            this.RL_CkbFixedCSEQ.TabStop = false;
            this.RL_CkbFixedCSEQ.Text = "固定委託人帳號";
            this.RL_CkbFixedCSEQ.UseVisualStyleBackColor = true;
            this.RL_CkbFixedCSEQ.CheckedChanged += new System.EventHandler(this.CkbFixedCSEQ_CheckedChanged);
            // 
            // RL_BtnSell
            // 
            this.RL_BtnSell.BackColor = System.Drawing.Color.Black;
            this.RL_BtnSell.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnSell.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnSell.ForeColor = System.Drawing.Color.Lime;
            this.RL_BtnSell.Location = new System.Drawing.Point(260, 327);
            this.RL_BtnSell.Name = "RL_BtnSell";
            this.RL_BtnSell.Size = new System.Drawing.Size(100, 30);
            this.RL_BtnSell.TabIndex = 4;
            this.RL_BtnSell.TabStop = false;
            this.RL_BtnSell.Text = "F16 賣出";
            this.RL_BtnSell.UseVisualStyleBackColor = false;
            // 
            // RL_BtnClear
            // 
            this.RL_BtnClear.BackColor = System.Drawing.Color.Black;
            this.RL_BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnClear.ForeColor = System.Drawing.Color.Gainsboro;
            this.RL_BtnClear.Location = new System.Drawing.Point(594, 291);
            this.RL_BtnClear.Name = "RL_BtnClear";
            this.RL_BtnClear.Size = new System.Drawing.Size(120, 30);
            this.RL_BtnClear.TabIndex = 3;
            this.RL_BtnClear.TabStop = false;
            this.RL_BtnClear.Text = "F5清除畫面";
            this.RL_BtnClear.UseVisualStyleBackColor = false;
            // 
            // RL_BtnBuy
            // 
            this.RL_BtnBuy.BackColor = System.Drawing.Color.Black;
            this.RL_BtnBuy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RL_BtnBuy.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RL_BtnBuy.ForeColor = System.Drawing.Color.Red;
            this.RL_BtnBuy.Location = new System.Drawing.Point(260, 291);
            this.RL_BtnBuy.Name = "RL_BtnBuy";
            this.RL_BtnBuy.Size = new System.Drawing.Size(100, 30);
            this.RL_BtnBuy.TabIndex = 2;
            this.RL_BtnBuy.TabStop = false;
            this.RL_BtnBuy.Text = "F1  買進";
            this.RL_BtnBuy.UseVisualStyleBackColor = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label53.ForeColor = System.Drawing.Color.Gold;
            this.label53.Location = new System.Drawing.Point(3, 3);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(332, 27);
            this.label53.TabIndex = 3;
            this.label53.Text = "<<非普通交易委託時間 >>";
            // 
            // OddLot
            // 
            this.OddLot.BackColor = System.Drawing.Color.Black;
            this.OddLot.Controls.Add(this.panel_OddLot);
            this.OddLot.Controls.Add(this.label54);
            this.OddLot.ForeColor = System.Drawing.Color.White;
            this.OddLot.Location = new System.Drawing.Point(4, 26);
            this.OddLot.Name = "OddLot";
            this.OddLot.Padding = new System.Windows.Forms.Padding(3);
            this.OddLot.Size = new System.Drawing.Size(1053, 364);
            this.OddLot.TabIndex = 3;
            this.OddLot.Text = "零股交易";
            // 
            // panel_OddLot
            // 
            this.panel_OddLot.BackColor = System.Drawing.Color.Black;
            this.panel_OddLot.Controls.Add(this.OD_LabCCodeText);
            this.panel_OddLot.Controls.Add(this.OD_LanWarText);
            this.panel_OddLot.Controls.Add(this.OD_TxbStockQty);
            this.panel_OddLot.Controls.Add(this.OD_LabCancelQty);
            this.panel_OddLot.Controls.Add(this.OD_BtnForceChangeQty);
            this.panel_OddLot.Controls.Add(this.OD_BtnForceReturn);
            this.panel_OddLot.Controls.Add(this.OD_BtnForceOrder);
            this.panel_OddLot.Controls.Add(this.OD_BtnForceClear);
            this.panel_OddLot.Controls.Add(this.OD_LabInfo);
            this.panel_OddLot.Controls.Add(this.OD_LabOrdErrMsg);
            this.panel_OddLot.Controls.Add(this.OD_TxbTERM);
            this.panel_OddLot.Controls.Add(this.label57);
            this.panel_OddLot.Controls.Add(this.OD_BtnChangeTargetNo);
            this.panel_OddLot.Controls.Add(this.OD_TxbCSEQ);
            this.panel_OddLot.Controls.Add(this.button31);
            this.panel_OddLot.Controls.Add(this.label40);
            this.panel_OddLot.Controls.Add(this.label17);
            this.panel_OddLot.Controls.Add(this.OD_LabQueryLaveQty);
            this.panel_OddLot.Controls.Add(this.button30);
            this.panel_OddLot.Controls.Add(this.button14);
            this.panel_OddLot.Controls.Add(this.button25);
            this.panel_OddLot.Controls.Add(this.button26);
            this.panel_OddLot.Controls.Add(this.button27);
            this.panel_OddLot.Controls.Add(this.button28);
            this.panel_OddLot.Controls.Add(this.button29);
            this.panel_OddLot.Controls.Add(this.OD_LabTDate);
            this.panel_OddLot.Controls.Add(this.label90);
            this.panel_OddLot.Controls.Add(this.label91);
            this.panel_OddLot.Controls.Add(this.label58);
            this.panel_OddLot.Controls.Add(this.OD_TxbECode);
            this.panel_OddLot.Controls.Add(this.label41);
            this.panel_OddLot.Controls.Add(this.label42);
            this.panel_OddLot.Controls.Add(this.label43);
            this.panel_OddLot.Controls.Add(this.label44);
            this.panel_OddLot.Controls.Add(this.OD_LabBHNO);
            this.panel_OddLot.Controls.Add(this.label46);
            this.panel_OddLot.Controls.Add(this.label47);
            this.panel_OddLot.Controls.Add(this.OD_TxbSale);
            this.panel_OddLot.Controls.Add(this.label48);
            this.panel_OddLot.Controls.Add(this.OD_TxbDSEQ);
            this.panel_OddLot.Controls.Add(this.label49);
            this.panel_OddLot.Controls.Add(this.OD_LabFinanceState);
            this.panel_OddLot.Controls.Add(this.OD_LabStockState);
            this.panel_OddLot.Controls.Add(this.label52);
            this.panel_OddLot.Controls.Add(this.OD_LabCSEQName);
            this.panel_OddLot.Controls.Add(this.OD_LabMType);
            this.panel_OddLot.Controls.Add(this.OD_TxbPrice);
            this.panel_OddLot.Controls.Add(this.OD_LabStockName);
            this.panel_OddLot.Controls.Add(this.OD_TxbStockNo);
            this.panel_OddLot.Controls.Add(this.OD_CkbFixedCSEQ);
            this.panel_OddLot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_OddLot.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_OddLot.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel_OddLot.Location = new System.Drawing.Point(3, 3);
            this.panel_OddLot.Name = "panel_OddLot";
            this.panel_OddLot.Size = new System.Drawing.Size(1047, 358);
            this.panel_OddLot.TabIndex = 2;
            this.panel_OddLot.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_OddLot_MouseClick);
            // 
            // OD_LabCCodeText
            // 
            this.OD_LabCCodeText.AutoSize = true;
            this.OD_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.OD_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.OD_LabCCodeText.Location = new System.Drawing.Point(353, 226);
            this.OD_LabCCodeText.Name = "OD_LabCCodeText";
            this.OD_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.OD_LabCCodeText.TabIndex = 1003;
            this.OD_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // OD_LanWarText
            // 
            this.OD_LanWarText.AutoSize = true;
            this.OD_LanWarText.BackColor = System.Drawing.Color.Red;
            this.OD_LanWarText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.OD_LanWarText.Location = new System.Drawing.Point(2, 179);
            this.OD_LanWarText.Name = "OD_LanWarText";
            this.OD_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.OD_LanWarText.TabIndex = 1002;
            this.OD_LanWarText.Text = "警示訊息";
            // 
            // OD_TxbStockQty
            // 
            this.OD_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.OD_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbStockQty.CausesValidation = false;
            this.OD_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbStockQty.Location = new System.Drawing.Point(466, 152);
            this.OD_TxbStockQty.Name = "OD_TxbStockQty";
            this.OD_TxbStockQty.Size = new System.Drawing.Size(60, 26);
            this.OD_TxbStockQty.TabIndex = 13;
            this.OD_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.OD_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // OD_LabCancelQty
            // 
            this.OD_LabCancelQty.AutoSize = true;
            this.OD_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabCancelQty.Location = new System.Drawing.Point(534, 152);
            this.OD_LabCancelQty.Name = "OD_LabCancelQty";
            this.OD_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.OD_LabCancelQty.TabIndex = 164;
            this.OD_LabCancelQty.Text = "0";
            this.OD_LabCancelQty.Visible = false;
            // 
            // OD_BtnForceChangeQty
            // 
            this.OD_BtnForceChangeQty.BackColor = System.Drawing.Color.Red;
            this.OD_BtnForceChangeQty.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OD_BtnForceChangeQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_BtnForceChangeQty.ForeColor = System.Drawing.Color.Yellow;
            this.OD_BtnForceChangeQty.Location = new System.Drawing.Point(873, 198);
            this.OD_BtnForceChangeQty.Name = "OD_BtnForceChangeQty";
            this.OD_BtnForceChangeQty.Size = new System.Drawing.Size(89, 34);
            this.OD_BtnForceChangeQty.TabIndex = 157;
            this.OD_BtnForceChangeQty.Text = "F9 改量";
            this.OD_BtnForceChangeQty.UseVisualStyleBackColor = false;
            this.OD_BtnForceChangeQty.Visible = false;
            // 
            // OD_BtnForceReturn
            // 
            this.OD_BtnForceReturn.BackColor = System.Drawing.Color.Red;
            this.OD_BtnForceReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OD_BtnForceReturn.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_BtnForceReturn.ForeColor = System.Drawing.Color.Yellow;
            this.OD_BtnForceReturn.Location = new System.Drawing.Point(778, 198);
            this.OD_BtnForceReturn.Name = "OD_BtnForceReturn";
            this.OD_BtnForceReturn.Size = new System.Drawing.Size(95, 34);
            this.OD_BtnForceReturn.TabIndex = 156;
            this.OD_BtnForceReturn.Text = "F10 返回";
            this.OD_BtnForceReturn.UseVisualStyleBackColor = false;
            this.OD_BtnForceReturn.Visible = false;
            // 
            // OD_BtnForceOrder
            // 
            this.OD_BtnForceOrder.BackColor = System.Drawing.Color.Red;
            this.OD_BtnForceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OD_BtnForceOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_BtnForceOrder.ForeColor = System.Drawing.Color.Yellow;
            this.OD_BtnForceOrder.Location = new System.Drawing.Point(683, 198);
            this.OD_BtnForceOrder.Name = "OD_BtnForceOrder";
            this.OD_BtnForceOrder.Size = new System.Drawing.Size(95, 34);
            this.OD_BtnForceOrder.TabIndex = 155;
            this.OD_BtnForceOrder.Text = "SF8 強行";
            this.OD_BtnForceOrder.UseVisualStyleBackColor = false;
            this.OD_BtnForceOrder.Visible = false;
            // 
            // OD_BtnForceClear
            // 
            this.OD_BtnForceClear.BackColor = System.Drawing.Color.Red;
            this.OD_BtnForceClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OD_BtnForceClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_BtnForceClear.ForeColor = System.Drawing.Color.Yellow;
            this.OD_BtnForceClear.Location = new System.Drawing.Point(594, 198);
            this.OD_BtnForceClear.Name = "OD_BtnForceClear";
            this.OD_BtnForceClear.Size = new System.Drawing.Size(89, 34);
            this.OD_BtnForceClear.TabIndex = 154;
            this.OD_BtnForceClear.Text = "F5 清除";
            this.OD_BtnForceClear.UseVisualStyleBackColor = false;
            this.OD_BtnForceClear.Visible = false;
            // 
            // OD_LabInfo
            // 
            this.OD_LabInfo.AutoSize = true;
            this.OD_LabInfo.BackColor = System.Drawing.Color.Red;
            this.OD_LabInfo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabInfo.ForeColor = System.Drawing.Color.Yellow;
            this.OD_LabInfo.Location = new System.Drawing.Point(2, 211);
            this.OD_LabInfo.Name = "OD_LabInfo";
            this.OD_LabInfo.Size = new System.Drawing.Size(98, 21);
            this.OD_LabInfo.TabIndex = 153;
            this.OD_LabInfo.Text = "相關訊息";
            this.OD_LabInfo.Visible = false;
            // 
            // OD_LabOrdErrMsg
            // 
            this.OD_LabOrdErrMsg.AutoSize = true;
            this.OD_LabOrdErrMsg.BackColor = System.Drawing.Color.Red;
            this.OD_LabOrdErrMsg.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabOrdErrMsg.ForeColor = System.Drawing.Color.Yellow;
            this.OD_LabOrdErrMsg.Location = new System.Drawing.Point(706, 123);
            this.OD_LabOrdErrMsg.Name = "OD_LabOrdErrMsg";
            this.OD_LabOrdErrMsg.Size = new System.Drawing.Size(274, 21);
            this.OD_LabOrdErrMsg.TabIndex = 152;
            this.OD_LabOrdErrMsg.Text = "下單連線異常，請重新下單";
            this.OD_LabOrdErrMsg.Visible = false;
            // 
            // OD_TxbTERM
            // 
            this.OD_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.OD_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbTERM.Location = new System.Drawing.Point(231, 55);
            this.OD_TxbTERM.Name = "OD_TxbTERM";
            this.OD_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.OD_TxbTERM.TabIndex = 17;
            this.OD_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.OD_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label57.Location = new System.Drawing.Point(250, 53);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(18, 21);
            this.label57.TabIndex = 151;
            this.label57.Text = "-";
            // 
            // OD_BtnChangeTargetNo
            // 
            this.OD_BtnChangeTargetNo.BackColor = System.Drawing.Color.Black;
            this.OD_BtnChangeTargetNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OD_BtnChangeTargetNo.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_BtnChangeTargetNo.ForeColor = System.Drawing.Color.Gainsboro;
            this.OD_BtnChangeTargetNo.Location = new System.Drawing.Point(720, 327);
            this.OD_BtnChangeTargetNo.Name = "OD_BtnChangeTargetNo";
            this.OD_BtnChangeTargetNo.Size = new System.Drawing.Size(140, 30);
            this.OD_BtnChangeTargetNo.TabIndex = 150;
            this.OD_BtnChangeTargetNo.TabStop = false;
            this.OD_BtnChangeTargetNo.Text = "SF9更改櫃號";
            this.OD_BtnChangeTargetNo.UseVisualStyleBackColor = false;
            // 
            // OD_TxbCSEQ
            // 
            this.OD_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.OD_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbCSEQ.Location = new System.Drawing.Point(461, 55);
            this.OD_TxbCSEQ.Name = "OD_TxbCSEQ";
            this.OD_TxbCSEQ.Size = new System.Drawing.Size(120, 26);
            this.OD_TxbCSEQ.TabIndex = 15;
            this.OD_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.OD_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Black;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button31.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button31.ForeColor = System.Drawing.Color.Gainsboro;
            this.button31.Location = new System.Drawing.Point(144, 291);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(110, 30);
            this.button31.TabIndex = 148;
            this.button31.TabStop = false;
            this.button31.Text = "F7平盤價";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label40.ForeColor = System.Drawing.Color.Gainsboro;
            this.label40.Location = new System.Drawing.Point(0, 270);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(2072, 16);
            this.label40.TabIndex = 146;
            this.label40.Text = resources.GetString("label40.Text");
            this.label40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.ForeColor = System.Drawing.Color.Gainsboro;
            this.label17.Location = new System.Drawing.Point(1, 101);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(2072, 16);
            this.label17.TabIndex = 145;
            this.label17.Text = resources.GetString("label17.Text");
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // OD_LabQueryLaveQty
            // 
            this.OD_LabQueryLaveQty.AutoSize = true;
            this.OD_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabQueryLaveQty.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabQueryLaveQty.Location = new System.Drawing.Point(162, 250);
            this.OD_LabQueryLaveQty.Name = "OD_LabQueryLaveQty";
            this.OD_LabQueryLaveQty.Size = new System.Drawing.Size(16, 21);
            this.OD_LabQueryLaveQty.TabIndex = 144;
            this.OD_LabQueryLaveQty.Text = " ";
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Black;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button30.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button30.ForeColor = System.Drawing.Color.Gainsboro;
            this.button30.Location = new System.Drawing.Point(720, 291);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(140, 30);
            this.button30.TabIndex = 143;
            this.button30.TabStop = false;
            this.button30.Text = "F3/F14 999股";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Black;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button14.ForeColor = System.Drawing.Color.Gainsboro;
            this.button14.Location = new System.Drawing.Point(488, 291);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(100, 30);
            this.button14.TabIndex = 142;
            this.button14.TabStop = false;
            this.button14.Text = "F12查詢";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Black;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button25.ForeColor = System.Drawing.Color.Gainsboro;
            this.button25.Location = new System.Drawing.Point(594, 327);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(120, 30);
            this.button25.TabIndex = 141;
            this.button25.TabStop = false;
            this.button25.Text = "F8部分取消";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Black;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button26.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button26.ForeColor = System.Drawing.Color.Gainsboro;
            this.button26.Location = new System.Drawing.Point(488, 327);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(100, 30);
            this.button26.TabIndex = 140;
            this.button26.TabStop = false;
            this.button26.Text = "SF4刪單";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Black;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button27.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button27.ForeColor = System.Drawing.Color.Lime;
            this.button27.Location = new System.Drawing.Point(28, 327);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(100, 30);
            this.button27.TabIndex = 139;
            this.button27.TabStop = false;
            this.button27.Text = "F16 賣出";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Black;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button28.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button28.ForeColor = System.Drawing.Color.Gainsboro;
            this.button28.Location = new System.Drawing.Point(594, 291);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(120, 30);
            this.button28.TabIndex = 138;
            this.button28.TabStop = false;
            this.button28.Text = "F5清除畫面";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Black;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button29.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button29.ForeColor = System.Drawing.Color.Red;
            this.button29.Location = new System.Drawing.Point(28, 291);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(100, 30);
            this.button29.TabIndex = 137;
            this.button29.TabStop = false;
            this.button29.Text = "F1  買進";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // OD_LabTDate
            // 
            this.OD_LabTDate.AutoSize = true;
            this.OD_LabTDate.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabTDate.Location = new System.Drawing.Point(921, 9);
            this.OD_LabTDate.Name = "OD_LabTDate";
            this.OD_LabTDate.Size = new System.Drawing.Size(86, 19);
            this.OD_LabTDate.TabIndex = 135;
            this.OD_LabTDate.Text = "1090107";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label90.ForeColor = System.Drawing.Color.Gold;
            this.label90.Location = new System.Drawing.Point(800, 9);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(115, 19);
            this.label90.TabIndex = 134;
            this.label90.Text = "交易日期 :";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label91.ForeColor = System.Drawing.Color.Gold;
            this.label91.Location = new System.Drawing.Point(24, 9);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(311, 16);
            this.label91.TabIndex = 133;
            this.label91.Text = "<<< 零股交易 委託輸入[集中市場] >>>";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label58.ForeColor = System.Drawing.Color.Gainsboro;
            this.label58.Location = new System.Drawing.Point(24, 250);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(132, 21);
            this.label58.TabIndex = 101;
            this.label58.Text = "未搓合股數 :";
            // 
            // OD_TxbECode
            // 
            this.OD_TxbECode.BackColor = System.Drawing.Color.Black;
            this.OD_TxbECode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbECode.CausesValidation = false;
            this.OD_TxbECode.Enabled = false;
            this.OD_TxbECode.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbECode.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbECode.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbECode.Location = new System.Drawing.Point(357, 152);
            this.OD_TxbECode.Name = "OD_TxbECode";
            this.OD_TxbECode.Size = new System.Drawing.Size(59, 26);
            this.OD_TxbECode.TabIndex = 46;
            this.OD_TxbECode.TabStop = false;
            this.OD_TxbECode.Text = "2";
            this.OD_TxbECode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label41.ForeColor = System.Drawing.Color.Gainsboro;
            this.label41.Location = new System.Drawing.Point(353, 123);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(76, 21);
            this.label41.TabIndex = 97;
            this.label41.Text = "交易別";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label42.ForeColor = System.Drawing.Color.Gainsboro;
            this.label42.Location = new System.Drawing.Point(24, 123);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(98, 21);
            this.label42.TabIndex = 96;
            this.label42.Text = "股票代號";
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label43.ForeColor = System.Drawing.Color.Gainsboro;
            this.label43.Location = new System.Drawing.Point(1, 31);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(2072, 16);
            this.label43.TabIndex = 95;
            this.label43.Text = resources.GetString("label43.Text");
            this.label43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label44.ForeColor = System.Drawing.Color.Gainsboro;
            this.label44.Location = new System.Drawing.Point(415, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(132, 21);
            this.label44.TabIndex = 94;
            this.label44.Text = "證券商代號: ";
            // 
            // OD_LabBHNO
            // 
            this.OD_LabBHNO.AutoSize = true;
            this.OD_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabBHNO.Location = new System.Drawing.Point(553, 9);
            this.OD_LabBHNO.Name = "OD_LabBHNO";
            this.OD_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.OD_LabBHNO.TabIndex = 87;
            this.OD_LabBHNO.Text = " 8455";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label46.ForeColor = System.Drawing.Color.Gainsboro;
            this.label46.Location = new System.Drawing.Point(118, 55);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(110, 21);
            this.label46.TabIndex = 91;
            this.label46.Text = "委託序號 :";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label47.ForeColor = System.Drawing.Color.Gainsboro;
            this.label47.Location = new System.Drawing.Point(456, 123);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(104, 21);
            this.label47.TabIndex = 93;
            this.label47.Text = "委託 股數";
            // 
            // OD_TxbSale
            // 
            this.OD_TxbSale.BackColor = System.Drawing.Color.Black;
            this.OD_TxbSale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbSale.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbSale.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbSale.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbSale.Location = new System.Drawing.Point(441, 250);
            this.OD_TxbSale.Name = "OD_TxbSale";
            this.OD_TxbSale.Size = new System.Drawing.Size(69, 26);
            this.OD_TxbSale.TabIndex = 11;
            this.OD_TxbSale.TabStop = false;
            this.OD_TxbSale.TextChanged += new System.EventHandler(this.TxbSale_TextChanged);
            this.OD_TxbSale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbSale.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label48.ForeColor = System.Drawing.Color.Gainsboro;
            this.label48.Location = new System.Drawing.Point(353, 250);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(82, 21);
            this.label48.TabIndex = 92;
            this.label48.Text = "營業員:";
            // 
            // OD_TxbDSEQ
            // 
            this.OD_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.OD_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbDSEQ.Location = new System.Drawing.Point(269, 55);
            this.OD_TxbDSEQ.Name = "OD_TxbDSEQ";
            this.OD_TxbDSEQ.Size = new System.Drawing.Size(55, 26);
            this.OD_TxbDSEQ.TabIndex = 16;
            this.OD_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.OD_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.OD_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label49.ForeColor = System.Drawing.Color.Gainsboro;
            this.label49.Location = new System.Drawing.Point(602, 123);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(104, 21);
            this.label49.TabIndex = 90;
            this.label49.Text = "委託 價格";
            // 
            // OD_LabFinanceState
            // 
            this.OD_LabFinanceState.AutoSize = true;
            this.OD_LabFinanceState.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabFinanceState.ForeColor = System.Drawing.Color.Red;
            this.OD_LabFinanceState.Location = new System.Drawing.Point(351, 181);
            this.OD_LabFinanceState.Name = "OD_LabFinanceState";
            this.OD_LabFinanceState.Size = new System.Drawing.Size(129, 19);
            this.OD_LabFinanceState.TabIndex = 89;
            this.OD_LabFinanceState.Text = "資券配額狀況";
            this.OD_LabFinanceState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OD_LabStockState
            // 
            this.OD_LabStockState.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabStockState.ForeColor = System.Drawing.Color.Red;
            this.OD_LabStockState.Location = new System.Drawing.Point(117, 124);
            this.OD_LabStockState.Name = "OD_LabStockState";
            this.OD_LabStockState.Size = new System.Drawing.Size(239, 18);
            this.OD_LabStockState.TabIndex = 88;
            this.OD_LabStockState.Text = "不可信用交易_可現沖";
            this.OD_LabStockState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label52.ForeColor = System.Drawing.Color.Gainsboro;
            this.label52.Location = new System.Drawing.Point(353, 55);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(110, 21);
            this.label52.TabIndex = 85;
            this.label52.Text = "客戶帳號 :";
            // 
            // OD_LabCSEQName
            // 
            this.OD_LabCSEQName.AutoSize = true;
            this.OD_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabCSEQName.Location = new System.Drawing.Point(587, 56);
            this.OD_LabCSEQName.Name = "OD_LabCSEQName";
            this.OD_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.OD_LabCSEQName.TabIndex = 84;
            this.OD_LabCSEQName.Text = "客戶名稱";
            // 
            // OD_LabMType
            // 
            this.OD_LabMType.AutoSize = true;
            this.OD_LabMType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabMType.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabMType.Location = new System.Drawing.Point(274, 152);
            this.OD_LabMType.Name = "OD_LabMType";
            this.OD_LabMType.Size = new System.Drawing.Size(23, 21);
            this.OD_LabMType.TabIndex = 83;
            this.OD_LabMType.Text = "T";
            // 
            // OD_TxbPrice
            // 
            this.OD_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.OD_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbPrice.Location = new System.Drawing.Point(606, 152);
            this.OD_TxbPrice.Name = "OD_TxbPrice";
            this.OD_TxbPrice.Size = new System.Drawing.Size(85, 26);
            this.OD_TxbPrice.TabIndex = 12;
            this.OD_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.OD_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.OD_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // OD_LabStockName
            // 
            this.OD_LabStockName.AutoSize = true;
            this.OD_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.OD_LabStockName.Location = new System.Drawing.Point(130, 152);
            this.OD_LabStockName.Name = "OD_LabStockName";
            this.OD_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.OD_LabStockName.TabIndex = 81;
            this.OD_LabStockName.Text = "股票名稱";
            // 
            // OD_TxbStockNo
            // 
            this.OD_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.OD_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OD_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.OD_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.OD_TxbStockNo.Location = new System.Drawing.Point(28, 152);
            this.OD_TxbStockNo.Name = "OD_TxbStockNo";
            this.OD_TxbStockNo.Size = new System.Drawing.Size(85, 26);
            this.OD_TxbStockNo.TabIndex = 14;
            this.OD_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.OD_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.OD_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.OD_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // OD_CkbFixedCSEQ
            // 
            this.OD_CkbFixedCSEQ.AutoSize = true;
            this.OD_CkbFixedCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.OD_CkbFixedCSEQ.ForeColor = System.Drawing.Color.Gainsboro;
            this.OD_CkbFixedCSEQ.Location = new System.Drawing.Point(873, 52);
            this.OD_CkbFixedCSEQ.Name = "OD_CkbFixedCSEQ";
            this.OD_CkbFixedCSEQ.Size = new System.Drawing.Size(168, 23);
            this.OD_CkbFixedCSEQ.TabIndex = 77;
            this.OD_CkbFixedCSEQ.TabStop = false;
            this.OD_CkbFixedCSEQ.Text = "固定委託人帳號";
            this.OD_CkbFixedCSEQ.UseVisualStyleBackColor = true;
            this.OD_CkbFixedCSEQ.CheckedChanged += new System.EventHandler(this.CkbFixedCSEQ_CheckedChanged);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label54.ForeColor = System.Drawing.Color.Gold;
            this.label54.Location = new System.Drawing.Point(3, 3);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(332, 27);
            this.label54.TabIndex = 4;
            this.label54.Text = "<<非零股交易委託時間 >>";
            // 
            // FixedPrice
            // 
            this.FixedPrice.BackColor = System.Drawing.Color.Black;
            this.FixedPrice.Controls.Add(this.panel_FixedPrice);
            this.FixedPrice.Controls.Add(this.label55);
            this.FixedPrice.ForeColor = System.Drawing.Color.Lime;
            this.FixedPrice.Location = new System.Drawing.Point(4, 26);
            this.FixedPrice.Name = "FixedPrice";
            this.FixedPrice.Size = new System.Drawing.Size(1053, 364);
            this.FixedPrice.TabIndex = 2;
            this.FixedPrice.Text = "定價交易";
            // 
            // panel_FixedPrice
            // 
            this.panel_FixedPrice.Controls.Add(this.FP_LabCCodeText);
            this.panel_FixedPrice.Controls.Add(this.FP_LanWarText);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbStockQty);
            this.panel_FixedPrice.Controls.Add(this.FP_LabCancelQty);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnForceChangeQty);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnForceReturn);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnForceOrder);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnForceClear);
            this.panel_FixedPrice.Controls.Add(this.FP_LabInfo);
            this.panel_FixedPrice.Controls.Add(this.FP_LabOrdErrMsg);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbTERM);
            this.panel_FixedPrice.Controls.Add(this.label61);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnChangeTargetNo);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbCSEQ);
            this.panel_FixedPrice.Controls.Add(this.label51);
            this.panel_FixedPrice.Controls.Add(this.label50);
            this.panel_FixedPrice.Controls.Add(this.label45);
            this.panel_FixedPrice.Controls.Add(this.FP_LabQueryDealQty);
            this.panel_FixedPrice.Controls.Add(this.FP_LabQueryLaveQty);
            this.panel_FixedPrice.Controls.Add(this.FP_LabTDate);
            this.panel_FixedPrice.Controls.Add(this.label87);
            this.panel_FixedPrice.Controls.Add(this.label88);
            this.panel_FixedPrice.Controls.Add(this.label60);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbECode);
            this.panel_FixedPrice.Controls.Add(this.button1);
            this.panel_FixedPrice.Controls.Add(this.label63);
            this.panel_FixedPrice.Controls.Add(this.label64);
            this.panel_FixedPrice.Controls.Add(this.label65);
            this.panel_FixedPrice.Controls.Add(this.label66);
            this.panel_FixedPrice.Controls.Add(this.label68);
            this.panel_FixedPrice.Controls.Add(this.FP_LabBHNO);
            this.panel_FixedPrice.Controls.Add(this.label70);
            this.panel_FixedPrice.Controls.Add(this.label71);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbSale);
            this.panel_FixedPrice.Controls.Add(this.label72);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbDSEQ);
            this.panel_FixedPrice.Controls.Add(this.button15);
            this.panel_FixedPrice.Controls.Add(this.FP_BtnOType);
            this.panel_FixedPrice.Controls.Add(this.button17);
            this.panel_FixedPrice.Controls.Add(this.button18);
            this.panel_FixedPrice.Controls.Add(this.label73);
            this.panel_FixedPrice.Controls.Add(this.FP_LabFinanceState);
            this.panel_FixedPrice.Controls.Add(this.FP_LabStockState);
            this.panel_FixedPrice.Controls.Add(this.button19);
            this.panel_FixedPrice.Controls.Add(this.button20);
            this.panel_FixedPrice.Controls.Add(this.button21);
            this.panel_FixedPrice.Controls.Add(this.label76);
            this.panel_FixedPrice.Controls.Add(this.FP_LabCSEQName);
            this.panel_FixedPrice.Controls.Add(this.FP_LabMType);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbPrice);
            this.panel_FixedPrice.Controls.Add(this.FP_LabStockName);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbStockNo);
            this.panel_FixedPrice.Controls.Add(this.FP_LabOType);
            this.panel_FixedPrice.Controls.Add(this.FP_TxbOType);
            this.panel_FixedPrice.Controls.Add(this.label82);
            this.panel_FixedPrice.Controls.Add(this.FP_CkbFixedCSEQ);
            this.panel_FixedPrice.Controls.Add(this.button22);
            this.panel_FixedPrice.Controls.Add(this.button23);
            this.panel_FixedPrice.Controls.Add(this.button24);
            this.panel_FixedPrice.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_FixedPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_FixedPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel_FixedPrice.Location = new System.Drawing.Point(0, 0);
            this.panel_FixedPrice.Name = "panel_FixedPrice";
            this.panel_FixedPrice.Size = new System.Drawing.Size(1053, 364);
            this.panel_FixedPrice.TabIndex = 0;
            this.panel_FixedPrice.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_FixedPrice_MouseClick);
            // 
            // FP_LabCCodeText
            // 
            this.FP_LabCCodeText.AutoSize = true;
            this.FP_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.FP_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.FP_LabCCodeText.Location = new System.Drawing.Point(356, 229);
            this.FP_LabCCodeText.Name = "FP_LabCCodeText";
            this.FP_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.FP_LabCCodeText.TabIndex = 1003;
            this.FP_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // FP_LanWarText
            // 
            this.FP_LanWarText.AutoSize = true;
            this.FP_LanWarText.BackColor = System.Drawing.Color.Red;
            this.FP_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.FP_LanWarText.Location = new System.Drawing.Point(5, 182);
            this.FP_LanWarText.Name = "FP_LanWarText";
            this.FP_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.FP_LanWarText.TabIndex = 1000;
            this.FP_LanWarText.Text = "警示訊息";
            // 
            // FP_TxbStockQty
            // 
            this.FP_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.FP_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbStockQty.CausesValidation = false;
            this.FP_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbStockQty.Location = new System.Drawing.Point(469, 155);
            this.FP_TxbStockQty.Name = "FP_TxbStockQty";
            this.FP_TxbStockQty.Size = new System.Drawing.Size(60, 26);
            this.FP_TxbStockQty.TabIndex = 23;
            this.FP_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.FP_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // FP_LabCancelQty
            // 
            this.FP_LabCancelQty.AutoSize = true;
            this.FP_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabCancelQty.Location = new System.Drawing.Point(537, 155);
            this.FP_LabCancelQty.Name = "FP_LabCancelQty";
            this.FP_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.FP_LabCancelQty.TabIndex = 162;
            this.FP_LabCancelQty.Text = "0";
            this.FP_LabCancelQty.Visible = false;
            // 
            // FP_BtnForceChangeQty
            // 
            this.FP_BtnForceChangeQty.BackColor = System.Drawing.Color.Red;
            this.FP_BtnForceChangeQty.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnForceChangeQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnForceChangeQty.ForeColor = System.Drawing.Color.Yellow;
            this.FP_BtnForceChangeQty.Location = new System.Drawing.Point(876, 201);
            this.FP_BtnForceChangeQty.Name = "FP_BtnForceChangeQty";
            this.FP_BtnForceChangeQty.Size = new System.Drawing.Size(89, 34);
            this.FP_BtnForceChangeQty.TabIndex = 161;
            this.FP_BtnForceChangeQty.Text = "F9 改量";
            this.FP_BtnForceChangeQty.UseVisualStyleBackColor = false;
            this.FP_BtnForceChangeQty.Visible = false;
            // 
            // FP_BtnForceReturn
            // 
            this.FP_BtnForceReturn.BackColor = System.Drawing.Color.Red;
            this.FP_BtnForceReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnForceReturn.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnForceReturn.ForeColor = System.Drawing.Color.Yellow;
            this.FP_BtnForceReturn.Location = new System.Drawing.Point(781, 201);
            this.FP_BtnForceReturn.Name = "FP_BtnForceReturn";
            this.FP_BtnForceReturn.Size = new System.Drawing.Size(95, 34);
            this.FP_BtnForceReturn.TabIndex = 160;
            this.FP_BtnForceReturn.Text = "F10 返回";
            this.FP_BtnForceReturn.UseVisualStyleBackColor = false;
            this.FP_BtnForceReturn.Visible = false;
            // 
            // FP_BtnForceOrder
            // 
            this.FP_BtnForceOrder.BackColor = System.Drawing.Color.Red;
            this.FP_BtnForceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnForceOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnForceOrder.ForeColor = System.Drawing.Color.Yellow;
            this.FP_BtnForceOrder.Location = new System.Drawing.Point(686, 201);
            this.FP_BtnForceOrder.Name = "FP_BtnForceOrder";
            this.FP_BtnForceOrder.Size = new System.Drawing.Size(95, 34);
            this.FP_BtnForceOrder.TabIndex = 159;
            this.FP_BtnForceOrder.Text = "SF8 強行";
            this.FP_BtnForceOrder.UseVisualStyleBackColor = false;
            this.FP_BtnForceOrder.Visible = false;
            // 
            // FP_BtnForceClear
            // 
            this.FP_BtnForceClear.BackColor = System.Drawing.Color.Red;
            this.FP_BtnForceClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnForceClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnForceClear.ForeColor = System.Drawing.Color.Yellow;
            this.FP_BtnForceClear.Location = new System.Drawing.Point(597, 201);
            this.FP_BtnForceClear.Name = "FP_BtnForceClear";
            this.FP_BtnForceClear.Size = new System.Drawing.Size(89, 34);
            this.FP_BtnForceClear.TabIndex = 158;
            this.FP_BtnForceClear.Text = "F5 清除";
            this.FP_BtnForceClear.UseVisualStyleBackColor = false;
            this.FP_BtnForceClear.Visible = false;
            // 
            // FP_LabInfo
            // 
            this.FP_LabInfo.AutoSize = true;
            this.FP_LabInfo.BackColor = System.Drawing.Color.Red;
            this.FP_LabInfo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabInfo.ForeColor = System.Drawing.Color.Yellow;
            this.FP_LabInfo.Location = new System.Drawing.Point(5, 214);
            this.FP_LabInfo.Name = "FP_LabInfo";
            this.FP_LabInfo.Size = new System.Drawing.Size(98, 21);
            this.FP_LabInfo.TabIndex = 155;
            this.FP_LabInfo.Text = "相關訊息";
            this.FP_LabInfo.Visible = false;
            // 
            // FP_LabOrdErrMsg
            // 
            this.FP_LabOrdErrMsg.AutoSize = true;
            this.FP_LabOrdErrMsg.BackColor = System.Drawing.Color.Red;
            this.FP_LabOrdErrMsg.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabOrdErrMsg.ForeColor = System.Drawing.Color.Yellow;
            this.FP_LabOrdErrMsg.Location = new System.Drawing.Point(709, 126);
            this.FP_LabOrdErrMsg.Name = "FP_LabOrdErrMsg";
            this.FP_LabOrdErrMsg.Size = new System.Drawing.Size(274, 21);
            this.FP_LabOrdErrMsg.TabIndex = 154;
            this.FP_LabOrdErrMsg.Text = "下單連線異常，請重新下單";
            this.FP_LabOrdErrMsg.Visible = false;
            // 
            // FP_TxbTERM
            // 
            this.FP_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.FP_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbTERM.Location = new System.Drawing.Point(234, 58);
            this.FP_TxbTERM.Name = "FP_TxbTERM";
            this.FP_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.FP_TxbTERM.TabIndex = 28;
            this.FP_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.FP_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label61.Location = new System.Drawing.Point(253, 56);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(18, 21);
            this.label61.TabIndex = 153;
            this.label61.Text = "-";
            // 
            // FP_BtnChangeTargetNo
            // 
            this.FP_BtnChangeTargetNo.BackColor = System.Drawing.Color.Black;
            this.FP_BtnChangeTargetNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnChangeTargetNo.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnChangeTargetNo.ForeColor = System.Drawing.Color.Gainsboro;
            this.FP_BtnChangeTargetNo.Location = new System.Drawing.Point(829, 330);
            this.FP_BtnChangeTargetNo.Name = "FP_BtnChangeTargetNo";
            this.FP_BtnChangeTargetNo.Size = new System.Drawing.Size(140, 30);
            this.FP_BtnChangeTargetNo.TabIndex = 151;
            this.FP_BtnChangeTargetNo.TabStop = false;
            this.FP_BtnChangeTargetNo.Text = "SF9更改櫃號";
            this.FP_BtnChangeTargetNo.UseVisualStyleBackColor = false;
            // 
            // FP_TxbCSEQ
            // 
            this.FP_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.FP_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbCSEQ.Location = new System.Drawing.Point(463, 58);
            this.FP_TxbCSEQ.Name = "FP_TxbCSEQ";
            this.FP_TxbCSEQ.Size = new System.Drawing.Size(120, 26);
            this.FP_TxbCSEQ.TabIndex = 26;
            this.FP_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.FP_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label51.ForeColor = System.Drawing.Color.Gainsboro;
            this.label51.Location = new System.Drawing.Point(3, 273);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(2072, 16);
            this.label51.TabIndex = 137;
            this.label51.Text = resources.GetString("label51.Text");
            this.label51.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label50.ForeColor = System.Drawing.Color.Gainsboro;
            this.label50.Location = new System.Drawing.Point(4, 104);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(2072, 16);
            this.label50.TabIndex = 136;
            this.label50.Text = resources.GetString("label50.Text");
            this.label50.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label45.ForeColor = System.Drawing.Color.Gainsboro;
            this.label45.Location = new System.Drawing.Point(4, 34);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(2072, 16);
            this.label45.TabIndex = 135;
            this.label45.Text = resources.GetString("label45.Text");
            this.label45.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // FP_LabQueryDealQty
            // 
            this.FP_LabQueryDealQty.AutoSize = true;
            this.FP_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabQueryDealQty.Location = new System.Drawing.Point(827, 254);
            this.FP_LabQueryDealQty.Name = "FP_LabQueryDealQty";
            this.FP_LabQueryDealQty.Size = new System.Drawing.Size(16, 21);
            this.FP_LabQueryDealQty.TabIndex = 134;
            this.FP_LabQueryDealQty.Text = " ";
            // 
            // FP_LabQueryLaveQty
            // 
            this.FP_LabQueryLaveQty.AutoSize = true;
            this.FP_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabQueryLaveQty.Location = new System.Drawing.Point(165, 253);
            this.FP_LabQueryLaveQty.Name = "FP_LabQueryLaveQty";
            this.FP_LabQueryLaveQty.Size = new System.Drawing.Size(16, 21);
            this.FP_LabQueryLaveQty.TabIndex = 133;
            this.FP_LabQueryLaveQty.Text = " ";
            // 
            // FP_LabTDate
            // 
            this.FP_LabTDate.AutoSize = true;
            this.FP_LabTDate.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabTDate.Location = new System.Drawing.Point(924, 12);
            this.FP_LabTDate.Name = "FP_LabTDate";
            this.FP_LabTDate.Size = new System.Drawing.Size(86, 19);
            this.FP_LabTDate.TabIndex = 132;
            this.FP_LabTDate.Text = "1090107";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label87.ForeColor = System.Drawing.Color.Gold;
            this.label87.Location = new System.Drawing.Point(803, 12);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(115, 19);
            this.label87.TabIndex = 131;
            this.label87.Text = "交易日期 :";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label88.ForeColor = System.Drawing.Color.Gold;
            this.label88.Location = new System.Drawing.Point(27, 12);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(311, 16);
            this.label88.TabIndex = 130;
            this.label88.Text = "<<< 定價交易 委託輸入[集中市場] >>>";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label60.ForeColor = System.Drawing.Color.Lime;
            this.label60.Location = new System.Drawing.Point(142, 254);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(0, 16);
            this.label60.TabIndex = 121;
            // 
            // FP_TxbECode
            // 
            this.FP_TxbECode.BackColor = System.Drawing.Color.Black;
            this.FP_TxbECode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbECode.CausesValidation = false;
            this.FP_TxbECode.Enabled = false;
            this.FP_TxbECode.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbECode.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbECode.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbECode.Location = new System.Drawing.Point(360, 155);
            this.FP_TxbECode.Name = "FP_TxbECode";
            this.FP_TxbECode.Size = new System.Drawing.Size(59, 26);
            this.FP_TxbECode.TabIndex = 999;
            this.FP_TxbECode.TabStop = false;
            this.FP_TxbECode.Text = "3";
            this.FP_TxbECode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Location = new System.Drawing.Point(491, 294);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 120;
            this.button1.TabStop = false;
            this.button1.Text = "F12查詢";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label63.ForeColor = System.Drawing.Color.Gainsboro;
            this.label63.Location = new System.Drawing.Point(689, 253);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(132, 21);
            this.label63.TabIndex = 117;
            this.label63.Text = "成交已回報 :";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label64.ForeColor = System.Drawing.Color.Gainsboro;
            this.label64.Location = new System.Drawing.Point(27, 253);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(132, 21);
            this.label64.TabIndex = 116;
            this.label64.Text = "未搓合張數 :";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label65.ForeColor = System.Drawing.Color.Gainsboro;
            this.label65.Location = new System.Drawing.Point(356, 126);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(76, 21);
            this.label65.TabIndex = 115;
            this.label65.Text = "交易別";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label66.ForeColor = System.Drawing.Color.Gainsboro;
            this.label66.Location = new System.Drawing.Point(27, 126);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(98, 21);
            this.label66.TabIndex = 114;
            this.label66.Text = "股票代號";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label68.ForeColor = System.Drawing.Color.Gainsboro;
            this.label68.Location = new System.Drawing.Point(418, 12);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(132, 21);
            this.label68.TabIndex = 112;
            this.label68.Text = "證券商代號: ";
            // 
            // FP_LabBHNO
            // 
            this.FP_LabBHNO.AutoSize = true;
            this.FP_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabBHNO.Location = new System.Drawing.Point(556, 12);
            this.FP_LabBHNO.Name = "FP_LabBHNO";
            this.FP_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.FP_LabBHNO.TabIndex = 99;
            this.FP_LabBHNO.Text = " 8455";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label70.ForeColor = System.Drawing.Color.Gainsboro;
            this.label70.Location = new System.Drawing.Point(121, 58);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(110, 21);
            this.label70.TabIndex = 108;
            this.label70.Text = "委託序號 :";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label71.ForeColor = System.Drawing.Color.Gainsboro;
            this.label71.Location = new System.Drawing.Point(459, 126);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(104, 21);
            this.label71.TabIndex = 111;
            this.label71.Text = "委託 張數";
            // 
            // FP_TxbSale
            // 
            this.FP_TxbSale.BackColor = System.Drawing.Color.Black;
            this.FP_TxbSale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbSale.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbSale.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbSale.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbSale.Location = new System.Drawing.Point(444, 253);
            this.FP_TxbSale.Name = "FP_TxbSale";
            this.FP_TxbSale.Size = new System.Drawing.Size(69, 26);
            this.FP_TxbSale.TabIndex = 21;
            this.FP_TxbSale.TabStop = false;
            this.FP_TxbSale.TextChanged += new System.EventHandler(this.TxbSale_TextChanged);
            this.FP_TxbSale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbSale.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label72.ForeColor = System.Drawing.Color.Gainsboro;
            this.label72.Location = new System.Drawing.Point(356, 253);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(82, 21);
            this.label72.TabIndex = 110;
            this.label72.Text = "營業員:";
            // 
            // FP_TxbDSEQ
            // 
            this.FP_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.FP_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbDSEQ.Location = new System.Drawing.Point(272, 58);
            this.FP_TxbDSEQ.Name = "FP_TxbDSEQ";
            this.FP_TxbDSEQ.Size = new System.Drawing.Size(55, 26);
            this.FP_TxbDSEQ.TabIndex = 27;
            this.FP_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.FP_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.FP_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Black;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button15.ForeColor = System.Drawing.Color.Gainsboro;
            this.button15.Location = new System.Drawing.Point(723, 294);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(100, 30);
            this.button15.TabIndex = 107;
            this.button15.TabStop = false;
            this.button15.Text = "F9改價";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // FP_BtnOType
            // 
            this.FP_BtnOType.BackColor = System.Drawing.Color.Black;
            this.FP_BtnOType.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FP_BtnOType.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_BtnOType.ForeColor = System.Drawing.Color.Gainsboro;
            this.FP_BtnOType.Location = new System.Drawing.Point(829, 294);
            this.FP_BtnOType.Name = "FP_BtnOType";
            this.FP_BtnOType.Size = new System.Drawing.Size(140, 30);
            this.FP_BtnOType.TabIndex = 106;
            this.FP_BtnOType.TabStop = false;
            this.FP_BtnOType.Text = "F10委託類別";
            this.FP_BtnOType.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Black;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button17.ForeColor = System.Drawing.Color.Gainsboro;
            this.button17.Location = new System.Drawing.Point(597, 330);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(120, 30);
            this.button17.TabIndex = 105;
            this.button17.TabStop = false;
            this.button17.Text = "F8部分取消";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Black;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button18.ForeColor = System.Drawing.Color.Gainsboro;
            this.button18.Location = new System.Drawing.Point(491, 330);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(100, 30);
            this.button18.TabIndex = 104;
            this.button18.TabStop = false;
            this.button18.Text = "SF4刪單";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label73.ForeColor = System.Drawing.Color.Gainsboro;
            this.label73.Location = new System.Drawing.Point(605, 126);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(104, 21);
            this.label73.TabIndex = 103;
            this.label73.Text = "委託 價格";
            // 
            // FP_LabFinanceState
            // 
            this.FP_LabFinanceState.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabFinanceState.ForeColor = System.Drawing.Color.Red;
            this.FP_LabFinanceState.Location = new System.Drawing.Point(354, 184);
            this.FP_LabFinanceState.Name = "FP_LabFinanceState";
            this.FP_LabFinanceState.Size = new System.Drawing.Size(129, 19);
            this.FP_LabFinanceState.TabIndex = 102;
            this.FP_LabFinanceState.Text = "資券配額狀況";
            this.FP_LabFinanceState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FP_LabStockState
            // 
            this.FP_LabStockState.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabStockState.ForeColor = System.Drawing.Color.Red;
            this.FP_LabStockState.Location = new System.Drawing.Point(120, 126);
            this.FP_LabStockState.Name = "FP_LabStockState";
            this.FP_LabStockState.Size = new System.Drawing.Size(234, 20);
            this.FP_LabStockState.TabIndex = 101;
            this.FP_LabStockState.Text = "不可信用交易_可現沖";
            this.FP_LabStockState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Black;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button19.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button19.ForeColor = System.Drawing.Color.Gainsboro;
            this.button19.Location = new System.Drawing.Point(30, 331);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(110, 30);
            this.button19.TabIndex = 98;
            this.button19.TabStop = false;
            this.button19.Text = "F14跌停價";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Black;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button20.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button20.ForeColor = System.Drawing.Color.Gainsboro;
            this.button20.Location = new System.Drawing.Point(147, 294);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(110, 30);
            this.button20.TabIndex = 97;
            this.button20.TabStop = false;
            this.button20.Text = "F7平盤價";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Black;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button21.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button21.ForeColor = System.Drawing.Color.Gainsboro;
            this.button21.Location = new System.Drawing.Point(30, 294);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(110, 30);
            this.button21.TabIndex = 96;
            this.button21.TabStop = false;
            this.button21.Text = "F3 漲停價";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label76.ForeColor = System.Drawing.Color.Gainsboro;
            this.label76.Location = new System.Drawing.Point(356, 58);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(110, 21);
            this.label76.TabIndex = 94;
            this.label76.Text = "客戶帳號 :";
            // 
            // FP_LabCSEQName
            // 
            this.FP_LabCSEQName.AutoSize = true;
            this.FP_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabCSEQName.Location = new System.Drawing.Point(590, 59);
            this.FP_LabCSEQName.Name = "FP_LabCSEQName";
            this.FP_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.FP_LabCSEQName.TabIndex = 93;
            this.FP_LabCSEQName.Text = "客戶名稱";
            // 
            // FP_LabMType
            // 
            this.FP_LabMType.AutoSize = true;
            this.FP_LabMType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabMType.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabMType.Location = new System.Drawing.Point(277, 155);
            this.FP_LabMType.Name = "FP_LabMType";
            this.FP_LabMType.Size = new System.Drawing.Size(23, 21);
            this.FP_LabMType.TabIndex = 92;
            this.FP_LabMType.Text = "T";
            // 
            // FP_TxbPrice
            // 
            this.FP_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.FP_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbPrice.Location = new System.Drawing.Point(609, 155);
            this.FP_TxbPrice.Name = "FP_TxbPrice";
            this.FP_TxbPrice.ReadOnly = true;
            this.FP_TxbPrice.Size = new System.Drawing.Size(85, 26);
            this.FP_TxbPrice.TabIndex = 22;
            this.FP_TxbPrice.Text = "定盤價";
            this.FP_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.FP_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // FP_LabStockName
            // 
            this.FP_LabStockName.AutoSize = true;
            this.FP_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabStockName.Location = new System.Drawing.Point(133, 155);
            this.FP_LabStockName.Name = "FP_LabStockName";
            this.FP_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.FP_LabStockName.TabIndex = 89;
            this.FP_LabStockName.Text = "股票名稱";
            // 
            // FP_TxbStockNo
            // 
            this.FP_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.FP_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbStockNo.Location = new System.Drawing.Point(30, 155);
            this.FP_TxbStockNo.Name = "FP_TxbStockNo";
            this.FP_TxbStockNo.Size = new System.Drawing.Size(85, 26);
            this.FP_TxbStockNo.TabIndex = 24;
            this.FP_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.FP_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // FP_LabOType
            // 
            this.FP_LabOType.AutoSize = true;
            this.FP_LabOType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_LabOType.ForeColor = System.Drawing.Color.Lime;
            this.FP_LabOType.Location = new System.Drawing.Point(832, 58);
            this.FP_LabOType.Name = "FP_LabOType";
            this.FP_LabOType.Size = new System.Drawing.Size(32, 21);
            this.FP_LabOType.TabIndex = 88;
            this.FP_LabOType.Text = "現";
            // 
            // FP_TxbOType
            // 
            this.FP_TxbOType.BackColor = System.Drawing.Color.Black;
            this.FP_TxbOType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FP_TxbOType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_TxbOType.ForeColor = System.Drawing.Color.Lime;
            this.FP_TxbOType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.FP_TxbOType.Location = new System.Drawing.Point(800, 58);
            this.FP_TxbOType.Name = "FP_TxbOType";
            this.FP_TxbOType.Size = new System.Drawing.Size(30, 26);
            this.FP_TxbOType.TabIndex = 25;
            this.FP_TxbOType.Text = "0";
            this.FP_TxbOType.TextChanged += new System.EventHandler(this.TxbOType_TextChanged);
            this.FP_TxbOType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.FP_TxbOType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.FP_TxbOType.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label82.ForeColor = System.Drawing.Color.Gainsboro;
            this.label82.Location = new System.Drawing.Point(689, 58);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(110, 21);
            this.label82.TabIndex = 86;
            this.label82.Text = "委託類別 :";
            // 
            // FP_CkbFixedCSEQ
            // 
            this.FP_CkbFixedCSEQ.AutoSize = true;
            this.FP_CkbFixedCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FP_CkbFixedCSEQ.ForeColor = System.Drawing.Color.Gainsboro;
            this.FP_CkbFixedCSEQ.Location = new System.Drawing.Point(876, 55);
            this.FP_CkbFixedCSEQ.Name = "FP_CkbFixedCSEQ";
            this.FP_CkbFixedCSEQ.Size = new System.Drawing.Size(168, 23);
            this.FP_CkbFixedCSEQ.TabIndex = 82;
            this.FP_CkbFixedCSEQ.TabStop = false;
            this.FP_CkbFixedCSEQ.Text = "固定委託人帳號";
            this.FP_CkbFixedCSEQ.UseVisualStyleBackColor = true;
            this.FP_CkbFixedCSEQ.CheckedChanged += new System.EventHandler(this.CkbFixedCSEQ_CheckedChanged);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Black;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button22.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button22.ForeColor = System.Drawing.Color.Lime;
            this.button22.Location = new System.Drawing.Point(263, 330);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(100, 30);
            this.button22.TabIndex = 80;
            this.button22.TabStop = false;
            this.button22.Text = "F16 賣出";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Black;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button23.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button23.ForeColor = System.Drawing.Color.Gainsboro;
            this.button23.Location = new System.Drawing.Point(597, 294);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(120, 30);
            this.button23.TabIndex = 79;
            this.button23.TabStop = false;
            this.button23.Text = "F5清除畫面";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Black;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button24.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button24.ForeColor = System.Drawing.Color.Red;
            this.button24.Location = new System.Drawing.Point(263, 294);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(100, 30);
            this.button24.TabIndex = 76;
            this.button24.TabStop = false;
            this.button24.Text = "F1  買進";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label55.ForeColor = System.Drawing.Color.Gold;
            this.label55.Location = new System.Drawing.Point(0, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(332, 27);
            this.label55.TabIndex = 4;
            this.label55.Text = "<<非定價交易委託時間 >>";
            // 
            // StockBorrow
            // 
            this.StockBorrow.BackColor = System.Drawing.Color.Black;
            this.StockBorrow.Controls.Add(this.panel_StockBorrow);
            this.StockBorrow.Controls.Add(this.label62);
            this.StockBorrow.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StockBorrow.ForeColor = System.Drawing.Color.Gainsboro;
            this.StockBorrow.Location = new System.Drawing.Point(4, 26);
            this.StockBorrow.Name = "StockBorrow";
            this.StockBorrow.Size = new System.Drawing.Size(1053, 364);
            this.StockBorrow.TabIndex = 4;
            this.StockBorrow.Text = "股票標借";
            // 
            // panel_StockBorrow
            // 
            this.panel_StockBorrow.Controls.Add(this.SB_LabCSEQName);
            this.panel_StockBorrow.Controls.Add(this.SB_LabStockName);
            this.panel_StockBorrow.Controls.Add(this.SB_LabCCodeText);
            this.panel_StockBorrow.Controls.Add(this.SB_LabCancelQty);
            this.panel_StockBorrow.Controls.Add(this.label69);
            this.panel_StockBorrow.Controls.Add(this.SB_LabOrdErrMsg);
            this.panel_StockBorrow.Controls.Add(this.SB_LabBHNO);
            this.panel_StockBorrow.Controls.Add(this.label74);
            this.panel_StockBorrow.Controls.Add(this.label67);
            this.panel_StockBorrow.Controls.Add(this.SB_LabTDate);
            this.panel_StockBorrow.Controls.Add(this.button37);
            this.panel_StockBorrow.Controls.Add(this.label85);
            this.panel_StockBorrow.Controls.Add(this.button36);
            this.panel_StockBorrow.Controls.Add(this.label86);
            this.panel_StockBorrow.Controls.Add(this.button35);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbTERM);
            this.panel_StockBorrow.Controls.Add(this.button34);
            this.panel_StockBorrow.Controls.Add(this.label89);
            this.panel_StockBorrow.Controls.Add(this.button33);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbDSEQ);
            this.panel_StockBorrow.Controls.Add(this.SB_LabQueryLaveQty);
            this.panel_StockBorrow.Controls.Add(this.label92);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbSale);
            this.panel_StockBorrow.Controls.Add(this.label93);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbBS);
            this.panel_StockBorrow.Controls.Add(this.label94);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbPrice);
            this.panel_StockBorrow.Controls.Add(this.label95);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbStockQty);
            this.panel_StockBorrow.Controls.Add(this.label96);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbStockNo);
            this.panel_StockBorrow.Controls.Add(this.label97);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbTDCC);
            this.panel_StockBorrow.Controls.Add(this.label98);
            this.panel_StockBorrow.Controls.Add(this.SB_TxbCSEQ);
            this.panel_StockBorrow.Controls.Add(this.label99);
            this.panel_StockBorrow.Controls.Add(this.label101);
            this.panel_StockBorrow.Controls.Add(this.label100);
            this.panel_StockBorrow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_StockBorrow.Location = new System.Drawing.Point(0, 0);
            this.panel_StockBorrow.Name = "panel_StockBorrow";
            this.panel_StockBorrow.Size = new System.Drawing.Size(1053, 364);
            this.panel_StockBorrow.TabIndex = 171;
            this.panel_StockBorrow.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_StockBorrow_MouseClick);
            // 
            // SB_LabCSEQName
            // 
            this.SB_LabCSEQName.AutoSize = true;
            this.SB_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.SB_LabCSEQName.Location = new System.Drawing.Point(142, 144);
            this.SB_LabCSEQName.Name = "SB_LabCSEQName";
            this.SB_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.SB_LabCSEQName.TabIndex = 1011;
            this.SB_LabCSEQName.Text = "客戶名稱";
            // 
            // SB_LabStockName
            // 
            this.SB_LabStockName.AutoSize = true;
            this.SB_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.SB_LabStockName.Location = new System.Drawing.Point(452, 144);
            this.SB_LabStockName.Name = "SB_LabStockName";
            this.SB_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.SB_LabStockName.TabIndex = 1010;
            this.SB_LabStockName.Text = "股票名稱";
            // 
            // SB_LabCCodeText
            // 
            this.SB_LabCCodeText.AutoSize = true;
            this.SB_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.SB_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.SB_LabCCodeText.Location = new System.Drawing.Point(27, 194);
            this.SB_LabCCodeText.Name = "SB_LabCCodeText";
            this.SB_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.SB_LabCCodeText.TabIndex = 1004;
            this.SB_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // SB_LabCancelQty
            // 
            this.SB_LabCancelQty.AutoSize = true;
            this.SB_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabCancelQty.Location = new System.Drawing.Point(715, 144);
            this.SB_LabCancelQty.Name = "SB_LabCancelQty";
            this.SB_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.SB_LabCancelQty.TabIndex = 171;
            this.SB_LabCancelQty.Text = "0";
            this.SB_LabCancelQty.Visible = false;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label69.ForeColor = System.Drawing.Color.Gold;
            this.label69.Location = new System.Drawing.Point(27, 12);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(327, 16);
            this.label69.TabIndex = 135;
            this.label69.Text = "<<< 股票標借 委託資料輸入[集中市場] >>>";
            // 
            // SB_LabOrdErrMsg
            // 
            this.SB_LabOrdErrMsg.AutoSize = true;
            this.SB_LabOrdErrMsg.BackColor = System.Drawing.Color.Red;
            this.SB_LabOrdErrMsg.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabOrdErrMsg.Location = new System.Drawing.Point(748, 189);
            this.SB_LabOrdErrMsg.Name = "SB_LabOrdErrMsg";
            this.SB_LabOrdErrMsg.Size = new System.Drawing.Size(274, 21);
            this.SB_LabOrdErrMsg.TabIndex = 170;
            this.SB_LabOrdErrMsg.Text = "下單連線異常，請重新下單";
            this.SB_LabOrdErrMsg.Visible = false;
            // 
            // SB_LabBHNO
            // 
            this.SB_LabBHNO.AutoSize = true;
            this.SB_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.SB_LabBHNO.Location = new System.Drawing.Point(562, 13);
            this.SB_LabBHNO.Name = "SB_LabBHNO";
            this.SB_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.SB_LabBHNO.TabIndex = 133;
            this.SB_LabBHNO.Text = " 8455";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label74.ForeColor = System.Drawing.Color.Gainsboro;
            this.label74.Location = new System.Drawing.Point(418, 13);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(138, 21);
            this.label74.TabIndex = 134;
            this.label74.Text = "證券商代號 : ";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label67.ForeColor = System.Drawing.Color.Gold;
            this.label67.Location = new System.Drawing.Point(803, 13);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(101, 19);
            this.label67.TabIndex = 136;
            this.label67.Text = "交易日期 :";
            // 
            // SB_LabTDate
            // 
            this.SB_LabTDate.AutoSize = true;
            this.SB_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.SB_LabTDate.Location = new System.Drawing.Point(924, 13);
            this.SB_LabTDate.Name = "SB_LabTDate";
            this.SB_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.SB_LabTDate.TabIndex = 137;
            this.SB_LabTDate.Text = "1090107";
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Black;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button37.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button37.ForeColor = System.Drawing.Color.Gainsboro;
            this.button37.Location = new System.Drawing.Point(422, 272);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(147, 30);
            this.button37.TabIndex = 165;
            this.button37.TabStop = false;
            this.button37.Text = "SF4  全部取消";
            this.button37.UseVisualStyleBackColor = false;
            // 
            // label85
            // 
            this.label85.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label85.ForeColor = System.Drawing.Color.Gainsboro;
            this.label85.Location = new System.Drawing.Point(8, 90);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(1040, 16);
            this.label85.TabIndex = 138;
            this.label85.Text = "................................................................................." +
    "................................................";
            this.label85.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Black;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button36.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button36.ForeColor = System.Drawing.Color.Gainsboro;
            this.button36.Location = new System.Drawing.Point(213, 308);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(125, 30);
            this.button36.TabIndex = 164;
            this.button36.TabStop = false;
            this.button36.Text = "F8 更改數量";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.Black;
            this.label86.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label86.ForeColor = System.Drawing.Color.Gainsboro;
            this.label86.Location = new System.Drawing.Point(418, 58);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(132, 21);
            this.label86.TabIndex = 139;
            this.label86.Text = "委託書編號 :";
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Black;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button35.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button35.ForeColor = System.Drawing.Color.Gainsboro;
            this.button35.Location = new System.Drawing.Point(213, 272);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(125, 30);
            this.button35.TabIndex = 163;
            this.button35.TabStop = false;
            this.button35.Text = "F5 清除畫面";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // SB_TxbTERM
            // 
            this.SB_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.SB_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbTERM.Location = new System.Drawing.Point(557, 56);
            this.SB_TxbTERM.Name = "SB_TxbTERM";
            this.SB_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.SB_TxbTERM.TabIndex = 38;
            this.SB_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.SB_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Black;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button34.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button34.ForeColor = System.Drawing.Color.Gainsboro;
            this.button34.Location = new System.Drawing.Point(30, 272);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(125, 30);
            this.button34.TabIndex = 162;
            this.button34.TabStop = false;
            this.button34.Text = "F1 出借輸入";
            this.button34.UseVisualStyleBackColor = false;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label89.ForeColor = System.Drawing.Color.Gainsboro;
            this.label89.Location = new System.Drawing.Point(580, 57);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(18, 21);
            this.label89.TabIndex = 141;
            this.label89.Text = "-";
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Black;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button33.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button33.ForeColor = System.Drawing.Color.Gainsboro;
            this.button33.Location = new System.Drawing.Point(30, 308);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(125, 30);
            this.button33.TabIndex = 161;
            this.button33.TabStop = false;
            this.button33.Text = "F12    查  詢";
            this.button33.UseVisualStyleBackColor = false;
            // 
            // SB_TxbDSEQ
            // 
            this.SB_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.SB_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SB_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbDSEQ.Location = new System.Drawing.Point(602, 57);
            this.SB_TxbDSEQ.Name = "SB_TxbDSEQ";
            this.SB_TxbDSEQ.Size = new System.Drawing.Size(60, 26);
            this.SB_TxbDSEQ.TabIndex = 37;
            this.SB_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SB_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.SB_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SB_LabQueryLaveQty
            // 
            this.SB_LabQueryLaveQty.AutoSize = true;
            this.SB_LabQueryLaveQty.Location = new System.Drawing.Point(165, 224);
            this.SB_LabQueryLaveQty.Name = "SB_LabQueryLaveQty";
            this.SB_LabQueryLaveQty.Size = new System.Drawing.Size(40, 21);
            this.SB_LabQueryLaveQty.TabIndex = 160;
            this.SB_LabQueryLaveQty.Text = "     ";
            // 
            // label92
            // 
            this.label92.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label92.ForeColor = System.Drawing.Color.Gainsboro;
            this.label92.Location = new System.Drawing.Point(8, 36);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(1040, 16);
            this.label92.TabIndex = 143;
            this.label92.Text = "................................................................................." +
    "................................................";
            this.label92.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SB_TxbSale
            // 
            this.SB_TxbSale.BackColor = System.Drawing.Color.Black;
            this.SB_TxbSale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbSale.Enabled = false;
            this.SB_TxbSale.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbSale.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbSale.Location = new System.Drawing.Point(512, 219);
            this.SB_TxbSale.Name = "SB_TxbSale";
            this.SB_TxbSale.Size = new System.Drawing.Size(55, 26);
            this.SB_TxbSale.TabIndex = 31;
            this.SB_TxbSale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbSale.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label93
            // 
            this.label93.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label93.ForeColor = System.Drawing.Color.Gainsboro;
            this.label93.Location = new System.Drawing.Point(9, 250);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(1040, 16);
            this.label93.TabIndex = 144;
            this.label93.Text = "................................................................................." +
    "................................................";
            this.label93.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SB_TxbBS
            // 
            this.SB_TxbBS.BackColor = System.Drawing.Color.Black;
            this.SB_TxbBS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbBS.Enabled = false;
            this.SB_TxbBS.ForeColor = System.Drawing.Color.Gainsboro;
            this.SB_TxbBS.Location = new System.Drawing.Point(918, 144);
            this.SB_TxbBS.Name = "SB_TxbBS";
            this.SB_TxbBS.Size = new System.Drawing.Size(52, 26);
            this.SB_TxbBS.TabIndex = 32;
            this.SB_TxbBS.Text = "S";
            this.SB_TxbBS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label94.ForeColor = System.Drawing.Color.Gainsboro;
            this.label94.Location = new System.Drawing.Point(27, 224);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(132, 21);
            this.label94.TabIndex = 145;
            this.label94.Text = "未搓合張數 :";
            // 
            // SB_TxbPrice
            // 
            this.SB_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.SB_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbPrice.Location = new System.Drawing.Point(752, 144);
            this.SB_TxbPrice.Name = "SB_TxbPrice";
            this.SB_TxbPrice.Size = new System.Drawing.Size(85, 26);
            this.SB_TxbPrice.TabIndex = 33;
            this.SB_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.SB_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label95.ForeColor = System.Drawing.Color.Gainsboro;
            this.label95.Location = new System.Drawing.Point(418, 224);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(88, 21);
            this.label95.TabIndex = 146;
            this.label95.Text = "營業員 :";
            // 
            // SB_TxbStockQty
            // 
            this.SB_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.SB_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbStockQty.Location = new System.Drawing.Point(584, 144);
            this.SB_TxbStockQty.Name = "SB_TxbStockQty";
            this.SB_TxbStockQty.Size = new System.Drawing.Size(125, 26);
            this.SB_TxbStockQty.TabIndex = 34;
            this.SB_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SB_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.SB_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label96.Location = new System.Drawing.Point(27, 111);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(120, 21);
            this.label96.TabIndex = 147;
            this.label96.Text = "投資人帳號";
            // 
            // SB_TxbStockNo
            // 
            this.SB_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.SB_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbStockNo.Location = new System.Drawing.Point(381, 144);
            this.SB_TxbStockNo.Name = "SB_TxbStockNo";
            this.SB_TxbStockNo.Size = new System.Drawing.Size(70, 26);
            this.SB_TxbStockNo.TabIndex = 35;
            this.SB_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.SB_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label97.Location = new System.Drawing.Point(235, 111);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(98, 21);
            this.label97.TabIndex = 148;
            this.label97.Text = "集保股票";
            this.label97.Visible = false;
            // 
            // SB_TxbTDCC
            // 
            this.SB_TxbTDCC.BackColor = System.Drawing.Color.Black;
            this.SB_TxbTDCC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbTDCC.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbTDCC.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbTDCC.Location = new System.Drawing.Point(239, 144);
            this.SB_TxbTDCC.Name = "SB_TxbTDCC";
            this.SB_TxbTDCC.Size = new System.Drawing.Size(85, 26);
            this.SB_TxbTDCC.TabIndex = 36;
            this.SB_TxbTDCC.Visible = false;
            this.SB_TxbTDCC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbTDCC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbTDCC.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label98.Location = new System.Drawing.Point(377, 111);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(176, 21);
            this.label98.TabIndex = 149;
            this.label98.Text = "股票代號 及 名稱";
            // 
            // SB_TxbCSEQ
            // 
            this.SB_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.SB_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SB_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SB_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SB_TxbCSEQ.Location = new System.Drawing.Point(31, 144);
            this.SB_TxbCSEQ.Name = "SB_TxbCSEQ";
            this.SB_TxbCSEQ.Size = new System.Drawing.Size(105, 26);
            this.SB_TxbCSEQ.TabIndex = 36;
            this.SB_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.SB_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SB_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SB_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label99.Location = new System.Drawing.Point(580, 111);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(170, 21);
            this.label99.TabIndex = 150;
            this.label99.Text = "出借 數量 [仟股]";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label101.Location = new System.Drawing.Point(914, 111);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(61, 21);
            this.label101.TabIndex = 152;
            this.label101.Text = "F1 ok";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label100.Location = new System.Drawing.Point(748, 111);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(104, 21);
            this.label100.TabIndex = 151;
            this.label100.Text = "借券 費用";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label62.ForeColor = System.Drawing.Color.Gold;
            this.label62.Location = new System.Drawing.Point(0, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(332, 27);
            this.label62.TabIndex = 181;
            this.label62.Text = "<<非股票標借委託時間 >>";
            // 
            // StockPurchase
            // 
            this.StockPurchase.BackColor = System.Drawing.Color.Black;
            this.StockPurchase.Controls.Add(this.panel_StockPurchase);
            this.StockPurchase.Controls.Add(this.label59);
            this.StockPurchase.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StockPurchase.Location = new System.Drawing.Point(4, 26);
            this.StockPurchase.Name = "StockPurchase";
            this.StockPurchase.Size = new System.Drawing.Size(1053, 364);
            this.StockPurchase.TabIndex = 5;
            this.StockPurchase.Text = "股票標購";
            // 
            // panel_StockPurchase
            // 
            this.panel_StockPurchase.Controls.Add(this.SP_LabCCodeText);
            this.panel_StockPurchase.Controls.Add(this.label79);
            this.panel_StockPurchase.Controls.Add(this.tableLayoutPanel7);
            this.panel_StockPurchase.Controls.Add(this.SP_LabBHNO);
            this.panel_StockPurchase.Controls.Add(this.tableLayoutPanel4);
            this.panel_StockPurchase.Controls.Add(this.label80);
            this.panel_StockPurchase.Controls.Add(this.tableLayoutPanel3);
            this.panel_StockPurchase.Controls.Add(this.label78);
            this.panel_StockPurchase.Controls.Add(this.SP_LabTDate);
            this.panel_StockPurchase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_StockPurchase.Location = new System.Drawing.Point(0, 0);
            this.panel_StockPurchase.Name = "panel_StockPurchase";
            this.panel_StockPurchase.Size = new System.Drawing.Size(1053, 364);
            this.panel_StockPurchase.TabIndex = 145;
            this.panel_StockPurchase.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_StockPurchase_MouseClick);
            // 
            // SP_LabCCodeText
            // 
            this.SP_LabCCodeText.AutoSize = true;
            this.SP_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.SP_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.SP_LabCCodeText.Location = new System.Drawing.Point(26, 210);
            this.SP_LabCCodeText.Name = "SP_LabCCodeText";
            this.SP_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.SP_LabCCodeText.TabIndex = 1005;
            this.SP_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label79.ForeColor = System.Drawing.Color.Gold;
            this.label79.Location = new System.Drawing.Point(27, 12);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(327, 16);
            this.label79.TabIndex = 140;
            this.label79.Text = "<<< 股票標購 委託資料輸入[集中市場] >>>";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(19, 244);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1012, 106);
            this.tableLayoutPanel7.TabIndex = 144;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.16336F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.83664F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 252F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 437F));
            this.tableLayoutPanel8.Controls.Add(this.SP_LabQueryDealQty, 3, 0);
            this.tableLayoutPanel8.Controls.Add(this.label109, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.button40, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.button41, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.button42, 2, 1);
            this.tableLayoutPanel8.Controls.Add(this.button44, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.label110, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.SP_LabQueryLaveQty, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.button45, 1, 2);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 3;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.57143F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.67347F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.7347F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1004, 98);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // SP_LabQueryDealQty
            // 
            this.SP_LabQueryDealQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP_LabQueryDealQty.AutoSize = true;
            this.SP_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabQueryDealQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP_LabQueryDealQty.Location = new System.Drawing.Point(569, 3);
            this.SP_LabQueryDealQty.Name = "SP_LabQueryDealQty";
            this.SP_LabQueryDealQty.Size = new System.Drawing.Size(0, 21);
            this.SP_LabQueryDealQty.TabIndex = 11;
            // 
            // label109
            // 
            this.label109.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label109.ForeColor = System.Drawing.Color.Gainsboro;
            this.label109.Location = new System.Drawing.Point(3, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(126, 28);
            this.label109.TabIndex = 0;
            this.label109.Text = "未撮合張數 :";
            // 
            // button40
            // 
            this.button40.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button40.BackColor = System.Drawing.Color.Black;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button40.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button40.ForeColor = System.Drawing.Color.Gainsboro;
            this.button40.Location = new System.Drawing.Point(3, 31);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(126, 27);
            this.button40.TabIndex = 2;
            this.button40.TabStop = false;
            this.button40.Text = "F1 賣出輸入";
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button41.BackColor = System.Drawing.Color.Black;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button41.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button41.ForeColor = System.Drawing.Color.Gainsboro;
            this.button41.Location = new System.Drawing.Point(3, 64);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(126, 30);
            this.button41.TabIndex = 3;
            this.button41.TabStop = false;
            this.button41.Text = "F5 清除畫面";
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button42.BackColor = System.Drawing.Color.Black;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button42.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button42.ForeColor = System.Drawing.Color.Gainsboro;
            this.button42.Location = new System.Drawing.Point(366, 31);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(148, 27);
            this.button42.TabIndex = 4;
            this.button42.TabStop = false;
            this.button42.Text = "SF4  全部取消";
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button44.BackColor = System.Drawing.Color.Black;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button44.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button44.ForeColor = System.Drawing.Color.Gainsboro;
            this.button44.Location = new System.Drawing.Point(158, 31);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(130, 27);
            this.button44.TabIndex = 6;
            this.button44.TabStop = false;
            this.button44.Text = "F12 查 詢";
            this.button44.UseVisualStyleBackColor = false;
            // 
            // label110
            // 
            this.label110.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label110.ForeColor = System.Drawing.Color.Gainsboro;
            this.label110.Location = new System.Drawing.Point(431, 3);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(132, 21);
            this.label110.TabIndex = 1;
            this.label110.Text = "成交已回報 :";
            // 
            // SP_LabQueryLaveQty
            // 
            this.SP_LabQueryLaveQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP_LabQueryLaveQty.AutoSize = true;
            this.SP_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabQueryLaveQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP_LabQueryLaveQty.Location = new System.Drawing.Point(135, 3);
            this.SP_LabQueryLaveQty.Name = "SP_LabQueryLaveQty";
            this.SP_LabQueryLaveQty.Size = new System.Drawing.Size(34, 21);
            this.SP_LabQueryLaveQty.TabIndex = 10;
            this.SP_LabQueryLaveQty.Text = "    ";
            // 
            // button45
            // 
            this.button45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button45.BackColor = System.Drawing.Color.Black;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button45.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button45.ForeColor = System.Drawing.Color.Gainsboro;
            this.button45.Location = new System.Drawing.Point(158, 64);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(130, 30);
            this.button45.TabIndex = 7;
            this.button45.TabStop = false;
            this.button45.Text = "F8  更 改";
            this.button45.UseVisualStyleBackColor = false;
            // 
            // SP_LabBHNO
            // 
            this.SP_LabBHNO.AutoSize = true;
            this.SP_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.SP_LabBHNO.Location = new System.Drawing.Point(562, 13);
            this.SP_LabBHNO.Name = "SP_LabBHNO";
            this.SP_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.SP_LabBHNO.TabIndex = 138;
            this.SP_LabBHNO.Text = " 8455";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.56281F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.67359F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.63996F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Controls.Add(this.label108, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label107, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label106, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label105, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.SP_TxbPrice, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel6, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel9, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel16, 2, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(19, 92);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1012, 100);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label108
            // 
            this.label108.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label108.ForeColor = System.Drawing.Color.Gainsboro;
            this.label108.Location = new System.Drawing.Point(826, 14);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(116, 21);
            this.label108.TabIndex = 3;
            this.label108.Text = "標 購 價 格";
            // 
            // label107
            // 
            this.label107.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label107.ForeColor = System.Drawing.Color.Gainsboro;
            this.label107.Location = new System.Drawing.Point(538, 14);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(200, 21);
            this.label107.TabIndex = 2;
            this.label107.Text = "申 購 數 量  [ 仟股 ]";
            // 
            // label106
            // 
            this.label106.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label106.ForeColor = System.Drawing.Color.Gainsboro;
            this.label106.Location = new System.Drawing.Point(225, 14);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(286, 21);
            this.label106.TabIndex = 1;
            this.label106.Text = "股票代號及名稱             序號";
            // 
            // label105
            // 
            this.label105.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label105.ForeColor = System.Drawing.Color.Gainsboro;
            this.label105.Location = new System.Drawing.Point(37, 14);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(144, 21);
            this.label105.TabIndex = 0;
            this.label105.Text = "投 資 人 帳 號";
            // 
            // SP_TxbPrice
            // 
            this.SP_TxbPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.SP_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbPrice.Location = new System.Drawing.Point(834, 61);
            this.SP_TxbPrice.Name = "SP_TxbPrice";
            this.SP_TxbPrice.Size = new System.Drawing.Size(100, 26);
            this.SP_TxbPrice.TabIndex = 41;
            this.SP_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.SP_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.0863F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.9137F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 149F));
            this.tableLayoutPanel6.Controls.Add(this.SP_LabStockName, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.SP_TxbSerialNum, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.SP_TxbStockNo, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(222, 53);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(293, 43);
            this.tableLayoutPanel6.TabIndex = 7;
            // 
            // SP_LabStockName
            // 
            this.SP_LabStockName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_LabStockName.AutoSize = true;
            this.SP_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.SP_LabStockName.Location = new System.Drawing.Point(61, 0);
            this.SP_LabStockName.Name = "SP_LabStockName";
            this.SP_LabStockName.Size = new System.Drawing.Size(76, 42);
            this.SP_LabStockName.TabIndex = 1009;
            this.SP_LabStockName.Text = "股票名稱";
            // 
            // SP_TxbSerialNum
            // 
            this.SP_TxbSerialNum.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.SP_TxbSerialNum.BackColor = System.Drawing.Color.Black;
            this.SP_TxbSerialNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbSerialNum.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbSerialNum.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbSerialNum.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbSerialNum.Location = new System.Drawing.Point(224, 8);
            this.SP_TxbSerialNum.Name = "SP_TxbSerialNum";
            this.SP_TxbSerialNum.Size = new System.Drawing.Size(66, 26);
            this.SP_TxbSerialNum.TabIndex = 43;
            this.SP_TxbSerialNum.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbSerialNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbSerialNum.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SP_TxbStockNo
            // 
            this.SP_TxbStockNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.SP_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbStockNo.Location = new System.Drawing.Point(3, 8);
            this.SP_TxbStockNo.Name = "SP_TxbStockNo";
            this.SP_TxbStockNo.Size = new System.Drawing.Size(50, 26);
            this.SP_TxbStockNo.TabIndex = 44;
            this.SP_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.SP_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.SP_LabCSEQName, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.SP_TxbCSEQ, 0, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(4, 53);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(211, 43);
            this.tableLayoutPanel9.TabIndex = 43;
            // 
            // SP_LabCSEQName
            // 
            this.SP_LabCSEQName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_LabCSEQName.AutoSize = true;
            this.SP_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.SP_LabCSEQName.Location = new System.Drawing.Point(109, 11);
            this.SP_LabCSEQName.Name = "SP_LabCSEQName";
            this.SP_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.SP_LabCSEQName.TabIndex = 1010;
            this.SP_LabCSEQName.Text = "客戶名稱";
            // 
            // SP_TxbCSEQ
            // 
            this.SP_TxbCSEQ.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.SP_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbCSEQ.Location = new System.Drawing.Point(5, 8);
            this.SP_TxbCSEQ.Name = "SP_TxbCSEQ";
            this.SP_TxbCSEQ.Size = new System.Drawing.Size(94, 26);
            this.SP_TxbCSEQ.TabIndex = 45;
            this.SP_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.SP_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37F));
            this.tableLayoutPanel16.Controls.Add(this.SP_LabCancelQty, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.SP_TxbStockQty, 0, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(554, 53);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel16.TabIndex = 1006;
            // 
            // SP_LabCancelQty
            // 
            this.SP_LabCancelQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP_LabCancelQty.AutoSize = true;
            this.SP_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabCancelQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP_LabCancelQty.Location = new System.Drawing.Point(129, 11);
            this.SP_LabCancelQty.Name = "SP_LabCancelQty";
            this.SP_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.SP_LabCancelQty.TabIndex = 172;
            this.SP_LabCancelQty.Text = "0";
            this.SP_LabCancelQty.Visible = false;
            // 
            // SP_TxbStockQty
            // 
            this.SP_TxbStockQty.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.SP_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.SP_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbStockQty.Location = new System.Drawing.Point(23, 8);
            this.SP_TxbStockQty.Name = "SP_TxbStockQty";
            this.SP_TxbStockQty.Size = new System.Drawing.Size(100, 26);
            this.SP_TxbStockQty.TabIndex = 42;
            this.SP_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SP_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.SP_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label80.ForeColor = System.Drawing.Color.Gainsboro;
            this.label80.Location = new System.Drawing.Point(418, 13);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(138, 21);
            this.label80.TabIndex = 139;
            this.label80.Text = "證券商代號 : ";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(19, 51);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1012, 42);
            this.tableLayoutPanel3.TabIndex = 143;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 4;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.29084F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.378486F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.191235F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.43825F));
            this.tableLayoutPanel5.Controls.Add(this.label104, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.SP_TxbTERM, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.SP_TxbDSEQ, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label103, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1004, 34);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // label104
            // 
            this.label104.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label104.ForeColor = System.Drawing.Color.Gainsboro;
            this.label104.Location = new System.Drawing.Point(382, 6);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(138, 21);
            this.label104.TabIndex = 1;
            this.label104.Text = "委託書編號 : ";
            // 
            // SP_TxbTERM
            // 
            this.SP_TxbTERM.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.SP_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbTERM.Location = new System.Drawing.Point(526, 4);
            this.SP_TxbTERM.Name = "SP_TxbTERM";
            this.SP_TxbTERM.Size = new System.Drawing.Size(47, 26);
            this.SP_TxbTERM.TabIndex = 47;
            this.SP_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.SP_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SP_TxbDSEQ
            // 
            this.SP_TxbDSEQ.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.SP_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SP_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP_TxbDSEQ.Location = new System.Drawing.Point(600, 4);
            this.SP_TxbDSEQ.Name = "SP_TxbDSEQ";
            this.SP_TxbDSEQ.Size = new System.Drawing.Size(100, 26);
            this.SP_TxbDSEQ.TabIndex = 46;
            this.SP_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SP_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.SP_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label103
            // 
            this.label103.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label103.ForeColor = System.Drawing.Color.Gainsboro;
            this.label103.Location = new System.Drawing.Point(579, 6);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(15, 21);
            this.label103.TabIndex = 4;
            this.label103.Text = "-";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label78.ForeColor = System.Drawing.Color.Gold;
            this.label78.Location = new System.Drawing.Point(803, 13);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(101, 19);
            this.label78.TabIndex = 141;
            this.label78.Text = "交易日期 :";
            // 
            // SP_LabTDate
            // 
            this.SP_LabTDate.AutoSize = true;
            this.SP_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.SP_LabTDate.Location = new System.Drawing.Point(924, 13);
            this.SP_LabTDate.Name = "SP_LabTDate";
            this.SP_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.SP_LabTDate.TabIndex = 142;
            this.SP_LabTDate.Text = "1090107";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label59.ForeColor = System.Drawing.Color.Gold;
            this.label59.Location = new System.Drawing.Point(0, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(332, 27);
            this.label59.TabIndex = 180;
            this.label59.Text = "<<非股票標購委託時間 >>";
            // 
            // StockPurchase2
            // 
            this.StockPurchase2.BackColor = System.Drawing.Color.Black;
            this.StockPurchase2.Controls.Add(this.panel_StockPurchase2);
            this.StockPurchase2.Controls.Add(this.label159);
            this.StockPurchase2.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold);
            this.StockPurchase2.Location = new System.Drawing.Point(4, 26);
            this.StockPurchase2.Name = "StockPurchase2";
            this.StockPurchase2.Size = new System.Drawing.Size(1053, 364);
            this.StockPurchase2.TabIndex = 8;
            this.StockPurchase2.Text = "證金標購";
            // 
            // panel_StockPurchase2
            // 
            this.panel_StockPurchase2.BackColor = System.Drawing.Color.Black;
            this.panel_StockPurchase2.Controls.Add(this.SP2_LabCCodeText);
            this.panel_StockPurchase2.Controls.Add(this.label141);
            this.panel_StockPurchase2.Controls.Add(this.tableLayoutPanel18);
            this.panel_StockPurchase2.Controls.Add(this.SP2_LabBHNO);
            this.panel_StockPurchase2.Controls.Add(this.tableLayoutPanel20);
            this.panel_StockPurchase2.Controls.Add(this.label154);
            this.panel_StockPurchase2.Controls.Add(this.tableLayoutPanel24);
            this.panel_StockPurchase2.Controls.Add(this.label157);
            this.panel_StockPurchase2.Controls.Add(this.SP2_LabTDate);
            this.panel_StockPurchase2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_StockPurchase2.Location = new System.Drawing.Point(0, 0);
            this.panel_StockPurchase2.Name = "panel_StockPurchase2";
            this.panel_StockPurchase2.Size = new System.Drawing.Size(1053, 364);
            this.panel_StockPurchase2.TabIndex = 146;
            this.panel_StockPurchase2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_StockPurchase2_MouseClick);
            // 
            // SP2_LabCCodeText
            // 
            this.SP2_LabCCodeText.AutoSize = true;
            this.SP2_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.SP2_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.SP2_LabCCodeText.Location = new System.Drawing.Point(26, 210);
            this.SP2_LabCCodeText.Name = "SP2_LabCCodeText";
            this.SP2_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.SP2_LabCCodeText.TabIndex = 1005;
            this.SP2_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label141.ForeColor = System.Drawing.Color.Gold;
            this.label141.Location = new System.Drawing.Point(27, 12);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(327, 16);
            this.label141.TabIndex = 140;
            this.label141.Text = "<<< 證金標購 委託資料輸入[集中市場] >>>";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel19, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(19, 244);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(1012, 106);
            this.tableLayoutPanel18.TabIndex = 144;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 4;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.16336F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.83664F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 252F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 437F));
            this.tableLayoutPanel19.Controls.Add(this.SP2_LabQueryDealQty, 3, 0);
            this.tableLayoutPanel19.Controls.Add(this.label143, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.button51, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.button52, 0, 2);
            this.tableLayoutPanel19.Controls.Add(this.button56, 2, 1);
            this.tableLayoutPanel19.Controls.Add(this.button57, 1, 1);
            this.tableLayoutPanel19.Controls.Add(this.label144, 2, 0);
            this.tableLayoutPanel19.Controls.Add(this.SP2_LabQueryLaveQty, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.button58, 1, 2);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 3;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.57143F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.67347F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.7347F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1004, 98);
            this.tableLayoutPanel19.TabIndex = 0;
            // 
            // SP2_LabQueryDealQty
            // 
            this.SP2_LabQueryDealQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP2_LabQueryDealQty.AutoSize = true;
            this.SP2_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabQueryDealQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP2_LabQueryDealQty.Location = new System.Drawing.Point(569, 3);
            this.SP2_LabQueryDealQty.Name = "SP2_LabQueryDealQty";
            this.SP2_LabQueryDealQty.Size = new System.Drawing.Size(0, 21);
            this.SP2_LabQueryDealQty.TabIndex = 11;
            // 
            // label143
            // 
            this.label143.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label143.ForeColor = System.Drawing.Color.Gainsboro;
            this.label143.Location = new System.Drawing.Point(3, 0);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(126, 28);
            this.label143.TabIndex = 0;
            this.label143.Text = "未撮合張數 :";
            // 
            // button51
            // 
            this.button51.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button51.BackColor = System.Drawing.Color.Black;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button51.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button51.ForeColor = System.Drawing.Color.Gainsboro;
            this.button51.Location = new System.Drawing.Point(3, 31);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(126, 27);
            this.button51.TabIndex = 2;
            this.button51.TabStop = false;
            this.button51.Text = "F1 賣出輸入";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button52.BackColor = System.Drawing.Color.Black;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button52.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button52.ForeColor = System.Drawing.Color.Gainsboro;
            this.button52.Location = new System.Drawing.Point(3, 64);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(126, 30);
            this.button52.TabIndex = 3;
            this.button52.TabStop = false;
            this.button52.Text = "F5 清除畫面";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button56.BackColor = System.Drawing.Color.Black;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button56.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button56.ForeColor = System.Drawing.Color.Gainsboro;
            this.button56.Location = new System.Drawing.Point(366, 31);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(148, 27);
            this.button56.TabIndex = 4;
            this.button56.TabStop = false;
            this.button56.Text = "SF4  全部取消";
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button57.BackColor = System.Drawing.Color.Black;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button57.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button57.ForeColor = System.Drawing.Color.Gainsboro;
            this.button57.Location = new System.Drawing.Point(158, 31);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(130, 27);
            this.button57.TabIndex = 6;
            this.button57.TabStop = false;
            this.button57.Text = "F12 查 詢";
            this.button57.UseVisualStyleBackColor = false;
            // 
            // label144
            // 
            this.label144.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label144.ForeColor = System.Drawing.Color.Gainsboro;
            this.label144.Location = new System.Drawing.Point(431, 3);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(132, 21);
            this.label144.TabIndex = 1;
            this.label144.Text = "成交已回報 :";
            // 
            // SP2_LabQueryLaveQty
            // 
            this.SP2_LabQueryLaveQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP2_LabQueryLaveQty.AutoSize = true;
            this.SP2_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabQueryLaveQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP2_LabQueryLaveQty.Location = new System.Drawing.Point(135, 3);
            this.SP2_LabQueryLaveQty.Name = "SP2_LabQueryLaveQty";
            this.SP2_LabQueryLaveQty.Size = new System.Drawing.Size(34, 21);
            this.SP2_LabQueryLaveQty.TabIndex = 10;
            this.SP2_LabQueryLaveQty.Text = "    ";
            // 
            // button58
            // 
            this.button58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button58.BackColor = System.Drawing.Color.Black;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button58.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button58.ForeColor = System.Drawing.Color.Gainsboro;
            this.button58.Location = new System.Drawing.Point(158, 64);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(130, 30);
            this.button58.TabIndex = 7;
            this.button58.TabStop = false;
            this.button58.Text = "F8  更 改";
            this.button58.UseVisualStyleBackColor = false;
            // 
            // SP2_LabBHNO
            // 
            this.SP2_LabBHNO.AutoSize = true;
            this.SP2_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.SP2_LabBHNO.Location = new System.Drawing.Point(562, 13);
            this.SP2_LabBHNO.Name = "SP2_LabBHNO";
            this.SP2_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.SP2_LabBHNO.TabIndex = 138;
            this.SP2_LabBHNO.Text = " 8455";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel20.ColumnCount = 4;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.56281F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.67359F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.63996F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel20.Controls.Add(this.label147, 3, 0);
            this.tableLayoutPanel20.Controls.Add(this.label148, 2, 0);
            this.tableLayoutPanel20.Controls.Add(this.label149, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label150, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.SP2_TxbPrice, 3, 1);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 1);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel22, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel23, 2, 1);
            this.tableLayoutPanel20.Location = new System.Drawing.Point(19, 92);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 2;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1012, 100);
            this.tableLayoutPanel20.TabIndex = 0;
            // 
            // label147
            // 
            this.label147.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label147.AutoSize = true;
            this.label147.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label147.ForeColor = System.Drawing.Color.Gainsboro;
            this.label147.Location = new System.Drawing.Point(826, 14);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(116, 21);
            this.label147.TabIndex = 3;
            this.label147.Text = "標 購 價 格";
            // 
            // label148
            // 
            this.label148.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label148.AutoSize = true;
            this.label148.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label148.ForeColor = System.Drawing.Color.Gainsboro;
            this.label148.Location = new System.Drawing.Point(538, 14);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(200, 21);
            this.label148.TabIndex = 2;
            this.label148.Text = "申 購 數 量  [ 仟股 ]";
            // 
            // label149
            // 
            this.label149.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label149.AutoSize = true;
            this.label149.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label149.ForeColor = System.Drawing.Color.Gainsboro;
            this.label149.Location = new System.Drawing.Point(225, 14);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(286, 21);
            this.label149.TabIndex = 1;
            this.label149.Text = "股票代號及名稱             序號";
            // 
            // label150
            // 
            this.label150.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label150.AutoSize = true;
            this.label150.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label150.ForeColor = System.Drawing.Color.Gainsboro;
            this.label150.Location = new System.Drawing.Point(37, 14);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(144, 21);
            this.label150.TabIndex = 0;
            this.label150.Text = "投 資 人 帳 號";
            // 
            // SP2_TxbPrice
            // 
            this.SP2_TxbPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP2_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbPrice.Location = new System.Drawing.Point(834, 61);
            this.SP2_TxbPrice.Name = "SP2_TxbPrice";
            this.SP2_TxbPrice.Size = new System.Drawing.Size(100, 26);
            this.SP2_TxbPrice.TabIndex = 41;
            this.SP2_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.SP2_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 3;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.0863F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.9137F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 149F));
            this.tableLayoutPanel21.Controls.Add(this.SP2_LabStockName, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.SP2_TxbSerialNum, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.SP2_TxbStockNo, 0, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(222, 53);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(293, 43);
            this.tableLayoutPanel21.TabIndex = 7;
            // 
            // SP2_LabStockName
            // 
            this.SP2_LabStockName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_LabStockName.AutoSize = true;
            this.SP2_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.SP2_LabStockName.Location = new System.Drawing.Point(61, 0);
            this.SP2_LabStockName.Name = "SP2_LabStockName";
            this.SP2_LabStockName.Size = new System.Drawing.Size(76, 42);
            this.SP2_LabStockName.TabIndex = 1009;
            this.SP2_LabStockName.Text = "股票名稱";
            // 
            // SP2_TxbSerialNum
            // 
            this.SP2_TxbSerialNum.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.SP2_TxbSerialNum.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbSerialNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbSerialNum.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbSerialNum.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbSerialNum.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbSerialNum.Location = new System.Drawing.Point(224, 8);
            this.SP2_TxbSerialNum.Name = "SP2_TxbSerialNum";
            this.SP2_TxbSerialNum.Size = new System.Drawing.Size(66, 26);
            this.SP2_TxbSerialNum.TabIndex = 43;
            this.SP2_TxbSerialNum.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbSerialNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbSerialNum.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SP2_TxbStockNo
            // 
            this.SP2_TxbStockNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbStockNo.Location = new System.Drawing.Point(3, 8);
            this.SP2_TxbStockNo.Name = "SP2_TxbStockNo";
            this.SP2_TxbStockNo.Size = new System.Drawing.Size(50, 26);
            this.SP2_TxbStockNo.TabIndex = 44;
            this.SP2_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.SP2_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Controls.Add(this.SP2_LabCSEQName, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.SP2_TxbCSEQ, 0, 0);
            this.tableLayoutPanel22.Location = new System.Drawing.Point(4, 53);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(211, 43);
            this.tableLayoutPanel22.TabIndex = 43;
            // 
            // SP2_LabCSEQName
            // 
            this.SP2_LabCSEQName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_LabCSEQName.AutoSize = true;
            this.SP2_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.SP2_LabCSEQName.Location = new System.Drawing.Point(109, 11);
            this.SP2_LabCSEQName.Name = "SP2_LabCSEQName";
            this.SP2_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.SP2_LabCSEQName.TabIndex = 1010;
            this.SP2_LabCSEQName.Text = "客戶名稱";
            // 
            // SP2_TxbCSEQ
            // 
            this.SP2_TxbCSEQ.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbCSEQ.Location = new System.Drawing.Point(5, 8);
            this.SP2_TxbCSEQ.Name = "SP2_TxbCSEQ";
            this.SP2_TxbCSEQ.Size = new System.Drawing.Size(94, 26);
            this.SP2_TxbCSEQ.TabIndex = 45;
            this.SP2_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.SP2_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37F));
            this.tableLayoutPanel23.Controls.Add(this.SP2_LabCancelQty, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.SP2_TxbStockQty, 0, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(554, 53);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel23.TabIndex = 1006;
            // 
            // SP2_LabCancelQty
            // 
            this.SP2_LabCancelQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP2_LabCancelQty.AutoSize = true;
            this.SP2_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabCancelQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SP2_LabCancelQty.Location = new System.Drawing.Point(129, 11);
            this.SP2_LabCancelQty.Name = "SP2_LabCancelQty";
            this.SP2_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.SP2_LabCancelQty.TabIndex = 172;
            this.SP2_LabCancelQty.Text = "0";
            this.SP2_LabCancelQty.Visible = false;
            // 
            // SP2_TxbStockQty
            // 
            this.SP2_TxbStockQty.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.SP2_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbStockQty.Location = new System.Drawing.Point(23, 8);
            this.SP2_TxbStockQty.Name = "SP2_TxbStockQty";
            this.SP2_TxbStockQty.Size = new System.Drawing.Size(100, 26);
            this.SP2_TxbStockQty.TabIndex = 42;
            this.SP2_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SP2_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.SP2_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label154.ForeColor = System.Drawing.Color.Gainsboro;
            this.label154.Location = new System.Drawing.Point(418, 13);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(138, 21);
            this.label154.TabIndex = 139;
            this.label154.Text = "證券商代號 : ";
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel25, 0, 0);
            this.tableLayoutPanel24.Location = new System.Drawing.Point(19, 51);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1012, 42);
            this.tableLayoutPanel24.TabIndex = 143;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 4;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.29084F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.378486F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.191235F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.43825F));
            this.tableLayoutPanel25.Controls.Add(this.label155, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.SP2_TxbTERM, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.SP2_TxbDSEQ, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.label156, 2, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1004, 34);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // label155
            // 
            this.label155.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label155.AutoSize = true;
            this.label155.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label155.ForeColor = System.Drawing.Color.Gainsboro;
            this.label155.Location = new System.Drawing.Point(382, 6);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(138, 21);
            this.label155.TabIndex = 1;
            this.label155.Text = "委託書編號 : ";
            // 
            // SP2_TxbTERM
            // 
            this.SP2_TxbTERM.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SP2_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbTERM.Location = new System.Drawing.Point(526, 4);
            this.SP2_TxbTERM.Name = "SP2_TxbTERM";
            this.SP2_TxbTERM.Size = new System.Drawing.Size(47, 26);
            this.SP2_TxbTERM.TabIndex = 47;
            this.SP2_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.SP2_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SP2_TxbDSEQ
            // 
            this.SP2_TxbDSEQ.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.SP2_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.SP2_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SP2_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SP2_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SP2_TxbDSEQ.Location = new System.Drawing.Point(600, 4);
            this.SP2_TxbDSEQ.Name = "SP2_TxbDSEQ";
            this.SP2_TxbDSEQ.Size = new System.Drawing.Size(100, 26);
            this.SP2_TxbDSEQ.TabIndex = 46;
            this.SP2_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SP2_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.SP2_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SP2_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SP2_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label156
            // 
            this.label156.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label156.AutoSize = true;
            this.label156.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label156.ForeColor = System.Drawing.Color.Gainsboro;
            this.label156.Location = new System.Drawing.Point(579, 6);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(15, 21);
            this.label156.TabIndex = 4;
            this.label156.Text = "-";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label157.ForeColor = System.Drawing.Color.Gold;
            this.label157.Location = new System.Drawing.Point(803, 13);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(101, 19);
            this.label157.TabIndex = 141;
            this.label157.Text = "交易日期 :";
            // 
            // SP2_LabTDate
            // 
            this.SP2_LabTDate.AutoSize = true;
            this.SP2_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SP2_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.SP2_LabTDate.Location = new System.Drawing.Point(924, 13);
            this.SP2_LabTDate.Name = "SP2_LabTDate";
            this.SP2_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.SP2_LabTDate.TabIndex = 142;
            this.SP2_LabTDate.Text = "1090107";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label159.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label159.ForeColor = System.Drawing.Color.Gold;
            this.label159.Location = new System.Drawing.Point(0, 0);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(332, 27);
            this.label159.TabIndex = 180;
            this.label159.Text = "<<非證金標購委託時間 >>";
            // 
            // StockAuction
            // 
            this.StockAuction.BackColor = System.Drawing.Color.Black;
            this.StockAuction.Controls.Add(this.panel_StockAuction);
            this.StockAuction.Controls.Add(this.label9);
            this.StockAuction.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StockAuction.Location = new System.Drawing.Point(4, 26);
            this.StockAuction.Name = "StockAuction";
            this.StockAuction.Size = new System.Drawing.Size(1053, 364);
            this.StockAuction.TabIndex = 6;
            this.StockAuction.Text = "股票拍賣";
            // 
            // panel_StockAuction
            // 
            this.panel_StockAuction.Controls.Add(this.SA_LabCSEQName);
            this.panel_StockAuction.Controls.Add(this.SA_LabStockName);
            this.panel_StockAuction.Controls.Add(this.SA_LabCancelQty);
            this.panel_StockAuction.Controls.Add(this.SA_LabCCodeText);
            this.panel_StockAuction.Controls.Add(this.label115);
            this.panel_StockAuction.Controls.Add(this.SA_LabBHNO);
            this.panel_StockAuction.Controls.Add(this.SA_LabQueryDealQty);
            this.panel_StockAuction.Controls.Add(this.label116);
            this.panel_StockAuction.Controls.Add(this.SA_LabQueryLaveQty);
            this.panel_StockAuction.Controls.Add(this.label114);
            this.panel_StockAuction.Controls.Add(this.SA_LabTDate);
            this.panel_StockAuction.Controls.Add(this.SA_TxbStockNo);
            this.panel_StockAuction.Controls.Add(this.label121);
            this.panel_StockAuction.Controls.Add(this.label120);
            this.panel_StockAuction.Controls.Add(this.button50);
            this.panel_StockAuction.Controls.Add(this.SA_TxbTERM);
            this.panel_StockAuction.Controls.Add(this.button49);
            this.panel_StockAuction.Controls.Add(this.label119);
            this.panel_StockAuction.Controls.Add(this.button48);
            this.panel_StockAuction.Controls.Add(this.SA_TxbDSEQ);
            this.panel_StockAuction.Controls.Add(this.button46);
            this.panel_StockAuction.Controls.Add(this.label118);
            this.panel_StockAuction.Controls.Add(this.button47);
            this.panel_StockAuction.Controls.Add(this.label122);
            this.panel_StockAuction.Controls.Add(this.label128);
            this.panel_StockAuction.Controls.Add(this.SA_TxbCSEQ);
            this.panel_StockAuction.Controls.Add(this.label127);
            this.panel_StockAuction.Controls.Add(this.label123);
            this.panel_StockAuction.Controls.Add(this.label126);
            this.panel_StockAuction.Controls.Add(this.label124);
            this.panel_StockAuction.Controls.Add(this.SA_TxbPrice);
            this.panel_StockAuction.Controls.Add(this.SA_TxbStockQty);
            this.panel_StockAuction.Controls.Add(this.label125);
            this.panel_StockAuction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_StockAuction.Location = new System.Drawing.Point(0, 0);
            this.panel_StockAuction.Name = "panel_StockAuction";
            this.panel_StockAuction.Size = new System.Drawing.Size(1053, 364);
            this.panel_StockAuction.TabIndex = 178;
            this.panel_StockAuction.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_StockAuction_MouseClick);
            // 
            // SA_LabCSEQName
            // 
            this.SA_LabCSEQName.AutoSize = true;
            this.SA_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.SA_LabCSEQName.Location = new System.Drawing.Point(142, 144);
            this.SA_LabCSEQName.Name = "SA_LabCSEQName";
            this.SA_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.SA_LabCSEQName.TabIndex = 1009;
            this.SA_LabCSEQName.Text = "客戶名稱";
            // 
            // SA_LabStockName
            // 
            this.SA_LabStockName.AutoSize = true;
            this.SA_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.SA_LabStockName.Location = new System.Drawing.Point(332, 144);
            this.SA_LabStockName.Name = "SA_LabStockName";
            this.SA_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.SA_LabStockName.TabIndex = 1008;
            this.SA_LabStockName.Text = "股票名稱";
            // 
            // SA_LabCancelQty
            // 
            this.SA_LabCancelQty.AutoSize = true;
            this.SA_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabCancelQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SA_LabCancelQty.Location = new System.Drawing.Point(713, 144);
            this.SA_LabCancelQty.Name = "SA_LabCancelQty";
            this.SA_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.SA_LabCancelQty.TabIndex = 1007;
            this.SA_LabCancelQty.Text = "0";
            this.SA_LabCancelQty.Visible = false;
            // 
            // SA_LabCCodeText
            // 
            this.SA_LabCCodeText.AutoSize = true;
            this.SA_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.SA_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.SA_LabCCodeText.Location = new System.Drawing.Point(27, 189);
            this.SA_LabCCodeText.Name = "SA_LabCCodeText";
            this.SA_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.SA_LabCCodeText.TabIndex = 1006;
            this.SA_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label115.ForeColor = System.Drawing.Color.Gold;
            this.label115.Location = new System.Drawing.Point(27, 12);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(247, 16);
            this.label115.TabIndex = 148;
            this.label115.Text = "<<< 股票拍賣 委託資料輸入 >>>\r\n";
            // 
            // SA_LabBHNO
            // 
            this.SA_LabBHNO.AutoSize = true;
            this.SA_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.SA_LabBHNO.Location = new System.Drawing.Point(562, 13);
            this.SA_LabBHNO.Name = "SA_LabBHNO";
            this.SA_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.SA_LabBHNO.TabIndex = 143;
            this.SA_LabBHNO.Text = " 8455";
            // 
            // SA_LabQueryDealQty
            // 
            this.SA_LabQueryDealQty.AutoSize = true;
            this.SA_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabQueryDealQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SA_LabQueryDealQty.Location = new System.Drawing.Point(844, 225);
            this.SA_LabQueryDealQty.Name = "SA_LabQueryDealQty";
            this.SA_LabQueryDealQty.Size = new System.Drawing.Size(34, 21);
            this.SA_LabQueryDealQty.TabIndex = 176;
            this.SA_LabQueryDealQty.Text = "    ";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label116.ForeColor = System.Drawing.Color.Gainsboro;
            this.label116.Location = new System.Drawing.Point(418, 13);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(138, 21);
            this.label116.TabIndex = 144;
            this.label116.Text = "證券商代號 : ";
            // 
            // SA_LabQueryLaveQty
            // 
            this.SA_LabQueryLaveQty.AutoSize = true;
            this.SA_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabQueryLaveQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.SA_LabQueryLaveQty.Location = new System.Drawing.Point(165, 225);
            this.SA_LabQueryLaveQty.Name = "SA_LabQueryLaveQty";
            this.SA_LabQueryLaveQty.Size = new System.Drawing.Size(34, 21);
            this.SA_LabQueryLaveQty.TabIndex = 175;
            this.SA_LabQueryLaveQty.Text = "    ";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label114.ForeColor = System.Drawing.Color.Gold;
            this.label114.Location = new System.Drawing.Point(803, 13);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(101, 19);
            this.label114.TabIndex = 146;
            this.label114.Text = "交易日期 :";
            // 
            // SA_LabTDate
            // 
            this.SA_LabTDate.AutoSize = true;
            this.SA_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.SA_LabTDate.Location = new System.Drawing.Point(924, 13);
            this.SA_LabTDate.Name = "SA_LabTDate";
            this.SA_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.SA_LabTDate.TabIndex = 147;
            this.SA_LabTDate.Text = "1090107";
            // 
            // SA_TxbStockNo
            // 
            this.SA_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.SA_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.SA_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbStockNo.Location = new System.Drawing.Point(270, 144);
            this.SA_TxbStockNo.Name = "SA_TxbStockNo";
            this.SA_TxbStockNo.Size = new System.Drawing.Size(70, 26);
            this.SA_TxbStockNo.TabIndex = 53;
            this.SA_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.SA_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label121
            // 
            this.label121.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label121.ForeColor = System.Drawing.Color.Gainsboro;
            this.label121.Location = new System.Drawing.Point(7, 36);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(1040, 16);
            this.label121.TabIndex = 149;
            this.label121.Text = "................................................................................." +
    "................................................";
            this.label121.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.BackColor = System.Drawing.Color.Black;
            this.label120.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label120.ForeColor = System.Drawing.Color.Gainsboro;
            this.label120.Location = new System.Drawing.Point(418, 58);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(132, 21);
            this.label120.TabIndex = 150;
            this.label120.Text = "委託書編號 :";
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.Black;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button50.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button50.ForeColor = System.Drawing.Color.Gainsboro;
            this.button50.Location = new System.Drawing.Point(422, 272);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(150, 30);
            this.button50.TabIndex = 170;
            this.button50.TabStop = false;
            this.button50.Text = "SF4   全部取消";
            this.button50.UseVisualStyleBackColor = false;
            // 
            // SA_TxbTERM
            // 
            this.SA_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.SA_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.SA_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbTERM.Location = new System.Drawing.Point(557, 56);
            this.SA_TxbTERM.Name = "SA_TxbTERM";
            this.SA_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.SA_TxbTERM.TabIndex = 56;
            this.SA_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.SA_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Black;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button49.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button49.ForeColor = System.Drawing.Color.Gainsboro;
            this.button49.Location = new System.Drawing.Point(233, 308);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(125, 30);
            this.button49.TabIndex = 169;
            this.button49.TabStop = false;
            this.button49.Text = "F8  更  改";
            this.button49.UseVisualStyleBackColor = false;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label119.ForeColor = System.Drawing.Color.Gainsboro;
            this.label119.Location = new System.Drawing.Point(580, 57);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(18, 21);
            this.label119.TabIndex = 152;
            this.label119.Text = "-";
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Black;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button48.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button48.ForeColor = System.Drawing.Color.Gainsboro;
            this.button48.Location = new System.Drawing.Point(233, 272);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(125, 30);
            this.button48.TabIndex = 168;
            this.button48.TabStop = false;
            this.button48.Text = "F12 查  詢";
            this.button48.UseVisualStyleBackColor = false;
            // 
            // SA_TxbDSEQ
            // 
            this.SA_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.SA_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SA_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbDSEQ.Location = new System.Drawing.Point(602, 57);
            this.SA_TxbDSEQ.Name = "SA_TxbDSEQ";
            this.SA_TxbDSEQ.Size = new System.Drawing.Size(60, 26);
            this.SA_TxbDSEQ.TabIndex = 55;
            this.SA_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SA_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.SA_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Black;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button46.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button46.ForeColor = System.Drawing.Color.Gainsboro;
            this.button46.Location = new System.Drawing.Point(30, 272);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(125, 30);
            this.button46.TabIndex = 167;
            this.button46.TabStop = false;
            this.button46.Text = "F1 買進輸入";
            this.button46.UseVisualStyleBackColor = false;
            // 
            // label118
            // 
            this.label118.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label118.ForeColor = System.Drawing.Color.Gainsboro;
            this.label118.Location = new System.Drawing.Point(6, 89);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(1040, 16);
            this.label118.TabIndex = 154;
            this.label118.Text = "................................................................................." +
    "................................................";
            this.label118.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Black;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button47.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button47.ForeColor = System.Drawing.Color.Gainsboro;
            this.button47.Location = new System.Drawing.Point(30, 308);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(125, 30);
            this.button47.TabIndex = 166;
            this.button47.TabStop = false;
            this.button47.Text = "F5 清除畫面";
            this.button47.UseVisualStyleBackColor = false;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label122.ForeColor = System.Drawing.Color.Gainsboro;
            this.label122.Location = new System.Drawing.Point(27, 111);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(120, 21);
            this.label122.TabIndex = 155;
            this.label122.Text = "投資人帳號";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label128.ForeColor = System.Drawing.Color.Gainsboro;
            this.label128.Location = new System.Drawing.Point(706, 223);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(132, 21);
            this.label128.TabIndex = 165;
            this.label128.Text = "成交已回報 :";
            // 
            // SA_TxbCSEQ
            // 
            this.SA_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.SA_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.SA_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbCSEQ.Location = new System.Drawing.Point(31, 144);
            this.SA_TxbCSEQ.Name = "SA_TxbCSEQ";
            this.SA_TxbCSEQ.Size = new System.Drawing.Size(105, 26);
            this.SA_TxbCSEQ.TabIndex = 54;
            this.SA_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.SA_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label127.ForeColor = System.Drawing.Color.Gainsboro;
            this.label127.Location = new System.Drawing.Point(27, 223);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(132, 21);
            this.label127.TabIndex = 164;
            this.label127.Text = "未搓合股數 :";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label123.ForeColor = System.Drawing.Color.Gainsboro;
            this.label123.Location = new System.Drawing.Point(266, 111);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(164, 21);
            this.label123.TabIndex = 157;
            this.label123.Text = "股票代號及名稱";
            // 
            // label126
            // 
            this.label126.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label126.ForeColor = System.Drawing.Color.Gainsboro;
            this.label126.Location = new System.Drawing.Point(6, 249);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(1040, 16);
            this.label126.TabIndex = 163;
            this.label126.Text = "................................................................................." +
    "................................................";
            this.label126.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label124.ForeColor = System.Drawing.Color.Gainsboro;
            this.label124.Location = new System.Drawing.Point(580, 111);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(182, 21);
            this.label124.TabIndex = 159;
            this.label124.Text = "申 購 數 量 [仟股]";
            // 
            // SA_TxbPrice
            // 
            this.SA_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.SA_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.SA_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbPrice.Location = new System.Drawing.Point(848, 144);
            this.SA_TxbPrice.Name = "SA_TxbPrice";
            this.SA_TxbPrice.Size = new System.Drawing.Size(85, 26);
            this.SA_TxbPrice.TabIndex = 51;
            this.SA_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.SA_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // SA_TxbStockQty
            // 
            this.SA_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.SA_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SA_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SA_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.SA_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.SA_TxbStockQty.Location = new System.Drawing.Point(602, 144);
            this.SA_TxbStockQty.Name = "SA_TxbStockQty";
            this.SA_TxbStockQty.Size = new System.Drawing.Size(105, 26);
            this.SA_TxbStockQty.TabIndex = 52;
            this.SA_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SA_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.SA_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.SA_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.SA_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label125.ForeColor = System.Drawing.Color.Gainsboro;
            this.label125.Location = new System.Drawing.Point(844, 111);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(98, 21);
            this.label125.TabIndex = 161;
            this.label125.Text = "申購價格";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(332, 27);
            this.label9.TabIndex = 179;
            this.label9.Text = "<<非股票拍賣委託時間 >>";
            // 
            // ErrAccount
            // 
            this.ErrAccount.BackColor = System.Drawing.Color.Black;
            this.ErrAccount.Controls.Add(this.panel_ErrAccout);
            this.ErrAccount.Controls.Add(this.label137);
            this.ErrAccount.Location = new System.Drawing.Point(4, 26);
            this.ErrAccount.Name = "ErrAccount";
            this.ErrAccount.Padding = new System.Windows.Forms.Padding(3);
            this.ErrAccount.Size = new System.Drawing.Size(1053, 364);
            this.ErrAccount.TabIndex = 7;
            this.ErrAccount.Text = "錯帳功能";
            // 
            // panel_ErrAccout
            // 
            this.panel_ErrAccout.BackColor = System.Drawing.Color.Black;
            this.panel_ErrAccout.Controls.Add(this.ER_BtnForceChangeQty);
            this.panel_ErrAccout.Controls.Add(this.ER_BtnForceReturn);
            this.panel_ErrAccout.Controls.Add(this.ER_BtnForceOrder);
            this.panel_ErrAccout.Controls.Add(this.ER_BtnForceClear);
            this.panel_ErrAccout.Controls.Add(this.ER_LanWarText);
            this.panel_ErrAccout.Controls.Add(this.ER_LabInfo);
            this.panel_ErrAccout.Controls.Add(this.label131);
            this.panel_ErrAccout.Controls.Add(this.label130);
            this.panel_ErrAccout.Controls.Add(this.tableLayoutPanel12);
            this.panel_ErrAccout.Controls.Add(this.tableLayoutPanel11);
            this.panel_ErrAccout.Controls.Add(this.ER_LabQueryDealQty);
            this.panel_ErrAccout.Controls.Add(this.ER_LabQueryLaveQty);
            this.panel_ErrAccout.Controls.Add(this.tableLayoutPanel2);
            this.panel_ErrAccout.Controls.Add(this.label111);
            this.panel_ErrAccout.Controls.Add(this.ER_LabTDate);
            this.panel_ErrAccout.Controls.Add(this.label77);
            this.panel_ErrAccout.Controls.Add(this.label81);
            this.panel_ErrAccout.Controls.Add(this.ER_LabBHNO);
            this.panel_ErrAccout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ErrAccout.Location = new System.Drawing.Point(3, 3);
            this.panel_ErrAccout.Name = "panel_ErrAccout";
            this.panel_ErrAccout.Size = new System.Drawing.Size(1047, 358);
            this.panel_ErrAccout.TabIndex = 0;
            this.panel_ErrAccout.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_ErrAccout_MouseClick);
            // 
            // ER_BtnForceChangeQty
            // 
            this.ER_BtnForceChangeQty.BackColor = System.Drawing.Color.Red;
            this.ER_BtnForceChangeQty.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ER_BtnForceChangeQty.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_BtnForceChangeQty.ForeColor = System.Drawing.Color.Yellow;
            this.ER_BtnForceChangeQty.Location = new System.Drawing.Point(885, 189);
            this.ER_BtnForceChangeQty.Name = "ER_BtnForceChangeQty";
            this.ER_BtnForceChangeQty.Size = new System.Drawing.Size(89, 34);
            this.ER_BtnForceChangeQty.TabIndex = 1005;
            this.ER_BtnForceChangeQty.TabStop = false;
            this.ER_BtnForceChangeQty.Text = "F9 改量";
            this.ER_BtnForceChangeQty.UseVisualStyleBackColor = false;
            this.ER_BtnForceChangeQty.Visible = false;
            // 
            // ER_BtnForceReturn
            // 
            this.ER_BtnForceReturn.BackColor = System.Drawing.Color.Red;
            this.ER_BtnForceReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ER_BtnForceReturn.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_BtnForceReturn.ForeColor = System.Drawing.Color.Yellow;
            this.ER_BtnForceReturn.Location = new System.Drawing.Point(790, 189);
            this.ER_BtnForceReturn.Name = "ER_BtnForceReturn";
            this.ER_BtnForceReturn.Size = new System.Drawing.Size(95, 34);
            this.ER_BtnForceReturn.TabIndex = 1004;
            this.ER_BtnForceReturn.TabStop = false;
            this.ER_BtnForceReturn.Text = "F10 返回";
            this.ER_BtnForceReturn.UseVisualStyleBackColor = false;
            this.ER_BtnForceReturn.Visible = false;
            // 
            // ER_BtnForceOrder
            // 
            this.ER_BtnForceOrder.BackColor = System.Drawing.Color.Red;
            this.ER_BtnForceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ER_BtnForceOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_BtnForceOrder.ForeColor = System.Drawing.Color.Yellow;
            this.ER_BtnForceOrder.Location = new System.Drawing.Point(695, 189);
            this.ER_BtnForceOrder.Name = "ER_BtnForceOrder";
            this.ER_BtnForceOrder.Size = new System.Drawing.Size(95, 34);
            this.ER_BtnForceOrder.TabIndex = 1003;
            this.ER_BtnForceOrder.TabStop = false;
            this.ER_BtnForceOrder.Text = "SF8 強行";
            this.ER_BtnForceOrder.UseVisualStyleBackColor = false;
            this.ER_BtnForceOrder.Visible = false;
            // 
            // ER_BtnForceClear
            // 
            this.ER_BtnForceClear.BackColor = System.Drawing.Color.Red;
            this.ER_BtnForceClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ER_BtnForceClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_BtnForceClear.ForeColor = System.Drawing.Color.Yellow;
            this.ER_BtnForceClear.Location = new System.Drawing.Point(606, 189);
            this.ER_BtnForceClear.Name = "ER_BtnForceClear";
            this.ER_BtnForceClear.Size = new System.Drawing.Size(89, 34);
            this.ER_BtnForceClear.TabIndex = 1002;
            this.ER_BtnForceClear.TabStop = false;
            this.ER_BtnForceClear.Text = "F5 清除";
            this.ER_BtnForceClear.UseVisualStyleBackColor = false;
            this.ER_BtnForceClear.Visible = false;
            // 
            // ER_LanWarText
            // 
            this.ER_LanWarText.AutoSize = true;
            this.ER_LanWarText.BackColor = System.Drawing.Color.Red;
            this.ER_LanWarText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.ER_LanWarText.Location = new System.Drawing.Point(15, 170);
            this.ER_LanWarText.Name = "ER_LanWarText";
            this.ER_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.ER_LanWarText.TabIndex = 1001;
            this.ER_LanWarText.Text = "警示訊息";
            // 
            // ER_LabInfo
            // 
            this.ER_LabInfo.AutoSize = true;
            this.ER_LabInfo.BackColor = System.Drawing.Color.Red;
            this.ER_LabInfo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabInfo.ForeColor = System.Drawing.Color.Yellow;
            this.ER_LabInfo.Location = new System.Drawing.Point(15, 195);
            this.ER_LabInfo.Name = "ER_LabInfo";
            this.ER_LabInfo.Size = new System.Drawing.Size(98, 21);
            this.ER_LabInfo.TabIndex = 167;
            this.ER_LabInfo.Text = "相關訊息";
            this.ER_LabInfo.Visible = false;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label131.ForeColor = System.Drawing.Color.Gainsboro;
            this.label131.Location = new System.Drawing.Point(657, 235);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(132, 21);
            this.label131.TabIndex = 166;
            this.label131.Text = "成交已回報 :";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label130.ForeColor = System.Drawing.Color.Gainsboro;
            this.label130.Location = new System.Drawing.Point(43, 235);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(132, 21);
            this.label130.TabIndex = 165;
            this.label130.Text = "未搓合張數 :";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel15, 0, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(15, 45);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(1012, 44);
            this.tableLayoutPanel12.TabIndex = 149;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 5;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 91.16279F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.83721F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 458F));
            this.tableLayoutPanel15.Controls.Add(this.ER_TxbTERM, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.label102, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.ER_TxbDSEQ, 3, 0);
            this.tableLayoutPanel15.Controls.Add(this.label117, 2, 0);
            this.tableLayoutPanel15.Controls.Add(this.label132, 4, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1004, 36);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // ER_TxbTERM
            // 
            this.ER_TxbTERM.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ER_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.ER_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbTERM.Location = new System.Drawing.Point(328, 5);
            this.ER_TxbTERM.Name = "ER_TxbTERM";
            this.ER_TxbTERM.Size = new System.Drawing.Size(24, 26);
            this.ER_TxbTERM.TabIndex = 67;
            this.ER_TxbTERM.Text = "Q";
            this.ER_TxbTERM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ER_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.ER_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label102
            // 
            this.label102.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label102.ForeColor = System.Drawing.Color.White;
            this.label102.Location = new System.Drawing.Point(321, 7);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(0, 21);
            this.label102.TabIndex = 0;
            // 
            // ER_TxbDSEQ
            // 
            this.ER_TxbDSEQ.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ER_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.ER_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ER_TxbDSEQ.Location = new System.Drawing.Point(397, 5);
            this.ER_TxbDSEQ.Name = "ER_TxbDSEQ";
            this.ER_TxbDSEQ.Size = new System.Drawing.Size(105, 26);
            this.ER_TxbDSEQ.TabIndex = 66;
            this.ER_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ER_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.ER_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label117
            // 
            this.label117.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label117.ForeColor = System.Drawing.Color.White;
            this.label117.Location = new System.Drawing.Point(365, 7);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(18, 21);
            this.label117.TabIndex = 5;
            this.label117.Text = "-";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.ForeColor = System.Drawing.Color.Red;
            this.label132.Location = new System.Drawing.Point(548, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(314, 32);
            this.label132.TabIndex = 68;
            this.label132.Text = "＊新單不須自行輸入委託序號＊\r\n＊進行查詢才需輸入對應委託序號查詢＊\r\n";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel11.ColumnCount = 4;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel11.Controls.Add(this.button43, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.button38, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.button39, 3, 1);
            this.tableLayoutPanel11.Controls.Add(this.button54, 3, 0);
            this.tableLayoutPanel11.Controls.Add(this.button53, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.button32, 2, 1);
            this.tableLayoutPanel11.Controls.Add(this.button16, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.button55, 1, 1);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(15, 259);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(1012, 85);
            this.tableLayoutPanel11.TabIndex = 148;
            // 
            // button43
            // 
            this.button43.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button43.BackColor = System.Drawing.Color.Black;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button43.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button43.ForeColor = System.Drawing.Color.Gainsboro;
            this.button43.Location = new System.Drawing.Point(4, 48);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(110, 30);
            this.button43.TabIndex = 99;
            this.button43.TabStop = false;
            this.button43.Text = "F14跌停價";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button38.BackColor = System.Drawing.Color.Black;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button38.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button38.ForeColor = System.Drawing.Color.Gainsboro;
            this.button38.Location = new System.Drawing.Point(4, 6);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(110, 30);
            this.button38.TabIndex = 97;
            this.button38.TabStop = false;
            this.button38.Text = "F3 漲停價";
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button39.BackColor = System.Drawing.Color.Black;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button39.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button39.ForeColor = System.Drawing.Color.Gainsboro;
            this.button39.Location = new System.Drawing.Point(760, 48);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(148, 30);
            this.button39.TabIndex = 4;
            this.button39.TabStop = false;
            this.button39.Text = "SF4  全部取消";
            this.button39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button54.BackColor = System.Drawing.Color.Black;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button54.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button54.ForeColor = System.Drawing.Color.Gainsboro;
            this.button54.Location = new System.Drawing.Point(760, 6);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(130, 30);
            this.button54.TabIndex = 7;
            this.button54.TabStop = false;
            this.button54.Text = "F8  更 改";
            this.button54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button53.BackColor = System.Drawing.Color.Black;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button53.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button53.ForeColor = System.Drawing.Color.Gainsboro;
            this.button53.Location = new System.Drawing.Point(508, 6);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(130, 30);
            this.button53.TabIndex = 6;
            this.button53.TabStop = false;
            this.button53.Text = "F12 查 詢";
            this.button53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button32.BackColor = System.Drawing.Color.Black;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button32.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button32.ForeColor = System.Drawing.Color.Gainsboro;
            this.button32.Location = new System.Drawing.Point(508, 48);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(150, 30);
            this.button32.TabIndex = 3;
            this.button32.TabStop = false;
            this.button32.Text = "F5 清除畫面";
            this.button32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button16.BackColor = System.Drawing.Color.Black;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button16.ForeColor = System.Drawing.Color.Red;
            this.button16.Location = new System.Drawing.Point(256, 6);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(150, 30);
            this.button16.TabIndex = 2;
            this.button16.TabStop = false;
            this.button16.Text = "F1 買入";
            this.button16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button55.BackColor = System.Drawing.Color.Black;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button55.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button55.ForeColor = System.Drawing.Color.Lime;
            this.button55.Location = new System.Drawing.Point(256, 48);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(150, 30);
            this.button55.TabIndex = 12;
            this.button55.TabStop = false;
            this.button55.Text = "F16 賣出";
            this.button55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button55.UseVisualStyleBackColor = false;
            // 
            // ER_LabQueryDealQty
            // 
            this.ER_LabQueryDealQty.AutoSize = true;
            this.ER_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabQueryDealQty.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabQueryDealQty.Location = new System.Drawing.Point(795, 235);
            this.ER_LabQueryDealQty.Name = "ER_LabQueryDealQty";
            this.ER_LabQueryDealQty.Size = new System.Drawing.Size(46, 21);
            this.ER_LabQueryDealQty.TabIndex = 147;
            this.ER_LabQueryDealQty.Text = "      ";
            // 
            // ER_LabQueryLaveQty
            // 
            this.ER_LabQueryLaveQty.AutoSize = true;
            this.ER_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabQueryLaveQty.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabQueryLaveQty.Location = new System.Drawing.Point(181, 235);
            this.ER_LabQueryLaveQty.Name = "ER_LabQueryLaveQty";
            this.ER_LabQueryLaveQty.Size = new System.Drawing.Size(64, 21);
            this.ER_LabQueryLaveQty.TabIndex = 146;
            this.ER_LabQueryLaveQty.Text = "         ";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.00288F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.45245F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.07829F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.44484F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 308F));
            this.tableLayoutPanel2.Controls.Add(this.label136, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel14, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label112, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel10, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.ER_LabErAccount, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label129, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.ER_TxbPrice, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.ER_LabOrdQty, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel13, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label75, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label113, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel17, 5, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(15, 88);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1012, 79);
            this.tableLayoutPanel2.TabIndex = 142;
            // 
            // label136
            // 
            this.label136.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label136.AutoSize = true;
            this.label136.BackColor = System.Drawing.Color.Black;
            this.label136.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label136.ForeColor = System.Drawing.Color.Gainsboro;
            this.label136.Location = new System.Drawing.Point(807, 9);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(98, 21);
            this.label136.TabIndex = 1004;
            this.label136.Text = "委託條件";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel14.Controls.Add(this.ER_LabCancelQty, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.ER_TxbStockQty, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.ER_LabUnit, 2, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(384, 43);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(123, 32);
            this.tableLayoutPanel14.TabIndex = 148;
            // 
            // ER_LabCancelQty
            // 
            this.ER_LabCancelQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ER_LabCancelQty.AutoSize = true;
            this.ER_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabCancelQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.ER_LabCancelQty.Location = new System.Drawing.Point(40, 5);
            this.ER_LabCancelQty.Name = "ER_LabCancelQty";
            this.ER_LabCancelQty.Size = new System.Drawing.Size(0, 21);
            this.ER_LabCancelQty.TabIndex = 1006;
            // 
            // ER_TxbStockQty
            // 
            this.ER_TxbStockQty.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ER_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.ER_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ER_TxbStockQty.Location = new System.Drawing.Point(3, 3);
            this.ER_TxbStockQty.Name = "ER_TxbStockQty";
            this.ER_TxbStockQty.Size = new System.Drawing.Size(31, 26);
            this.ER_TxbStockQty.TabIndex = 63;
            this.ER_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ER_TxbStockQty.TextChanged += new System.EventHandler(this.TxbStockQty_TextChanged);
            this.ER_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // ER_LabUnit
            // 
            this.ER_LabUnit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_LabUnit.AutoSize = true;
            this.ER_LabUnit.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabUnit.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabUnit.Location = new System.Drawing.Point(71, 5);
            this.ER_LabUnit.Name = "ER_LabUnit";
            this.ER_LabUnit.Size = new System.Drawing.Size(32, 21);
            this.ER_LabUnit.TabIndex = 1002;
            this.ER_LabUnit.Text = "張";
            // 
            // label112
            // 
            this.label112.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label112.ForeColor = System.Drawing.Color.Gainsboro;
            this.label112.Location = new System.Drawing.Point(44, 9);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(0, 21);
            this.label112.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.38983F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.61017F));
            this.tableLayoutPanel10.Controls.Add(this.ER_LabECodeText, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.ER_TxbECode, 0, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(91, 43);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(92, 32);
            this.tableLayoutPanel10.TabIndex = 2;
            // 
            // ER_LabECodeText
            // 
            this.ER_LabECodeText.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_LabECodeText.AutoSize = true;
            this.ER_LabECodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabECodeText.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabECodeText.Location = new System.Drawing.Point(32, 5);
            this.ER_LabECodeText.Name = "ER_LabECodeText";
            this.ER_LabECodeText.Size = new System.Drawing.Size(54, 21);
            this.ER_LabECodeText.TabIndex = 1001;
            this.ER_LabECodeText.Text = "普通";
            // 
            // ER_TxbECode
            // 
            this.ER_TxbECode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_TxbECode.BackColor = System.Drawing.Color.Black;
            this.ER_TxbECode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbECode.CausesValidation = false;
            this.ER_TxbECode.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbECode.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbECode.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ER_TxbECode.Location = new System.Drawing.Point(4, 3);
            this.ER_TxbECode.Name = "ER_TxbECode";
            this.ER_TxbECode.Size = new System.Drawing.Size(18, 26);
            this.ER_TxbECode.TabIndex = 65;
            this.ER_TxbECode.TextChanged += new System.EventHandler(this.ER_TxbECode_TextChanged);
            this.ER_TxbECode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbECode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbECode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // ER_LabErAccount
            // 
            this.ER_LabErAccount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_LabErAccount.AutoSize = true;
            this.ER_LabErAccount.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabErAccount.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabErAccount.Location = new System.Drawing.Point(6, 40);
            this.ER_LabErAccount.Name = "ER_LabErAccount";
            this.ER_LabErAccount.Size = new System.Drawing.Size(76, 38);
            this.ER_LabErAccount.TabIndex = 114;
            this.ER_LabErAccount.Text = "0003332";
            // 
            // label129
            // 
            this.label129.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label129.ForeColor = System.Drawing.Color.Gainsboro;
            this.label129.Location = new System.Drawing.Point(554, 9);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(104, 21);
            this.label129.TabIndex = 113;
            this.label129.Text = "委託 價格";
            // 
            // ER_TxbPrice
            // 
            this.ER_TxbPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.ER_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbPrice.ForeColor = System.Drawing.Color.Gainsboro;
            this.ER_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ER_TxbPrice.Location = new System.Drawing.Point(540, 46);
            this.ER_TxbPrice.Name = "ER_TxbPrice";
            this.ER_TxbPrice.Size = new System.Drawing.Size(131, 26);
            this.ER_TxbPrice.TabIndex = 62;
            this.ER_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ER_TxbPrice.TextChanged += new System.EventHandler(this.TxbPrice_TextChanged);
            this.ER_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // ER_LabOrdQty
            // 
            this.ER_LabOrdQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_LabOrdQty.AutoSize = true;
            this.ER_LabOrdQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabOrdQty.ForeColor = System.Drawing.Color.Gainsboro;
            this.ER_LabOrdQty.Location = new System.Drawing.Point(393, 9);
            this.ER_LabOrdQty.Name = "ER_LabOrdQty";
            this.ER_LabOrdQty.Size = new System.Drawing.Size(104, 21);
            this.ER_LabOrdQty.TabIndex = 112;
            this.ER_LabOrdQty.Text = "委託 數量";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.37736F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tableLayoutPanel13.Controls.Add(this.ER_LabStockName, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.ER_TxbStockNo, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(190, 43);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(187, 32);
            this.tableLayoutPanel13.TabIndex = 116;
            // 
            // ER_LabStockName
            // 
            this.ER_LabStockName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_LabStockName.AutoSize = true;
            this.ER_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabStockName.Location = new System.Drawing.Point(72, 5);
            this.ER_LabStockName.Name = "ER_LabStockName";
            this.ER_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.ER_LabStockName.TabIndex = 1002;
            this.ER_LabStockName.Text = "股票名稱";
            // 
            // ER_TxbStockNo
            // 
            this.ER_TxbStockNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ER_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.ER_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ER_TxbStockNo.Location = new System.Drawing.Point(3, 3);
            this.ER_TxbStockNo.Name = "ER_TxbStockNo";
            this.ER_TxbStockNo.Size = new System.Drawing.Size(49, 26);
            this.ER_TxbStockNo.TabIndex = 64;
            this.ER_TxbStockNo.TextChanged += new System.EventHandler(this.TxbStockNo_TextChanged);
            this.ER_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label75
            // 
            this.label75.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label75.ForeColor = System.Drawing.Color.Gainsboro;
            this.label75.Location = new System.Drawing.Point(99, 9);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(76, 21);
            this.label75.TabIndex = 115;
            this.label75.Text = "交易別";
            // 
            // label113
            // 
            this.label113.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label113.ForeColor = System.Drawing.Color.Gainsboro;
            this.label113.Location = new System.Drawing.Point(201, 9);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(164, 21);
            this.label113.TabIndex = 1;
            this.label113.Text = "股票代號及名稱";
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Controls.Add(this.ER_LabOrdType, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.ER_TxbOrdType, 0, 0);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(705, 43);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(145, 32);
            this.tableLayoutPanel17.TabIndex = 1005;
            // 
            // ER_LabOrdType
            // 
            this.ER_LabOrdType.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ER_LabOrdType.AutoSize = true;
            this.ER_LabOrdType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabOrdType.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabOrdType.Location = new System.Drawing.Point(75, 5);
            this.ER_LabOrdType.Name = "ER_LabOrdType";
            this.ER_LabOrdType.Size = new System.Drawing.Size(54, 21);
            this.ER_LabOrdType.TabIndex = 1005;
            this.ER_LabOrdType.Text = "ROD";
            // 
            // ER_TxbOrdType
            // 
            this.ER_TxbOrdType.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ER_TxbOrdType.BackColor = System.Drawing.Color.Black;
            this.ER_TxbOrdType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ER_TxbOrdType.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_TxbOrdType.ForeColor = System.Drawing.Color.Lime;
            this.ER_TxbOrdType.Location = new System.Drawing.Point(42, 3);
            this.ER_TxbOrdType.Name = "ER_TxbOrdType";
            this.ER_TxbOrdType.Size = new System.Drawing.Size(27, 26);
            this.ER_TxbOrdType.TabIndex = 61;
            this.ER_TxbOrdType.Text = "0";
            this.ER_TxbOrdType.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ER_TxbOrdType.TextChanged += new System.EventHandler(this.TxbOrdType_TextChanged);
            this.ER_TxbOrdType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.ER_TxbOrdType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.ER_TxbOrdType.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label111.ForeColor = System.Drawing.Color.Gold;
            this.label111.Location = new System.Drawing.Point(24, 9);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(327, 16);
            this.label111.TabIndex = 141;
            this.label111.Text = "<<< 錯帳功能 委託資料輸入[集中市場] >>>";
            // 
            // ER_LabTDate
            // 
            this.ER_LabTDate.AutoSize = true;
            this.ER_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabTDate.Location = new System.Drawing.Point(921, 10);
            this.ER_LabTDate.Name = "ER_LabTDate";
            this.ER_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.ER_LabTDate.TabIndex = 136;
            this.ER_LabTDate.Text = "1090107";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label77.ForeColor = System.Drawing.Color.Gold;
            this.label77.Location = new System.Drawing.Point(800, 10);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(101, 19);
            this.label77.TabIndex = 135;
            this.label77.Text = "交易日期 :";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label81.ForeColor = System.Drawing.Color.Gainsboro;
            this.label81.Location = new System.Drawing.Point(415, 10);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(138, 21);
            this.label81.TabIndex = 134;
            this.label81.Text = "證券商代號 : ";
            // 
            // ER_LabBHNO
            // 
            this.ER_LabBHNO.AutoSize = true;
            this.ER_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ER_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.ER_LabBHNO.Location = new System.Drawing.Point(559, 10);
            this.ER_LabBHNO.Name = "ER_LabBHNO";
            this.ER_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.ER_LabBHNO.TabIndex = 133;
            this.ER_LabBHNO.Text = " 8450";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label137.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label137.ForeColor = System.Drawing.Color.Gold;
            this.label137.Location = new System.Drawing.Point(3, 3);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(332, 27);
            this.label137.TabIndex = 180;
            this.label137.Text = "<<非錯帳交易委託時間 >>";
            // 
            // Emst
            // 
            this.Emst.Controls.Add(this.panel_Emst);
            this.Emst.Location = new System.Drawing.Point(4, 26);
            this.Emst.Name = "Emst";
            this.Emst.Padding = new System.Windows.Forms.Padding(3);
            this.Emst.Size = new System.Drawing.Size(1053, 364);
            this.Emst.TabIndex = 9;
            this.Emst.Text = "興櫃交易";
            this.Emst.UseVisualStyleBackColor = true;
            // 
            // panel_Emst
            // 
            this.panel_Emst.BackColor = System.Drawing.Color.Black;
            this.panel_Emst.Controls.Add(this.EM_Message);
            this.panel_Emst.Controls.Add(this.EM_LanWarText);
            this.panel_Emst.Controls.Add(this.EM_LabCCodeText);
            this.panel_Emst.Controls.Add(this.EM_LabStockState);
            this.panel_Emst.Controls.Add(this.EM_CkbFixedCSEQ);
            this.panel_Emst.Controls.Add(this.label161);
            this.panel_Emst.Controls.Add(this.button62);
            this.panel_Emst.Controls.Add(this.button61);
            this.panel_Emst.Controls.Add(this.button60);
            this.panel_Emst.Controls.Add(this.EM_LabCancelQty);
            this.panel_Emst.Controls.Add(this.EM_Search);
            this.panel_Emst.Controls.Add(this.EM_BasicPrice);
            this.panel_Emst.Controls.Add(this.label145);
            this.panel_Emst.Controls.Add(this.label140);
            this.panel_Emst.Controls.Add(this.EM_BuySell);
            this.panel_Emst.Controls.Add(this.label142);
            this.panel_Emst.Controls.Add(this.EM_LabelUnit);
            this.panel_Emst.Controls.Add(this.EM_TxbTERM);
            this.panel_Emst.Controls.Add(this.label160);
            this.panel_Emst.Controls.Add(this.EM_TxbCSEQ);
            this.panel_Emst.Controls.Add(this.label162);
            this.panel_Emst.Controls.Add(this.label163);
            this.panel_Emst.Controls.Add(this.EM_LabTDate);
            this.panel_Emst.Controls.Add(this.label165);
            this.panel_Emst.Controls.Add(this.label166);
            this.panel_Emst.Controls.Add(this.label171);
            this.panel_Emst.Controls.Add(this.label172);
            this.panel_Emst.Controls.Add(this.label173);
            this.panel_Emst.Controls.Add(this.EM_LabBHNO);
            this.panel_Emst.Controls.Add(this.label175);
            this.panel_Emst.Controls.Add(this.label176);
            this.panel_Emst.Controls.Add(this.EM_Sales);
            this.panel_Emst.Controls.Add(this.label177);
            this.panel_Emst.Controls.Add(this.EM_TxbDSEQ);
            this.panel_Emst.Controls.Add(this.button63);
            this.panel_Emst.Controls.Add(this.button68);
            this.panel_Emst.Controls.Add(this.button69);
            this.panel_Emst.Controls.Add(this.label178);
            this.panel_Emst.Controls.Add(this.button71);
            this.panel_Emst.Controls.Add(this.button72);
            this.panel_Emst.Controls.Add(this.button73);
            this.panel_Emst.Controls.Add(this.label181);
            this.panel_Emst.Controls.Add(this.EM_LabCSEQName);
            this.panel_Emst.Controls.Add(this.EM_TxbPrice);
            this.panel_Emst.Controls.Add(this.EM_TxbStockQty);
            this.panel_Emst.Controls.Add(this.EM_LabStockName);
            this.panel_Emst.Controls.Add(this.EM_TxbStockNo);
            this.panel_Emst.Controls.Add(this.label185);
            this.panel_Emst.Controls.Add(this.button75);
            this.panel_Emst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Emst.Font = new System.Drawing.Font("標楷體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_Emst.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel_Emst.Location = new System.Drawing.Point(3, 3);
            this.panel_Emst.Name = "panel_Emst";
            this.panel_Emst.Size = new System.Drawing.Size(1047, 358);
            this.panel_Emst.TabIndex = 102;
            this.panel_Emst.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_Emst_MouseClick);
            // 
            // EM_Message
            // 
            this.EM_Message.AutoSize = true;
            this.EM_Message.BackColor = System.Drawing.Color.Red;
            this.EM_Message.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_Message.ForeColor = System.Drawing.Color.Yellow;
            this.EM_Message.Location = new System.Drawing.Point(18, 260);
            this.EM_Message.Name = "EM_Message";
            this.EM_Message.Size = new System.Drawing.Size(98, 21);
            this.EM_Message.TabIndex = 1001;
            this.EM_Message.Text = "我是訊息";
            // 
            // EM_LanWarText
            // 
            this.EM_LanWarText.AutoSize = true;
            this.EM_LanWarText.BackColor = System.Drawing.Color.Red;
            this.EM_LanWarText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.EM_LanWarText.Location = new System.Drawing.Point(18, 234);
            this.EM_LanWarText.Name = "EM_LanWarText";
            this.EM_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.EM_LanWarText.TabIndex = 1001;
            this.EM_LanWarText.Text = "警示訊息";
            // 
            // EM_LabCCodeText
            // 
            this.EM_LabCCodeText.AutoSize = true;
            this.EM_LabCCodeText.BackColor = System.Drawing.Color.Black;
            this.EM_LabCCodeText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabCCodeText.ForeColor = System.Drawing.Color.Gold;
            this.EM_LabCCodeText.Location = new System.Drawing.Point(265, 200);
            this.EM_LabCCodeText.Name = "EM_LabCCodeText";
            this.EM_LabCCodeText.Size = new System.Drawing.Size(182, 21);
            this.EM_LabCCodeText.TabIndex = 6573;
            this.EM_LabCCodeText.Text = "[  客戶開戶狀態  ]";
            // 
            // EM_LabStockState
            // 
            this.EM_LabStockState.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabStockState.ForeColor = System.Drawing.Color.Red;
            this.EM_LabStockState.Location = new System.Drawing.Point(119, 140);
            this.EM_LabStockState.Name = "EM_LabStockState";
            this.EM_LabStockState.Size = new System.Drawing.Size(154, 26);
            this.EM_LabStockState.TabIndex = 6572;
            this.EM_LabStockState.Text = "不可信用交易_可現沖";
            this.EM_LabStockState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EM_CkbFixedCSEQ
            // 
            this.EM_CkbFixedCSEQ.AutoSize = true;
            this.EM_CkbFixedCSEQ.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_CkbFixedCSEQ.ForeColor = System.Drawing.Color.Gainsboro;
            this.EM_CkbFixedCSEQ.Location = new System.Drawing.Point(808, 100);
            this.EM_CkbFixedCSEQ.Name = "EM_CkbFixedCSEQ";
            this.EM_CkbFixedCSEQ.Size = new System.Drawing.Size(168, 23);
            this.EM_CkbFixedCSEQ.TabIndex = 6571;
            this.EM_CkbFixedCSEQ.TabStop = false;
            this.EM_CkbFixedCSEQ.Text = "固定委託人帳號";
            this.EM_CkbFixedCSEQ.UseVisualStyleBackColor = true;
            this.EM_CkbFixedCSEQ.CheckedChanged += new System.EventHandler(this.CkbFixedCSEQ_CheckedChanged);
            // 
            // label161
            // 
            this.label161.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label161.AutoSize = true;
            this.label161.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label161.ForeColor = System.Drawing.Color.Gainsboro;
            this.label161.Location = new System.Drawing.Point(0, 270);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(2072, 16);
            this.label161.TabIndex = 132;
            this.label161.Text = resources.GetString("label161.Text");
            this.label161.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.Black;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button62.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button62.ForeColor = System.Drawing.Color.Gainsboro;
            this.button62.Location = new System.Drawing.Point(406, 310);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(129, 30);
            this.button62.TabIndex = 6570;
            this.button62.TabStop = false;
            this.button62.Text = "F8 部分取消";
            this.button62.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Black;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button61.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button61.ForeColor = System.Drawing.Color.Gainsboro;
            this.button61.Location = new System.Drawing.Point(406, 280);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(110, 30);
            this.button61.TabIndex = 6569;
            this.button61.TabStop = false;
            this.button61.Text = "F9 改價";
            this.button61.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Black;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button60.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button60.ForeColor = System.Drawing.Color.Gainsboro;
            this.button60.Location = new System.Drawing.Point(150, 310);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(203, 30);
            this.button60.TabIndex = 6568;
            this.button60.TabStop = false;
            this.button60.Text = "F12 查詢";
            this.button60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button60.UseVisualStyleBackColor = false;
            // 
            // EM_LabCancelQty
            // 
            this.EM_LabCancelQty.AutoSize = true;
            this.EM_LabCancelQty.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabCancelQty.Location = new System.Drawing.Point(618, 165);
            this.EM_LabCancelQty.Name = "EM_LabCancelQty";
            this.EM_LabCancelQty.Size = new System.Drawing.Size(21, 21);
            this.EM_LabCancelQty.TabIndex = 6567;
            this.EM_LabCancelQty.Text = "0";
            this.EM_LabCancelQty.Visible = false;
            // 
            // EM_Search
            // 
            this.EM_Search.AutoSize = true;
            this.EM_Search.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_Search.ForeColor = System.Drawing.Color.Lime;
            this.EM_Search.Location = new System.Drawing.Point(500, 250);
            this.EM_Search.Name = "EM_Search";
            this.EM_Search.Size = new System.Drawing.Size(98, 21);
            this.EM_Search.TabIndex = 6564;
            this.EM_Search.Text = "查詢結果";
            // 
            // EM_BasicPrice
            // 
            this.EM_BasicPrice.AutoSize = true;
            this.EM_BasicPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_BasicPrice.ForeColor = System.Drawing.Color.Lime;
            this.EM_BasicPrice.Location = new System.Drawing.Point(317, 165);
            this.EM_BasicPrice.Name = "EM_BasicPrice";
            this.EM_BasicPrice.Size = new System.Drawing.Size(21, 21);
            this.EM_BasicPrice.TabIndex = 6563;
            this.EM_BasicPrice.Text = "0";
            this.EM_BasicPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label145
            // 
            this.label145.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label145.ForeColor = System.Drawing.Color.Gainsboro;
            this.label145.Location = new System.Drawing.Point(0, 80);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(2072, 16);
            this.label145.TabIndex = 1009;
            this.label145.Text = resources.GetString("label145.Text");
            this.label145.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label140
            // 
            this.label140.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label140.ForeColor = System.Drawing.Color.Gainsboro;
            this.label140.Location = new System.Drawing.Point(0, 220);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(2072, 16);
            this.label140.TabIndex = 1008;
            this.label140.Text = resources.GetString("label140.Text");
            this.label140.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // EM_BuySell
            // 
            this.EM_BuySell.BackColor = System.Drawing.Color.Black;
            this.EM_BuySell.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_BuySell.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_BuySell.ForeColor = System.Drawing.Color.Lime;
            this.EM_BuySell.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_BuySell.Location = new System.Drawing.Point(900, 160);
            this.EM_BuySell.Name = "EM_BuySell";
            this.EM_BuySell.Size = new System.Drawing.Size(85, 26);
            this.EM_BuySell.TabIndex = 1006;
            this.EM_BuySell.TabStop = false;
            this.EM_BuySell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label142.Location = new System.Drawing.Point(900, 140);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(76, 21);
            this.label142.TabIndex = 1005;
            this.label142.Text = "買賣別";
            // 
            // EM_LabelUnit
            // 
            this.EM_LabelUnit.AutoSize = true;
            this.EM_LabelUnit.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabelUnit.Location = new System.Drawing.Point(580, 165);
            this.EM_LabelUnit.Name = "EM_LabelUnit";
            this.EM_LabelUnit.Size = new System.Drawing.Size(32, 21);
            this.EM_LabelUnit.TabIndex = 163;
            this.EM_LabelUnit.Tag = "0";
            this.EM_LabelUnit.Text = "張";
            // 
            // EM_TxbTERM
            // 
            this.EM_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.EM_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbTERM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbTERM.Location = new System.Drawing.Point(515, 55);
            this.EM_TxbTERM.MaxLength = 1;
            this.EM_TxbTERM.Name = "EM_TxbTERM";
            this.EM_TxbTERM.Size = new System.Drawing.Size(20, 26);
            this.EM_TxbTERM.TabIndex = 6;
            this.EM_TxbTERM.Text = "V";
            this.EM_TxbTERM.TextChanged += new System.EventHandler(this.TxbTERM_TextChanged);
            this.EM_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label160.Location = new System.Drawing.Point(534, 53);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(18, 21);
            this.label160.TabIndex = 134;
            this.label160.Text = "-";
            // 
            // EM_TxbCSEQ
            // 
            this.EM_TxbCSEQ.BackColor = System.Drawing.Color.Black;
            this.EM_TxbCSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbCSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbCSEQ.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbCSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbCSEQ.Location = new System.Drawing.Point(373, 100);
            this.EM_TxbCSEQ.MaxLength = 7;
            this.EM_TxbCSEQ.Name = "EM_TxbCSEQ";
            this.EM_TxbCSEQ.Size = new System.Drawing.Size(120, 26);
            this.EM_TxbCSEQ.TabIndex = 4;
            this.EM_TxbCSEQ.TextChanged += new System.EventHandler(this.TxbCSEQ_TextChanged);
            this.EM_TxbCSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbCSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbCSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label162
            // 
            this.label162.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label162.AutoSize = true;
            this.label162.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label162.ForeColor = System.Drawing.Color.Gainsboro;
            this.label162.Location = new System.Drawing.Point(0, 120);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(2072, 16);
            this.label162.TabIndex = 131;
            this.label162.Text = resources.GetString("label162.Text");
            this.label162.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label163
            // 
            this.label163.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label163.AutoSize = true;
            this.label163.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label163.ForeColor = System.Drawing.Color.Gainsboro;
            this.label163.Location = new System.Drawing.Point(0, 30);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(2072, 16);
            this.label163.TabIndex = 130;
            this.label163.Text = resources.GetString("label163.Text");
            this.label163.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // EM_LabTDate
            // 
            this.EM_LabTDate.AutoSize = true;
            this.EM_LabTDate.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.EM_LabTDate.Location = new System.Drawing.Point(921, 9);
            this.EM_LabTDate.Name = "EM_LabTDate";
            this.EM_LabTDate.Size = new System.Drawing.Size(86, 19);
            this.EM_LabTDate.TabIndex = 129;
            this.EM_LabTDate.Text = "1090107";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Font = new System.Drawing.Font("細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label165.ForeColor = System.Drawing.Color.Gold;
            this.label165.Location = new System.Drawing.Point(800, 9);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(115, 19);
            this.label165.TabIndex = 128;
            this.label165.Text = "交易日期 :";
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label166.ForeColor = System.Drawing.Color.Gold;
            this.label166.Location = new System.Drawing.Point(24, 9);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(234, 16);
            this.label166.TabIndex = 127;
            this.label166.Text = "<<< 委託輸入[興櫃市場] >>>";
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label171.Location = new System.Drawing.Point(265, 140);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(76, 21);
            this.label171.TabIndex = 67;
            this.label171.Text = "基準價";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label172.Location = new System.Drawing.Point(24, 140);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(98, 21);
            this.label172.TabIndex = 65;
            this.label172.Text = "股票代號";
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label173.ForeColor = System.Drawing.Color.Gainsboro;
            this.label173.Location = new System.Drawing.Point(24, 55);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(132, 21);
            this.label173.TabIndex = 63;
            this.label173.Text = "證券商代號: ";
            // 
            // EM_LabBHNO
            // 
            this.EM_LabBHNO.AutoSize = true;
            this.EM_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.EM_LabBHNO.Location = new System.Drawing.Point(162, 55);
            this.EM_LabBHNO.Name = "EM_LabBHNO";
            this.EM_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.EM_LabBHNO.TabIndex = 44;
            this.EM_LabBHNO.Text = " 8455";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label175.ForeColor = System.Drawing.Color.Gainsboro;
            this.label175.Location = new System.Drawing.Point(402, 55);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(110, 21);
            this.label175.TabIndex = 58;
            this.label175.Text = "委託序號 :";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label176.Location = new System.Drawing.Point(500, 140);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(76, 21);
            this.label176.TabIndex = 62;
            this.label176.Text = "委託數";
            // 
            // EM_Sales
            // 
            this.EM_Sales.BackColor = System.Drawing.Color.Black;
            this.EM_Sales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_Sales.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_Sales.ForeColor = System.Drawing.Color.Lime;
            this.EM_Sales.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_Sales.Location = new System.Drawing.Point(112, 100);
            this.EM_Sales.Name = "EM_Sales";
            this.EM_Sales.ReadOnly = true;
            this.EM_Sales.Size = new System.Drawing.Size(69, 26);
            this.EM_Sales.TabIndex = 7;
            this.EM_Sales.TabStop = false;
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label177.Location = new System.Drawing.Point(24, 100);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(82, 21);
            this.label177.TabIndex = 60;
            this.label177.Text = "營業員:";
            // 
            // EM_TxbDSEQ
            // 
            this.EM_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.EM_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbDSEQ.Location = new System.Drawing.Point(553, 55);
            this.EM_TxbDSEQ.MaxLength = 4;
            this.EM_TxbDSEQ.Name = "EM_TxbDSEQ";
            this.EM_TxbDSEQ.Size = new System.Drawing.Size(55, 26);
            this.EM_TxbDSEQ.TabIndex = 5;
            this.EM_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EM_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.EM_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Black;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button63.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button63.ForeColor = System.Drawing.Color.Gainsboro;
            this.button63.Location = new System.Drawing.Point(800, 309);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(140, 30);
            this.button63.TabIndex = 105;
            this.button63.TabStop = false;
            this.button63.Text = "*強行跳號";
            this.button63.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Black;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button68.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button68.ForeColor = System.Drawing.Color.Gainsboro;
            this.button68.Location = new System.Drawing.Point(800, 280);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(140, 30);
            this.button68.TabIndex = 105;
            this.button68.TabStop = false;
            this.button68.Text = "ESC 結束";
            this.button68.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.Black;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button69.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button69.ForeColor = System.Drawing.Color.Gainsboro;
            this.button69.Location = new System.Drawing.Point(620, 310);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(178, 30);
            this.button69.TabIndex = 110;
            this.button69.TabStop = false;
            this.button69.Text = "SF7 零/整股切換";
            this.button69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button69.UseVisualStyleBackColor = false;
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label178.Location = new System.Drawing.Point(700, 140);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(98, 21);
            this.label178.TabIndex = 50;
            this.label178.Text = "委託單價";
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Black;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button71.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button71.ForeColor = System.Drawing.Color.Gainsboro;
            this.button71.Location = new System.Drawing.Point(24, 310);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(110, 30);
            this.button71.TabIndex = 106;
            this.button71.TabStop = false;
            this.button71.Text = "SF4 刪單";
            this.button71.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Black;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button72.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button72.ForeColor = System.Drawing.Color.Lime;
            this.button72.Location = new System.Drawing.Point(150, 280);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(110, 30);
            this.button72.TabIndex = 101;
            this.button72.TabStop = false;
            this.button72.Text = "F16 賣出";
            this.button72.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.Black;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button73.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button73.ForeColor = System.Drawing.Color.Red;
            this.button73.Location = new System.Drawing.Point(24, 280);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(110, 30);
            this.button73.TabIndex = 100;
            this.button73.TabStop = false;
            this.button73.Text = "F1 買進";
            this.button73.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button73.UseVisualStyleBackColor = false;
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label181.ForeColor = System.Drawing.Color.Gainsboro;
            this.label181.Location = new System.Drawing.Point(265, 100);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(110, 21);
            this.label181.TabIndex = 38;
            this.label181.Text = "客戶帳號 :";
            // 
            // EM_LabCSEQName
            // 
            this.EM_LabCSEQName.AutoSize = true;
            this.EM_LabCSEQName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabCSEQName.ForeColor = System.Drawing.Color.Lime;
            this.EM_LabCSEQName.Location = new System.Drawing.Point(500, 100);
            this.EM_LabCSEQName.Name = "EM_LabCSEQName";
            this.EM_LabCSEQName.Size = new System.Drawing.Size(98, 21);
            this.EM_LabCSEQName.TabIndex = 37;
            this.EM_LabCSEQName.Text = "客戶名稱";
            // 
            // EM_TxbPrice
            // 
            this.EM_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.EM_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbPrice.Location = new System.Drawing.Point(700, 165);
            this.EM_TxbPrice.MaxLength = 7;
            this.EM_TxbPrice.Name = "EM_TxbPrice";
            this.EM_TxbPrice.Size = new System.Drawing.Size(98, 26);
            this.EM_TxbPrice.TabIndex = 1;
            this.EM_TxbPrice.Text = " ";
            this.EM_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EM_TxbPrice.TextChanged += new System.EventHandler(this.EM_TxbStockPrice_TextChange);
            this.EM_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // EM_TxbStockQty
            // 
            this.EM_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.EM_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbStockQty.CausesValidation = false;
            this.EM_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbStockQty.Location = new System.Drawing.Point(500, 165);
            this.EM_TxbStockQty.MaxLength = 4;
            this.EM_TxbStockQty.Name = "EM_TxbStockQty";
            this.EM_TxbStockQty.Size = new System.Drawing.Size(74, 26);
            this.EM_TxbStockQty.TabIndex = 2;
            this.EM_TxbStockQty.Text = " ";
            this.EM_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EM_TxbStockQty.TextChanged += new System.EventHandler(this.EM_TxbStockQty_TextChanged);
            this.EM_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // EM_LabStockName
            // 
            this.EM_LabStockName.AutoSize = true;
            this.EM_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.EM_LabStockName.Location = new System.Drawing.Point(24, 200);
            this.EM_LabStockName.Name = "EM_LabStockName";
            this.EM_LabStockName.Size = new System.Drawing.Size(16, 21);
            this.EM_LabStockName.TabIndex = 6562;
            this.EM_LabStockName.Text = " ";
            // 
            // EM_TxbStockNo
            // 
            this.EM_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.EM_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EM_TxbStockNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.EM_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EM_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.EM_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EM_TxbStockNo.Location = new System.Drawing.Point(28, 165);
            this.EM_TxbStockNo.MaxLength = 6;
            this.EM_TxbStockNo.Name = "EM_TxbStockNo";
            this.EM_TxbStockNo.Size = new System.Drawing.Size(85, 26);
            this.EM_TxbStockNo.TabIndex = 3;
            this.EM_TxbStockNo.TextChanged += new System.EventHandler(this.EM_TxbStockNo_TextChanged);
            this.EM_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EM_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EM_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label185.ForeColor = System.Drawing.Color.Red;
            this.label185.Location = new System.Drawing.Point(829, 55);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(116, 21);
            this.label185.TabIndex = 10;
            this.label185.Text = "[登錄中... ]";
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.Black;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button75.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button75.ForeColor = System.Drawing.Color.Gainsboro;
            this.button75.Location = new System.Drawing.Point(620, 280);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(165, 30);
            this.button75.TabIndex = 104;
            this.button75.TabStop = false;
            this.button75.Text = "F5 清除畫面";
            this.button75.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button75.UseVisualStyleBackColor = false;
            // 
            // EmstErrAccount
            // 
            this.EmstErrAccount.Controls.Add(this.panel_EmstErrAccount);
            this.EmstErrAccount.ForeColor = System.Drawing.Color.Red;
            this.EmstErrAccount.Location = new System.Drawing.Point(4, 26);
            this.EmstErrAccount.Name = "EmstErrAccount";
            this.EmstErrAccount.Padding = new System.Windows.Forms.Padding(3);
            this.EmstErrAccount.Size = new System.Drawing.Size(1053, 364);
            this.EmstErrAccount.TabIndex = 10;
            this.EmstErrAccount.Text = "興櫃錯帳";
            // 
            // panel_EmstErrAccount
            // 
            this.panel_EmstErrAccount.BackColor = System.Drawing.Color.Black;
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LanWarText);
            this.panel_EmstErrAccount.Controls.Add(this.tableLayoutPanel26);
            this.panel_EmstErrAccount.Controls.Add(this.tableLayoutPanel28);
            this.panel_EmstErrAccount.Controls.Add(this.button66);
            this.panel_EmstErrAccount.Controls.Add(this.button67);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_BtnForceOrder);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_BtnForceClear);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LabInfo);
            this.panel_EmstErrAccount.Controls.Add(this.label189);
            this.panel_EmstErrAccount.Controls.Add(this.label190);
            this.panel_EmstErrAccount.Controls.Add(this.tableLayoutPanel33);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LabQueryDealQty);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LabQueryLaveQty);
            this.panel_EmstErrAccount.Controls.Add(this.label193);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LabTDate);
            this.panel_EmstErrAccount.Controls.Add(this.label195);
            this.panel_EmstErrAccount.Controls.Add(this.label196);
            this.panel_EmstErrAccount.Controls.Add(this.EMER_LabBHNO);
            this.panel_EmstErrAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_EmstErrAccount.Location = new System.Drawing.Point(3, 3);
            this.panel_EmstErrAccount.Name = "panel_EmstErrAccount";
            this.panel_EmstErrAccount.Size = new System.Drawing.Size(1047, 358);
            this.panel_EmstErrAccount.TabIndex = 2;
            this.panel_EmstErrAccount.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_EmstErrAccount_MouseClick);
            // 
            // EMER_LanWarText
            // 
            this.EMER_LanWarText.AutoSize = true;
            this.EMER_LanWarText.BackColor = System.Drawing.Color.Red;
            this.EMER_LanWarText.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LanWarText.ForeColor = System.Drawing.Color.Yellow;
            this.EMER_LanWarText.Location = new System.Drawing.Point(15, 170);
            this.EMER_LanWarText.Name = "EMER_LanWarText";
            this.EMER_LanWarText.Size = new System.Drawing.Size(98, 21);
            this.EMER_LanWarText.TabIndex = 1008;
            this.EMER_LanWarText.Text = "警示訊息";
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(15, 45);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(1012, 44);
            this.tableLayoutPanel26.TabIndex = 1007;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 5;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 91.16279F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.83721F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 490F));
            this.tableLayoutPanel27.Controls.Add(this.EMER_TxbTERM, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.label151, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.EMER_TxbDSEQ, 3, 0);
            this.tableLayoutPanel27.Controls.Add(this.label158, 2, 0);
            this.tableLayoutPanel27.Controls.Add(this.label164, 4, 0);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(1004, 36);
            this.tableLayoutPanel27.TabIndex = 0;
            // 
            // EMER_TxbTERM
            // 
            this.EMER_TxbTERM.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.EMER_TxbTERM.BackColor = System.Drawing.Color.Black;
            this.EMER_TxbTERM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_TxbTERM.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_TxbTERM.ForeColor = System.Drawing.Color.Lime;
            this.EMER_TxbTERM.Location = new System.Drawing.Point(298, 5);
            this.EMER_TxbTERM.Name = "EMER_TxbTERM";
            this.EMER_TxbTERM.Size = new System.Drawing.Size(22, 26);
            this.EMER_TxbTERM.TabIndex = 67;
            this.EMER_TxbTERM.TabStop = false;
            this.EMER_TxbTERM.Text = "X";
            this.EMER_TxbTERM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EMER_TxbTERM.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.EMER_TxbTERM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EMER_TxbTERM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EMER_TxbTERM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label151
            // 
            this.label151.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label151.AutoSize = true;
            this.label151.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label151.ForeColor = System.Drawing.Color.White;
            this.label151.Location = new System.Drawing.Point(292, 7);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(0, 21);
            this.label151.TabIndex = 0;
            // 
            // EMER_TxbDSEQ
            // 
            this.EMER_TxbDSEQ.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.EMER_TxbDSEQ.BackColor = System.Drawing.Color.Black;
            this.EMER_TxbDSEQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_TxbDSEQ.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_TxbDSEQ.ForeColor = System.Drawing.Color.Lime;
            this.EMER_TxbDSEQ.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EMER_TxbDSEQ.Location = new System.Drawing.Point(365, 5);
            this.EMER_TxbDSEQ.MaxLength = 4;
            this.EMER_TxbDSEQ.Name = "EMER_TxbDSEQ";
            this.EMER_TxbDSEQ.Size = new System.Drawing.Size(105, 26);
            this.EMER_TxbDSEQ.TabIndex = 65;
            this.EMER_TxbDSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EMER_TxbDSEQ.TextChanged += new System.EventHandler(this.TxbDSEQ_TextChanged);
            this.EMER_TxbDSEQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EMER_TxbDSEQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EMER_TxbDSEQ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label158
            // 
            this.label158.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label158.AutoSize = true;
            this.label158.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label158.ForeColor = System.Drawing.Color.White;
            this.label158.Location = new System.Drawing.Point(333, 7);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(18, 21);
            this.label158.TabIndex = 5;
            this.label158.Text = "-";
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.ForeColor = System.Drawing.Color.Red;
            this.label164.Location = new System.Drawing.Point(516, 0);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(314, 32);
            this.label164.TabIndex = 68;
            this.label164.Text = "＊新單不須自行輸入委託序號＊\r\n＊進行查詢才需輸入對應委託序號查詢＊\r\n";
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel28.ColumnCount = 5;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.4342F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.04424F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.43125F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.09031F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 380F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel28.Controls.Add(this.tableLayoutPanel29, 3, 1);
            this.tableLayoutPanel28.Controls.Add(this.label170, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.label179, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.label180, 4, 0);
            this.tableLayoutPanel28.Controls.Add(this.EMER_TxbPrice, 4, 1);
            this.tableLayoutPanel28.Controls.Add(this.label182, 3, 0);
            this.tableLayoutPanel28.Controls.Add(this.tableLayoutPanel31, 1, 1);
            this.tableLayoutPanel28.Controls.Add(this.label186, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label146, 2, 0);
            this.tableLayoutPanel28.Controls.Add(this.EMER_BasicPrice, 2, 1);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(15, 88);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(1012, 79);
            this.tableLayoutPanel28.TabIndex = 1006;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 3;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 91F));
            this.tableLayoutPanel29.Controls.Add(this.label168, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.EMER_TxbStockQty, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.EMER_LabelUnit, 2, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(469, 43);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(157, 32);
            this.tableLayoutPanel29.TabIndex = 1007;
            // 
            // label168
            // 
            this.label168.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label168.AutoSize = true;
            this.label168.Font = new System.Drawing.Font("新細明體", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label168.ForeColor = System.Drawing.Color.Gainsboro;
            this.label168.Location = new System.Drawing.Point(49, 5);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(0, 21);
            this.label168.TabIndex = 1006;
            // 
            // EMER_TxbStockQty
            // 
            this.EMER_TxbStockQty.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.EMER_TxbStockQty.BackColor = System.Drawing.Color.Black;
            this.EMER_TxbStockQty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_TxbStockQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_TxbStockQty.ForeColor = System.Drawing.Color.Lime;
            this.EMER_TxbStockQty.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EMER_TxbStockQty.Location = new System.Drawing.Point(3, 3);
            this.EMER_TxbStockQty.MaxLength = 4;
            this.EMER_TxbStockQty.Name = "EMER_TxbStockQty";
            this.EMER_TxbStockQty.Size = new System.Drawing.Size(40, 26);
            this.EMER_TxbStockQty.TabIndex = 63;
            this.EMER_TxbStockQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EMER_TxbStockQty.TextChanged += new System.EventHandler(this.EM_TxbStockQty_TextChanged);
            this.EMER_TxbStockQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EMER_TxbStockQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EMER_TxbStockQty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // EMER_LabelUnit
            // 
            this.EMER_LabelUnit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EMER_LabelUnit.AutoSize = true;
            this.EMER_LabelUnit.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabelUnit.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabelUnit.Location = new System.Drawing.Point(95, 5);
            this.EMER_LabelUnit.Name = "EMER_LabelUnit";
            this.EMER_LabelUnit.Size = new System.Drawing.Size(32, 21);
            this.EMER_LabelUnit.TabIndex = 1002;
            this.EMER_LabelUnit.Text = "張";
            // 
            // label170
            // 
            this.label170.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label170.AutoSize = true;
            this.label170.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label170.ForeColor = System.Drawing.Color.Gainsboro;
            this.label170.Location = new System.Drawing.Point(55, 9);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(0, 21);
            this.label170.TabIndex = 0;
            // 
            // label179
            // 
            this.label179.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label179.AutoSize = true;
            this.label179.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label179.ForeColor = System.Drawing.Color.Lime;
            this.label179.Location = new System.Drawing.Point(12, 48);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(87, 21);
            this.label179.TabIndex = 114;
            this.label179.Text = "0003332";
            // 
            // label180
            // 
            this.label180.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label180.AutoSize = true;
            this.label180.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label180.ForeColor = System.Drawing.Color.Gainsboro;
            this.label180.Location = new System.Drawing.Point(768, 9);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(104, 21);
            this.label180.TabIndex = 113;
            this.label180.Text = "委託 價格";
            // 
            // EMER_TxbPrice
            // 
            this.EMER_TxbPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EMER_TxbPrice.BackColor = System.Drawing.Color.Black;
            this.EMER_TxbPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_TxbPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_TxbPrice.ForeColor = System.Drawing.Color.Lime;
            this.EMER_TxbPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EMER_TxbPrice.Location = new System.Drawing.Point(755, 46);
            this.EMER_TxbPrice.MaxLength = 7;
            this.EMER_TxbPrice.Name = "EMER_TxbPrice";
            this.EMER_TxbPrice.Size = new System.Drawing.Size(131, 26);
            this.EMER_TxbPrice.TabIndex = 62;
            this.EMER_TxbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EMER_TxbPrice.TextChanged += new System.EventHandler(this.EM_TxbStockPrice_TextChange);
            this.EMER_TxbPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EMER_TxbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EMER_TxbPrice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label182
            // 
            this.label182.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label182.AutoSize = true;
            this.label182.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label182.ForeColor = System.Drawing.Color.Gainsboro;
            this.label182.Location = new System.Drawing.Point(495, 9);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(104, 21);
            this.label182.TabIndex = 112;
            this.label182.Text = "委託 數量";
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.37736F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tableLayoutPanel31.Controls.Add(this.EMER_LabStockName, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.EMER_TxbStockNo, 0, 0);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(114, 43);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(238, 32);
            this.tableLayoutPanel31.TabIndex = 1008;
            // 
            // EMER_LabStockName
            // 
            this.EMER_LabStockName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EMER_LabStockName.AutoSize = true;
            this.EMER_LabStockName.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabStockName.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabStockName.Location = new System.Drawing.Point(123, 5);
            this.EMER_LabStockName.Name = "EMER_LabStockName";
            this.EMER_LabStockName.Size = new System.Drawing.Size(98, 21);
            this.EMER_LabStockName.TabIndex = 1002;
            this.EMER_LabStockName.Text = "股票名稱";
            // 
            // EMER_TxbStockNo
            // 
            this.EMER_TxbStockNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EMER_TxbStockNo.BackColor = System.Drawing.Color.Black;
            this.EMER_TxbStockNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_TxbStockNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.EMER_TxbStockNo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_TxbStockNo.ForeColor = System.Drawing.Color.Lime;
            this.EMER_TxbStockNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EMER_TxbStockNo.Location = new System.Drawing.Point(6, 3);
            this.EMER_TxbStockNo.MaxLength = 6;
            this.EMER_TxbStockNo.Name = "EMER_TxbStockNo";
            this.EMER_TxbStockNo.Size = new System.Drawing.Size(93, 26);
            this.EMER_TxbStockNo.TabIndex = 64;
            this.EMER_TxbStockNo.TextChanged += new System.EventHandler(this.EM_TxbStockNo_TextChanged);
            this.EMER_TxbStockNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderPageControl_KeyDown);
            this.EMER_TxbStockNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Control_KeyPress);
            this.EMER_TxbStockNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Control_KeyUp);
            // 
            // label186
            // 
            this.label186.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label186.AutoSize = true;
            this.label186.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label186.ForeColor = System.Drawing.Color.Gainsboro;
            this.label186.Location = new System.Drawing.Point(151, 9);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(164, 21);
            this.label186.TabIndex = 1;
            this.label186.Text = "股票代號及名稱";
            // 
            // label146
            // 
            this.label146.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label146.ForeColor = System.Drawing.Color.Gainsboro;
            this.label146.Location = new System.Drawing.Point(372, 9);
            this.label146.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(76, 21);
            this.label146.TabIndex = 149;
            this.label146.Text = "基準價";
            // 
            // EMER_BasicPrice
            // 
            this.EMER_BasicPrice.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.EMER_BasicPrice.BackColor = System.Drawing.Color.Black;
            this.EMER_BasicPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EMER_BasicPrice.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_BasicPrice.ForeColor = System.Drawing.Color.Lime;
            this.EMER_BasicPrice.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EMER_BasicPrice.Location = new System.Drawing.Point(388, 46);
            this.EMER_BasicPrice.Margin = new System.Windows.Forms.Padding(2);
            this.EMER_BasicPrice.Name = "EMER_BasicPrice";
            this.EMER_BasicPrice.Size = new System.Drawing.Size(75, 26);
            this.EMER_BasicPrice.TabIndex = 150;
            this.EMER_BasicPrice.TabStop = false;
            this.EMER_BasicPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.Red;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button66.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button66.ForeColor = System.Drawing.Color.Yellow;
            this.button66.Location = new System.Drawing.Point(885, 189);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(89, 34);
            this.button66.TabIndex = 1005;
            this.button66.TabStop = false;
            this.button66.Text = "F9 改量";
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Visible = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Red;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button67.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button67.ForeColor = System.Drawing.Color.Yellow;
            this.button67.Location = new System.Drawing.Point(790, 189);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(95, 34);
            this.button67.TabIndex = 1004;
            this.button67.TabStop = false;
            this.button67.Text = "F10 返回";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Visible = false;
            // 
            // EMER_BtnForceOrder
            // 
            this.EMER_BtnForceOrder.BackColor = System.Drawing.Color.Red;
            this.EMER_BtnForceOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EMER_BtnForceOrder.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_BtnForceOrder.ForeColor = System.Drawing.Color.Yellow;
            this.EMER_BtnForceOrder.Location = new System.Drawing.Point(695, 189);
            this.EMER_BtnForceOrder.Name = "EMER_BtnForceOrder";
            this.EMER_BtnForceOrder.Size = new System.Drawing.Size(95, 34);
            this.EMER_BtnForceOrder.TabIndex = 1003;
            this.EMER_BtnForceOrder.TabStop = false;
            this.EMER_BtnForceOrder.Text = "SF8 強行";
            this.EMER_BtnForceOrder.UseVisualStyleBackColor = false;
            this.EMER_BtnForceOrder.Visible = false;
            // 
            // EMER_BtnForceClear
            // 
            this.EMER_BtnForceClear.BackColor = System.Drawing.Color.Red;
            this.EMER_BtnForceClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EMER_BtnForceClear.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_BtnForceClear.ForeColor = System.Drawing.Color.Yellow;
            this.EMER_BtnForceClear.Location = new System.Drawing.Point(606, 189);
            this.EMER_BtnForceClear.Name = "EMER_BtnForceClear";
            this.EMER_BtnForceClear.Size = new System.Drawing.Size(89, 34);
            this.EMER_BtnForceClear.TabIndex = 1002;
            this.EMER_BtnForceClear.TabStop = false;
            this.EMER_BtnForceClear.Text = "F5 清除";
            this.EMER_BtnForceClear.UseVisualStyleBackColor = false;
            this.EMER_BtnForceClear.Visible = false;
            // 
            // EMER_LabInfo
            // 
            this.EMER_LabInfo.AutoSize = true;
            this.EMER_LabInfo.BackColor = System.Drawing.Color.Red;
            this.EMER_LabInfo.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabInfo.ForeColor = System.Drawing.Color.Yellow;
            this.EMER_LabInfo.Location = new System.Drawing.Point(15, 195);
            this.EMER_LabInfo.Name = "EMER_LabInfo";
            this.EMER_LabInfo.Size = new System.Drawing.Size(98, 21);
            this.EMER_LabInfo.TabIndex = 167;
            this.EMER_LabInfo.Text = "相關訊息";
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label189.ForeColor = System.Drawing.Color.Gainsboro;
            this.label189.Location = new System.Drawing.Point(657, 235);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(132, 21);
            this.label189.TabIndex = 166;
            this.label189.Text = "成交已回報 :";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label190.ForeColor = System.Drawing.Color.Gainsboro;
            this.label190.Location = new System.Drawing.Point(43, 235);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(132, 21);
            this.label190.TabIndex = 165;
            this.label190.Text = "未搓合股數 :";
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel33.ColumnCount = 4;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel33.Controls.Add(this.button78, 0, 1);
            this.tableLayoutPanel33.Controls.Add(this.button79, 0, 0);
            this.tableLayoutPanel33.Controls.Add(this.button80, 3, 1);
            this.tableLayoutPanel33.Controls.Add(this.button81, 3, 0);
            this.tableLayoutPanel33.Controls.Add(this.button82, 2, 0);
            this.tableLayoutPanel33.Controls.Add(this.button83, 2, 1);
            this.tableLayoutPanel33.Controls.Add(this.button84, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.button85, 1, 1);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(15, 259);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 2;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(1012, 85);
            this.tableLayoutPanel33.TabIndex = 148;
            // 
            // button78
            // 
            this.button78.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button78.BackColor = System.Drawing.Color.Black;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button78.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button78.ForeColor = System.Drawing.Color.Gainsboro;
            this.button78.Location = new System.Drawing.Point(4, 48);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(110, 30);
            this.button78.TabIndex = 99;
            this.button78.TabStop = false;
            this.button78.Text = "*強行跳號";
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button79.BackColor = System.Drawing.Color.Black;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button79.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button79.ForeColor = System.Drawing.Color.Gainsboro;
            this.button79.Location = new System.Drawing.Point(4, 6);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(170, 30);
            this.button79.TabIndex = 97;
            this.button79.TabStop = false;
            this.button79.Text = "SF7 零/整股切換";
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button80.BackColor = System.Drawing.Color.Black;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button80.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button80.ForeColor = System.Drawing.Color.Gainsboro;
            this.button80.Location = new System.Drawing.Point(760, 48);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(148, 30);
            this.button80.TabIndex = 4;
            this.button80.TabStop = false;
            this.button80.Text = "SF4  全部取消";
            this.button80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button81.BackColor = System.Drawing.Color.Black;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button81.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button81.ForeColor = System.Drawing.Color.Gainsboro;
            this.button81.Location = new System.Drawing.Point(760, 6);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(225, 30);
            this.button81.TabIndex = 7;
            this.button81.TabStop = false;
            this.button81.Text = "F8 部分取消 / F9 改價";
            this.button81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button82.BackColor = System.Drawing.Color.Black;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button82.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button82.ForeColor = System.Drawing.Color.Gainsboro;
            this.button82.Location = new System.Drawing.Point(508, 6);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(130, 30);
            this.button82.TabIndex = 6;
            this.button82.TabStop = false;
            this.button82.Text = "F12 查 詢";
            this.button82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button83.BackColor = System.Drawing.Color.Black;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button83.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button83.ForeColor = System.Drawing.Color.Gainsboro;
            this.button83.Location = new System.Drawing.Point(508, 48);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(150, 30);
            this.button83.TabIndex = 3;
            this.button83.TabStop = false;
            this.button83.Text = "F5 清除畫面";
            this.button83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button84.BackColor = System.Drawing.Color.Black;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button84.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button84.ForeColor = System.Drawing.Color.Red;
            this.button84.Location = new System.Drawing.Point(256, 6);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(150, 30);
            this.button84.TabIndex = 2;
            this.button84.TabStop = false;
            this.button84.Text = "F1 買入";
            this.button84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button85.BackColor = System.Drawing.Color.Black;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button85.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button85.ForeColor = System.Drawing.Color.Lime;
            this.button85.Location = new System.Drawing.Point(256, 48);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(150, 30);
            this.button85.TabIndex = 12;
            this.button85.TabStop = false;
            this.button85.Text = "F16 賣出";
            this.button85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button85.UseVisualStyleBackColor = false;
            // 
            // EMER_LabQueryDealQty
            // 
            this.EMER_LabQueryDealQty.AutoSize = true;
            this.EMER_LabQueryDealQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabQueryDealQty.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabQueryDealQty.Location = new System.Drawing.Point(795, 235);
            this.EMER_LabQueryDealQty.Name = "EMER_LabQueryDealQty";
            this.EMER_LabQueryDealQty.Size = new System.Drawing.Size(46, 21);
            this.EMER_LabQueryDealQty.TabIndex = 147;
            this.EMER_LabQueryDealQty.Text = "      ";
            // 
            // EMER_LabQueryLaveQty
            // 
            this.EMER_LabQueryLaveQty.AutoSize = true;
            this.EMER_LabQueryLaveQty.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabQueryLaveQty.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabQueryLaveQty.Location = new System.Drawing.Point(181, 235);
            this.EMER_LabQueryLaveQty.Name = "EMER_LabQueryLaveQty";
            this.EMER_LabQueryLaveQty.Size = new System.Drawing.Size(64, 21);
            this.EMER_LabQueryLaveQty.TabIndex = 146;
            this.EMER_LabQueryLaveQty.Text = "         ";
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label193.ForeColor = System.Drawing.Color.Gold;
            this.label193.Location = new System.Drawing.Point(24, 9);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(327, 16);
            this.label193.TabIndex = 141;
            this.label193.Text = "<<< 興櫃錯帳 委託資料輸入[興櫃市場] >>>";
            // 
            // EMER_LabTDate
            // 
            this.EMER_LabTDate.AutoSize = true;
            this.EMER_LabTDate.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabTDate.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabTDate.Location = new System.Drawing.Point(921, 10);
            this.EMER_LabTDate.Name = "EMER_LabTDate";
            this.EMER_LabTDate.Size = new System.Drawing.Size(79, 19);
            this.EMER_LabTDate.TabIndex = 136;
            this.EMER_LabTDate.Text = "1090107";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label195.ForeColor = System.Drawing.Color.Gold;
            this.label195.Location = new System.Drawing.Point(800, 10);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(101, 19);
            this.label195.TabIndex = 135;
            this.label195.Text = "交易日期 :";
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label196.ForeColor = System.Drawing.Color.Gainsboro;
            this.label196.Location = new System.Drawing.Point(415, 10);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(138, 21);
            this.label196.TabIndex = 134;
            this.label196.Text = "證券商代號 : ";
            // 
            // EMER_LabBHNO
            // 
            this.EMER_LabBHNO.AutoSize = true;
            this.EMER_LabBHNO.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EMER_LabBHNO.ForeColor = System.Drawing.Color.Lime;
            this.EMER_LabBHNO.Location = new System.Drawing.Point(559, 10);
            this.EMER_LabBHNO.Name = "EMER_LabBHNO";
            this.EMER_LabBHNO.Size = new System.Drawing.Size(60, 21);
            this.EMER_LabBHNO.TabIndex = 133;
            this.EMER_LabBHNO.Text = " 8450";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.設定ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1067, 29);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 設定ToolStripMenuItem
            // 
            this.設定ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.委託設定ToolStripMenuItem,
            this.上傳LogToolStripMenuItem});
            this.設定ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.設定ToolStripMenuItem.Name = "設定ToolStripMenuItem";
            this.設定ToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.設定ToolStripMenuItem.Text = "設定";
            // 
            // 委託設定ToolStripMenuItem
            // 
            this.委託設定ToolStripMenuItem.Name = "委託設定ToolStripMenuItem";
            this.委託設定ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.委託設定ToolStripMenuItem.Text = "委託設定";
            this.委託設定ToolStripMenuItem.Click += new System.EventHandler(this.委託設定ToolStripMenuItem_Click);
            // 
            // 上傳LogToolStripMenuItem
            // 
            this.上傳LogToolStripMenuItem.Name = "上傳LogToolStripMenuItem";
            this.上傳LogToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.上傳LogToolStripMenuItem.Text = "上傳Log";
            this.上傳LogToolStripMenuItem.Click += new System.EventHandler(this.上傳LogToolStripMenuItem_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button13.ForeColor = System.Drawing.Color.Red;
            this.button13.Location = new System.Drawing.Point(222, 250);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(80, 30);
            this.button13.TabIndex = 2;
            this.button13.TabStop = false;
            this.button13.Text = "F1買進";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button12.ForeColor = System.Drawing.Color.Black;
            this.button12.Location = new System.Drawing.Point(442, 250);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(90, 30);
            this.button12.TabIndex = 3;
            this.button12.TabStop = false;
            this.button12.Text = "F5清除畫面";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button11.ForeColor = System.Drawing.Color.Green;
            this.button11.Location = new System.Drawing.Point(222, 286);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(80, 30);
            this.button11.TabIndex = 4;
            this.button11.TabStop = false;
            this.button11.Text = "F16賣出";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox3.Location = new System.Drawing.Point(945, 51);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(146, 20);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.TabStop = false;
            this.checkBox3.Text = "固定委託人帳號";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(712, 54);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 16);
            this.label39.TabIndex = 8;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox7.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox7.ForeColor = System.Drawing.Color.Lime;
            this.textBox7.Location = new System.Drawing.Point(802, 52);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(30, 27);
            this.textBox7.TabIndex = 6;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label38.ForeColor = System.Drawing.Color.Lime;
            this.label38.Location = new System.Drawing.Point(840, 57);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(25, 16);
            this.label38.TabIndex = 10;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox6.ForeColor = System.Drawing.Color.Lime;
            this.textBox6.Location = new System.Drawing.Point(19, 146);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(85, 27);
            this.textBox6.TabIndex = 5;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label37.ForeColor = System.Drawing.Color.Lime;
            this.label37.Location = new System.Drawing.Point(110, 150);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(76, 16);
            this.label37.TabIndex = 14;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox5.CausesValidation = false;
            this.textBox5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox5.ForeColor = System.Drawing.Color.Lime;
            this.textBox5.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox5.Location = new System.Drawing.Point(522, 144);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(75, 27);
            this.textBox5.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.ForeColor = System.Drawing.Color.Lime;
            this.textBox4.Location = new System.Drawing.Point(715, 146);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(69, 27);
            this.textBox4.TabIndex = 2;
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(784, 146);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 28);
            this.vScrollBar1.TabIndex = 24;
            this.vScrollBar1.Value = 11;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label36.Location = new System.Drawing.Point(808, 149);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(24, 16);
            this.label36.TabIndex = 25;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label35.ForeColor = System.Drawing.Color.Lime;
            this.label35.Location = new System.Drawing.Point(262, 153);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(15, 13);
            this.label35.TabIndex = 29;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label34.ForeColor = System.Drawing.Color.Lime;
            this.label34.Location = new System.Drawing.Point(538, 54);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(76, 16);
            this.label34.TabIndex = 37;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(351, 54);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 16);
            this.label33.TabIndex = 38;
            // 
            // checkBox2
            // 
            this.checkBox2.Location = new System.Drawing.Point(20, 250);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(104, 24);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "123456";
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button10.ForeColor = System.Drawing.Color.Red;
            this.button10.Location = new System.Drawing.Point(20, 250);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(80, 30);
            this.button10.TabIndex = 41;
            this.button10.TabStop = false;
            this.button10.Text = "F3漲停";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(108, 250);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(80, 30);
            this.button9.TabIndex = 42;
            this.button9.TabStop = false;
            this.button9.Text = "F7平盤價";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button8.ForeColor = System.Drawing.Color.Green;
            this.button8.Location = new System.Drawing.Point(19, 287);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(80, 30);
            this.button8.TabIndex = 43;
            this.button8.TabStop = false;
            this.button8.Text = "F14跌停";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox1.Location = new System.Drawing.Point(945, 77);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(61, 20);
            this.checkBox1.TabIndex = 45;
            this.checkBox1.TabStop = false;
            this.checkBox1.Text = "拆單";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(123, 121);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(189, 14);
            this.label32.TabIndex = 47;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(18, 176);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(462, 15);
            this.label31.TabIndex = 48;
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.BackColor = System.Drawing.SystemColors.Desktop;
            this.comboBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.ForeColor = System.Drawing.Color.Lime;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(402, 51);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 7;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("新細明體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label30.Location = new System.Drawing.Point(712, 119);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 16);
            this.label30.TabIndex = 50;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(323, 287);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(80, 30);
            this.button7.TabIndex = 52;
            this.button7.TabStop = false;
            this.button7.Text = "SF4刪單";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(442, 286);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 30);
            this.button6.TabIndex = 53;
            this.button6.TabStop = false;
            this.button6.Text = "F8部分取消";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(629, 250);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(94, 30);
            this.button5.TabIndex = 55;
            this.button5.TabStop = false;
            this.button5.Text = "F10委託類別";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(546, 250);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(68, 30);
            this.button4.TabIndex = 56;
            this.button4.TabStop = false;
            this.button4.Text = "F9改價";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.ForeColor = System.Drawing.Color.Lime;
            this.textBox3.Location = new System.Drawing.Point(209, 49);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(79, 27);
            this.textBox3.TabIndex = 8;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(945, 118);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(86, 30);
            this.button3.TabIndex = 59;
            this.button3.TabStop = false;
            this.button3.Text = "委託設定";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label29.Location = new System.Drawing.Point(351, 204);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(64, 16);
            this.label29.TabIndex = 60;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.ForeColor = System.Drawing.Color.Lime;
            this.textBox2.Location = new System.Drawing.Point(417, 199);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(69, 27);
            this.textBox2.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("新細明體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label28.Location = new System.Drawing.Point(521, 118);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(81, 16);
            this.label28.TabIndex = 62;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(122, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 16);
            this.label27.TabIndex = 58;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label26.ForeColor = System.Drawing.Color.Lime;
            this.label26.Location = new System.Drawing.Point(553, 8);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 16);
            this.label26.TabIndex = 44;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label25.Location = new System.Drawing.Point(439, 8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(108, 16);
            this.label25.TabIndex = 63;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.Location = new System.Drawing.Point(2, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(1094, 19);
            this.label24.TabIndex = 64;
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("新細明體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label23.Location = new System.Drawing.Point(24, 118);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 16);
            this.label23.TabIndex = 65;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("新細明體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label22.Location = new System.Drawing.Point(351, 118);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 16);
            this.label22.TabIndex = 67;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(24, 204);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 16);
            this.label21.TabIndex = 68;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(712, 204);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(103, 16);
            this.label20.TabIndex = 69;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(2, 225);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(1094, 19);
            this.label19.TabIndex = 70;
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(2, 94);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(1094, 19);
            this.label18.TabIndex = 71;
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(323, 250);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 30);
            this.button2.TabIndex = 72;
            this.button2.TabStop = false;
            this.button2.Text = "F12查詢";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox1.CausesValidation = false;
            this.textBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.ForeColor = System.Drawing.Color.Lime;
            this.textBox1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox1.Location = new System.Drawing.Point(350, 144);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(59, 27);
            this.textBox1.TabIndex = 73;
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // panel_Recover
            // 
            this.panel_Recover.BackColor = System.Drawing.SystemColors.Control;
            this.panel_Recover.Controls.Add(this.LabRecoverInfo);
            this.panel_Recover.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_Recover.Location = new System.Drawing.Point(4, 29);
            this.panel_Recover.Name = "panel_Recover";
            this.panel_Recover.Size = new System.Drawing.Size(344, 25);
            this.panel_Recover.TabIndex = 1007;
            this.panel_Recover.UseWaitCursor = true;
            this.panel_Recover.Visible = false;
            // 
            // LabRecoverInfo
            // 
            this.LabRecoverInfo.AutoSize = true;
            this.LabRecoverInfo.BackColor = System.Drawing.SystemColors.Control;
            this.LabRecoverInfo.ForeColor = System.Drawing.Color.Red;
            this.LabRecoverInfo.Location = new System.Drawing.Point(0, 0);
            this.LabRecoverInfo.Name = "LabRecoverInfo";
            this.LabRecoverInfo.Size = new System.Drawing.Size(336, 21);
            this.LabRecoverInfo.TabIndex = 0;
            this.LabRecoverInfo.Text = "分公司當日回報回補中.. 請稍後﹒";
            this.LabRecoverInfo.UseWaitCursor = true;
            this.LabRecoverInfo.Visible = false;
            // 
            // EmTradingCheck
            // 
            this.EmTradingCheck.AutoSize = true;
            this.EmTradingCheck.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.EmTradingCheck.ForeColor = System.Drawing.Color.Red;
            this.EmTradingCheck.Location = new System.Drawing.Point(346, 33);
            this.EmTradingCheck.Name = "EmTradingCheck";
            this.EmTradingCheck.Size = new System.Drawing.Size(108, 16);
            this.EmTradingCheck.TabIndex = 1009;
            this.EmTradingCheck.Text = "興櫃連線中...";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 674);
            this.Controls.Add(this.EmTradingCheck);
            this.Controls.Add(this.panel_Recover);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tsMainStatus);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "新KeyIn下單系統(含興櫃)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form_KeyDown);
            this.tsMainStatus.ResumeLayout(false);
            this.tsMainStatus.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tab_Request.ResumeLayout(false);
            this.tabPagKeyIn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVEmstOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVKeyIn)).EndInit();
            this.tabPagRequest.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVEmstRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVRequest)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPagDeal.ResumeLayout(false);
            this.tabLayPanel_DealView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVCheckDeal)).EndInit();
            this.tabLayPanel_DealQueryControl.ResumeLayout(false);
            this.tabLayPanel_DealQueryControl.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabLayOutChkQueryInfo.ResumeLayout(false);
            this.tabLayOutChkQueryInfo.PerformLayout();
            this.tabPagPassiveRequest.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVPasRequest)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tab_Order.ResumeLayout(false);
            this.RoundLot.ResumeLayout(false);
            this.RoundLot.PerformLayout();
            this.panel_RoundLot.ResumeLayout(false);
            this.panel_RoundLot.PerformLayout();
            this.OddLot.ResumeLayout(false);
            this.OddLot.PerformLayout();
            this.panel_OddLot.ResumeLayout(false);
            this.panel_OddLot.PerformLayout();
            this.FixedPrice.ResumeLayout(false);
            this.FixedPrice.PerformLayout();
            this.panel_FixedPrice.ResumeLayout(false);
            this.panel_FixedPrice.PerformLayout();
            this.StockBorrow.ResumeLayout(false);
            this.StockBorrow.PerformLayout();
            this.panel_StockBorrow.ResumeLayout(false);
            this.panel_StockBorrow.PerformLayout();
            this.StockPurchase.ResumeLayout(false);
            this.StockPurchase.PerformLayout();
            this.panel_StockPurchase.ResumeLayout(false);
            this.panel_StockPurchase.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.StockPurchase2.ResumeLayout(false);
            this.StockPurchase2.PerformLayout();
            this.panel_StockPurchase2.ResumeLayout(false);
            this.panel_StockPurchase2.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.StockAuction.ResumeLayout(false);
            this.StockAuction.PerformLayout();
            this.panel_StockAuction.ResumeLayout(false);
            this.panel_StockAuction.PerformLayout();
            this.ErrAccount.ResumeLayout(false);
            this.ErrAccount.PerformLayout();
            this.panel_ErrAccout.ResumeLayout(false);
            this.panel_ErrAccout.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.Emst.ResumeLayout(false);
            this.panel_Emst.ResumeLayout(false);
            this.panel_Emst.PerformLayout();
            this.EmstErrAccount.ResumeLayout(false);
            this.panel_EmstErrAccount.ResumeLayout(false);
            this.panel_EmstErrAccount.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel31.PerformLayout();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel_Recover.ResumeLayout(false);
            this.panel_Recover.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip tsMainStatus;
        public System.Windows.Forms.ToolStripLabel tslSOrderSend;
        public System.Windows.Forms.ToolStripLabel tslPushServer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel_RoundLot;
        public System.Windows.Forms.TextBox RL_TxbSale;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Button RL_RtnPersonalSetup;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.TextBox RL_TxbDSEQ;
        private System.Windows.Forms.Button RL_BtnChgPrice;
        private System.Windows.Forms.Button RL_BtnOType;
        private System.Windows.Forms.Button RL_BtnChgOrder;
        private System.Windows.Forms.Button RL_BtnDelOrder;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label RL_LabFinanceState;
        public System.Windows.Forms.Label RL_LabStockState;
        public System.Windows.Forms.Label RL_LabBHNO;
        private System.Windows.Forms.Button RL_BtnFallPrice;
        private System.Windows.Forms.Button RL_BtnCPrice;
        private System.Windows.Forms.Button RL_BtnRiskPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label RL_LabCSEQName;
        public System.Windows.Forms.Label RL_LabMType;
        public System.Windows.Forms.TextBox RL_TxbPrice;
        public System.Windows.Forms.TextBox RL_TxbStockQty;
        public System.Windows.Forms.Label RL_LabStockName;
        public System.Windows.Forms.TextBox RL_TxbStockNo;
        private System.Windows.Forms.CheckBox RL_CkbFixedCSEQ;
        private System.Windows.Forms.Button RL_BtnSell;
        private System.Windows.Forms.Button RL_BtnClear;
        public System.Windows.Forms.Button RL_BtnBuy;
        private System.Windows.Forms.TabControl tab_Request;
        private System.Windows.Forms.TabPage tabPagRequest;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.DataGridView DGVRequest;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label labDealAmt;
        public System.Windows.Forms.Label labDealQty;
        public System.Windows.Forms.Label labRequestAmt;
        public System.Windows.Forms.Label labRequestQty;
        public System.Windows.Forms.Label labCount;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton rbNoDeal;
        private System.Windows.Forms.RadioButton rbDeal;
        private System.Windows.Forms.RadioButton rbAll;
        private System.Windows.Forms.Button btnFilterClear;
        private System.Windows.Forms.Button btnFilterOK;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnMultiDeleAllCancel;
        private System.Windows.Forms.Button btnMultiDeleAllSelect;
        private System.Windows.Forms.Button btnMultiDeleAllOK;
        private System.Windows.Forms.TabPage tabPagDeal;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 設定ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 上傳LogToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel tSLEnvironment;
        private System.Windows.Forms.Label labECodeUnit;
        private System.Windows.Forms.TextBox txbFilterCSEQ;
        private System.Windows.Forms.TabControl tab_Order;
        private System.Windows.Forms.TabPage RoundLot;
        private System.Windows.Forms.TabPage FixedPrice;
        private System.Windows.Forms.Label RL_LabOType;
        public System.Windows.Forms.TextBox RL_TxbOType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button RL_BtnQuery;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox RL_TxbECode;
        private System.Windows.Forms.TabPage OddLot;
        private System.Windows.Forms.Panel panel_OddLot;
        public System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label39;
        public System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label38;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.Label label37;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Label label36;
        public System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.CheckBox checkBox1;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label29;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox OD_TxbECode;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        public System.Windows.Forms.Label OD_LabBHNO;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        public System.Windows.Forms.TextBox OD_TxbSale;
        private System.Windows.Forms.Label label48;
        public System.Windows.Forms.TextBox OD_TxbDSEQ;
        private System.Windows.Forms.Label label49;
        public System.Windows.Forms.Label OD_LabFinanceState;
        public System.Windows.Forms.Label OD_LabStockState;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label OD_LabCSEQName;
        public System.Windows.Forms.Label OD_LabMType;
        public System.Windows.Forms.TextBox OD_TxbPrice;
        public System.Windows.Forms.Label OD_LabStockName;
        public System.Windows.Forms.TextBox OD_TxbStockNo;
        private System.Windows.Forms.CheckBox OD_CkbFixedCSEQ;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TabPage tabPagKeyIn;
        private System.Windows.Forms.DataGridView DGVKeyIn;
        private System.Windows.Forms.Panel panel_FixedPrice;
        private System.Windows.Forms.Label RL_LabQueryDealQty;
        private System.Windows.Forms.Label RL_LabQueryLaveQty;
        private System.Windows.Forms.Label label60;
        public System.Windows.Forms.TextBox FP_TxbECode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label68;
        public System.Windows.Forms.Label FP_LabBHNO;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        public System.Windows.Forms.TextBox FP_TxbSale;
        private System.Windows.Forms.Label label72;
        public System.Windows.Forms.TextBox FP_TxbDSEQ;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button FP_BtnOType;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label73;
        public System.Windows.Forms.Label FP_LabFinanceState;
        public System.Windows.Forms.Label FP_LabStockState;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label FP_LabCSEQName;
        public System.Windows.Forms.Label FP_LabMType;
        public System.Windows.Forms.TextBox FP_TxbPrice;
        public System.Windows.Forms.Label FP_LabStockName;
        public System.Windows.Forms.TextBox FP_TxbStockNo;
        private System.Windows.Forms.Label FP_LabOType;
        public System.Windows.Forms.TextBox FP_TxbOType;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.CheckBox FP_CkbFixedCSEQ;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        public System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button RL_BtnSellFallTick;
        public System.Windows.Forms.Button RL_BtnBuyRiseTick;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label RL_LabTDate;
        private System.Windows.Forms.Label FP_LabTDate;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label OD_LabTDate;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        public System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        public System.Windows.Forms.DataGridView DGVCheckDeal;
        private System.Windows.Forms.Label OD_LabQueryLaveQty;
        private System.Windows.Forms.Label FP_LabQueryDealQty;
        private System.Windows.Forms.Label FP_LabQueryLaveQty;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.TextBox RL_TxbCSEQ;
        private System.Windows.Forms.TextBox OD_TxbCSEQ;
        private System.Windows.Forms.TextBox FP_TxbCSEQ;
        private System.Windows.Forms.ToolStripMenuItem 委託設定ToolStripMenuItem;
        private System.Windows.Forms.Button RL_BtnChangeTargetNo;
        private System.Windows.Forms.Button OD_BtnChangeTargetNo;
        private System.Windows.Forms.Button FP_BtnChangeTargetNo;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox RL_TxbTERM;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox OD_TxbTERM;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox FP_TxbTERM;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label OD_LabOrdErrMsg;
        private System.Windows.Forms.Label FP_LabOrdErrMsg;
        private System.Windows.Forms.TabPage StockBorrow;
        private System.Windows.Forms.TabPage StockPurchase;
        private System.Windows.Forms.TabPage StockAuction;
        private System.Windows.Forms.Label RL_LabOrdErrMsg;
        private System.Windows.Forms.Label SB_LabTDate;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label74;
        public System.Windows.Forms.Label SB_LabBHNO;
        private System.Windows.Forms.Label SP_LabTDate;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        public System.Windows.Forms.Label SP_LabBHNO;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox SB_TxbTERM;
        private System.Windows.Forms.TextBox SB_TxbDSEQ;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox SB_TxbBS;
        private System.Windows.Forms.TextBox SB_TxbPrice;
        private System.Windows.Forms.TextBox SB_TxbStockQty;
        private System.Windows.Forms.TextBox SB_TxbStockNo;
        private System.Windows.Forms.TextBox SB_TxbTDCC;
        private System.Windows.Forms.TextBox SB_TxbCSEQ;
        private System.Windows.Forms.TextBox SB_TxbSale;
        private System.Windows.Forms.Label SB_LabQueryLaveQty;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox SP_TxbTERM;
        private System.Windows.Forms.TextBox SP_TxbDSEQ;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox SP_TxbCSEQ;
        private System.Windows.Forms.TextBox SP_TxbStockQty;
        private System.Windows.Forms.TextBox SP_TxbPrice;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TextBox SP_TxbSerialNum;
        private System.Windows.Forms.TextBox SP_TxbStockNo;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label SP_LabQueryDealQty;
        private System.Windows.Forms.Label SP_LabQueryLaveQty;
        private System.Windows.Forms.Label SA_LabTDate;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label116;
        public System.Windows.Forms.Label SA_LabBHNO;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox SA_TxbDSEQ;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox SA_TxbTERM;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.TextBox SA_TxbCSEQ;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox SA_TxbPrice;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox SA_TxbStockQty;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.TextBox SA_TxbStockNo;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label SB_LabOrdErrMsg;
        private System.Windows.Forms.Label SA_LabQueryDealQty;
        private System.Windows.Forms.Label SA_LabQueryLaveQty;
        private System.Windows.Forms.Label RL_LabInfo;
        private System.Windows.Forms.Label OD_LabInfo;
        private System.Windows.Forms.Label FP_LabInfo;
        private System.Windows.Forms.Button RL_BtnForceClear;
        private System.Windows.Forms.Button RL_BtnForceReturn;
        private System.Windows.Forms.Button RL_BtnForceOrder;
        private System.Windows.Forms.Button RL_BtnForceChangeQty;
        private System.Windows.Forms.Button OD_BtnForceChangeQty;
        private System.Windows.Forms.Button OD_BtnForceReturn;
        private System.Windows.Forms.Button OD_BtnForceOrder;
        private System.Windows.Forms.Button OD_BtnForceClear;
        private System.Windows.Forms.Button FP_BtnForceChangeQty;
        private System.Windows.Forms.Button FP_BtnForceReturn;
        private System.Windows.Forms.Button FP_BtnForceOrder;
        private System.Windows.Forms.Button FP_BtnForceClear;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label FP_LabCancelQty;
        private System.Windows.Forms.Label RL_LabCancelQty;
        private System.Windows.Forms.Label OD_LabCancelQty;
        public System.Windows.Forms.TextBox OD_TxbStockQty;
        public System.Windows.Forms.TextBox FP_TxbStockQty;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Panel panel_StockAuction;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel_StockPurchase;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Panel panel_StockBorrow;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TableLayoutPanel tabLayPanel_DealView;
        private System.Windows.Forms.TableLayoutPanel tabLayPanel_DealQueryControl;
        private System.Windows.Forms.Button Btn_QueryDeal;
        private System.Windows.Forms.Label LabQueryDealTime;
        private System.Windows.Forms.Label FP_LanWarText;
        private System.Windows.Forms.Label RL_LanWarText;
        private System.Windows.Forms.Label OD_LanWarText;
        private System.Windows.Forms.TabPage ErrAccount;
        private System.Windows.Forms.Panel panel_ErrAccout;
        private System.Windows.Forms.Label ER_LabTDate;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label81;
        public System.Windows.Forms.Label ER_LabBHNO;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label ER_LabOrdQty;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label ER_LabErAccount;
        private System.Windows.Forms.TextBox ER_TxbPrice;
        private System.Windows.Forms.TextBox ER_TxbStockQty;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        public System.Windows.Forms.TextBox ER_TxbECode;
        private System.Windows.Forms.Label ER_LabECodeText;
        private System.Windows.Forms.Label ER_LabQueryDealQty;
        private System.Windows.Forms.Label ER_LabQueryLaveQty;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label ER_LabUnit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdbRL;
        private System.Windows.Forms.RadioButton rdbFP;
        private System.Windows.Forms.RadioButton rdbOD;
        private System.Windows.Forms.Label RL_LabCCodeText;
        private System.Windows.Forms.Label OD_LabCCodeText;
        private System.Windows.Forms.Label FP_LabCCodeText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.TextBox ER_TxbTERM;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox ER_TxbDSEQ;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label ER_LanWarText;
        private System.Windows.Forms.Label ER_LabInfo;
        private System.Windows.Forms.Button ER_BtnForceChangeQty;
        private System.Windows.Forms.Button ER_BtnForceReturn;
        private System.Windows.Forms.Button ER_BtnForceOrder;
        private System.Windows.Forms.Button ER_BtnForceClear;
        private System.Windows.Forms.Label ER_LabCancelQty;
        private System.Windows.Forms.Label SB_LabCancelQty;
        private System.Windows.Forms.Label SB_LabCCodeText;
        private System.Windows.Forms.Label SP_LabCCodeText;
        private System.Windows.Forms.Label SA_LabCCodeText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label SP_LabCancelQty;
        private System.Windows.Forms.Label SA_LabCancelQty;
        private System.Windows.Forms.TableLayoutPanel tabLayOutChkQueryInfo;
        private System.Windows.Forms.Label LabChkDealQT1;
        private System.Windows.Forms.Label LabChkDealQCount;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label LabChkDealQDSEQ;
        private System.Windows.Forms.Label LabChkDealQT2;
        private System.Windows.Forms.Label LabChkDealQT3;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label LabCheckFinishInfo;
        private System.Windows.Forms.Label LabChkDealQR3;
        private System.Windows.Forms.Label LabChkDealQR2;
        private System.Windows.Forms.Label LabChkDealQR1;
        private System.Windows.Forms.Label LabChkDealQR5;
        private System.Windows.Forms.Label LabChkDealQR4;
        private System.Windows.Forms.Label LabChkDealQT4;
        private System.Windows.Forms.Label LabChkDealQT5;
        public System.Windows.Forms.TextBox RL_TxbOrdType;
        private System.Windows.Forms.Label RL_LabOrdType;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label ER_LabOrdType;
        public System.Windows.Forms.TextBox ER_TxbOrdType;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label Lab_OrdTypeInfo;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Panel panel_Recover;
        private System.Windows.Forms.Label LabRecoverInfo;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBHNO_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCDI;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDSEQ_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCSEQ_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOType_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStock_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStockName_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBefChgQty_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrdQty_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrdPrice_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSide_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDealQty_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTimeInForce_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransTime_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colErrText_KeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ECode;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_BHNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colum_ECODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TimeInForce;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_OQTY;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_OTYPE;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_STOCK;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_STOCKNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_BS;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CheckStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DPRICE;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DQTY;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_AllDQTY;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colCheckDelete;
        private System.Windows.Forms.DataGridViewButtonColumn colDeleteOrder;
        private System.Windows.Forms.DataGridViewButtonColumn colChangeOrder;
        private System.Windows.Forms.DataGridViewButtonColumn colChangePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransactTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCusName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSTOCK;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSTOCKNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn colECODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSide;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSTATUS;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTimeInForce;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrdPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrdQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCancelQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDealQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDealPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn colText;
        private System.Windows.Forms.DataGridViewTextBoxColumn colClOrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColOrigin;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColLaveQty;
        private System.Windows.Forms.TextBox txbFilterDSEQ;
        private System.Windows.Forms.Label Lab_TodayLastFill;
        private System.Windows.Forms.CheckBox ChKSplitLot;
        private System.Windows.Forms.Label ER_LabStockName;
        private System.Windows.Forms.TextBox ER_TxbStockNo;
        private System.Windows.Forms.Label SA_LabStockName;
        private System.Windows.Forms.Label SA_LabCSEQName;
        private System.Windows.Forms.Label SP_LabStockName;
        private System.Windows.Forms.Label SP_LabCSEQName;
        private System.Windows.Forms.Label SB_LabStockName;
        private System.Windows.Forms.Label SB_LabCSEQName;
        private System.Windows.Forms.TabPage StockPurchase2;
        private System.Windows.Forms.Panel panel_StockPurchase2;
        private System.Windows.Forms.Label SP2_LabCCodeText;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label SP2_LabQueryDealQty;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label SP2_LabQueryLaveQty;
        private System.Windows.Forms.Button button58;
        public System.Windows.Forms.Label SP2_LabBHNO;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.TextBox SP2_TxbPrice;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label SP2_LabStockName;
        private System.Windows.Forms.TextBox SP2_TxbSerialNum;
        private System.Windows.Forms.TextBox SP2_TxbStockNo;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Label SP2_LabCSEQName;
        private System.Windows.Forms.TextBox SP2_TxbCSEQ;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Label SP2_LabCancelQty;
        private System.Windows.Forms.TextBox SP2_TxbStockQty;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.TextBox SP2_TxbTERM;
        private System.Windows.Forms.TextBox SP2_TxbDSEQ;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label SP2_LabTDate;
        private System.Windows.Forms.TabPage tabPagPassiveRequest;
        public System.Windows.Forms.DataGridView DGVPasRequest;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbPasFilterCSEQ;
        public System.Windows.Forms.Label labPasDealAmt;
        public System.Windows.Forms.Label labPasDealQty;
        public System.Windows.Forms.Label labPasRequestAmt;
        public System.Windows.Forms.Label labPasRequestQty;
        public System.Windows.Forms.Label labPasCount;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rbPasNoDeal;
        private System.Windows.Forms.RadioButton rbPasDeal;
        private System.Windows.Forms.RadioButton rbPasAll;
        private System.Windows.Forms.Button btnPasFilterClear;
        private System.Windows.Forms.Button btnPasFilterOK;
        private System.Windows.Forms.TextBox txbPasFilterDSEQ;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Button btnPasMultiDeleAllCancel;
        private System.Windows.Forms.Button btnPasMultiDeleAllSelect;
        private System.Windows.Forms.Button btnPasMultiDeleAllOK;
        private System.Windows.Forms.DataGridViewCheckBoxColumn col_CheckDelete;
        private System.Windows.Forms.DataGridViewButtonColumn col_DeleteOrder;
        private System.Windows.Forms.DataGridViewButtonColumn col_ChangeOrder;
        private System.Windows.Forms.DataGridViewButtonColumn col_ChangePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TransactTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__DSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__CSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CusName;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__STOCK;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__STOCKNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__ECODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn col__OType;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Side;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_STATUS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col__TimeInForce;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_OrdPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_OrdQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_CancelQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DealQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_DealPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Mtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_Text;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ClOrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Origin;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_LaveQty;
        private System.Windows.Forms.DataGridView DGVEmstOrder;
        public System.Windows.Forms.DataGridView DGVEmstRequest;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEmCheckDelete;
        private System.Windows.Forms.DataGridViewButtonColumn colEmDeleteBtn;
        private System.Windows.Forms.DataGridViewButtonColumn colEmChangeQtyBtn;
        private System.Windows.Forms.DataGridViewButtonColumn colEmChangePriceBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmDSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmCSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmCusName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmStockName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmSide;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmOrdPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmOrdQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmCancelQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmDealQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmDealPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.TabPage Emst;
        private System.Windows.Forms.Panel panel_Emst;
        private System.Windows.Forms.Label EM_LabCCodeText;
        public System.Windows.Forms.Label EM_LabStockState;
        private System.Windows.Forms.CheckBox EM_CkbFixedCSEQ;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Label EM_LabCancelQty;
        private System.Windows.Forms.Label EM_Search;
        public System.Windows.Forms.Label EM_BasicPrice;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label140;
        public System.Windows.Forms.TextBox EM_BuySell;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label EM_Message;
        private System.Windows.Forms.Label EM_LabelUnit;
        private System.Windows.Forms.TextBox EM_TxbTERM;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.TextBox EM_TxbCSEQ;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label EM_LabTDate;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        public System.Windows.Forms.Label EM_LabBHNO;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        public System.Windows.Forms.TextBox EM_Sales;
        private System.Windows.Forms.Label label177;
        public System.Windows.Forms.TextBox EM_TxbDSEQ;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label EM_LabCSEQName;
        public System.Windows.Forms.TextBox EM_TxbPrice;
        public System.Windows.Forms.TextBox EM_TxbStockQty;
        public System.Windows.Forms.Label EM_LabStockName;
        public System.Windows.Forms.TextBox EM_TxbStockNo;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.TabPage EmstErrAccount;
        private System.Windows.Forms.Panel panel_EmstErrAccount;
        private System.Windows.Forms.Label EMER_LanWarText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.TextBox EMER_TxbTERM;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.TextBox EMER_TxbDSEQ;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.TextBox EMER_TxbStockQty;
        private System.Windows.Forms.Label EMER_LabelUnit;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.TextBox EMER_TxbPrice;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label EMER_LabStockName;
        private System.Windows.Forms.TextBox EMER_TxbStockNo;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.TextBox EMER_BasicPrice;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button EMER_BtnForceOrder;
        private System.Windows.Forms.Button EMER_BtnForceClear;
        private System.Windows.Forms.Label EMER_LabInfo;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Label EMER_LabQueryDealQty;
        private System.Windows.Forms.Label EMER_LabQueryLaveQty;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label EMER_LabTDate;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        public System.Windows.Forms.Label EMER_LabBHNO;
        private System.Windows.Forms.Label EmTradingCheck;
        private System.Windows.Forms.Label EM_LanWarText;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrdQty_EMKeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDealQty_EMKeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransactTime_EMKeyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.Button btn_OpenFrmTimeSharing;
    }
}