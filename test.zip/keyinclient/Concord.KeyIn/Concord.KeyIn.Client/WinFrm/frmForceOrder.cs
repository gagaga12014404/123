﻿using Concord.SDK.Logging;
using Concord.SDK.Utility;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmForceOrder : Form
    {
        /// <summary>
        /// 是否確認完成
        /// </summary>
        public bool _Command = false;

        public frmForceOrder()
        {
            InitializeComponent();
        }

        public void Init()
        {
            TxbPassword.Text = "";
            _Command = false;
        }

        private void BtnPasswordCheck_Click(object sender, EventArgs e)
        {
            string[] parameters = { $"845{UserInfo._BHNO}", TxbPassword.Text };
            HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_CheckPWD", parameters);
            if (result.StatusCode != rCode.Success)
            {
                MessageBox.Show(result.CodeDesc, "密碼錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ConcordLogger.Logger.Info($"[Order] 萬能強制確認視窗 確認失敗: {result.CodeDesc}");
            }
            else
            {
                ConcordLogger.Logger.Info("[Order] 萬能強制確認視窗 確認送出");
                _Command = true; ;
                Hide();
            }
        }

        private void BtmCancel_Click(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("[Order] 萬能強制確認視窗 取消委託");
            _Command = false;
            Hide();
        }
    }
}
