﻿namespace Concord.KeyIn.Client
{
    partial class frmStockChangeConfirm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txbDSEQ = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.labUnit = new System.Windows.Forms.Label();
            this.labNoDealQty = new System.Windows.Forms.Label();
            this.nudChangeQTY = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.btnChangeOrder = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.labSale = new System.Windows.Forms.Label();
            this.labOrderType = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labRequestAmount = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.labStockNo = new System.Windows.Forms.Label();
            this.labPrice = new System.Windows.Forms.Label();
            this.labStockName = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.labMType = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.page_ChangeQty = new System.Windows.Forms.TabPage();
            this.page_ChangePrice = new System.Windows.Forms.TabPage();
            this.nudChangePrice = new System.Windows.Forms.NumericUpDown();
            this.btnChangePrice = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudChangeQTY)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.page_ChangeQty.SuspendLayout();
            this.page_ChangePrice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudChangePrice)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txbDSEQ);
            this.groupBox3.Controls.Add(this.Label2);
            this.groupBox3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(-1, 6);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(420, 64);
            this.groupBox3.TabIndex = 157;
            this.groupBox3.TabStop = false;
            // 
            // txbDSEQ
            // 
            this.txbDSEQ.Enabled = false;
            this.txbDSEQ.Location = new System.Drawing.Point(104, 23);
            this.txbDSEQ.Name = "txbDSEQ";
            this.txbDSEQ.Size = new System.Drawing.Size(100, 27);
            this.txbDSEQ.TabIndex = 20;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label2.Location = new System.Drawing.Point(9, 29);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(88, 16);
            this.Label2.TabIndex = 115;
            this.Label2.Text = "委託書號：";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label1.Location = new System.Drawing.Point(7, 45);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(104, 16);
            this.Label1.TabIndex = 112;
            this.Label1.Text = "請輸入數量：";
            // 
            // labUnit
            // 
            this.labUnit.AutoSize = true;
            this.labUnit.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labUnit.ForeColor = System.Drawing.Color.Blue;
            this.labUnit.Location = new System.Drawing.Point(194, 45);
            this.labUnit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labUnit.Name = "labUnit";
            this.labUnit.Size = new System.Drawing.Size(35, 16);
            this.labUnit.TabIndex = 134;
            this.labUnit.Text = "Unit";
            // 
            // labNoDealQty
            // 
            this.labNoDealQty.AutoSize = true;
            this.labNoDealQty.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labNoDealQty.ForeColor = System.Drawing.Color.Blue;
            this.labNoDealQty.Location = new System.Drawing.Point(92, 9);
            this.labNoDealQty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labNoDealQty.Name = "labNoDealQty";
            this.labNoDealQty.Size = new System.Drawing.Size(16, 16);
            this.labNoDealQty.TabIndex = 144;
            this.labNoDealQty.Text = "0";
            // 
            // nudChangeQTY
            // 
            this.nudChangeQTY.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.nudChangeQTY.Location = new System.Drawing.Point(119, 38);
            this.nudChangeQTY.Margin = new System.Windows.Forms.Padding(4);
            this.nudChangeQTY.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.nudChangeQTY.Name = "nudChangeQTY";
            this.nudChangeQTY.Size = new System.Drawing.Size(67, 27);
            this.nudChangeQTY.TabIndex = 110;
            this.nudChangeQTY.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(7, 9);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 16);
            this.label5.TabIndex = 143;
            this.label5.Text = "可改數量：";
            // 
            // btnChangeOrder
            // 
            this.btnChangeOrder.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnChangeOrder.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnChangeOrder.Location = new System.Drawing.Point(297, 39);
            this.btnChangeOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnChangeOrder.Name = "btnChangeOrder";
            this.btnChangeOrder.Size = new System.Drawing.Size(108, 35);
            this.btnChangeOrder.TabIndex = 113;
            this.btnChangeOrder.Text = "改量 (F8)";
            this.btnChangeOrder.UseVisualStyleBackColor = false;
            this.btnChangeOrder.Click += new System.EventHandler(this.btnChangeOrder_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCancel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Location = new System.Drawing.Point(116, 322);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(181, 35);
            this.btnCancel.TabIndex = 158;
            this.btnCancel.Text = "取消 (Esc)";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Label6);
            this.groupBox1.Controls.Add(this.labSale);
            this.groupBox1.Controls.Add(this.labOrderType);
            this.groupBox1.Controls.Add(this.Label8);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.labRequestAmount);
            this.groupBox1.Controls.Add(this.Label10);
            this.groupBox1.Controls.Add(this.labStockNo);
            this.groupBox1.Controls.Add(this.labPrice);
            this.groupBox1.Controls.Add(this.labStockName);
            this.groupBox1.Controls.Add(this.Label4);
            this.groupBox1.Controls.Add(this.labMType);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(-1, 70);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(420, 127);
            this.groupBox1.TabIndex = 156;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本資料";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label6.Location = new System.Drawing.Point(8, 27);
            this.Label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(88, 16);
            this.Label6.TabIndex = 119;
            this.Label6.Text = "股票代號：";
            // 
            // labSale
            // 
            this.labSale.AutoSize = true;
            this.labSale.ForeColor = System.Drawing.Color.Blue;
            this.labSale.Location = new System.Drawing.Point(300, 99);
            this.labSale.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labSale.Name = "labSale";
            this.labSale.Size = new System.Drawing.Size(32, 16);
            this.labSale.TabIndex = 140;
            this.labSale.Text = "123";
            // 
            // labOrderType
            // 
            this.labOrderType.AutoSize = true;
            this.labOrderType.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labOrderType.ForeColor = System.Drawing.Color.Blue;
            this.labOrderType.Location = new System.Drawing.Point(114, 63);
            this.labOrderType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labOrderType.Name = "labOrderType";
            this.labOrderType.Size = new System.Drawing.Size(24, 16);
            this.labOrderType.TabIndex = 121;
            this.labOrderType.Text = "現";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label8.Location = new System.Drawing.Point(8, 99);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(88, 16);
            this.Label8.TabIndex = 122;
            this.Label8.Text = "委託股數：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(218, 99);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 16);
            this.label11.TabIndex = 139;
            this.label11.Text = "交易員：";
            // 
            // labRequestAmount
            // 
            this.labRequestAmount.AutoSize = true;
            this.labRequestAmount.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labRequestAmount.ForeColor = System.Drawing.Color.Blue;
            this.labRequestAmount.Location = new System.Drawing.Point(114, 99);
            this.labRequestAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labRequestAmount.Name = "labRequestAmount";
            this.labRequestAmount.Size = new System.Drawing.Size(16, 16);
            this.labRequestAmount.TabIndex = 123;
            this.labRequestAmount.Text = "0";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label10.Location = new System.Drawing.Point(8, 63);
            this.Label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(72, 16);
            this.Label10.TabIndex = 124;
            this.Label10.Text = "委託別：";
            // 
            // labStockNo
            // 
            this.labStockNo.AutoSize = true;
            this.labStockNo.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labStockNo.ForeColor = System.Drawing.Color.Blue;
            this.labStockNo.Location = new System.Drawing.Point(114, 27);
            this.labStockNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labStockNo.Name = "labStockNo";
            this.labStockNo.Size = new System.Drawing.Size(40, 16);
            this.labStockNo.TabIndex = 125;
            this.labStockNo.Text = "6016";
            // 
            // labPrice
            // 
            this.labPrice.AutoSize = true;
            this.labPrice.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPrice.ForeColor = System.Drawing.Color.Blue;
            this.labPrice.Location = new System.Drawing.Point(300, 63);
            this.labPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPrice.Name = "labPrice";
            this.labPrice.Size = new System.Drawing.Size(36, 16);
            this.labPrice.TabIndex = 131;
            this.labPrice.Text = "0.00";
            // 
            // labStockName
            // 
            this.labStockName.AutoSize = true;
            this.labStockName.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labStockName.ForeColor = System.Drawing.Color.Blue;
            this.labStockName.Location = new System.Drawing.Point(218, 27);
            this.labStockName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labStockName.Name = "labStockName";
            this.labStockName.Size = new System.Drawing.Size(56, 16);
            this.labStockName.TabIndex = 126;
            this.labStockName.Text = "康和證";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label4.Location = new System.Drawing.Point(218, 63);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(56, 16);
            this.Label4.TabIndex = 130;
            this.Label4.Text = "價格：";
            // 
            // labMType
            // 
            this.labMType.AutoSize = true;
            this.labMType.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labMType.ForeColor = System.Drawing.Color.Blue;
            this.labMType.Location = new System.Drawing.Point(343, 27);
            this.labMType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labMType.Name = "labMType";
            this.labMType.Size = new System.Drawing.Size(19, 16);
            this.labMType.TabIndex = 127;
            this.labMType.Text = "O";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.page_ChangeQty);
            this.tabControl.Controls.Add(this.page_ChangePrice);
            this.tabControl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl.Location = new System.Drawing.Point(-1, 197);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(420, 111);
            this.tabControl.TabIndex = 159;
            // 
            // page_ChangeQty
            // 
            this.page_ChangeQty.Controls.Add(this.btnChangeOrder);
            this.page_ChangeQty.Controls.Add(this.labUnit);
            this.page_ChangeQty.Controls.Add(this.Label1);
            this.page_ChangeQty.Controls.Add(this.nudChangeQTY);
            this.page_ChangeQty.Controls.Add(this.label5);
            this.page_ChangeQty.Controls.Add(this.labNoDealQty);
            this.page_ChangeQty.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.page_ChangeQty.Location = new System.Drawing.Point(4, 26);
            this.page_ChangeQty.Name = "page_ChangeQty";
            this.page_ChangeQty.Padding = new System.Windows.Forms.Padding(3);
            this.page_ChangeQty.Size = new System.Drawing.Size(412, 81);
            this.page_ChangeQty.TabIndex = 0;
            this.page_ChangeQty.Text = "改量";
            this.page_ChangeQty.UseVisualStyleBackColor = true;
            // 
            // page_ChangePrice
            // 
            this.page_ChangePrice.Controls.Add(this.nudChangePrice);
            this.page_ChangePrice.Controls.Add(this.btnChangePrice);
            this.page_ChangePrice.Controls.Add(this.label3);
            this.page_ChangePrice.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.page_ChangePrice.Location = new System.Drawing.Point(4, 26);
            this.page_ChangePrice.Name = "page_ChangePrice";
            this.page_ChangePrice.Padding = new System.Windows.Forms.Padding(3);
            this.page_ChangePrice.Size = new System.Drawing.Size(412, 81);
            this.page_ChangePrice.TabIndex = 1;
            this.page_ChangePrice.Text = "改價";
            this.page_ChangePrice.UseVisualStyleBackColor = true;
            // 
            // nudChangePrice
            // 
            this.nudChangePrice.DecimalPlaces = 2;
            this.nudChangePrice.Location = new System.Drawing.Point(140, 28);
            this.nudChangePrice.Name = "nudChangePrice";
            this.nudChangePrice.Size = new System.Drawing.Size(98, 27);
            this.nudChangePrice.TabIndex = 115;
            this.nudChangePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudChangePrice.ThousandsSeparator = true;
            // 
            // btnChangePrice
            // 
            this.btnChangePrice.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnChangePrice.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnChangePrice.Location = new System.Drawing.Point(297, 39);
            this.btnChangePrice.Margin = new System.Windows.Forms.Padding(4);
            this.btnChangePrice.Name = "btnChangePrice";
            this.btnChangePrice.Size = new System.Drawing.Size(108, 35);
            this.btnChangePrice.TabIndex = 114;
            this.btnChangePrice.Text = "改價 (F9)";
            this.btnChangePrice.UseVisualStyleBackColor = false;
            this.btnChangePrice.Click += new System.EventHandler(this.btnChangePrice_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "請輸入欲改價格:";
            // 
            // frmStockChangeConfirm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 368);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.groupBox1);
            this.KeyPreview = true;
            this.Name = "frmStockChangeConfirm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "改價/量確認視窗";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmStockChangeConfirm_FormClosing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmStockChangeOrder_KeyUp);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudChangeQTY)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.page_ChangeQty.ResumeLayout(false);
            this.page_ChangeQty.PerformLayout();
            this.page_ChangePrice.ResumeLayout(false);
            this.page_ChangePrice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudChangePrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label labUnit;
        private System.Windows.Forms.Label labNoDealQty;
        public System.Windows.Forms.NumericUpDown nudChangeQTY;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button btnChangeOrder;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labSale;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label Label6;
        private System.Windows.Forms.Label labOrderType;
        private System.Windows.Forms.Label Label8;
        private System.Windows.Forms.Label labRequestAmount;
        private System.Windows.Forms.Label Label10;
        public System.Windows.Forms.Label labStockNo;
        private System.Windows.Forms.Label labPrice;
        private System.Windows.Forms.Label labStockName;
        private System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Label labMType;
        public System.Windows.Forms.TextBox txbDSEQ;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage page_ChangeQty;
        private System.Windows.Forms.TabPage page_ChangePrice;
        public System.Windows.Forms.Button btnChangePrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudChangePrice;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}