﻿namespace Concord.KeyIn.Client
{
    partial class frmForceOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TxbPassword = new System.Windows.Forms.TextBox();
            this.BtnPasswordCheck = new System.Windows.Forms.Button();
            this.BtmCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "請輸入管理人員密碼:";
            // 
            // TxbPassword
            // 
            this.TxbPassword.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TxbPassword.Location = new System.Drawing.Point(168, 15);
            this.TxbPassword.Name = "TxbPassword";
            this.TxbPassword.PasswordChar = '*';
            this.TxbPassword.Size = new System.Drawing.Size(100, 27);
            this.TxbPassword.TabIndex = 1;
            // 
            // BtnPasswordCheck
            // 
            this.BtnPasswordCheck.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnPasswordCheck.ForeColor = System.Drawing.Color.Red;
            this.BtnPasswordCheck.Location = new System.Drawing.Point(274, 12);
            this.BtnPasswordCheck.Name = "BtnPasswordCheck";
            this.BtnPasswordCheck.Size = new System.Drawing.Size(100, 30);
            this.BtnPasswordCheck.TabIndex = 6;
            this.BtnPasswordCheck.Text = "確認密碼";
            this.BtnPasswordCheck.UseVisualStyleBackColor = true;
            this.BtnPasswordCheck.Click += new System.EventHandler(this.BtnPasswordCheck_Click);
            // 
            // BtmCancel
            // 
            this.BtmCancel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtmCancel.Location = new System.Drawing.Point(274, 57);
            this.BtmCancel.Name = "BtmCancel";
            this.BtmCancel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BtmCancel.Size = new System.Drawing.Size(100, 30);
            this.BtmCancel.TabIndex = 14;
            this.BtmCancel.Text = "取消";
            this.BtmCancel.UseVisualStyleBackColor = true;
            this.BtmCancel.Click += new System.EventHandler(this.BtmCancel_Click);
            // 
            // frmForceOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 90);
            this.Controls.Add(this.BtmCancel);
            this.Controls.Add(this.BtnPasswordCheck);
            this.Controls.Add(this.TxbPassword);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frmForceOrder";
            this.Text = "萬能強制下單確認";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxbPassword;
        private System.Windows.Forms.Button BtnPasswordCheck;
        private System.Windows.Forms.Button BtmCancel;
    }
}