﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Concord.KeyIn.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Client.Tests
{
    [TestClass()]
    public class EMRiskControlHandlerTests
    {
        [TestMethod()]
        public void EMRiskControlHandlerTest()
        {
            Assert.IsTrue(true);
        }

        [TestMethod()]
        public void CheckStockTest()
        {
            List<string> datas = new List<string>() { "1260||E||||||||||||||", "2330||||||||||||||||" };
            STMBStore.ParserSTMB(datas);
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            Assert.IsTrue(eMRiskControlHandler.CheckStock("1260"));
            Assert.IsFalse(eMRiskControlHandler.CheckStock("2330"));
            Assert.IsFalse(eMRiskControlHandler.CheckStock("87"));
        }

        [TestMethod()]
        public void CheckAllIsPassedTest()
        {
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            Assert.IsFalse(eMRiskControlHandler.CheckAllIsPassed());
            EMRiskControlHandler._CSEQChecked = true;
            Assert.IsFalse(eMRiskControlHandler.CheckAllIsPassed());
            EMRiskControlHandler._StockNoChecked = true;
            Assert.IsFalse(eMRiskControlHandler.CheckAllIsPassed());
            EMRiskControlHandler._OrdQtyChecked = true;
            Assert.IsTrue(eMRiskControlHandler.CheckAllIsPassed());
        }

        [TestMethod()]
        public void CheckChangeQtyTest()
        {
            Order order = new Order();
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            order.OrdQty = 0;
            Assert.IsFalse(eMRiskControlHandler.CheckChangeQty(order, "0"));
            Assert.IsFalse(eMRiskControlHandler.CheckChangeQty(order, "1"));
            order.OrdQty = 2000;
            Assert.IsFalse(eMRiskControlHandler.CheckChangeQty(order, "1000"));
            Assert.IsTrue(eMRiskControlHandler.CheckChangeQty(order, "2000"));
        }

        [TestMethod()]
        public void CheckDeleteTest()
        {
            Order order = new Order();
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            Assert.IsFalse(eMRiskControlHandler.CheckDelete(order, 0));
            Assert.IsTrue(eMRiskControlHandler.CheckDelete(order, 1));
        }

        [TestMethod()]
        public void CheckChangePriceTest()
        {
            Order order = new Order();
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            order.OrdPrice = "10";
            Assert.IsFalse(eMRiskControlHandler.CheckChangePrice(order, 0));
            Assert.IsTrue(eMRiskControlHandler.CheckChangePrice(order, 1));
        }

        [TestMethod()]
        public void CheckStockPriceTest()
        {
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            //小數位數超過4位
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("10.00001"));
            //整數位數超過6位
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("1234567.01"));
            //委託價錢非數字
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("abc"));
            //委託價錢不可小於或等於0
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("0"));
            //價格檔數錯誤
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("5.001"));
            //委託價錢異常
            Assert.IsFalse(eMRiskControlHandler.CheckStockPrice("5+"));
            //成功
            Assert.IsTrue(eMRiskControlHandler.CheckStockPrice("5"));
        }

        [TestMethod()]
        public void ResetRiskControlTest()
        {
            //先測true情況
            EMRiskControlHandler._StockNoChecked = true;
            EMRiskControlHandler._OrdQtyChecked = true;
            Assert.IsTrue(EMRiskControlHandler._StockNoChecked);
            Assert.IsTrue(EMRiskControlHandler._OrdQtyChecked);
            //Reset後變成false
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            EMRiskControlHandler._IsKeepCusAccount = true;
            eMRiskControlHandler.ResetRiskControl();
            Assert.IsFalse(EMRiskControlHandler._StockNoChecked);
            Assert.IsFalse(EMRiskControlHandler._OrdQtyChecked);
            Assert.IsTrue(eMRiskControlHandler.GetForceOrderObject() == null);
        }

        [TestMethod()]
        public void CheckCanBeForcedTest()
        {
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            Order order = new Order();//_ForceOrderObject不能為null
            eMRiskControlHandler.CheckNewOrder(order);
            for (int i = 1006; i <= 1008; i++)
                Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced(i.ToString(), ""));
            for (int i = 1402; i <= 1413; i++)
                Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced(i.ToString(), ""));
            Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced("1501", ""));
            Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced("1302", ""));
            Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced("1417", ""));
            Assert.IsTrue(eMRiskControlHandler.CheckCanBeForced("1418", ""));
            for (int i = 0; i < 1006; i++)
                Assert.IsFalse(eMRiskControlHandler.CheckCanBeForced(i.ToString(), ""));
            for (int i = 1009; i < 1402; i++)
            {
                if (i == 1201 || i == 1302)
                    continue;
                Assert.IsFalse(eMRiskControlHandler.CheckCanBeForced(i.ToString(), ""));
            }
            Assert.IsFalse(eMRiskControlHandler.CheckCanBeForced("1414", ""));
            Assert.IsFalse(eMRiskControlHandler.CheckCanBeForced("1415", ""));
            for (int i = 1419; i < 10000; i++)
            {
                if (i == 1501)
                    continue;
                Assert.IsFalse(eMRiskControlHandler.CheckCanBeForced(i.ToString(), ""));
            }
        }
        [TestMethod()]
        public void systemErrorTest()
        {
            EMRiskControlHandler eMRiskControlHandler = new EMRiskControlHandler();
            Assert.IsTrue(eMRiskControlHandler.systemError("8000"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8001"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8002"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8003"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8004"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8005"));
            Assert.IsTrue(eMRiskControlHandler.systemError("8888"));
            for (int i = 8006; i < 8888; i++)
                Assert.IsFalse(eMRiskControlHandler.systemError(i.ToString()));
            for (int i = 8889; i <= 9999; i++)
                Assert.IsFalse(eMRiskControlHandler.systemError(i.ToString()));
            for (int i = 1000; i < 8000; i++)
                Assert.IsFalse(eMRiskControlHandler.systemError(i.ToString()));
        }
    }
}