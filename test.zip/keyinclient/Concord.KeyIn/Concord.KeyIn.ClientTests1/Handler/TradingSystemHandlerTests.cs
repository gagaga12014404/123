﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Concord.KeyIn.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Client.Tests
{
    [TestClass()]
    public class TradingSystemHandlerTests
    {
        [TestMethod()]
        public void ParserMessageToDicTest()
        {
            string msg = "35=241=982446076=845055=0050  ";
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            Dictionary<int, string> dic = TradingSystemHandler.ParserMessageToDic(msg, '\u0001');
            Assert.AreEqual(dic[35], "24");
            Assert.AreEqual(dic[1], "9824460");
            Assert.AreEqual(dic[76], "8450");
            Assert.AreEqual(dic[55], "0050  ");
        }

        [TestMethod()]
        public void CheckAccountTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string msg = tsh.CheckAccount("9826125", "8450");
            string actual = "35=2001=982612576=8450" + "\n";
            Assert.AreEqual(msg, actual);
            msg = tsh.CheckAccount("9824460", "8450");
            actual = "35=2001=982446076=8450" + "\n";
            Assert.AreEqual(msg, actual);
        }

        [TestMethod()]
        public void CheckStockTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string msg = tsh.CheckStock("8329", 0);
            string actual = "35=20155=8329  81001=0" + "\n";
            Assert.AreEqual(msg, actual);
            msg = tsh.CheckStock("T3714Y", 0);
            actual = "35=20155=T3714Y81001=0" + "\n";
            Assert.AreEqual(msg, actual);
        }

        [TestMethod()]
        public void CheckOrderQtyTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string msg = tsh.CheckOrderQty("9826125", "8450", "8329", "1000", 0);
            string actual = "35=2021=982612576=845055=8329  38=100081001=0" + "\n";
            Assert.AreEqual(msg, actual);
            msg = tsh.CheckOrderQty("1300018", "8450", "T3714Y", "2000", 0);
            actual = "35=2021=130001876=845055=T3714Y38=200081001=0" + "\n";
            Assert.AreEqual(msg, actual);
        }
        [TestMethod()]
        public void CheckOrderPriceTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string expected = tsh.CheckOrderPrice("9826125", "8450", "1260", "1000", "20", 0);
            string actual = "35=2031=98261276=845055=1260  38=100044=2081001=0" + "\n";
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void SendLoginTest()
        {
            UserInfo._EMNO = "110101";
            UserInfo._UserIP = "192.168.103.90";
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string expected = tsh.Login();
            string actual = "35=881=11010120000=192.168.103.90" + "\n";
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void RecoverTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            UserInfo._EMNO = "110101";
            string expected = tsh.Recover("8450", "W");
            string actual = "35=20650002=11010176=8450117=W118=Y" + "\n";
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void SendOrderTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            Order order = new Order();
            order.CSEQ = "1300018";
            order.BHNO = "8450";
            order.DSEQ = "W0001";
            order.Symbol = "8329";
            order.OrdQty = 1000;
            order.OrdPrice = "7";
            order.Side = Side.BUY;
            order.ECode = "0";
            order.ExecType = "I";
            order.Sale = "06";
            order.AllForceFlag = "N";
            order.Guid = "";
            UserInfo._UserIP = "192.168.103.90";
            UserInfo._EMNO = "110101";
            string msg = tsh.Order(order);
            string now = msg.Substring(67, 17);
            string actual = "35=11=130001876=8450117=W000155=8329  38=100044=754=180024=" + now + "81001=081008=I20000=192.168.103.9020001=0650001= 50002=11010160005=N20002=" + "\n";
            Assert.AreEqual(msg, actual);
            order.CSEQ = "1317894";
            order.BHNO = "8450";
            order.DSEQ = "W0002";
            order.Symbol = "1563";
            order.OrdQty = 1000;
            order.OrdPrice = "55";
            order.Side = Side.SELL;
            order.ECode = "0";
            order.ExecType = "I";
            order.Sale = "23";
            order.AllForceFlag = "N";
            order.Guid = "";
            msg = tsh.Order(order);
            now = msg.Substring(68, 17);
            actual = "35=11=131789476=8450117=W000255=1563  38=100044=5554=280024=" + now + "81001=081008=I20000=192.168.103.9020001=2350001= 50002=11010160005=N20002=" + "\n";
            Assert.AreEqual(msg, actual);
        }
        [TestMethod()]
        public void ComposeHeartBeatMessageTest()
        {
            TradingSystemHandler tsh = new TradingSystemHandler(null);
            string actual = "35=880714" + "\n";
            Assert.AreEqual(TradingSystemHandler.ComposeHeartBeatMessage(), actual);
        }
    }
}