﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Concord.KeyIn.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Concord.KeyIn.Client.Tests
{
    [TestClass()]
    public class EMOrderStoreTests
    {
        EMOrderStore eMOrderStore = new EMOrderStore();
        //錯帳
        [TestMethod()]
        public void ParseReportTest_Err_t1()
        {
            List<string> datas = new List<string>() { "8329|台視|E|1|7.46|0.00|0.00|1000||O|X| |不可信用交易_不可現沖|||" };
            STMBStore.ParserSTMB(datas);
            //X0001新單
            string msg = "35=201=000333276=845055=8329  80025=20220520095438117=X000120001=50002=11010180004=080014=81001=054=B50001= 118=180024=09543814481008=I37=100038=100044=720002=K0000220003=K00002";
            Report report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "0003332");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "8329");
            Assert.AreEqual(report.TransactTime, "09:54:38");
            Assert.AreEqual(report.DSEQ, "X0001");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00002");
            Assert.AreEqual(report.OrigClOrdID, "K00002");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1000);
            Assert.AreEqual(report.OrdPrice, "7");
            Assert.AreEqual(report.AfterChangeQty, 1000);
            Assert.AreEqual(report.ExecType, "I");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
            Assert.AreEqual(eMOrderStore.ErrAccountOrderNo, 2);
            //X0001改價
            msg = "35=201=000333276=845055=8329  80025=20220520095605117=X000120001=50002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=P37=100038=100044=7.120002=K0000420003=K00002";
            report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "0003332");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "8329");
            Assert.AreEqual(report.TransactTime, "09:56:05");
            Assert.AreEqual(report.DSEQ, "X0001");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00004");
            Assert.AreEqual(report.OrigClOrdID, "K00002");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1000);
            Assert.AreEqual(report.OrdPrice, "7.1");
            Assert.AreEqual(report.AfterChangeQty, 1000);
            Assert.AreEqual(report.ExecType, "P");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
            Assert.AreEqual(eMOrderStore.ErrAccountOrderNo, 2);
            //X0001改量
            msg = "35=201=000333276=845055=8329  80025=20220520095605117=X000120001=50002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=C37=100038=044=7.120002=K0000520003=K00002";
            report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "0003332");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "8329");
            Assert.AreEqual(report.TransactTime, "09:56:05");
            Assert.AreEqual(report.DSEQ, "X0001");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00005");
            Assert.AreEqual(report.OrigClOrdID, "K00002");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1000);
            Assert.AreEqual(report.OrdPrice, "7.1");
            Assert.AreEqual(report.ExecType, "C");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
            Assert.AreEqual(eMOrderStore.ErrAccountOrderNo, 2);
        }
        [TestMethod()]
        public void ParseReportTest_Err_t2()
        {
            //X0002新單
            string msg = "35=201=000333276=845055=1260  80025=20220520095622117=X000220001=50002=11010180004=080014=81001=054=B50001= 118=180024=09562246481008=I37=100038=100044=2020002=K0000620003=K00006";
            Report report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "0003332");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "1260");
            Assert.AreEqual(report.TransactTime, "09:56:22");
            Assert.AreEqual(report.DSEQ, "X0002");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00006");
            Assert.AreEqual(report.OrigClOrdID, "K00006");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1000);
            Assert.AreEqual(report.OrdPrice, "20");
            Assert.AreEqual(report.AfterChangeQty, 1000);
            Assert.AreEqual(report.ExecType, "I");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
            Assert.AreEqual(eMOrderStore.ErrAccountOrderNo, 3);
        }
        [TestMethod()]
        public void ParseReportTest_Err_t3()
        {
            //X0003新單
            string msg = "35=201=000333276=845055=AU9901  80025=20220520105622117=X000320001=50002=11010180004=080014=81001=054=B50001= 118=180024=10562246481008=I37=138=144=650020002=K0000720003=K00007";
            Report report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "0003332");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "AU9901");
            Assert.AreEqual(report.TransactTime, "10:56:22");
            Assert.AreEqual(report.DSEQ, "X0003");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00007");
            Assert.AreEqual(report.OrigClOrdID, "K00007");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1);
            Assert.AreEqual(report.OrdPrice, "6500");
            Assert.AreEqual(report.AfterChangeQty, 1);
            Assert.AreEqual(report.ExecType, "I");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
            Assert.AreEqual(eMOrderStore.ErrAccountOrderNo, 4);
        }
        [TestMethod()]
        public void ParseReportTest_Err_t4()
        {
            //37為0測試
            List<string> datas = new List<string>() { "8329|台視|E|1|7.46|0.00|0.00|1000||O|X| |不可信用交易_不可現沖|||" };
            STMBStore.ParserSTMB(datas);
            string msg = "35=201=982446076=845055=8329  80025=20220520095438117=W000120001=50002=11010180004=080014=81001=054=B50001= 118=180024=09543814481008=I37=038=100044=720002=K0000220003=K00002";
            Report report = eMOrderStore.ParseReport(msg);
            Assert.AreEqual(report.CSEQ, "9824460");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.Stock, "8329");
            Assert.AreEqual(report.TransactTime, "09:54:38");
            Assert.AreEqual(report.DSEQ, "W0001");
            Assert.AreEqual(report.Sale, "");
            Assert.AreEqual(report.ClOrdID, "K00002");
            Assert.AreEqual(report.OrigClOrdID, "K00002");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.OrdQty, 1000);
            Assert.AreEqual(report.OrdPrice, "7");
            Assert.AreEqual(report.AfterChangeQty, 1000);
            Assert.AreEqual(report.ExecType, "I");
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.Origin, "110101");
        }

        [TestMethod()]
        public void ParseDealReportTest()
        {
            string msg = "35=241=130001876=845055=1260  80025=20220527104940117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=2022052710494058337=038=100044=2320002=K0000D20003=K0000D20004=1";
            Report report = eMOrderStore.ParseDealReport(msg);
            Assert.AreEqual(report.CSEQ, "1300018");
            Assert.AreEqual(report.BHNO, "8450");
            Assert.AreEqual(report.DSEQ, "W0001");
            Assert.AreEqual(report.Side, "B");
            Assert.AreEqual(report.Stock, "1260");
            Assert.AreEqual(report.ClOrdID, "K0000D");
            Assert.AreEqual(report.OrigClOrdID, "K0000D");
            Assert.AreEqual(report.LaveQty, 0);
            Assert.AreEqual(report.DealQty, 1000);
            Assert.AreEqual(report.Status, "0");
            Assert.AreEqual(report.DealPrice, 23);
            Assert.AreEqual(report.Text, "");
            Assert.AreEqual(report.TransactTime, "10:49:40");
            Assert.AreEqual(report.ExecType, "F");
            Assert.AreEqual(report.Origin, "110101");
            //相同電文，確認是否過濾
            msg = "35=241=130001876=845055=1260  80025=20220527104940117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=2022052710494058337=038=100044=2320002=K0000D20003=K0000D20004=1";
            report = eMOrderStore.ParseDealReport(msg);
            Assert.AreEqual(report, null);
        }
        [TestMethod()]
        public void Add_Update_ReportTest1()
        {
            EMOrderStore _EMOrderStore = new EMOrderStore();
            //設定action函式
            _EMOrderStore._EvntAddReport += (DataRow dr) =>
            {
                EMOrderStore._OrdReportStore.Rows.Add(dr);
            };
            //STMB假資料
            List<string> stmb_datas = new List<string>() { "1260||E||||||||||||||", "2330||||||||||||||||" };
            STMBStore.ParserSTMB(stmb_datas);
            //CUMB假資料
            CUMBStore cumb = new CUMBStore();
            List<string> cumb_datas = new List<string>() { "8450|1300018|A123456789||name|06|||" };
            cumb.Parser(cumb_datas);
            string msg = "35=241=130001876=845055=1260  80025=20220527104940117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=2022052710494058337=200038=100044=2320002=K0000D20003=K0000D20004=1";
            Report report = _EMOrderStore.ParseDealReport(msg);
            _EMOrderStore.AddReport(report);
            var list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "F");
            Assert.AreEqual(list[0]["Sale"].ToString(), "06");
            Assert.AreEqual(list[0]["DSEQ"].ToString(), "W0001");
            Assert.AreEqual(list[0]["BHNO"].ToString(), "8450");
            Assert.AreEqual(list[0]["CSEQ"].ToString(), "1300018");
            Assert.AreEqual(list[0]["ClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["OrigClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["Stock"].ToString(), "1260");
            Assert.AreEqual(list[0]["Side"].ToString(), "B");
            Assert.AreEqual(list[0]["ECode"].ToString(), "整股");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "1000");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "2000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "0");
            Assert.AreEqual(list[0]["Status"].ToString(), "委託成功");
            Assert.AreEqual(list[0]["Text"].ToString(), "");
            Assert.AreEqual(list[0]["TransactTime"].ToString(), "10:49:40");
            Assert.AreEqual(list[0]["MType"].ToString(), "E");
            Assert.AreEqual(list[0]["CusName"].ToString(), "name");
            Assert.AreEqual(list[0]["StockName"].ToString(), "");
            msg = "35=201=130001876=845055=1260  80025=20220527104941117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09543814481008=I37=400038=400044=2420002=K0000D20003=K0000D";
            report = _EMOrderStore.ParseReport(msg);
            _EMOrderStore.UpdateReport(report);
            list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "I");
            Assert.AreEqual(list[0]["ClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["OrigClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "1000");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "24");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "3000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "0");
            msg = "35=201=130001876=845055=1260  80025=20220527104942117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=P37=300038=300044=2320002=K0000E20003=K0000D";
            report = _EMOrderStore.ParseReport(msg);
            _EMOrderStore.UpdateReport(report);
            list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "P");
            Assert.AreEqual(list[0]["ClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["OrigClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "1000");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "23");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "3000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "0");
            msg = "35=201=130001876=845055=1260  80025=20220527104942117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=C37=300038=200044=2320002=K0000F20003=K0000D";
            report = _EMOrderStore.ParseReport(msg);
            _EMOrderStore.UpdateReport(report);
            list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "C");
            Assert.AreEqual(list[0]["ClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["OrigClOrdID"].ToString(), "K0000D");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "1000");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "23");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "2000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "1000");
        }
        [TestMethod()]
        public void Add_Update_ReportTest2()
        {
            EMOrderStore _EMOrderStore = new EMOrderStore();
            //設定action函式
            _EMOrderStore._EvntAddReport += (DataRow dr) =>
            {
                EMOrderStore._OrdReportStore.Rows.Add(dr);
            };
            //STMB假資料
            List<string> stmb_datas = new List<string>() { "1260||E||||||||||||||", "2330||||||||||||||||" };
            STMBStore.ParserSTMB(stmb_datas);
            //CUMB假資料
            CUMBStore cumb = new CUMBStore();
            List<string> cumb_datas = new List<string>() { "8450|1300018|A123456789||name|06|||" };
            cumb.Parser(cumb_datas);
            string msg;
            msg = "35=201=130001876=845055=1260  80025=20220527104941117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09543814481008=I37=400038=400044=2420002=K0000D20003=K0000D";
            _EMOrderStore.AddReport(_EMOrderStore.ParseReport(msg));
            msg = "35=241=130001876=845055=1260  80025=20220527104940117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=2022052710494058337=200038=100044=2320002=K0000D20003=K0000D20004=1";
            _EMOrderStore.UpdateReport(_EMOrderStore.ParseDealReport(msg));
            msg = "35=201=130001876=845055=1260  80025=20220527104942117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=C37=300038=200044=2320002=K0000F20003=K0000D";
            _EMOrderStore.UpdateReport(_EMOrderStore.ParseReport(msg));
            msg = "35=201=130001876=845055=1260  80025=20220527104942117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09560582881008=P37=300038=300044=2320002=K0000E20003=K0000D";
            _EMOrderStore.UpdateReport(_EMOrderStore.ParseReport(msg));
            var list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "P");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "1000");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "23");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "2000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "1000");
        }
        public void Add_Update_ReportTest3()
        {
            //37是0的情況
            EMOrderStore _EMOrderStore = new EMOrderStore();
            //設定action函式
            _EMOrderStore._EvntAddReport += (DataRow dr) =>
            {
                EMOrderStore._OrdReportStore.Rows.Add(dr);
            };
            //STMB假資料
            List<string> stmb_datas = new List<string>() { "1260||E||||||||||||||", "2330||||||||||||||||" };
            STMBStore.ParserSTMB(stmb_datas);
            //CUMB假資料
            CUMBStore cumb = new CUMBStore();
            List<string> cumb_datas = new List<string>() { "8450|1300018|A123456789||name|06|||" };
            cumb.Parser(cumb_datas);
            string msg;
            msg = "35=201=130001876=845055=1260  80025=20220527104941117=W000120001=0650002=11010180004=080014=81001=054=B50001= 118=180024=09543814481008=I37=038=400044=2420002=K0000D20003=K0000D";
            _EMOrderStore.AddReport(_EMOrderStore.ParseReport(msg));
            var list = _EMOrderStore.FindEmOrder("W0001");
            Assert.AreEqual(list[0]["ExecType"].ToString(), "I");
            Assert.AreEqual(list[0]["DealQty"].ToString(), "0");
            Assert.AreEqual(list[0]["OrdQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["OrdPrice"].ToString(), "24");
            Assert.AreEqual(list[0]["LaveQty"].ToString(), "4000");
            Assert.AreEqual(list[0]["CancelQty"].ToString(), "0");
        }
    }
}