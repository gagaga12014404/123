﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Concord.SDK.Utility;

namespace KeyInMgm
{
    public partial class SKeyInSetting : System.Web.UI.Page
    {
        private readonly List<string> authList = new List<string> { "KeyIn", "KeyInIB", "Dev", "OP" };

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string[] FunctionGroup = { "AdmGrp", "ManaGrp", "ViewGrp", "ViewBkno", "ViewDept", "ViewBkno", "ViewSale" };
                string ROLE = "";

                if (!IsPostBack)
                {
                    bool blAccess = WebAuthority.checkAccessAuthority(getUserID(), Request);
                    blAccess = true;
                    if (blAccess)
                    {
                        ROLE = WebAuthority.getFucntionGroup(getUserID(), Request, FunctionGroup);
                        if (!string.IsNullOrEmpty(ROLE))
                        {
                            if (Request["Mode"] == null)
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUser"].ConnectionString;
                                lblTitle.Text += "(總公司)";
                            }
                            else if (Request["Mode"] == "Remote")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserRemote"].ConnectionString;
                                lblTitle.Text += "(復北)";
                            }
                            else if (Request["Mode"] == "QC")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserQC"].ConnectionString;
                                lblTitle.Text += "(QC)";
                            }
                            else if (Request["Mode"] == "Test")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserTest"].ConnectionString;
                                lblTitle.Text += "(測試)";
                            }
                            else
                            {
                                showAcctErr();
                                return;
                            }
                            ddlAuth.DataSource = authList;
                            ddlAuth.DataBind();
                            ddlNewAuth.DataSource = authList;
                            ddlNewAuth.DataBind();
                            getAuthList();
                        }
                        else
                        {
                            showAcctErr();
                        }
                    }
                    else
                    {
                        showAcctErr();
                    }
                }
            }
            catch (Exception ex)
            {
                showMsg(ex.ToString());
            }
        }

        #region 共用Method
        private void showAcctErr()//產生非法使用者訊息
        {
            string errStr = "<script laguage='javascript' type=''>alert('權限異常');</script>";
            Response.Clear();
            Response.Write(errStr);
            Response.End();
        }

        private void showMsg(string strMsg)//產生非法使用者訊息
        {
            string MsgErr = strMsg;
            MsgErr = MsgErr.Replace("'", "’");
            MsgErr = MsgErr.Replace("%", "％");
            MsgErr = MsgErr.Replace("\\", "＼");
            MsgErr = MsgErr.Replace("\"", "”");
            MsgErr = MsgErr.Replace("/", "／");
            MsgErr = MsgErr.Replace("\r\n", "");
            MsgErr = MsgErr.Replace("\n", "\\n");
            string Msg = "<script laguage='javascript' type=''>alert('" + MsgErr + "');</script>";
            if (!ClientScript.IsStartupScriptRegistered("alert"))
                ClientScript.RegisterStartupScript(this.GetType(), "alert", Msg);
        }

        private string getUserID()
        {
            string id = Request.LogonUserIdentity.Name;
            int index = id.IndexOf("\\");
            id = id.Substring(index + 1, id.Length - index - 1);
            id = id.ToUpper();
            return id;
        }

        private void getAuthList(string EMNO = "")
        {
            try
            {
                DataTable dt = new DataTable();
                string strErrMsg = "";
                SqlParameter[] arParam = new SqlParameter[] { new SqlParameter("@EMNO", EMNO) };
                string strSqlCmd = $@"SELECT
[EMNO],[BHNO],[IP],[Authority],[TERM],
[IsSplitLot],[IsBatchOddLot],[UpdateCFID],[UpdateDate]
FROM [KeyIn].[dbo].[SYS_RSettingKeyIn]
WHERE @EMNO = '' OR [EMNO] = @EMNO";
                dt = DBHelper.QueryData("KeyIn", strSqlCmd, ViewState["strSqlConn"].ToString(), arParam, ref strErrMsg);
                if (strErrMsg == "")
                {
                    dt.DefaultView.Sort = "BHNO, EMNO, TERM";
                    gvList.DataSource = dt;
                    gvList.DataBind();
                }
                else
                {
                    showMsg(strErrMsg);
                }
            }
            catch (Exception ex)
            {
                showMsg(ex.ToString());
            }
        }
        #endregion

        protected void lbtnQuery_Click(object sender, EventArgs e)
        {
            getAuthList(txtID.Text);
        }

        protected void lbtnQueryAll_Click(object sender, EventArgs e)
        {
            getAuthList();
        }

        protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ToUpdate")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                txtEMNO.Text = gvList.Rows[index].Cells[2].Text;
                txtBHNO.Text = gvList.Rows[index].Cells[3].Text;
                txtIP.Text = gvList.Rows[index].Cells[4].Text;
                ddlAuth.SelectedIndex = authList.IndexOf(gvList.Rows[index].Cells[5].Text);
                txtTERM.Text = gvList.Rows[index].Cells[6].Text;
                cbSplitLot.Checked = gvList.Rows[index].Cells[7].Text == "Y";
                cbBatchOddLot.Checked = gvList.Rows[index].Cells[8].Text == "Y";
                lblOrigData.Text = $"{txtEMNO.Text}|{txtBHNO.Text}|{txtIP.Text}|{ddlAuth.Text}|{txtTERM.Text}|{gvList.Rows[index].Cells[7].Text}|{gvList.Rows[index].Cells[8].Text}";
                StringBuilder sb = new StringBuilder();
                sb.Append("<script type='text/javascript'>");
                sb.Append("(() => {");
                sb.Append("$('#updateModal').modal('show')");
                sb.Append("})();");
                sb.Append("</script>");
                if (!ClientScript.IsStartupScriptRegistered("updateModal"))
                    ClientScript.RegisterStartupScript(this.GetType(), "updateModal", sb.ToString());
            }
        }

        protected void gvList_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void gvList_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string strErrMsg = "";
            SqlParameter[] arParam = new SqlParameter[]
            {
                new SqlParameter("@EMNO", e.Values["EMNO"]),
                new SqlParameter("@BHNO", e.Values["BHNO"]),
                new SqlParameter("@IP", e.Values["IP"])
            };
            string strSqlCmd = "DELETE FROM [KeyIn].[dbo].[SYS_RSettingKeyIn] WHERE [EMNO] = @EMNO AND [BHNO] = @BHNO AND [IP] = @IP";
            int c = DBHelper.DeleteData("KeyIn", strSqlCmd, ViewState["strSqlConn"].ToString(), arParam, ref strErrMsg);
            if (strErrMsg == "")
            {
                showMsg($"已刪除{c}筆資料");
            }
            else
            {
                showMsg(strErrMsg);
            }
            getAuthList(txtID.Text);
        }

        protected void gvList_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void lbtnUpdateConfirm_Click(object sender, EventArgs e)
        {
            string[] origDatas = lblOrigData.Text.Split('|');
            string emno = origDatas[0], bhno = origDatas[1], ip = origDatas[2],
                auth = origDatas[3], term = origDatas[4], splitLot = origDatas[5], batchOddLot = origDatas[6];
            Dictionary<string, string> dicParam = new Dictionary<string, string>();
            if (emno != txtEMNO.Text)
                dicParam.Add("EMNO", txtEMNO.Text);
            if (bhno != txtBHNO.Text)
                dicParam.Add("BHNO", txtBHNO.Text);
            if (ip != txtIP.Text)
                dicParam.Add("IP", txtIP.Text);
            if (auth != ddlAuth.Text)
                dicParam.Add("Authority", ddlAuth.Text);
            if (term != txtTERM.Text)
                dicParam.Add("TERM", txtTERM.Text);
            string cbValue = cbSplitLot.Checked ? "Y" : "N";
            if (splitLot != cbValue)
                dicParam.Add("IsSplitLot", cbValue);
            cbValue = cbBatchOddLot.Checked ? "Y" : "N";
            if (batchOddLot != cbValue)
                dicParam.Add("IsBatchOddLot", cbValue);

            if (dicParam.Count <= 0)
                return;
            string strErrMsg = "";
            StringBuilder sb = new StringBuilder();
            sb.Append(dicParam.Aggregate("UPDATE [KeyIn].[dbo].[SYS_RSettingKeyIn] SET ", (s, kvp) => $"{s}{kvp.Key}=@{kvp.Key}_U,"));
            sb.Append($"UpdateCFID='{getUserID()}',UpdateDate=GETDATE() WHERE EMNO=@EMNO AND BHNO = @BHNO AND IP = @IP");
            var arParam = dicParam.Select(kvp => new SqlParameter($"@{kvp.Key}_U", kvp.Value))
                .Concat(new[] { new SqlParameter("@EMNO", emno), new SqlParameter("@BHNO", bhno), new SqlParameter("@IP", ip) })
                .ToArray();
            int c = DBHelper.UpdateData("KeyIn", sb.ToString(), ViewState["strSqlConn"].ToString(), arParam, ref strErrMsg);
            if (strErrMsg == "")
            {
                showMsg($"已更新{c}筆資料");
            }
            else
            {
                showMsg(strErrMsg);
            }
            getAuthList();
        }

        protected void lbtnNewConfirm_Click(object sender, EventArgs e)
        {
            string strErrMsg = "";
            SqlParameter[] arParam = new SqlParameter[]
            {
                new SqlParameter("@EMNO", txtNewEMNO.Text),
                new SqlParameter("@BHNO", txtNewBHNO.Text),
                new SqlParameter("@IP", txtNewIP.Text),
                new SqlParameter("@Auth", ddlNewAuth.Text),
                new SqlParameter("@TERM", txtNewTERM.Text),
                new SqlParameter("@IsSplitLot", cbNewSplitLot.Checked ? "Y" : "N"),
                new SqlParameter("@IsBatchOddLot", cbNewBatchOddLot.Checked ? "Y" : "N"),
                new SqlParameter("@UpdateCFID", getUserID())
            };
            string strSqlCmd = @"INSERT INTO [KeyIn].[dbo].[SYS_RSettingKeyIn]
VALUES(@EMNO, @BHNO, @IP, @Auth, @TERM, 'N', @BHNO, @IsSplitLot, @IsBatchOddLot, @UpdateCFID, GETDATE(), GETDATE())";
            int c = DBHelper.InsertData("KeyIn", strSqlCmd, ViewState["strSqlConn"].ToString(), arParam, ref strErrMsg);
            if (strErrMsg == "")
            {
                showMsg($"已新增{c}筆資料");
            }
            else
            {
                showMsg(strErrMsg);
            }
            getAuthList();
        }
    }
}