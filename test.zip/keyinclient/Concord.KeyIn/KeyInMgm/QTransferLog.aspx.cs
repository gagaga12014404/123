﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Concord.SDK.Utility;

namespace KeyInMgm
{
    public partial class QTransferLog : System.Web.UI.Page
    {
        DataTable dtBranch = new DataTable();
        DataTable dtBranchTransList = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string[] FunctionGroup = { "AdmGrp", "ManaGrp", "ViewGrp", "ViewBkno", "ViewDept", "ViewBkno", "ViewSale" };
                string ROLE = "";

                if (!IsPostBack)
                {
                    bool blAccess = WebAuthority.checkAccessAuthority(getUserID(), Request);
                    blAccess = true;
                    if (blAccess)
                    {
                        ROLE = WebAuthority.getFucntionGroup(getUserID(), Request, FunctionGroup);
                        if (!string.IsNullOrEmpty(ROLE))
                        {
                            if (Request["Mode"] == null)
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUser"].ConnectionString;
                                lblTitle.Text += "(總公司)";
                            }
                            else if (Request["Mode"] == "Remote")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserRemote"].ConnectionString;
                                lblTitle.Text += "(復北)";
                            }
                            else if (Request["Mode"] == "QC")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserQC"].ConnectionString;
                                lblTitle.Text += "(QC)";
                            }
                            else if (Request["Mode"] == "Test")
                            {
                                ViewState["strSqlConn"] = ConfigurationManager.ConnectionStrings["KeyInUserTest"].ConnectionString;
                                lblTitle.Text += "(測試)";
                            }
                            else
                            {
                                showAcctErr();
                                return;
                            }
                            txtDate.Text = DateTime.Now.ToString("yyyyMMdd");

                            //取得證券分公司
                            getStockBranch();
                            //取得轉檔記錄
                            getTransferLog();
                        }
                        else
                        {
                            showAcctErr();
                        }
                    }
                    else
                    {
                        showAcctErr();
                    }
                }
            }
            catch (Exception ex)
            {
                showMsg(ex.ToString());
            }
        }

        #region 共用Method
        private void showAcctErr()//產生非法使用者訊息
        {
            string errStr = "<script laguage='javascript' type=''>alert('權限異常');</script>";
            Response.Clear();
            Response.Write(errStr);
            Response.End();
        }

        private void showMsg(string strMsg)//產生非法使用者訊息
        {
            string MsgErr = strMsg;
            MsgErr = MsgErr.Replace("'", "’");
            MsgErr = MsgErr.Replace("%", "％");
            MsgErr = MsgErr.Replace("\\", "＼");
            MsgErr = MsgErr.Replace("\"", "”");
            MsgErr = MsgErr.Replace("/", "／");
            MsgErr = MsgErr.Replace("\r\n", "");
            MsgErr = MsgErr.Replace("\n", "\\n");
            string Msg = "<script laguage='javascript' type=''>alert('" + MsgErr + "');</script>";
            if (!ClientScript.IsStartupScriptRegistered("alert"))
                ClientScript.RegisterStartupScript(this.GetType(), "alert", Msg);
        }

        private string getUserID()
        {
            string id = Request.LogonUserIdentity.Name;
            int index = id.IndexOf("\\");
            id = id.Substring(index + 1, id.Length - index - 1);
            id = id.ToUpper();
            return id;
        }

        private void getStockBranch()
        {
            try
            {
                string strErrMsg = "";
                string strSqlCmd = "SELECT [BranchCode] FROM [KeyIn].[dbo].[StockBranch]";
                dtBranch = DBHelper.QueryData("BC", strSqlCmd, ViewState["strSqlConn"].ToString(), new SqlParameter[] { }, ref strErrMsg);
            }
            catch (Exception ex)
            {
                showMsg(ex.ToString());
            }
        }

        private void getTransferLog()
        {
            try
            {
                DataTable dtTransLog = new DataTable();
                DataTable dtFinal = new DataTable();
                string strErrMsg = "";
                SqlParameter[] arParam = new SqlParameter[] { new SqlParameter("@TransDate", txtDate.Text) };
                string strSqlCmd = $@"SELECT A.[Time],A.Kind,A.[Type],A.Name,A.[Description],A.Seq,
CASE WHEN B.TransMsg = '' THEN 'Y' WHEN B.TransMsg IS NULL THEN 'U' ELSE 'N' END AS TransStatus,
ISNULL(B.TransMsg,'') AS TransMsg,B.CreateDate FROM
(SELECT * FROM [KeyIn].[dbo].[TF_TransferList] WITH(NOLOCK)) A
LEFT JOIN
(SELECT * FROM [KeyIn].[dbo].[TF_TransferLog] WITH(NOLOCK) WHERE TransDate = @TransDate) B
ON A.Kind = B.Kind AND A.[Type] = B.[Type] AND A.Name = B.Name AND A.[Time] = B.[Time]
ORDER BY [Time],[Type],[Seq],[Name]";
                dtTransLog = DBHelper.QueryData("KeyIn", strSqlCmd, ViewState["strSqlConn"].ToString(), arParam, ref strErrMsg);
                dtFinal = dtTransLog.Clone();

                //一般轉檔處理
                foreach (DataRow drTrans in dtTransLog.Rows)
                {
                    dtFinal.ImportRow(drTrans);
                }

                //final排序
                dtFinal.DefaultView.Sort = "Time";

                if (strErrMsg == "")
                {
                    gvResult.DataSource = dtFinal;
                    gvResult.DataBind();
                }
                else
                {
                    showMsg(strErrMsg);
                }
            }
            catch (Exception ex)
            {
                showMsg(ex.ToString());
            }
        }
        #endregion

        protected void gvResult_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.Header)
            {
                switch (e.Row.Cells[1].Text)
                {
                    case "0":
                        e.Row.Cells[1].Text = "轉入";
                        break;
                    case "1":
                        e.Row.Cells[1].Text = "轉出";
                        break;
                }

                //一般轉檔
                switch (e.Row.Cells[5].Text)
                {
                    case "Y":
                        e.Row.Cells[5].Text = "成功";
                        e.Row.Cells[5].ForeColor = Color.Green;
                        ((LinkButton)e.Row.Cells[6].FindControl("lbtnDetail")).Visible = false;
                        break;
                    case "U":
                        e.Row.Cells[5].Text = "尚未轉檔";
                        e.Row.Cells[5].ForeColor = Color.Blue;
                        ((LinkButton)e.Row.Cells[6].FindControl("lbtnDetail")).Visible = false;
                        break;
                    case "N":
                        e.Row.Cells[5].Text = "失敗";
                        e.Row.Cells[5].ForeColor = Color.Red;
                        ((LinkButton)e.Row.Cells[6].FindControl("lbtnDetail")).Visible = true;
                        break;
                }
            }
        }

        protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Detail")
            {
                txtDetail.Text = "";
                int index = int.Parse(e.CommandArgument.ToString());
                txtDetail.Text = ((HiddenField)gvResult.Rows[index].Cells[6].FindControl("hidDetail")).Value;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "openModal();", true);
            }
        }

        protected void lbtnQuery_Click(object sender, EventArgs e)
        {
            //取得證券分公司
            getStockBranch();
            //取得轉檔記錄
            getTransferLog();
        }
    }
}