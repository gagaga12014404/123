﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public static class DAL
    {
        private static readonly string m_sqlUserId = Properties.Settings.Default.SqlUserID;
        private static readonly string m_sqlConn = Properties.Settings.Default.SqlConn;

        /// <summary>
        /// 是否為交易日
        /// </summary>
        public static bool IsTradeDay
        {
            get
            {
                return DBHelper.IsTradeDay(m_sqlUserId, m_sqlConn, DBHelper.MarketType.Stock);
            }
        }

        /// <summary>
        /// 取得當日回報的獨立KEY值
        /// </summary>
        /// <param name="TDATE">交易日</param>
        /// <param name="errorMessage">錯誤訊息</param>
        /// <returns></returns>
        public static IEnumerable<string> GetORUniqueKeys(string TDATE, ref string errorMessage)
        {
            var sqlCommand = "SELECT [TDATE],[UniqueKey] "
                           + "FROM [KeyIn].[dbo].[S_OrderReceive] "
                           + "WHERE TDATE=@TDATE";
            var sqlParams = new[] { new SqlParameter("@TDATE", TDATE) };
            var dt = DBHelper.QueryData("KeyIn", sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            return dt.AsEnumerable().Select(row => row.Field<string>("UniqueKey"));
        }

        /// <summary>
        /// 插入新回報並取得序號
        /// </summary>
        /// <param name="TDATE">交易日</param>
        /// <param name="REGCODE">註冊碼</param>
        /// <param name="PUSHMSG">Push電文</param>
        /// <param name="UNIQUEKEY">獨立KEY值</param>
        /// <param name="isInsert">是否為新增</param>
        /// <returns>序號</returns>
        public static int GetSerialNumber(string TDATE, string REGCODE, string PUSHMSG, string UNIQUEKEY, ref bool isInsert)
        {
            try
            {
                var cmdText = @"SET XACT_ABORT ON
BEGIN TRANSACTION
DECLARE @SNO int
SELECT @SNO=[SerialNO] FROM [KeyIn].[dbo].[S_OrderReceive] WITH (UPDLOCK, HOLDLOCK) WHERE [UniqueKey]=@UNIQUEKEY

IF @SNO IS NOT NULL
    SELECT @SNO AS SNO
ELSE BEGIN
    INSERT INTO [KeyIn].[dbo].[S_OrderReceive] ([TDATE],[RegisterCode],[PushMsg],[UniqueKey])
    VALUES (@TDATE,@REGCODE,@PUSHMSG,@UNIQUEKEY);
    SELECT SCOPE_IDENTITY() AS SNOI
END
COMMIT TRANSACTION";
                using (var sqlConn = new SqlConnection(m_sqlConn))
                using (var sqlCmd = new SqlCommand(cmdText, sqlConn))
                using (var sda = new SqlDataAdapter(sqlCmd))
                {
                    sqlCmd.Parameters.AddWithValue("@TDATE", TDATE);
                    sqlCmd.Parameters.AddWithValue("@PUSHMSG", PUSHMSG);
                    sqlCmd.Parameters.AddWithValue("@REGCODE", REGCODE);
                    sqlCmd.Parameters.AddWithValue("@UNIQUEKEY", UNIQUEKEY);
                    var dt = new DataTable();
                    sda.Fill(dt);
                    isInsert = dt.Columns[0].ColumnName == "SNOI";
                    return Convert.ToInt32(dt.Rows[0][0]);
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GetSerialNumber 錯誤", ex);
                ConcordLogger.Alert("9999", "GetSerialNumber 錯誤", ex.ToString());
                return 0;
            }
        }
    }
}
