﻿namespace Concord.KeyIn.Stock.SOrderReceive
{
    partial class frmSOrderReceive
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.SOrderReceiveQueue = new System.Messaging.MessageQueue();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gbStatus = new System.Windows.Forms.GroupBox();
            this.tlpStatus = new System.Windows.Forms.TableLayoutPanel();
            this.lblcBOSStatus = new System.Windows.Forms.Label();
            this.lblBOSStatus = new System.Windows.Forms.Label();
            this.lblcPSStatus = new System.Windows.Forms.Label();
            this.lblPSStatus = new System.Windows.Forms.Label();
            this.gbTransData = new System.Windows.Forms.GroupBox();
            this.tlpTransData = new System.Windows.Forms.TableLayoutPanel();
            this.txtRecvData = new System.Windows.Forms.RichTextBox();
            this.txtSendData = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.gbStatus.SuspendLayout();
            this.tlpStatus.SuspendLayout();
            this.gbTransData.SuspendLayout();
            this.tlpTransData.SuspendLayout();
            this.SuspendLayout();
            // 
            // SOrderReceiveQueue
            // 
            this.SOrderReceiveQueue.MessageReadPropertyFilter.LookupId = true;
            this.SOrderReceiveQueue.SynchronizingObject = this;
            this.SOrderReceiveQueue.ReceiveCompleted += new System.Messaging.ReceiveCompletedEventHandler(this.SOrderReceiveQueue_ReceiveCompleted);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.gbStatus, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.gbTransData, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(584, 442);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // gbStatus
            // 
            this.gbStatus.Controls.Add(this.tlpStatus);
            this.gbStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbStatus.Location = new System.Drawing.Point(3, 3);
            this.gbStatus.Name = "gbStatus";
            this.gbStatus.Size = new System.Drawing.Size(578, 90);
            this.gbStatus.TabIndex = 0;
            this.gbStatus.TabStop = false;
            this.gbStatus.Text = "主程式狀態";
            // 
            // tlpStatus
            // 
            this.tlpStatus.ColumnCount = 3;
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.Controls.Add(this.lblcBOSStatus, 0, 1);
            this.tlpStatus.Controls.Add(this.lblBOSStatus, 1, 1);
            this.tlpStatus.Controls.Add(this.lblcPSStatus, 0, 0);
            this.tlpStatus.Controls.Add(this.lblPSStatus, 1, 0);
            this.tlpStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStatus.Location = new System.Drawing.Point(3, 18);
            this.tlpStatus.Name = "tlpStatus";
            this.tlpStatus.RowCount = 2;
            this.tlpStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStatus.Size = new System.Drawing.Size(572, 69);
            this.tlpStatus.TabIndex = 0;
            // 
            // lblcBOSStatus
            // 
            this.lblcBOSStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcBOSStatus.AutoSize = true;
            this.lblcBOSStatus.Location = new System.Drawing.Point(17, 45);
            this.lblcBOSStatus.Name = "lblcBOSStatus";
            this.lblcBOSStatus.Size = new System.Drawing.Size(41, 12);
            this.lblcBOSStatus.TabIndex = 4;
            this.lblcBOSStatus.Text = "後台：";
            // 
            // lblBOSStatus
            // 
            this.lblBOSStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBOSStatus.AutoSize = true;
            this.lblBOSStatus.Location = new System.Drawing.Point(84, 45);
            this.lblBOSStatus.Name = "lblBOSStatus";
            this.lblBOSStatus.Size = new System.Drawing.Size(41, 12);
            this.lblBOSStatus.TabIndex = 5;
            this.lblBOSStatus.Text = "未連線";
            // 
            // lblcPSStatus
            // 
            this.lblcPSStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblcPSStatus.AutoSize = true;
            this.lblcPSStatus.Location = new System.Drawing.Point(3, 11);
            this.lblcPSStatus.Name = "lblcPSStatus";
            this.lblcPSStatus.Size = new System.Drawing.Size(69, 12);
            this.lblcPSStatus.TabIndex = 6;
            this.lblcPSStatus.Text = "PushServer：";
            // 
            // lblPSStatus
            // 
            this.lblPSStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPSStatus.AutoSize = true;
            this.lblPSStatus.Location = new System.Drawing.Point(84, 11);
            this.lblPSStatus.Name = "lblPSStatus";
            this.lblPSStatus.Size = new System.Drawing.Size(41, 12);
            this.lblPSStatus.TabIndex = 7;
            this.lblPSStatus.Text = "未連線";
            // 
            // gbTransData
            // 
            this.gbTransData.Controls.Add(this.tlpTransData);
            this.gbTransData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbTransData.Location = new System.Drawing.Point(3, 99);
            this.gbTransData.Name = "gbTransData";
            this.gbTransData.Size = new System.Drawing.Size(578, 340);
            this.gbTransData.TabIndex = 1;
            this.gbTransData.TabStop = false;
            this.gbTransData.Text = "收送資訊";
            // 
            // tlpTransData
            // 
            this.tlpTransData.ColumnCount = 1;
            this.tlpTransData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpTransData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpTransData.Controls.Add(this.txtRecvData, 0, 0);
            this.tlpTransData.Controls.Add(this.txtSendData, 0, 1);
            this.tlpTransData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpTransData.Location = new System.Drawing.Point(3, 18);
            this.tlpTransData.Name = "tlpTransData";
            this.tlpTransData.RowCount = 2;
            this.tlpTransData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTransData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTransData.Size = new System.Drawing.Size(572, 319);
            this.tlpTransData.TabIndex = 0;
            // 
            // txtRecvData
            // 
            this.txtRecvData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRecvData.Location = new System.Drawing.Point(3, 3);
            this.txtRecvData.Name = "txtRecvData";
            this.txtRecvData.ReadOnly = true;
            this.txtRecvData.Size = new System.Drawing.Size(566, 153);
            this.txtRecvData.TabIndex = 0;
            this.txtRecvData.Text = "";
            // 
            // txtSendData
            // 
            this.txtSendData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSendData.Location = new System.Drawing.Point(3, 162);
            this.txtSendData.Name = "txtSendData";
            this.txtSendData.ReadOnly = true;
            this.txtSendData.Size = new System.Drawing.Size(566, 154);
            this.txtSendData.TabIndex = 1;
            this.txtSendData.Text = "";
            // 
            // frmSOrderReceive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 442);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmSOrderReceive";
            this.Text = "KeyIn證券回報";
            this.Load += new System.EventHandler(this.frmSOrderReceive_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.gbStatus.ResumeLayout(false);
            this.tlpStatus.ResumeLayout(false);
            this.tlpStatus.PerformLayout();
            this.gbTransData.ResumeLayout(false);
            this.tlpTransData.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Messaging.MessageQueue SOrderReceiveQueue;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox gbStatus;
        private System.Windows.Forms.TableLayoutPanel tlpStatus;
        private System.Windows.Forms.GroupBox gbTransData;
        private System.Windows.Forms.TableLayoutPanel tlpTransData;
        private System.Windows.Forms.RichTextBox txtRecvData;
        private System.Windows.Forms.RichTextBox txtSendData;
        private System.Windows.Forms.Label lblcBOSStatus;
        private System.Windows.Forms.Label lblBOSStatus;
        private System.Windows.Forms.Label lblcPSStatus;
        private System.Windows.Forms.Label lblPSStatus;
    }
}

