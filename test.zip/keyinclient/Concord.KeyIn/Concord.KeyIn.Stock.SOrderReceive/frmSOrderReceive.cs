﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Messaging;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public partial class frmSOrderReceive : Form
    {
        #region 變數定義
        private static readonly string m_pushIp = Properties.Settings.Default.PushIP;
        private static readonly int m_pushPort = Properties.Settings.Default.PushPort;
        private static readonly string m_bosIp = Properties.Settings.Default.BosIP;
        private static readonly int m_bosPort = Properties.Settings.Default.BosPort;
        private readonly bool m_isForced = Properties.Settings.Default.IsForced;
        private readonly string m_sOrderReceiveQueuePath = Properties.Settings.Default.SOrderReceiveQueuePath;
        private readonly string m_sOrderReceiveQueueName = Properties.Settings.Default.SOrderReceiveQueueName;
        private readonly string m_sMessageParserQueuePath = Properties.Settings.Default.SMessageParserQueuePath;
        private readonly string m_sMessageParserQueueName = Properties.Settings.Default.SMessageParserQueueName;
        private readonly BosClient m_bosClient = new BosClient(new DnsEndPoint(m_bosIp, m_bosPort));
        private readonly ConcordPushClient m_pushClient = new ConcordPushClient(new DnsEndPoint(m_pushIp, m_pushPort));
        private readonly AsyncQueue<string> m_orMessageQueue = new AsyncQueue<string>();
        private readonly AsyncQueue<string> m_drMessageQueue = new AsyncQueue<string>();
        private readonly AsyncQueue<string> m_sMessageQueue = new AsyncQueue<string>();
        private readonly HashSet<string> m_messageSet = new HashSet<string>();
        private int m_bosClientFailCount = 0;
        private int m_pushClientFailCount = 0;
        #endregion

        #region Form 設定
        public frmSOrderReceive()
        {
            InitializeComponent();
        }

        private void frmSOrderReceive_Load(object sender, EventArgs e)
        {
            #region 檢查交易日
            if (!DAL.IsTradeDay && !m_isForced)
            {
                ConcordLogger.Logger.Info($"{DateTime.Today:yyyy/MM/dd} 非交易日");
                Close();
                return;
            }
            #endregion

            var errorMessage = "";
            var uk = DAL.GetORUniqueKeys(DateTime.Today.ToString("yyyyMMdd"), ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                ConcordLogger.Logger.Error("取得今日回報錯誤", new Exception(errorMessage));
                ConcordLogger.Alert("9999", "取得今日回報錯誤", errorMessage);
            }
            else
            {
                foreach (var message in uk)
                    m_messageSet.Add(message);
            }

            ConfigureBosClient();
            ConfigurePushClient();

            Task.Run(DequeueBosORMessage);
            Task.Run(DequeueBosDRMessage);
            Task.Run(DequeueSMessage);

            SOrderReceiveQueue.Path = m_sOrderReceiveQueuePath + m_sOrderReceiveQueueName;
            SOrderReceiveQueue.Formatter = new BinaryMessageFormatter();
            SOrderReceiveQueue.BeginReceive();
        }
        #endregion

        #region 證後台 Client 設定
        private void ConfigureBosClient()
        {
            m_bosClient.NoDelay = true;
            m_bosClient.OnConnect += Client_OnConnect;
            m_bosClient.OnConnectFail += Client_OnConnectFail;
            m_bosClient.OnReceiveBosMessage += Client_OnReceiveBosMessage;
            m_bosClient.OnReceiveFailMsg += Client_OnReceiveFailMsg;
            m_bosClient.OnSendMsg += Client_OnSendMsg;
            m_bosClient.OnSendFailMsg += Client_OnSendFailMsg;
            m_bosClient.DoConnect();
        }

        private void Client_OnConnect()
        {
            m_bosClientFailCount = 0;
            ConcordLogger.Logger.Info($"證後台 {m_bosIp}:{m_bosPort} 已連線");
            BeginInvoke((Action)(() => lblBOSStatus.Text = "已連線"));
        }

        private void Client_OnConnectFail(string message)
        {
            m_bosClientFailCount++;
            ConcordLogger.Logger.Error($"證後台 {m_bosIp}:{m_bosPort} 連線失敗：{message}");
            if (m_bosClientFailCount <= 5)
                ConcordLogger.Alert("9999", $"證後台 {m_bosIp}:{m_bosPort} 連線失敗", message);
            BeginInvoke((Func<Task>)(async () =>
            {
                lblBOSStatus.Text = "連線失敗";
                await Task.Delay(500);
                lblBOSStatus.Text = "重連中";
            }));
        }

        private void Client_OnReceiveBosMessage(byte type, string message)
        {
            switch (type)
            {
                case 0:
                    ConcordLogger.Logger.Debug($"收到心跳訊息：{message}");
                    break;
                case 2:
                    m_orMessageQueue.Enqueue(message);
                    break;
                case 3:
                    m_drMessageQueue.Enqueue(message);
                    break;
                case 4:
                    SendLastFillReport(message);
                    break;
                default:
                    ConcordLogger.Logger.Warn($"收到未知訊息：{type}, {message}");
                    break;
            }
            BeginInvoke((Action)(() => txtRecvData.Text = message));
        }

        private void Client_OnReceiveFailMsg(string message)
        {
            ConcordLogger.Logger.Error($"證後台訊息接收失敗：{message}");
            ConcordLogger.Alert("9999", "證後台訊息接收失敗", message);
            BeginInvoke((Action)(() => txtRecvData.Text = $"接收失敗：{message}"));
        }

        private void Client_OnSendMsg(string message)
        {
            ConcordLogger.Logger.Debug($"送至證後台：{message}");
        }

        private void Client_OnSendFailMsg(string message)
        {
            ConcordLogger.Logger.Warn($"證後台訊息傳送失敗：{message}");
        }
        #endregion

        #region PushServer 設定
        private void ConfigurePushClient()
        {
            m_pushClient.NoDelay = true;
            m_pushClient.OnConnect += Push_OnConnect;
            m_pushClient.OnConnectFail += Push_OnConnectFail;
            m_pushClient.OnReceiveMsg += Push_OnReceiveMsg;
            m_pushClient.OnReceiveFailMsg += Push_OnReceiveFailMsg;
            m_pushClient.OnSendMsg += Push_OnSendMsg;
            m_pushClient.OnSendFailMsg += Push_OnSendFailMsg;
            m_pushClient.DoConnect();
        }

        private void Push_OnConnect()
        {
            m_pushClientFailCount = 0;
            ConcordLogger.Logger.Info($"PushServer {m_pushIp}:{m_pushPort} 已連線");
            BeginInvoke((Action)(() => lblPSStatus.Text = "已連線"));
        }

        private void Push_OnConnectFail(string message)
        {
            m_pushClientFailCount++;
            ConcordLogger.Logger.Error($"PushServer {m_pushIp}:{m_pushPort} 連線失敗：{message}");
            if (m_pushClientFailCount <= 5)
                ConcordLogger.Alert("9999", $"PushServer {m_pushIp}:{m_pushPort} 連線失敗", message);
            BeginInvoke((Func<Task>)(async () =>
            {
                lblPSStatus.Text = "連線失敗";
                await Task.Delay(500);
                lblPSStatus.Text = "重連中";
            }));
        }

        private void Push_OnReceiveMsg(string message)
        {
            ConcordLogger.Logger.Info($"從 PushServer 接收：{message}");
        }

        private void Push_OnReceiveFailMsg(string message)
        {
            ConcordLogger.Logger.Warn($"PushServer 訊息接收失敗：{message}");
        }

        private void Push_OnSendMsg(string message)
        {
            ConcordLogger.Logger.Info($"送至 PushServer：{message}");
            BeginInvoke((Action)(() => txtSendData.Text = message));
        }

        private void Push_OnSendFailMsg(string message)
        {
            ConcordLogger.Logger.Error($"PushServer 訊息傳送失敗：{message}");
            ConcordLogger.Alert("9999", "PushServer 訊息傳送失敗", message);
            BeginInvoke((Action)(() => txtSendData.Text = $"傳送失敗：{message}"));
        }
        #endregion

        #region 處理回報電文
        private async Task DequeueBosORMessage()
        {
            string message;
            while (true)
            {
                if (m_orMessageQueue.TryDequeue(out message))
                {
                    try
                    {
                        ConcordLogger.Logger.Debug($"處理委回電文：{message}");
                        if (!m_messageSet.Add(message))
                        {
                            ConcordLogger.Logger.Debug("重覆回報");
                            continue;
                        }
                        var or = message.ParseToORMessage();
                        var isErrAcc = or.BHNO == "0" && or.CSEQ == "000333" && or.CKNO == "2";
                        var regcode = isErrAcc ? or.CSEQ + or.CKNO : or.BHNO;
                        var fixMessage = or.ToFixMessage();
                        var isInsert = false;
                        var serialNo = DAL.GetSerialNumber(or.TDATE, regcode, fixMessage, message, ref isInsert);
                        fixMessage = string.Format(fixMessage, serialNo);
                        var pushMessage = $"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(fixMessage)}{fixMessage}";
                        m_pushClient.SendMessage("OrderReceive", regcode, "N", pushMessage);
                        if (isInsert)
                            m_sMessageQueue.Enqueue($"KeyIn$S$OR${pushMessage}");
                    }
                    catch (Exception ex)
                    {
                        ConcordLogger.Logger.Error("DequeueBosORMessage 錯誤", ex);
                        ConcordLogger.Alert("9999", "DequeueBosORMessage 錯誤", ex.ToString());
                    }
                }
                else await m_orMessageQueue.WaitAsync();
            }
        }

        private async Task DequeueBosDRMessage()
        {
            string message;
            while (true)
            {
                if (m_drMessageQueue.TryDequeue(out message))
                {
                    try
                    {
                        ConcordLogger.Logger.Debug($"處理成回電文：{message}");
                        if (!m_messageSet.Add(message))
                        {
                            ConcordLogger.Logger.Debug("重覆回報");
                            continue;
                        }
                        var dr = message.ParseToDRMessage();
                        var isErrAcc = dr.BHNO == "0" && dr.CSEQ == "000333" && dr.CKNO == "2";
                        var regcode = isErrAcc ? dr.CSEQ + dr.CKNO : dr.BHNO;
                        var fixMessage = dr.ToFixMessage();
                        var isInsert = false;
                        var serialNo = DAL.GetSerialNumber(dr.TDATE, regcode, fixMessage, message, ref isInsert);
                        fixMessage = string.Format(fixMessage, serialNo);
                        var pushMessage = $"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(fixMessage)}{fixMessage}";
                        m_pushClient.SendMessage("OrderReceive", regcode, "N", pushMessage);
                        if (isInsert)
                            m_sMessageQueue.Enqueue($"KeyIn$S$DR${pushMessage}");
                    }
                    catch (Exception ex)
                    {
                        ConcordLogger.Logger.Error("DequeueBosDRMessage 錯誤", ex);
                        ConcordLogger.Alert("9999", "DequeueBosDRMessage 錯誤", ex.ToString());
                    }
                }
                else await m_drMessageQueue.WaitAsync();
            }
        }

        private void SendLastFillReport(string message)
        {
            var fixMessage = $"|35=LF|20005={message}";
            var isInsert = false;
            DAL.GetSerialNumber(DateTime.Today.ToString("yyyyMMdd"), "*", fixMessage, message, ref isInsert);
            var pushMessage = $"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(fixMessage)}{fixMessage}";
            m_pushClient.SendMessage("LastFill", "*", "N", pushMessage);
        }
        #endregion

        #region 回報電文送至 SMessageParser MSMQ
        private async Task DequeueSMessage()
        {
            var fullPath = m_sMessageParserQueuePath + m_sMessageParserQueueName;
            var msmq = new MessageQueue(fullPath);
            string message;
            while (true)
            {
                if (m_sMessageQueue.TryDequeue(out message))
                {
                    var mm = new System.Messaging.Message(message, new BinaryMessageFormatter());
                    try
                    {
                        msmq.Send(mm);
                        ConcordLogger.Logger.Debug($"中台回報送 MSMQ：{message}");
                    }
                    catch (Exception ex)
                    {
                        ConcordLogger.Logger.Error("DequeueSMessage 錯誤", ex);
                        ConcordLogger.Alert("9999", "DequeueSMessage 錯誤", ex.ToString());
                    }
                }
                else await m_sMessageQueue.WaitAsync();
            }
        }
        #endregion

        #region 從 MSMQ 接收錯誤單回報
        private void SOrderReceiveQueue_ReceiveCompleted(object sender, ReceiveCompletedEventArgs e)
        {
            try
            {
                var mm = SOrderReceiveQueue.EndReceive(e.AsyncResult);
                mm.Formatter = new BinaryMessageFormatter();
                var message = mm.Body.ToString();
                ConcordLogger.Logger.Info($"處理錯誤單：{message}");
                // registerCode, uniqueKey, body
                var arr = message.Split(new char[] { '$' }, 3);
                var isInsert = false;
                var serialNo = DAL.GetSerialNumber(DateTime.Today.ToString("yyyyMMdd"), arr[0], arr[2], arr[1], ref isInsert);
                var pushBody = string.Format(arr[2], serialNo);
                var pushMessage = $"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(pushBody)}{pushBody}";
                m_pushClient.SendMessage("OrderReceive", arr[0], "N", pushMessage);
                if (isInsert)
                    m_sMessageQueue.Enqueue($"KeyIn$S$OR${pushMessage}");
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("收回報MSMQ異常", ex);
                ConcordLogger.Alert("9999", "收回報MSMQ異常", ex.ToString());
            }
            finally
            {
                SOrderReceiveQueue.BeginReceive();
            }
        }
        #endregion
    }
}
