﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.ThreadException += Application_ThreadException;
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            ConcordLogger.Logger.Info("程式開始");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var form = new frmSOrderReceive();
            var sysType = Properties.Settings.Default.SysType;
            form.Text += sysType == 0 ? "(經紀版本)" : sysType == 1 ? "(自營版本)" : "";
            Application.Run(form);

            ConcordLogger.Logger.Info("程式結束");
        }

        private static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            ConcordLogger.Logger.Error("Application_ThreadException", e.Exception);
            MessageBox.Show("程式發生錯誤，即將關閉");
            Environment.Exit(Environment.ExitCode);
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var ex = e.ExceptionObject as Exception ?? new Exception();
            ConcordLogger.Logger.Error("CurrentDomain_UnhandledException", ex);
            Environment.Exit(Environment.ExitCode);
        }
    }
}
