﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public class ORMessage
    {
        public string BHNO { get; set; }
        public string MSEQNO { get; set; }
        public string CDI { get; set; }
        public string TERM { get; set; }
        public string DSEQ { get; set; }
        public string SEQNO { get; set; }
        public string CSEQ { get; set; }
        public string CKNO { get; set; }
        public string OTYPE { get; set; }
        public string STOCK { get; set; }
        public string ECODE { get; set; }
        public int BFQTY { get; set; }
        public int AFQTY { get; set; }
        public int OQTY { get; set; }
        public int OriQTY { get; set; }
        public string PRICE { get; set; }
        public string BS { get; set; }
        public string TDATE { get; set; }
        public string TTIME { get; set; }
        public string ORIGN { get; set; }
        public string DTrade { get; set; }
        public string SIP { get; set; }
        public string SALE { get; set; }
        public string MTYPE { get; set; }
        public string ErrorFlag { get; set; } = "";
        public string ETYPE { get; set; } = "";
        public string Msg { get; set; } = "";
        public string ORDTYPE { get; set; }
        public string TIF { get; set; }
        public string KEYIN { get; set; }

        public string ToFixMessage()
        {
            string msgType = "", status = "";
            string oqty = "", roqty = "", bfqty = BFQTY.ToString();
            if (ErrorFlag == "E")
            {
                msgType = CDI == "I" ? "8" : "9";
                status = "8";
            }
            else
            {
                //可能為警告單，會有警示訊息
                msgType = "8";
                switch (CDI)
                {
                    case "I":
                        status = "0";
                        oqty = OriQTY.ToString();
                        roqty = OQTY.ToString();
                        bfqty = "0";
                        break;
                    case "D":
                        status = "4";
                        oqty = OQTY.ToString();
                        break;
                    case "C":
                        status = "5";
                        oqty = OQTY.ToString();
                        break;
                    case "P":
                        status = "M";
                        oqty = "0";
                        bfqty = AFQTY.ToString();
                        break;
                    default:
                        break;
                }
            }
            if (string.IsNullOrEmpty(TTIME))
                TTIME = DateTime.Now.ToString("HHmmssfff");
            var dicMessage = new List<KeyValuePair<uint, string>>();
            dicMessage.Add(new KeyValuePair<uint, string>(35, msgType));
            dicMessage.Add(new KeyValuePair<uint, string>(52, $"{TDATE}-{TTIME.Substring(0, 2)}:{TTIME.Substring(2, 2)}:{TTIME.Substring(4, 2)}.{TTIME.Substring(6, 3)}"));
            dicMessage.Add(new KeyValuePair<uint, string>(34, "{0}"));
            dicMessage.Add(new KeyValuePair<uint, string>(11, MSEQNO));
            dicMessage.Add(new KeyValuePair<uint, string>(41, SEQNO));
            dicMessage.Add(new KeyValuePair<uint, string>(150, status));
            dicMessage.Add(new KeyValuePair<uint, string>(10002, CDI));
            dicMessage.Add(new KeyValuePair<uint, string>(37, $"{TERM}{DSEQ}"));
            dicMessage.Add(new KeyValuePair<uint, string>(50, BHNO));
            dicMessage.Add(new KeyValuePair<uint, string>(1, $"{CSEQ}{CKNO}"));
            if (!string.IsNullOrEmpty(ErrorFlag))
            {
                dicMessage.Add(new KeyValuePair<uint, string>(103, ETYPE));
                dicMessage.Add(new KeyValuePair<uint, string>(58, Msg));
            }
            dicMessage.Add(new KeyValuePair<uint, string>(56, MTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(57, ECODE));
            dicMessage.Add(new KeyValuePair<uint, string>(10001, OTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(55, STOCK));
            dicMessage.Add(new KeyValuePair<uint, string>(54, BS));
            dicMessage.Add(new KeyValuePair<uint, string>(40, ORDTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(59, TIF));
            dicMessage.Add(new KeyValuePair<uint, string>(38, oqty));
            dicMessage.Add(new KeyValuePair<uint, string>(20053, roqty));
            dicMessage.Add(new KeyValuePair<uint, string>(44, PRICE));
            dicMessage.Add(new KeyValuePair<uint, string>(60, $"{TDATE}-{TTIME}"));
            dicMessage.Add(new KeyValuePair<uint, string>(10000, ORIGN));
            dicMessage.Add(new KeyValuePair<uint, string>(20001, SALE));
            dicMessage.Add(new KeyValuePair<uint, string>(20003, DTrade));
            dicMessage.Add(new KeyValuePair<uint, string>(20004, SIP));
            dicMessage.Add(new KeyValuePair<uint, string>(20009, bfqty));
            dicMessage.Add(new KeyValuePair<uint, string>(20010, AFQTY.ToString()));
            dicMessage.Add(new KeyValuePair<uint, string>(50002, KEYIN));

            return dicMessage.Aggregate(
                "",
                (m, kvp) => $"{m}|{kvp.Key}={kvp.Value}",
                m => m);
        }
    }
}
