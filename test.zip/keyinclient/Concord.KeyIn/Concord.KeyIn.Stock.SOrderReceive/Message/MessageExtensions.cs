﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public static class ConcordMessageExtensions
    {
        private const char cSectionSplitChar = '|';
        private const char cDataSplitChar = '=';

        public static KeyValuePair<uint, string>? GetSingleTagValue(this string section, char splitChar = cSectionSplitChar)
        {
            var pair = section.Split(new[] { cDataSplitChar }, 2);
            if (pair.Length != 2)
                return null;
            uint tag;
            if (!uint.TryParse(pair[0], out tag) || tag <= 0)
                return null;
            return new KeyValuePair<uint, string>(tag, pair[1]);
        }

        public static ORMessage ParseToORMessage(this string message)
        {
            var or = new ORMessage();
            or.BHNO = message.Substring(0, 1).Trim();
            or.MSEQNO = message.Substring(1, 6).Trim().PadLeft(6, '0');//人工單把網單補滿000000
            var CDI = message.Substring(7, 1).Trim();
            switch (CDI)
            {
                case "D":
                    or.CDI = "I";
                    break;
                case "G":
                    or.CDI = "C";
                    break;
                case "P":
                    or.CDI = "P";
                    break;
                case "F":
                    or.CDI = "D";
                    break;
                default:
                    or.CDI = CDI;
                    break;
            }
            or.TERM = message.Substring(8, 1).Trim().PadLeft(1, '0');//錯誤單補櫃號=0
            or.DSEQ = message.Substring(9, 4).Trim().PadLeft(4, '0');//錯誤單=0000
            or.SEQNO = message.Substring(13, 6).Trim().PadLeft(6, '0');//人工單把網單補滿000000
            or.CSEQ = message.Substring(19, 6).Trim();
            or.CKNO = message.Substring(25, 1).Trim();
            or.STOCK = message.Substring(27, 6).Trim();
            or.OTYPE = message.Substring(33, 1).Trim();
            or.ECODE = message.Substring(34, 1).Trim();
            or.OriQTY = int.Parse(message.Substring(35, 6).Trim());
            or.OQTY = int.Parse(message.Substring(41, 6).Trim());
            or.AFQTY = int.Parse(message.Substring(47, 6).Trim());
            or.BFQTY = or.OQTY + or.AFQTY;
            or.ORDTYPE = message.Substring(53, 1).Trim();
            or.TIF = message.Substring(54, 1).Trim();
            or.PRICE = int.Parse(message.Substring(55, 5).Trim()).ToString() + "." + message.Substring(60, 4).Trim();
            var BS = message.Substring(64, 1).Trim();
            switch (BS)
            {
                case "1":
                    or.BS = "B";
                    break;
                case "2":
                    or.BS = "S";
                    break;
                default:
                    or.BS = BS;
                    break;
            }
            or.TDATE = message.Substring(65, 8).Trim();
            or.TTIME = message.Substring(73, 9).Trim();
            or.ORIGN = message.Substring(83, 1).Trim();
            or.DTrade = message.Substring(84, 1).Trim();
            or.SIP = message.Substring(85, 1).Trim();
            or.SALE = message.Substring(90, 3).Trim();
            or.MTYPE = message.Substring(93, 1).Trim();
            if (message.Length > 95)
            {
                or.ErrorFlag = message.Substring(94, 1).Trim();
                or.ETYPE = message.Substring(95, 4).Trim();
                or.Msg = message.Substring(99).Trim();
            }
            return or;
        }

        public static DRMessage ParseToDRMessage(this string message)
        {
            var dr = new DRMessage();
            dr.BHNO = message.Substring(0, 1).Trim();
            dr.TERM = message.Substring(1, 1).Trim();
            dr.DSEQ = message.Substring(2, 4).Trim();
            dr.SEQNO = message.Substring(6, 6).Trim().PadLeft(6, '0');//人工單把網單補滿000000
            dr.CSEQ = message.Substring(12, 6).Trim();
            dr.CKNO = message.Substring(18, 1).Trim();
            dr.MTYPE = message.Substring(19, 1).Trim();
            dr.STOCK = message.Substring(20, 6).Trim();
            dr.OTYPE = message.Substring(26, 1).Trim();
            dr.ECODE = message.Substring(27, 1).Trim();
            dr.ORDTYPE = message.Substring(28, 1).Trim();
            dr.TIF = message.Substring(29, 1).Trim();
            dr.OPRICE = int.Parse(message.Substring(30, 5).Trim()).ToString() + "." + message.Substring(35, 4).Trim();
            var BS = message.Substring(39, 1).Trim();
            switch (BS)
            {
                case "1":
                    dr.BS = "B";
                    break;
                case "2":
                    dr.BS = "S";
                    break;
                default:
                    dr.BS = BS;
                    break;
            }
            dr.QTY = int.Parse(message.Substring(40, 6).Trim());
            dr.LEAVESQTY = int.Parse(message.Substring(46, 6).Trim());
            dr.CUMQTY = int.Parse(message.Substring(52, 6).Trim());
            dr.PRICE = int.Parse(message.Substring(58, 5).Trim()).ToString() + "." + message.Substring(63, 4).Trim();
            dr.TDATE = message.Substring(67, 8).Trim();
            dr.TTIME = message.Substring(75, 9).Trim();
            dr.TSENO = message.Substring(84, 8).Trim();
            dr.ORIGN = message.Substring(92, 1).Trim();
            dr.DTRADE = message.Substring(93, 1).Trim();
            dr.SIP = message.Substring(94, 1).Trim();
            dr.SALE = message.Substring(98, 3).Trim();
            return dr;
        }
    }
}
