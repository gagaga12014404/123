﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public class DRMessage
    {
        public string BHNO { get; set; }
        public string TERM { get; set; }
        public string DSEQ { get; set; }
        public string SEQNO { get; set; }
        public string CSEQ { get; set; }
        public string CKNO { get; set; }
        public string STOCK { get; set; }
        public string OTYPE { get; set; }
        public string ECODE { get; set; }
        public int QTY { get; set; }
        public string PRICE { get; set; }
        public string BS { get; set; }
        public string MTYPE { get; set; }
        public string TDATE { get; set; }
        public string TTIME { get; set; }
        public string TSENO { get; set; }
        public string ORIGN { get; set; }
        public string DTRADE { get; set; }
        public string SIP { get; set; }
        public string SALE { get; set; }
        public string OPRICE { get; set; }
        public int LEAVESQTY { get; set; }
        public int CUMQTY { get; set; }
        public string ORDTYPE { get; set; }
        public string TIF { get; set; }

        public string ToFixMessage()
        {
            if (string.IsNullOrEmpty(TTIME))
                TTIME = DateTime.Now.ToString("HHmmssfff");
            var dicMessage = new List<KeyValuePair<uint, string>>();
            dicMessage.Add(new KeyValuePair<uint, string>(35, "8"));
            dicMessage.Add(new KeyValuePair<uint, string>(52, $"{TDATE}-{TTIME.Substring(0, 2)}:{TTIME.Substring(2, 2)}:{TTIME.Substring(4, 2)}.{TTIME.Substring(6, 3)}"));
            dicMessage.Add(new KeyValuePair<uint, string>(34, "{0}"));
            dicMessage.Add(new KeyValuePair<uint, string>(17, TSENO));
            dicMessage.Add(new KeyValuePair<uint, string>(41, SEQNO));
            dicMessage.Add(new KeyValuePair<uint, string>(150, "F"));
            dicMessage.Add(new KeyValuePair<uint, string>(37, $"{TERM}{DSEQ}"));
            dicMessage.Add(new KeyValuePair<uint, string>(50, BHNO));
            dicMessage.Add(new KeyValuePair<uint, string>(1, $"{CSEQ}{CKNO}"));
            dicMessage.Add(new KeyValuePair<uint, string>(56, MTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(57, ECODE));
            dicMessage.Add(new KeyValuePair<uint, string>(10001, OTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(55, STOCK));
            dicMessage.Add(new KeyValuePair<uint, string>(54, BS));
            dicMessage.Add(new KeyValuePair<uint, string>(40, ORDTYPE));
            dicMessage.Add(new KeyValuePair<uint, string>(59, TIF));
            dicMessage.Add(new KeyValuePair<uint, string>(32, QTY.ToString()));
            dicMessage.Add(new KeyValuePair<uint, string>(31, PRICE.ToString()));
            dicMessage.Add(new KeyValuePair<uint, string>(60, $"{TDATE}-{TTIME}"));
            dicMessage.Add(new KeyValuePair<uint, string>(10000, ORIGN));
            dicMessage.Add(new KeyValuePair<uint, string>(20001, SALE));
            dicMessage.Add(new KeyValuePair<uint, string>(20003, DTRADE));
            dicMessage.Add(new KeyValuePair<uint, string>(20004, SIP));

            return dicMessage.Aggregate(
                "",
                (m, kvp) => $"{m}|{kvp.Key}={kvp.Value}",
                m => m);
        }
    }
}
