﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public static class ByteArrayExtensions
    {
        /// <summary>
        /// 取得符合條件的資料位置
        /// </summary>
        /// <param name="data">來源資料</param>
        /// <param name="candidate">條件資料</param>
        /// <param name="offset">偏移量</param>
        /// <returns>第一個符合條件的位置</returns>
        public static int Locate(this byte[] data, byte[] candidate, int offset = 0)
        {
            if (data == null || data.Length <= offset)
                return -1;
            for (int i = offset; i < data.Length; i++)
                if (IsMatch(data, candidate, i))
                    return i;
            return -1;
        }

        public static int Locate(this byte[] data, char candidate, int offset = 0)
        {
            if (data == null || data.Length <= offset)
                return -1;
            for (int i = offset; i < data.Length; i++)
                if (data[i] == candidate)
                    return i;
            return -1;
        }

        /// <summary>
        /// 判斷是否符合條件
        /// </summary>
        /// <param name="data">來源資料</param>
        /// <param name="candidate">條件資料</param>
        /// <param name="offset">偏移量</param>
        /// <returns>是否符合</returns>
        private static bool IsMatch(byte[] data, byte[] candidate, int offset)
        {
            if (candidate == null || candidate.Length <= 0
                || data.Length - offset < candidate.Length)
                return false;
            for (int i = offset, j = 0; j < candidate.Length; i++, j++)
                if (data[i] != candidate[j])
                    return false;
            return true;
        }
    }
}
