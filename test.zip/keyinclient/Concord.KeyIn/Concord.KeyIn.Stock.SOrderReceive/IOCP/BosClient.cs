﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.IOCPHelper;

namespace Concord.KeyIn.Stock.SOrderReceive
{
    public class BosClient : AppClient
    {
        private readonly MemoryStream inMessageBuffer = new MemoryStream();
        private const char END = '\u000a';
        private readonly Encoding m_encoding = Encoding.GetEncoding("Big5");

        public event Action<byte, string> OnReceiveBosMessage;

        public BosClient(DnsEndPoint remoteEndPoint) : base(remoteEndPoint) { }

        public override void HandleReceive(byte[] data)
        {
            inMessageBuffer.Write(data, 0, data.Length);
            byte[] buffer = inMessageBuffer.ToArray();
            int sPos = 0, ePos = 0;
            while (true)
            {
                ePos = buffer.Locate(END, sPos);
                if (ePos < 0)
                    break;
                var messageType = buffer[sPos++];
                var messageRaw = m_encoding.GetString(buffer, sPos, ePos - sPos);
                OnReceiveBosMessage?.Invoke(messageType, messageRaw);
                sPos = ePos + 1;
            }
            inMessageBuffer.SetLength(0);
            if (buffer.Length > sPos)
            {
                inMessageBuffer.Write(buffer, sPos, buffer.Length - sPos);
            }
        }
    }
}
