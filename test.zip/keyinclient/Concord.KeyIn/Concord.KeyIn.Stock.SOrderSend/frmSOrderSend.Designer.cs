﻿namespace Concord.KeyIn.Stock.SOrderSend
{
    partial class frmSOrderSend
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gbStatus = new System.Windows.Forms.GroupBox();
            this.tlpStatus = new System.Windows.Forms.TableLayoutPanel();
            this.btnReloadSTMB = new System.Windows.Forms.Button();
            this.lblcBOSStatus = new System.Windows.Forms.Label();
            this.lblcTConnCount = new System.Windows.Forms.Label();
            this.lblTConnCount = new System.Windows.Forms.Label();
            this.lblBOSStatus = new System.Windows.Forms.Label();
            this.lblcCConnCount = new System.Windows.Forms.Label();
            this.lblcQuoteStatus = new System.Windows.Forms.Label();
            this.lblCConnCount = new System.Windows.Forms.Label();
            this.lblQuoteStatus = new System.Windows.Forms.Label();
            this.gbTransData = new System.Windows.Forms.GroupBox();
            this.tlpTransData = new System.Windows.Forms.TableLayoutPanel();
            this.txtSendData = new System.Windows.Forms.RichTextBox();
            this.txtRecvData = new System.Windows.Forms.RichTextBox();
            this.dgvConn = new System.Windows.Forms.DataGridView();
            this.ClientIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientPort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientConnectedTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientSessionGuid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderSendQueue = new System.Messaging.MessageQueue();
            this.tableLayoutPanel1.SuspendLayout();
            this.gbStatus.SuspendLayout();
            this.tlpStatus.SuspendLayout();
            this.gbTransData.SuspendLayout();
            this.tlpTransData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConn)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.gbStatus, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.gbTransData, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.dgvConn, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(680, 618);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // gbStatus
            // 
            this.gbStatus.Controls.Add(this.tlpStatus);
            this.gbStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbStatus.Location = new System.Drawing.Point(3, 3);
            this.gbStatus.Name = "gbStatus";
            this.gbStatus.Size = new System.Drawing.Size(674, 90);
            this.gbStatus.TabIndex = 0;
            this.gbStatus.TabStop = false;
            this.gbStatus.Text = "主程式狀態";
            // 
            // tlpStatus
            // 
            this.tlpStatus.ColumnCount = 11;
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tlpStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpStatus.Controls.Add(this.btnReloadSTMB, 8, 1);
            this.tlpStatus.Controls.Add(this.lblcBOSStatus, 0, 0);
            this.tlpStatus.Controls.Add(this.lblcTConnCount, 0, 1);
            this.tlpStatus.Controls.Add(this.lblTConnCount, 2, 1);
            this.tlpStatus.Controls.Add(this.lblBOSStatus, 1, 0);
            this.tlpStatus.Controls.Add(this.lblcCConnCount, 4, 1);
            this.tlpStatus.Controls.Add(this.lblcQuoteStatus, 4, 0);
            this.tlpStatus.Controls.Add(this.lblCConnCount, 6, 1);
            this.tlpStatus.Controls.Add(this.lblQuoteStatus, 5, 0);
            this.tlpStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStatus.Location = new System.Drawing.Point(3, 18);
            this.tlpStatus.Name = "tlpStatus";
            this.tlpStatus.RowCount = 2;
            this.tlpStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStatus.Size = new System.Drawing.Size(668, 69);
            this.tlpStatus.TabIndex = 0;
            // 
            // btnReloadSTMB
            // 
            this.btnReloadSTMB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tlpStatus.SetColumnSpan(this.btnReloadSTMB, 2);
            this.btnReloadSTMB.Location = new System.Drawing.Point(271, 37);
            this.btnReloadSTMB.Name = "btnReloadSTMB";
            this.btnReloadSTMB.Size = new System.Drawing.Size(75, 29);
            this.btnReloadSTMB.TabIndex = 6;
            this.btnReloadSTMB.Text = "重取股票檔";
            this.btnReloadSTMB.UseVisualStyleBackColor = true;
            this.btnReloadSTMB.Click += new System.EventHandler(this.btnReloadSTMB_Click);
            // 
            // lblcBOSStatus
            // 
            this.lblcBOSStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblcBOSStatus.AutoSize = true;
            this.lblcBOSStatus.Location = new System.Drawing.Point(3, 11);
            this.lblcBOSStatus.Name = "lblcBOSStatus";
            this.lblcBOSStatus.Size = new System.Drawing.Size(41, 12);
            this.lblcBOSStatus.TabIndex = 0;
            this.lblcBOSStatus.Text = "後台：";
            // 
            // lblcTConnCount
            // 
            this.lblcTConnCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblcTConnCount.AutoSize = true;
            this.tlpStatus.SetColumnSpan(this.lblcTConnCount, 2);
            this.lblcTConnCount.Location = new System.Drawing.Point(3, 45);
            this.lblcTConnCount.Name = "lblcTConnCount";
            this.lblcTConnCount.Size = new System.Drawing.Size(77, 12);
            this.lblcTConnCount.TabIndex = 2;
            this.lblcTConnCount.Text = "總連線次數：";
            // 
            // lblTConnCount
            // 
            this.lblTConnCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTConnCount.AutoSize = true;
            this.lblTConnCount.Location = new System.Drawing.Point(100, 45);
            this.lblTConnCount.Name = "lblTConnCount";
            this.lblTConnCount.Size = new System.Drawing.Size(11, 12);
            this.lblTConnCount.TabIndex = 3;
            this.lblTConnCount.Text = "0";
            // 
            // lblBOSStatus
            // 
            this.lblBOSStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblBOSStatus.AutoSize = true;
            this.tlpStatus.SetColumnSpan(this.lblBOSStatus, 2);
            this.lblBOSStatus.Location = new System.Drawing.Point(50, 11);
            this.lblBOSStatus.Name = "lblBOSStatus";
            this.lblBOSStatus.Size = new System.Drawing.Size(41, 12);
            this.lblBOSStatus.TabIndex = 1;
            this.lblBOSStatus.Text = "未連線";
            // 
            // lblcCConnCount
            // 
            this.lblcCConnCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblcCConnCount.AutoSize = true;
            this.tlpStatus.SetColumnSpan(this.lblcCConnCount, 2);
            this.lblcCConnCount.Location = new System.Drawing.Point(137, 45);
            this.lblcCConnCount.Name = "lblcCConnCount";
            this.lblcCConnCount.Size = new System.Drawing.Size(77, 12);
            this.lblcCConnCount.TabIndex = 4;
            this.lblcCConnCount.Text = "目前連線數：";
            // 
            // lblcQuoteStatus
            // 
            this.lblcQuoteStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblcQuoteStatus.AutoSize = true;
            this.lblcQuoteStatus.Location = new System.Drawing.Point(137, 11);
            this.lblcQuoteStatus.Name = "lblcQuoteStatus";
            this.lblcQuoteStatus.Size = new System.Drawing.Size(41, 12);
            this.lblcQuoteStatus.TabIndex = 7;
            this.lblcQuoteStatus.Text = "行情：";
            // 
            // lblCConnCount
            // 
            this.lblCConnCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblCConnCount.AutoSize = true;
            this.lblCConnCount.Location = new System.Drawing.Point(234, 45);
            this.lblCConnCount.Name = "lblCConnCount";
            this.lblCConnCount.Size = new System.Drawing.Size(11, 12);
            this.lblCConnCount.TabIndex = 5;
            this.lblCConnCount.Text = "0";
            // 
            // lblQuoteStatus
            // 
            this.lblQuoteStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblQuoteStatus.AutoSize = true;
            this.tlpStatus.SetColumnSpan(this.lblQuoteStatus, 2);
            this.lblQuoteStatus.Location = new System.Drawing.Point(184, 11);
            this.lblQuoteStatus.Name = "lblQuoteStatus";
            this.lblQuoteStatus.Size = new System.Drawing.Size(53, 12);
            this.lblQuoteStatus.TabIndex = 8;
            this.lblQuoteStatus.Text = "未初始化";
            // 
            // gbTransData
            // 
            this.gbTransData.Controls.Add(this.tlpTransData);
            this.gbTransData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbTransData.Location = new System.Drawing.Point(3, 99);
            this.gbTransData.Name = "gbTransData";
            this.gbTransData.Size = new System.Drawing.Size(674, 200);
            this.gbTransData.TabIndex = 1;
            this.gbTransData.TabStop = false;
            this.gbTransData.Text = "收送資訊";
            // 
            // tlpTransData
            // 
            this.tlpTransData.ColumnCount = 1;
            this.tlpTransData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpTransData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpTransData.Controls.Add(this.txtSendData, 0, 1);
            this.tlpTransData.Controls.Add(this.txtRecvData, 0, 0);
            this.tlpTransData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpTransData.Location = new System.Drawing.Point(3, 18);
            this.tlpTransData.Name = "tlpTransData";
            this.tlpTransData.RowCount = 2;
            this.tlpTransData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTransData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTransData.Size = new System.Drawing.Size(668, 179);
            this.tlpTransData.TabIndex = 0;
            // 
            // txtSendData
            // 
            this.txtSendData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSendData.Location = new System.Drawing.Point(3, 92);
            this.txtSendData.Name = "txtSendData";
            this.txtSendData.ReadOnly = true;
            this.txtSendData.Size = new System.Drawing.Size(662, 84);
            this.txtSendData.TabIndex = 1;
            this.txtSendData.Text = "";
            // 
            // txtRecvData
            // 
            this.txtRecvData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRecvData.Location = new System.Drawing.Point(3, 3);
            this.txtRecvData.Name = "txtRecvData";
            this.txtRecvData.ReadOnly = true;
            this.txtRecvData.Size = new System.Drawing.Size(662, 83);
            this.txtRecvData.TabIndex = 0;
            this.txtRecvData.Text = "";
            // 
            // dgvConn
            // 
            this.dgvConn.AllowUserToAddRows = false;
            this.dgvConn.AllowUserToDeleteRows = false;
            this.dgvConn.AllowUserToResizeColumns = false;
            this.dgvConn.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConn.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvConn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientIP,
            this.ClientPort,
            this.ClientConnectedTime,
            this.ClientSessionGuid});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvConn.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvConn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConn.Location = new System.Drawing.Point(3, 305);
            this.dgvConn.Name = "dgvConn";
            this.dgvConn.ReadOnly = true;
            this.dgvConn.RowHeadersVisible = false;
            this.dgvConn.RowTemplate.Height = 24;
            this.dgvConn.Size = new System.Drawing.Size(674, 310);
            this.dgvConn.TabIndex = 2;
            // 
            // ClientIP
            // 
            this.ClientIP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.ClientIP.DataPropertyName = "ClientIP";
            this.ClientIP.HeaderText = "主機 IP";
            this.ClientIP.MinimumWidth = 120;
            this.ClientIP.Name = "ClientIP";
            this.ClientIP.ReadOnly = true;
            this.ClientIP.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ClientIP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ClientIP.Width = 120;
            // 
            // ClientPort
            // 
            this.ClientPort.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.ClientPort.DataPropertyName = "ClientPort";
            this.ClientPort.HeaderText = "主機 Port";
            this.ClientPort.MinimumWidth = 75;
            this.ClientPort.Name = "ClientPort";
            this.ClientPort.ReadOnly = true;
            this.ClientPort.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ClientPort.Width = 75;
            // 
            // ClientConnectedTime
            // 
            this.ClientConnectedTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.ClientConnectedTime.DataPropertyName = "ClientConnectedTime";
            this.ClientConnectedTime.HeaderText = "連線時間";
            this.ClientConnectedTime.MinimumWidth = 160;
            this.ClientConnectedTime.Name = "ClientConnectedTime";
            this.ClientConnectedTime.ReadOnly = true;
            this.ClientConnectedTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ClientConnectedTime.Width = 160;
            // 
            // ClientSessionGuid
            // 
            this.ClientSessionGuid.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ClientSessionGuid.DataPropertyName = "ClientSessionGuid";
            this.ClientSessionGuid.HeaderText = "Session GUID";
            this.ClientSessionGuid.Name = "ClientSessionGuid";
            this.ClientSessionGuid.ReadOnly = true;
            this.ClientSessionGuid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SOrderSendQueue
            // 
            this.SOrderSendQueue.MessageReadPropertyFilter.LookupId = true;
            this.SOrderSendQueue.SynchronizingObject = this;
            this.SOrderSendQueue.ReceiveCompleted += new System.Messaging.ReceiveCompletedEventHandler(this.SOrderSendQueue_ReceiveCompleted);
            // 
            // frmSOrderSend
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 618);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmSOrderSend";
            this.Text = "KeyIn證券下單";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSOrderSend_FormClosing);
            this.Load += new System.EventHandler(this.frmSOrderSend_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.gbStatus.ResumeLayout(false);
            this.tlpStatus.ResumeLayout(false);
            this.tlpStatus.PerformLayout();
            this.gbTransData.ResumeLayout(false);
            this.tlpTransData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox gbStatus;
        private System.Windows.Forms.TableLayoutPanel tlpStatus;
        private System.Windows.Forms.Label lblcBOSStatus;
        private System.Windows.Forms.Label lblBOSStatus;
        private System.Windows.Forms.Label lblcTConnCount;
        private System.Windows.Forms.Label lblTConnCount;
        private System.Windows.Forms.Label lblcCConnCount;
        private System.Windows.Forms.Label lblCConnCount;
        private System.Windows.Forms.Button btnReloadSTMB;
        private System.Windows.Forms.GroupBox gbTransData;
        private System.Windows.Forms.TableLayoutPanel tlpTransData;
        private System.Windows.Forms.RichTextBox txtSendData;
        private System.Windows.Forms.RichTextBox txtRecvData;
        private System.Windows.Forms.DataGridView dgvConn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientPort;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientConnectedTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientSessionGuid;
        private System.Windows.Forms.Label lblcQuoteStatus;
        private System.Windows.Forms.Label lblQuoteStatus;
        private System.Messaging.MessageQueue SOrderSendQueue;
    }
}

