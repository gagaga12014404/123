﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class AsyncQueue<T>
    {
        private readonly ConcurrentQueue<T> m_queue = new ConcurrentQueue<T>();
        private readonly SemaphoreSlim m_sem = new SemaphoreSlim(0);

        public void Enqueue(T item)
        {
            m_queue.Enqueue(item);
            if (m_sem.CurrentCount <= 0)
                m_sem.Release();
        }

        public bool TryDequeue(out T result)
        {
            return m_queue.TryDequeue(out result);
        }

        public Task WaitAsync()
        {
            return m_sem.WaitAsync();
        }
    }
}
