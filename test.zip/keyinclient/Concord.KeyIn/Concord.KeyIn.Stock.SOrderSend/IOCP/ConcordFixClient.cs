﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.IOCPHelper;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class ConcordFixClient : AppClient
    {
        private readonly MemoryStream inMessageBuffer = new MemoryStream();
        private const string cMessageHeaderString = "8=Concords|";
        private const char cSplitChar = '|';
        private readonly Encoding m_encoding = Encoding.GetEncoding("Big5");

        public ConcordFixClient(DnsEndPoint remoteEndPoint) : base(remoteEndPoint) { }

        public override void HandleReceive(byte[] data)
        {
            inMessageBuffer.Write(data, 0, data.Length);
            byte[] buffer = inMessageBuffer.ToArray();
            int headStart, tag9Start, tag9End, tag9Value, bodyStart, bodyEnd = 0;
            while (true)
            {
                headStart = buffer.Locate(m_encoding.GetBytes(cMessageHeaderString), bodyEnd);
                if (headStart < 0)
                    break;
                tag9Start = headStart + cMessageHeaderString.Length;
                tag9End = buffer.Locate(cSplitChar, tag9Start);
                if (tag9End < 0)
                    break;
                var tag9 = m_encoding.GetString(buffer, tag9Start, tag9End - tag9Start).GetSingleTagValue() ?? new KeyValuePair<uint, string>(0, "");
                if (tag9.Key != 9 || !int.TryParse(tag9.Value, out tag9Value))
                    break;
                bodyStart = tag9End;
                if (bodyStart + tag9Value > buffer.Length)
                    break;
                bodyEnd = bodyStart + tag9Value;
                var messageRaw = m_encoding.GetString(buffer, headStart, bodyEnd - headStart);
                OnReceiveMsg?.Invoke(messageRaw);
            }
            inMessageBuffer.SetLength(0);
            if (buffer.Length > bodyEnd)
            {
                inMessageBuffer.Write(buffer, bodyEnd, buffer.Length - bodyEnd);
            }
        }

        public void SendMessage(IEnumerable<KeyValuePair<uint, string>> msgList)
        {
            var message = msgList.Aggregate(
                "",
                (m, kvp) => $"{m}{cSplitChar}{kvp.Key}={kvp.Value}",
                m => $"{cMessageHeaderString}9={m_encoding.GetByteCount(m):D5}{m}");
            SendMessage(message);
        }
    }
}
