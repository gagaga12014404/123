﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.IOCPHelper;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class BosFixClient : AppClient
    {
        private readonly MemoryStream inMessageBuffer = new MemoryStream();
        private const char SOH = '\u0001';
        private const char END = '\u000a';
        private readonly Encoding m_encoding = Encoding.GetEncoding("Big5");

        public BosFixClient(DnsEndPoint remoteEndPoint) : base(remoteEndPoint) { }

        public override void HandleReceive(byte[] data)
        {
            inMessageBuffer.Write(data, 0, data.Length);
            byte[] buffer = inMessageBuffer.ToArray();
            int sPos = 0, ePos = 0;
            while (true)
            {
                ePos = buffer.Locate(END, sPos);
                if (ePos < 0)
                    break;
                var messageRaw = m_encoding.GetString(buffer, sPos, ePos - sPos);
                OnReceiveMsg?.Invoke(messageRaw);
                sPos = ePos + 1;
            }
            inMessageBuffer.SetLength(0);
            if (buffer.Length > sPos)
            {
                inMessageBuffer.Write(buffer, sPos, buffer.Length - sPos);
            }
        }

        public void SendMessage(IEnumerable<KeyValuePair<uint, string>> msgList)
        {
            var message = string.Join($"{SOH}", msgList.Select(kvp => $"{kvp.Key}={kvp.Value}")) + END;
            SendMessage(message);
        }
    }
}
