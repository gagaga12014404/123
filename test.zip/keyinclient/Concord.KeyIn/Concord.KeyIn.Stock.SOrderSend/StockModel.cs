﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class StockModel
    {
        public string StockId { get; set; }
        public string StockName { get; set; }
        public string SType { get; set; }
        public decimal CPrice { get; set; }
        public decimal TPrice { get; set; }
        public decimal BPrice { get; set; }
        public decimal DPrice { get; set; }
    }
}
