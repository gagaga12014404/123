﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public static class DAL
    {
        private static readonly string m_sqlUserId = Properties.Settings.Default.SqlUserID;
        private static readonly string m_sqlConn = Properties.Settings.Default.SqlConn;

        public static bool IsTradeDay
        {
            get
            {
                return DBHelper.IsTradeDay(m_sqlUserId, m_sqlConn, DBHelper.MarketType.Stock);
            }
        }

        public static DataTable GetSTMB()
        {
            var errorMessage = "";
            var sqlCommand = "SELECT [STOCK],[CNAME],[MTYPE],[STYPE],"
                           + "[CPRICE],[TPRICE],[BPRICE],[UNIT],"
                           + "[DTCODE],[CRMARK],[DBMARK],[TMMARK],"
                           + "[CreditTradeState],[FTState],[StockTradeState],[FT98State] "
                           + "FROM [KeyIn].[dbo].[S_Basic_STMB] "
                           + "WHERE [TSDate]=@TDATE";
            var sqlParams = new[] { new SqlParameter("@TDATE", DateTime.Today.ToString("yyyyMMdd")) };
            var dt = DBHelper.QueryData(m_sqlUserId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                ConcordLogger.Logger.Error($"GetSTMB DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "GetSTMB DB 錯誤", errorMessage);
            }
            return dt;
        }

        public static string GetErrAccountOrderDSEQ(FixMessageDictionary dicMessage, string TERM)
        {
            string CDI = dicMessage[35];
            string MSEQNO = dicMessage[11];
            string SEQNO = dicMessage[41];
            //新單未提供tag41:原網單, 需以新網單補上
            SEQNO = string.IsNullOrEmpty(SEQNO) ? MSEQNO : SEQNO;
            string DSEQ = dicMessage[37];
            string BHNO = dicMessage[50];
            string CSEQ = dicMessage[1].PadLeft(7, '0');
            string MTYPE = dicMessage[56];
            string ECODE = dicMessage[57];
            string OTYPE = dicMessage[10001];
            string STOCK = dicMessage[55];
            string BS = dicMessage[54];
            string ORDTYPE = dicMessage[40];
            string TIF = dicMessage[59];
            string OQTY = dicMessage[38];
            string PRICE = dicMessage[44];
            string TDATE = DateTime.Today.ToString("yyyyMMdd");
            string ORIGN = dicMessage[10000];
            string BROKER = dicMessage[20001];
            string DTrade = string.IsNullOrWhiteSpace(dicMessage[20003]) ? "N" : dicMessage[20003];
            string SIP = string.IsNullOrWhiteSpace(dicMessage[20004]) ? "N" : dicMessage[20004];
            string KEYIN = dicMessage[50002];
            string ClientIP = dicMessage[20000];

            var errorMessage = "";
            var ParamsName = new[] { "TDATE", "MSEQNO", "SEQNO", "CDI", "BHNO", "CSEQ", "DSEQ", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "PRICE", "DTRADE", "SIP", "ORIGN", "BROKER", "KEYIN", "ClientIP" };
            var ParamsValue = new[] { TDATE, MSEQNO, SEQNO, CDI, BHNO, CSEQ, DSEQ, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY, PRICE, DTrade, SIP, ORIGN, BROKER, KEYIN, ClientIP };
            var dt = DBHelper.ExecProcData(m_sqlUserId, "sp_UpdateErrAccountOrder", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            ConcordLogger.Logger.Debug($"呼叫sp_UpdateErrAccountOrder取得錯帳委託書號, 櫃號為{TERM}");

            if (!string.IsNullOrEmpty(errorMessage))
            {
                ConcordLogger.Logger.Error($"GetSTMB DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "GetSTMB DB 錯誤", errorMessage);
            }
            return $"{TERM}{Convert.ToInt32(dt.Rows[0][0]):00000}";
        }
    }
}
