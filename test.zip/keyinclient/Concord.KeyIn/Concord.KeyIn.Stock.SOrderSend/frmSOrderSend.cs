﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Messaging;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public partial class frmSOrderSend : Form
    {
        #region 變數定義
        private static readonly string m_serverIp = Properties.Settings.Default.ServerIP;
        private static readonly int m_serverPort = Properties.Settings.Default.ServerPort;
        private static readonly string m_bosIp = Properties.Settings.Default.BosIP;
        private static readonly int m_bosPort = Properties.Settings.Default.BosPort;
        private readonly bool m_isForced = Properties.Settings.Default.IsForced;
        private readonly string m_sOrderReceiveQueuePath = Properties.Settings.Default.SOrderReceiveQueuePath;
        private readonly string m_sOrderReceiveQueueName = Properties.Settings.Default.SOrderReceiveQueueName;
        private readonly bool m_isSOrderReceiveRemoteQueue = Properties.Settings.Default.IsSOrderReceiveRemoteQueue;
        private readonly string[] m_sOrderReceiveRemoteQueuePaths = Properties.Settings.Default.SOrderReceiveRemoteQueuePath.Split(';');
        private readonly string[] m_sMessageParserQueuePaths = Properties.Settings.Default.SMessageParserQueuePath.Split(';');
        private readonly string m_sMessageParserQueueName = Properties.Settings.Default.SMessageParserQueueName;
        private readonly string m_sNetNoPrefix = Properties.Settings.Default.SNetNoPrefix;
        private readonly int m_sysType = Properties.Settings.Default.SysType;
        private readonly AppServer<ConcordFixSession> m_server = new AppServer<ConcordFixSession>();
        private readonly BosFixClient m_bosClient = new BosFixClient(new DnsEndPoint(m_bosIp, m_bosPort));
        private readonly DataTable m_dtClientConn = new DataTable();
        private readonly AsyncQueue<ConcordFixMessage> m_clientMessageQueue = new AsyncQueue<ConcordFixMessage>();
        private readonly AsyncQueue<string> m_sOrderReceiveQueue = new AsyncQueue<string>();
        private readonly AsyncQueue<string> m_sMessageQueue = new AsyncQueue<string>();
        private readonly AsyncQueue<string> m_quoteMessageQueue = new AsyncQueue<string>();
        private readonly ConcurrentDictionary<string, StockModel> m_stockEntity = new ConcurrentDictionary<string, StockModel>();
        private readonly FiisQuote m_quote = new FiisQuote();
        private bool m_isBosConnected = false;
        private int m_bosClientFailCount = 0, m_totalConnCount = 0, m_currConnCount = 0;
        private static readonly int m_heartBeatInterval = Properties.Settings.Default.HeartBeatInterval;
        private readonly System.Timers.Timer m_serverHeartBeatTimer = new System.Timers.Timer();

        private readonly string m_sOrderSendQueuePath = Properties.Settings.Default.SOrderSendQueuePath;
        private readonly string m_sOrderSendQueueName = Properties.Settings.Default.SOrderSendQueueName;
        private readonly Func<string, string> m_getNetNoDelegate;
        #endregion

        #region Form 設定
        public frmSOrderSend()
        {
            InitializeComponent();
            InitializeStockEntity();
            InitializeClientConnectionTable();
            // TODO: 網單暫時區分經紀/自營
            switch (m_sysType)
            {
                case 0:
                    Text += "(經紀版本)";
                    m_getNetNoDelegate = GetNetNo;
                    break;
                case 1:
                    Text += "(自營版本)";
                    m_getNetNoDelegate = GetNumericNetNo;
                    break;
                default:
                    Text += "(未知版本)";
                    break;
            }
            Text += $" {m_serverIp}:{m_serverPort}";
        }

        private void frmSOrderSend_Load(object sender, EventArgs e)
        {
            #region 檢查交易日
            if (!DAL.IsTradeDay && !m_isForced)
            {
                ConcordLogger.Logger.Info($"{DateTime.Today:yyyy/MM/dd} 非交易日");
                Close();
                return;
            }
            #endregion

            ConfigureBosClient1();
            ConfigureQuoteObject();
            ConfigureOSServer();

            Task.Run(DequeueQuoteMessage);
            Task.Run(DequeueSOrderReceiveMessage);
            Task.Run(DequeueSMessageParserMessage);
            Task.Run(DequeueClientMessage);

            SOrderSendQueue.Path = m_sOrderSendQueuePath + m_sOrderSendQueueName;
            SOrderSendQueue.Formatter = new BinaryMessageFormatter();
            SOrderSendQueue.BeginReceive();
        }

        private void frmSOrderSend_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_serverHeartBeatTimer.Enabled = false;
            m_quote.Dispose();
        }

        private void btnReloadSTMB_Click(object sender, EventArgs e)
        {
            InitializeStockEntity();
        }
        #endregion

        #region 程式初始化設定
        /// <summary>
        /// 建立股票模型
        /// </summary>
        private void InitializeStockEntity()
        {
            var dt = DAL.GetSTMB();
            if (dt.Rows.Count <= 0)
                ConcordLogger.Logger.Warn("STMB 查無資料");
            else
                ConcordLogger.Logger.Info("STMB 初始化完成");
            foreach (var row in dt.AsEnumerable())
            {
                var s = row.Field<string>("STOCK").Trim();
                m_stockEntity.TryAdd(s, new StockModel
                {
                    StockId = s,
                    StockName = row.Field<string>("CNAME").Trim(),
                    SType = row.Field<string>("STYPE").Trim(),
                    CPrice = row.Field<decimal>("CPRICE"),
                    TPrice = row.Field<decimal>("TPRICE"),
                    BPrice = row.Field<decimal>("BPRICE"),
                    DPrice = row.Field<decimal>("CPRICE")
                });
            }
        }
        /// <summary>
        /// 建立連線 Table
        /// </summary>
        private void InitializeClientConnectionTable()
        {
            var ipcol = m_dtClientConn.Columns.Add("ClientIP", typeof(string));
            ipcol.AllowDBNull = false;
            var portcol = m_dtClientConn.Columns.Add("ClientPort", typeof(int));
            portcol.AllowDBNull = false;
            var timecol = m_dtClientConn.Columns.Add("ClientConnectedTime", typeof(DateTime));
            timecol.AllowDBNull = false;
            var guidcol = m_dtClientConn.Columns.Add("ClientSessionGuid", typeof(string));
            guidcol.AllowDBNull = false;
            guidcol.Unique = true;
            m_dtClientConn.PrimaryKey = new[] { guidcol };
            dgvConn.DataSource = m_dtClientConn;
        }
        #endregion

        #region 證後台 Client 設定
        private void ConfigureBosClient1()
        {
            m_bosClient.NoDelay = true;
            m_bosClient.OnConnect += Client1_OnConnect;
            m_bosClient.OnConnectFail += Client1_OnConnectFail;
            m_bosClient.OnReceiveMsg += Client1_OnReceiveMsg;
            m_bosClient.OnReceiveFailMsg += Client1_OnReceiveFailMsg;
            m_bosClient.OnSendMsg += Client1_OnSendMsg;
            m_bosClient.OnSendFailMsg += Client1_OnSendFailMsg;
            m_bosClient.DoConnect();
        }

        private void Client1_OnConnect()
        {
            m_isBosConnected = true;
            m_bosClientFailCount = 0;
            ConcordLogger.Logger.Info($"證後台1 {m_bosIp}:{m_bosPort} 已連線");
            BeginInvoke((Action)(() => lblBOSStatus.Text = "已連線"));
        }

        private void Client1_OnConnectFail(string message)
        {
            m_isBosConnected = false;
            m_bosClientFailCount++;
            ConcordLogger.Logger.Error($"證後台1 {m_bosIp}:{m_bosPort} 連線失敗：{message}");
            if (m_bosClientFailCount <= 5)
                ConcordLogger.Alert("9999", $"證後台1 {m_bosIp}:{m_bosPort} 連線失敗", message);
            BeginInvoke((Func<Task>)(async () =>
            {
                lblBOSStatus.Text = "連線失敗";
                await Task.Delay(500);
                lblBOSStatus.Text = "重連中";
            }));
        }

        private void Client1_OnReceiveMsg(string message)
        {
            ConcordLogger.Logger.Debug($"從證後台1接收：{message}");
        }

        private void Client1_OnReceiveFailMsg(string message)
        {
            ConcordLogger.Logger.Warn($"證後台1訊息接收失敗：{message}");
        }

        private void Client1_OnSendMsg(string message)
        {
            ConcordLogger.Logger.Info($"送至證後台1：{message}");
            BeginInvoke((Action)(() => txtSendData.Text = message));
        }

        private void Client1_OnSendFailMsg(string message)
        {
            ConcordLogger.Logger.Error($"證後台1訊息傳送失敗：{message}");
            ConcordLogger.Alert("9999", "證後台1訊息傳送失敗", message);
            BeginInvoke((Action)(() => txtSendData.Text = $"傳送失敗：{message}"));
        }
        #endregion

        #region 行情中台設定
        private async void ConfigureQuoteObject()
        {
            m_quote.OnReceiveMessage += Quote_OnReceiveMessage;
            m_quote.OnConnectionStatusChanged += Quote_OnConnectionStatusChanged;
            while (true)
            {
                try
                {
                    var ret = 0;
                    if (m_quote.Initialize(ref ret))
                    {
                        lblQuoteStatus.Text = "已初始化";
                        ConcordLogger.Logger.Info("MOB 已初始化");
                        if (m_quote.Connect(ref ret))
                        {
                            Quote_OnConnectionStatusChanged(0, "連線成功");
                            return;
                        }
                        else
                            throw new Exception($"精誠行情連線失敗, error code = {ret}");
                    }
                    lblQuoteStatus.Text = "未初始化";
                    ConcordLogger.Logger.Error("MOB 初始化失敗");
                    ConcordLogger.Alert("9999", "MOB 初始化失敗");
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("ConfigureQuoteObject 錯誤", ex);
                    ConcordLogger.Alert("9999", "ConfigureQuoteObject 錯誤", ex.ToString());
                }
                await Task.Delay(500);
            }
        }

        private void Quote_OnReceiveMessage(string message)
        {
            m_quoteMessageQueue.Enqueue(message);
        }

        private void Quote_OnConnectionStatusChanged(int status, string message)
        {
            switch (status)
            {
                case 0:
                    ConcordLogger.Logger.Info($"行情已連線：{message}");
                    BeginInvoke((Action)(() => lblQuoteStatus.Text = "已連線"));
                    if (m_quote.Subscribe(0x81, "*"))
                    {
                        ConcordLogger.Logger.Info("證券行情訂閱成功");
                        BeginInvoke((Action)(() => lblQuoteStatus.Text = "已訂閱"));
                    }
                    else
                    {
                        ConcordLogger.Logger.Error($"證券行情訂閱失敗");
                        ConcordLogger.Alert("9999", $"證券行情訂閱失敗");
                    }
                    break;
                case -3:
                    ConcordLogger.Logger.Error($"行情連線失敗：{message}");
                    BeginInvoke((Action)(() => lblQuoteStatus.Text = "未連線"));
                    break;
                default:
                    ConcordLogger.Logger.Error($"行情狀態異常 {status}：{message}");
                    ConcordLogger.Alert("9999", "行情狀態異常", $"{status}：{message}");
                    BeginInvoke((Action)(() => lblQuoteStatus.Text = "異常"));
                    break;
            }
        }
        #endregion

        #region 中台 Server 設定
        private void ConfigureOSServer()
        {
            m_serverHeartBeatTimer.Interval = 1000;
            m_serverHeartBeatTimer.Elapsed += ServerHeartBeatTimer_Elapsed;

            m_server.NoDelay = true;
            m_server.OnServerStart += Server_OnServerStart;
            m_server.OnServerFail += Server_OnOnServerFail;
            m_server.OnSessionConnect += Server_OnSessionConnect;
            m_server.OnSessionDisconnect += Server_OnSessionDisconnect;
            m_server.OnReceiveMsg += Server_OnReceiveMsg;
            m_server.OnSendMsg += Server_OnSendMsg;
            m_server.OnSendMsgFail += Server_OnSendMsgFail;
            m_server.Start(new IPEndPoint(IPAddress.Any, m_serverPort));
        }

        private void ServerHeartBeatTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            m_serverHeartBeatTimer.Enabled = false;
            foreach (var kvp in m_server.SessionCollection)
            {
                if (kvp.Value.LastReceivedTime + TimeSpan.FromSeconds(m_heartBeatInterval) < DateTime.Now)
                {
                    kvp.Value.LastReceivedTime = DateTime.Now;
                    kvp.Value.SendMessage(new[] { new KeyValuePair<uint, string>(35, "0") });
                }
            }
            if (!IsDisposed)
                m_serverHeartBeatTimer.Enabled = true;
        }

        private void Server_OnServerStart()
        {
            ConcordLogger.Logger.Info($"SOrderSend Server {m_serverIp}:{m_serverPort} 已啟動");
            m_serverHeartBeatTimer.Enabled = true;
        }

        private void Server_OnOnServerFail(Exception ex)
        {
            ConcordLogger.Logger.Error("SOrderSend Server 啟動失敗", ex);
            ConcordLogger.Alert("9999", "SOrderSend Server 啟動失敗", ex.ToString());
        }

        private void Server_OnSessionConnect(string sessionGuid, Socket clientSocket)
        {
            var client = (IPEndPoint)clientSocket.RemoteEndPoint;
            ConcordLogger.Logger.Info($"Session: {sessionGuid}, {client.Address}:{client.Port} 連線");
            clientSocket.NoDelay = true;
            Interlocked.Increment(ref m_totalConnCount);
            Interlocked.Increment(ref m_currConnCount);
            BeginInvoke((Action)(() =>
            {
                lblTConnCount.Text = m_totalConnCount.ToString();
                lblCConnCount.Text = m_currConnCount.ToString();
                var dr = m_dtClientConn.NewRow();
                dr["ClientIP"] = client.Address.ToString();
                dr["ClientPort"] = client.Port;
                dr["ClientConnectedTime"] = DateTime.Now;
                dr["ClientSessionGuid"] = sessionGuid;
                m_dtClientConn.Rows.Add(dr);
            }));
        }

        private void Server_OnSessionDisconnect(string sessionGuid, Socket clientSocket)
        {
            var client = (IPEndPoint)clientSocket.RemoteEndPoint;
            ConcordLogger.Logger.Info($"Session: {sessionGuid}, {client.Address}:{client.Port} 斷線");
            Interlocked.Decrement(ref m_currConnCount);
            BeginInvoke((Action)(() =>
            {
                lblCConnCount.Text = m_currConnCount.ToString();
                var dr = m_dtClientConn.Rows.Find(sessionGuid);
                m_dtClientConn.Rows.Remove(dr);
            }));
        }

        private void Server_OnReceiveMsg(string message, string sessionGuid)
        {
            m_clientMessageQueue.Enqueue(new ConcordFixMessage(sessionGuid, message));
            BeginInvoke((Action)(() => txtRecvData.Text = message));
        }

        private void Server_OnSendMsg(string message, string sessionGuid)
        {
            ConcordLogger.Logger.Info($"送至 {sessionGuid}：{message}");
        }

        private void Server_OnSendMsgFail(string message, string sessionGuid, Exception ex)
        {
            ConcordLogger.Logger.Error($"傳送失敗 {sessionGuid}：{message}", ex);
            ConcordLogger.Alert("9999", "Server 傳送失敗", $"{sessionGuid}：{message}, {ex}");
        }

        private void SOrderSendQueue_ReceiveCompleted(object sender, ReceiveCompletedEventArgs e)
        {
            try
            {
                var mm = SOrderSendQueue.EndReceive(e.AsyncResult);
                mm.Formatter = new BinaryMessageFormatter();
                var message = mm.Body.ToString();
                ConcordLogger.Logger.Info($"處理MSMQ委託單：{message}");
                m_clientMessageQueue.Enqueue(new ConcordFixMessage("", message));
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("收委託MSMQ異常", ex);
                ConcordLogger.Alert("9999", "收委託MSMQ異常", ex.ToString());
            }
            finally
            {
                SOrderSendQueue.BeginReceive();
            }
        }
        #endregion

        #region 處理行情電文
        private async Task DequeueQuoteMessage()
        {
            string message;
            while (true)
            {
                if (m_quoteMessageQueue.TryDequeue(out message))
                {
                    try
                    {
                        var cfm = new ConcordFixMessage("", message);
                        var dicMessage = cfm.ParseToDictionary('\u0001');
                        string stockId, dPrice;
                        StockModel stockModel;
                        if (dicMessage.TryGetValue(55, out stockId)
                            && dicMessage.TryGetValue(125, out dPrice)
                            && m_stockEntity.TryGetValue(stockId, out stockModel))
                        {
                            stockModel.DPrice = decimal.Parse(dPrice);
                        }
                    }
                    catch (Exception ex)
                    {
                        var nex = new Exception(message, ex);
                        ConcordLogger.Logger.Error("DequeueQuoteMessage 錯誤", nex);
                        ConcordLogger.Alert("9999", "DequeueQuoteMessage 錯誤", nex.ToString());
                    }
                }
                else await m_quoteMessageQueue.WaitAsync();
            }
        }
        #endregion

        #region 處理下單電文
        private async Task DequeueClientMessage()
        {
            ConcordFixMessage message;
            while (true)
            {
                if (m_clientMessageQueue.TryDequeue(out message))
                {
                    try
                    {
                        ConcordLogger.Logger.Debug($"收到 {message.SessionGuid}：{message.RawMessage}");
                        var dicMessage = message.ParseToDictionary();
                        if (dicMessage.MessageType == FixMessageType.HeartBeat)
                        {
                            // 心跳訊息不處理
                            continue;
                        }
                        // TODO: 待泛自營中台可收文數字網單後再合併
                        if (m_getNetNoDelegate == null)
                        {
                            ConcordLogger.Logger.Error("GetNetNo Delegate is NULL!!");
                            ConcordLogger.Alert("9999", "GetNetNo Delegate is NULL!!");
                        }
                        else
                        {
                            dicMessage[11] = m_getNetNoDelegate(m_sNetNoPrefix);
                        }
                        var orMessage = "";
                        switch (dicMessage.MessageType)
                        {
                            case FixMessageType.InsertOrder:
                                #region 新單
                                var iResult = OrderMessageCheck(dicMessage, new List<FieldCheckBase> { });
                                if (iResult.Item1)
                                {
                                    int tick;
                                    StockModel stock;
                                    //判斷是否有指定行情現價上下跳動
                                    if (int.TryParse(dicMessage[22001], out tick) && tick != 0
                                        && m_stockEntity.TryGetValue(dicMessage[55], out stock))
                                    {
                                        var dPrice = stock.DPrice;
                                        var price = TickHelper.GetSymbolPrice(stock.SType, dPrice, tick > 0 ? TickHelper.Side.Increase : TickHelper.Side.Decrease, Math.Abs(tick));
                                        if (price > stock.TPrice)
                                            price = stock.TPrice;
                                        else if (price < stock.BPrice)
                                            price = stock.BPrice;
                                        ConcordLogger.Logger.Debug($"取得現價：{dPrice}，跳動檔數：{tick}，結果：{price}");
                                        dicMessage[44] = price.ToString("0.####");
                                    }
                                    m_bosClient.SendMessage(dicMessage.ComposeInsertOrder());
                                }
                                else
                                {
                                    dicMessage[41] = dicMessage[11];
                                    orMessage = ComposeOrderReceiveMessage(dicMessage, iResult.Item2, iResult.Item3);
                                    m_sOrderReceiveQueue.Enqueue(orMessage);
                                }
                                m_sMessageQueue.Enqueue(dicMessage.ToString());
                                #endregion
                                break;
                            case FixMessageType.DeleteOrder:
                                #region 刪單
                                var dResult = OrderMessageCheck(dicMessage, new List<FieldCheckBase> { });
                                if (dResult.Item1)
                                {
                                    m_bosClient.SendMessage(dicMessage.ComposeDeleteOrder());
                                }
                                else
                                {
                                    orMessage = ComposeOrderReceiveMessage(dicMessage, dResult.Item2, dResult.Item3);
                                    m_sOrderReceiveQueue.Enqueue(orMessage);
                                }
                                m_sMessageQueue.Enqueue(dicMessage.ToString());
                                #endregion
                                break;
                            case FixMessageType.ChangeOrder:
                                #region 改量
                                var cResult = OrderMessageCheck(dicMessage, new List<FieldCheckBase> { });
                                if (cResult.Item1)
                                {
                                    m_bosClient.SendMessage(dicMessage.ComposeChangeOrder());
                                }
                                else
                                {
                                    orMessage = ComposeOrderReceiveMessage(dicMessage, cResult.Item2, cResult.Item3);
                                    m_sOrderReceiveQueue.Enqueue(orMessage);
                                }
                                m_sMessageQueue.Enqueue(dicMessage.ToString());
                                #endregion
                                break;
                            case FixMessageType.PriceOrder:
                                #region 改價
                                var pResult = OrderMessageCheck(dicMessage, new List<FieldCheckBase> { });
                                if (pResult.Item1)
                                {
                                    m_bosClient.SendMessage(dicMessage.ComposePriceOrder());
                                }
                                else
                                {
                                    orMessage = ComposeOrderReceiveMessage(dicMessage, pResult.Item2, pResult.Item3);
                                    m_sOrderReceiveQueue.Enqueue(orMessage);
                                }
                                m_sMessageQueue.Enqueue(dicMessage.ToString());
                                #endregion
                                break;
                            default:
                                ConcordLogger.Logger.Warn($"收到未知的訊息類別：{dicMessage[35]}");
                                break;
                        }
                        SendNetNo(message.SessionGuid, dicMessage[20103], dicMessage[11], "");
                    }
                    catch (Exception ex)
                    {
                        ConcordLogger.Logger.Error("DequeueClientMessage 錯誤", ex);
                        ConcordLogger.Alert("9999", "DequeueClientMessage 錯誤", ex.ToString());
                    }
                }
                else await m_clientMessageQueue.WaitAsync();
            }
        }

        private static readonly string m_alphanumericKeys = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private static readonly int AlphanumericKeyLength = m_alphanumericKeys.Length;
        private string GetNetNo(string prefix)
        {
            int q = NetNoHelper.GetNetNo(), r;
            var result = "";
            do
            {
                q = Math.DivRem(q, AlphanumericKeyLength, out r);
                result = $"{m_alphanumericKeys[r]}{result}";
            } while (q > 0);
            return $"{prefix}{result.PadLeft(4, '0')}";
        }

        private string GetNumericNetNo(string _)
        {
            return NetNoHelper.GetNetNo().ToString("D6");
        }

        /// <summary>
        /// 網單回覆
        /// </summary>
        /// <param name="sessionGuid">Client GUID</param>
        /// <param name="messageGuid">電文GUID</param>
        /// <param name="netno">網單編號</param>
        /// <param name="errorMessage">錯誤訊息</param>
        private void SendNetNo(string sessionGuid, string messageGuid, string netno, string errorMessage)
        {
            var message = new[]
            {
                new KeyValuePair<uint, string>(35, "8"),
                new KeyValuePair<uint, string>(52, DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff")),
                new KeyValuePair<uint, string>(20103, messageGuid),
                new KeyValuePair<uint, string>(11, netno),
                new KeyValuePair<uint, string>(58, errorMessage)
            };
            ConcordFixSession session;
            if (m_server.SessionCollection.TryGetValue(sessionGuid, out session))
                session.SendMessage(message);
        }
        /// <summary>
        /// 組成錯誤單電文
        /// </summary>
        /// <param name="dicMessage">電文集合</param>
        /// <param name="ETYPE">錯誤代碼</param>
        /// <param name="EMSG">錯誤訊息</param>
        /// <returns></returns>
        private string ComposeOrderReceiveMessage(IDictionary<uint, string> dicMessage, string ETYPE, string EMSG)
        {
            var msgList = new List<KeyValuePair<uint, string>>();
            var msgType = dicMessage[35];
            var now = DateTime.Now;
            var registerCode = $"{dicMessage[50]}";
            var uniqueKey = $"{dicMessage[11]}";
            if (msgType == "I")
                msgList.Add(new KeyValuePair<uint, string>(35, "8"));
            else
                msgList.Add(new KeyValuePair<uint, string>(35, "9"));
            msgList.Add(new KeyValuePair<uint, string>(52, now.ToString("yyyyMMdd-HH:mm:ss.fff")));
            msgList.Add(new KeyValuePair<uint, string>(34, "{0}"));
            msgList.Add(new KeyValuePair<uint, string>(11, dicMessage[11]));
            msgList.Add(new KeyValuePair<uint, string>(41, dicMessage[41]));
            msgList.Add(new KeyValuePair<uint, string>(150, "8"));
            msgList.Add(new KeyValuePair<uint, string>(10002, msgType));
            msgList.Add(new KeyValuePair<uint, string>(37, dicMessage[37]));
            msgList.Add(new KeyValuePair<uint, string>(50, dicMessage[50]));
            msgList.Add(new KeyValuePair<uint, string>(1, dicMessage[1]));
            msgList.Add(new KeyValuePair<uint, string>(57, dicMessage[57]));
            msgList.Add(new KeyValuePair<uint, string>(10001, dicMessage[10001]));
            msgList.Add(new KeyValuePair<uint, string>(55, dicMessage[55]));
            msgList.Add(new KeyValuePair<uint, string>(54, dicMessage[54]));
            msgList.Add(new KeyValuePair<uint, string>(40, dicMessage[40]));
            msgList.Add(new KeyValuePair<uint, string>(59, dicMessage[59]));
            msgList.Add(new KeyValuePair<uint, string>(38, dicMessage[38]));
            msgList.Add(new KeyValuePair<uint, string>(44, dicMessage[44]));
            msgList.Add(new KeyValuePair<uint, string>(103, ETYPE));
            msgList.Add(new KeyValuePair<uint, string>(58, EMSG));
            msgList.Add(new KeyValuePair<uint, string>(60, $"{now:yyyyMMdd-HHmmssfff}"));
            msgList.Add(new KeyValuePair<uint, string>(10000, dicMessage[10000]));
            msgList.Add(new KeyValuePair<uint, string>(20001, dicMessage[20001]));
            msgList.Add(new KeyValuePair<uint, string>(20003, dicMessage[20003]));
            msgList.Add(new KeyValuePair<uint, string>(20009, "0"));
            msgList.Add(new KeyValuePair<uint, string>(20010, "0"));
            return msgList.Aggregate(
                "",
                (m, kvp) => $"{m}|{kvp.Key}={kvp.Value}",
                m => $"{registerCode}${uniqueKey}${m}");
        }
        #endregion

        #region 錯誤單送至 SOrderReceive MSMQ
        private async Task DequeueSOrderReceiveMessage()
        {
            var fullPath = m_sOrderReceiveQueuePath + m_sOrderReceiveQueueName;
            var sorMsmq = new MessageQueue(fullPath);
            var sorRemoteMsmqs = m_sOrderReceiveRemoteQueuePaths.Where(_ => m_isSOrderReceiveRemoteQueue)
                .Select(path => new MessageQueue(path + m_sOrderReceiveQueueName, QueueAccessMode.Send)).ToList();
            string message;
            while (true)
            {
                if (m_sOrderReceiveQueue.TryDequeue(out message))
                {
                    var mm = new System.Messaging.Message(message, new BinaryMessageFormatter());
                    try
                    {
                        sorMsmq.Send(mm);
                        ConcordLogger.Logger.Info($"錯誤單送出：{message}");
                    }
                    catch (Exception ex)
                    {
                        var nex = new Exception(message, ex);
                        ConcordLogger.Logger.Error("錯誤單送 MSMQ 錯誤", nex);
                        ConcordLogger.Alert("9999", "錯誤單送 MSMQ 錯誤", nex.ToString());
                    }

                    //mm.UseAuthentication = false;
                    mm.AttachSenderId = false;
                    foreach (var remoteQueue in sorRemoteMsmqs)
                    {
                        try
                        {
                            remoteQueue.Send(mm);
                            ConcordLogger.Logger.Info($"錯誤單遠端 {remoteQueue.Path} 送出：{mm.Body}");
                        }
                        catch (Exception ex)
                        {
                            var nex = new Exception(message, ex);
                            ConcordLogger.Logger.Error($"錯誤單送遠端 {remoteQueue.Path} 錯誤", nex);
                            ConcordLogger.Alert("9999", $"錯誤單送遠端 {remoteQueue.Path} 錯誤", nex.ToString());
                        }
                    }
                }
                else await m_sOrderReceiveQueue.WaitAsync();
            }
        }
        #endregion

        #region 下單電文送至 SMessageParser MSMQ
        private async Task DequeueSMessageParserMessage()
        {
            var smpMsmqs = m_sMessageParserQueuePaths
                .Select(path => new MessageQueue(path + m_sMessageParserQueueName)).ToList();
            string message;
            while (true)
            {
                if (m_sMessageQueue.TryDequeue(out message))
                {
                    var mm = new System.Messaging.Message($"KeyIn$S$O${message}", new BinaryMessageFormatter());
                    foreach (var smpQueue in smpMsmqs)
                    {
                        try
                        {
                            smpQueue.Send(mm);
                            ConcordLogger.Logger.Info($"下單電文 {smpQueue.Path} 送出：{message}");
                        }
                        catch (Exception ex)
                        {
                            var nex = new Exception(message, ex);
                            ConcordLogger.Logger.Error($"下單電文送 {smpQueue.Path} 錯誤", nex);
                            ConcordLogger.Alert("9999", "下單電文送 MSMQ 錯誤", nex.ToString());
                        }
                    }
                }
                else await m_sMessageQueue.WaitAsync();
            }
        }
        #endregion

        #region 委託單檢核
        private Tuple<bool, string, string> OrderMessageCheck(IDictionary<uint, string> dicMessage, IEnumerable<FieldCheckBase> lsChecks)
        {
            bool result = true;
            string ETYPE = "", EMSG = "";
            //必定先檢查後台連線狀態
            if (!m_isBosConnected)
            {
                result = false;
                ETYPE = "T024";
                EMSG = "中台與後台斷線";
            }
            else
            {
                foreach (var check in lsChecks)
                {
                    if (!(result = check.DoCheck(dicMessage)))
                    {
                        ETYPE = check.ECODE;
                        EMSG = check.EMSG;
                        break;
                    }
                }
            }
            return Tuple.Create(result, ETYPE, EMSG);
        }
        #endregion
    }
}
