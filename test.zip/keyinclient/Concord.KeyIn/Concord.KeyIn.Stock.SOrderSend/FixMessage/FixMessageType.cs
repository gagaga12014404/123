﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public enum FixMessageType
    {
        HeartBeat = 0,
        InsertOrder,
        DeleteOrder,
        ChangeOrder,
        PriceOrder,
        Unknown
    }
}
