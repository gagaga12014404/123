﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public static class ConcordMessageExtensions
    {
        private const char cSectionSplitChar = '|';
        private const char cDataSplitChar = '=';

        public static KeyValuePair<uint, string>? GetSingleTagValue(this string section)
        {
            var pair = section.Split(new[] { cDataSplitChar }, 2);
            if (pair.Length != 2)
                return null;
            uint tag;
            if (!uint.TryParse(pair[0], out tag) || tag <= 0)
                return null;
            return new KeyValuePair<uint, string>(tag, pair[1]);
        }

        public static FixMessageDictionary ParseToDictionary(this ConcordFixMessage message, char splitChar = cSectionSplitChar)
        {
            var result = new FixMessageDictionary();
            foreach (var section in message.RawMessage.Split(splitChar))
            {
                var kvp = section.GetSingleTagValue() ?? new KeyValuePair<uint, string>(0, "");
                if (kvp.Key != 0)
                    result.Add(kvp.Key, kvp.Value);
            }
            switch (result[35])
            {
                case "0":
                    result.MessageType = FixMessageType.HeartBeat;
                    break;
                case "I":
                    result.MessageType = FixMessageType.InsertOrder;
                    break;
                case "D":
                    result.MessageType = FixMessageType.DeleteOrder;
                    break;
                case "C":
                    result.MessageType = FixMessageType.ChangeOrder;
                    break;
                case "P":
                    result.MessageType = FixMessageType.PriceOrder;
                    break;
                default:
                    result.MessageType = FixMessageType.Unknown;
                    break;
            }
            return result;
        }
    }
}
