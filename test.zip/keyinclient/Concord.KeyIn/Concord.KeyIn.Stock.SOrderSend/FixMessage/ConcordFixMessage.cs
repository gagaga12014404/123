﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class ConcordFixMessage
    {
        public string SessionGuid { get; }
        public string RawMessage { get; }

        public ConcordFixMessage(string sessionGuid, string messageRaw)
        {
            SessionGuid = sessionGuid;
            RawMessage = messageRaw;
        }
    }
}
