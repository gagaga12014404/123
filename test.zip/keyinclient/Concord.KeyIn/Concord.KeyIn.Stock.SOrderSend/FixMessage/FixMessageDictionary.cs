﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class FixMessageDictionary : IDictionary<uint, string>
    {
        private readonly Dictionary<uint, string> m_dic = new Dictionary<uint, string>();

        public FixMessageType MessageType { get; set; }

        public string this[uint key]
        {
            get
            {
                return m_dic.ContainsKey(key) ? m_dic[key] : "";
            }

            set
            {
                if (m_dic.ContainsKey(key))
                    m_dic[key] = value;
                else
                    Add(key, value);
            }
        }

        public int Count
        {
            get
            {
                return m_dic.Count;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).IsReadOnly;
            }
        }

        public ICollection<uint> Keys
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).Keys;
            }
        }

        public ICollection<string> Values
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).Values;
            }
        }

        public void Add(KeyValuePair<uint, string> item)
        {
            ((IDictionary<uint, string>)m_dic).Add(item);
        }

        public void Add(uint key, string value)
        {
            m_dic.Add(key, value);
        }

        public void Clear()
        {
            m_dic.Clear();
        }

        public bool Contains(KeyValuePair<uint, string> item)
        {
            return ((IDictionary<uint, string>)m_dic).Contains(item);
        }

        public bool ContainsKey(uint key)
        {
            return m_dic.ContainsKey(key);
        }

        public void CopyTo(KeyValuePair<uint, string>[] array, int arrayIndex)
        {
            ((IDictionary<uint, string>)m_dic).CopyTo(array, arrayIndex);
        }

        public IEnumerator<KeyValuePair<uint, string>> GetEnumerator()
        {
            return ((IDictionary<uint, string>)m_dic).GetEnumerator();
        }

        public bool Remove(KeyValuePair<uint, string> item)
        {
            return ((IDictionary<uint, string>)m_dic).Remove(item);
        }

        public bool Remove(uint key)
        {
            return m_dic.Remove(key);
        }

        public bool TryGetValue(uint key, out string value)
        {
            return m_dic.TryGetValue(key, out value);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IDictionary<uint, string>)m_dic).GetEnumerator();
        }

        public override string ToString()
        {
            return string.Join("|", m_dic.Select(kvp => $"{kvp.Key}={kvp.Value}"));
        }

        public IEnumerable<KeyValuePair<uint, string>> ComposeInsertOrder()
        {
            var clOrdId = this[11].PadLeft(12, '0');
            var bhno = $"845{this[50]}";
            var cseq = this[1].PadLeft(7, '0');
            var bs = this[54];
            if (bs == "B")
                bs = "1";
            else if (bs == "S")
                bs = "2";
            yield return new KeyValuePair<uint, string>(1, cseq);
            yield return new KeyValuePair<uint, string>(11, clOrdId);
            yield return new KeyValuePair<uint, string>(37, this[37]);
            yield return new KeyValuePair<uint, string>(38, this[38]);
            yield return new KeyValuePair<uint, string>(40, this[40]);
            yield return new KeyValuePair<uint, string>(44, this[44]);
            yield return new KeyValuePair<uint, string>(50, bhno);
            yield return new KeyValuePair<uint, string>(54, bs);
            yield return new KeyValuePair<uint, string>(55, this[55]);
            yield return new KeyValuePair<uint, string>(59, this[59]);
            yield return new KeyValuePair<uint, string>(60, DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff"));
            yield return new KeyValuePair<uint, string>(10000, "1");
            yield return new KeyValuePair<uint, string>(10001, this[10001]);
            yield return new KeyValuePair<uint, string>(50001, this[20001]);
            yield return new KeyValuePair<uint, string>(50002, this[50002]);
            yield return new KeyValuePair<uint, string>(50003, this[10000]);
            yield return new KeyValuePair<uint, string>(50004, this[20003]);
            yield return new KeyValuePair<uint, string>(50005, this[20004]);
            yield return new KeyValuePair<uint, string>(50008, "1");
            yield return new KeyValuePair<uint, string>(50009, this[57]);
            yield return new KeyValuePair<uint, string>(60001, this[60001]);
            yield return new KeyValuePair<uint, string>(60002, this[60002]);
            yield return new KeyValuePair<uint, string>(60003, this[60003]);
            yield return new KeyValuePair<uint, string>(60004, this[60004]);
            yield return new KeyValuePair<uint, string>(60005, this[60005]);
        }

        public IEnumerable<KeyValuePair<uint, string>> ComposeDeleteOrder()
        {
            var clOrdId = this[11].PadLeft(12, '0');
            var origClOrdId = this[41].PadLeft(12, '0');
            var bhno = $"845{this[50]}";
            var cseq = this[1].PadLeft(7, '0');
            var bs = this[54];
            if (bs == "B")
                bs = "1";
            else if (bs == "S")
                bs = "2";
            yield return new KeyValuePair<uint, string>(1, cseq);
            yield return new KeyValuePair<uint, string>(11, clOrdId);
            yield return new KeyValuePair<uint, string>(37, this[37]);
            yield return new KeyValuePair<uint, string>(40, this[40]);
            yield return new KeyValuePair<uint, string>(41, origClOrdId);
            yield return new KeyValuePair<uint, string>(50, bhno);
            yield return new KeyValuePair<uint, string>(54, bs);
            yield return new KeyValuePair<uint, string>(55, this[55]);
            yield return new KeyValuePair<uint, string>(59, this[59]);
            yield return new KeyValuePair<uint, string>(60, DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff"));
            yield return new KeyValuePair<uint, string>(10000, "1");
            yield return new KeyValuePair<uint, string>(50001, this[20001]);
            yield return new KeyValuePair<uint, string>(50002, this[50002]);
            yield return new KeyValuePair<uint, string>(50003, this[10000]);
            yield return new KeyValuePair<uint, string>(50008, "4");
            yield return new KeyValuePair<uint, string>(50009, this[57]);
            yield return new KeyValuePair<uint, string>(60004, this[60004]);
        }

        public IEnumerable<KeyValuePair<uint, string>> ComposeChangeOrder()
        {
            var clOrdId = this[11].PadLeft(12, '0');
            var origClOrdId = this[41].PadLeft(12, '0');
            var bhno = $"845{this[50]}";
            var cseq = this[1].PadLeft(7, '0');
            var bs = this[54];
            if (bs == "B")
                bs = "1";
            else if (bs == "S")
                bs = "2";
            yield return new KeyValuePair<uint, string>(1, cseq);
            yield return new KeyValuePair<uint, string>(11, clOrdId);
            yield return new KeyValuePair<uint, string>(37, this[37]);
            yield return new KeyValuePair<uint, string>(38, this[38]);
            yield return new KeyValuePair<uint, string>(40, this[40]);
            yield return new KeyValuePair<uint, string>(41, origClOrdId);
            yield return new KeyValuePair<uint, string>(50, bhno);
            yield return new KeyValuePair<uint, string>(54, bs);
            yield return new KeyValuePair<uint, string>(55, this[55]);
            yield return new KeyValuePair<uint, string>(59, this[59]);
            yield return new KeyValuePair<uint, string>(60, DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff"));
            yield return new KeyValuePair<uint, string>(10000, "1");
            yield return new KeyValuePair<uint, string>(50001, this[20001]);
            yield return new KeyValuePair<uint, string>(50002, this[50002]);
            yield return new KeyValuePair<uint, string>(50003, this[10000]);
            yield return new KeyValuePair<uint, string>(50008, "2");
            yield return new KeyValuePair<uint, string>(50009, this[57]);
            yield return new KeyValuePair<uint, string>(60004, this[60004]);
        }

        public IEnumerable<KeyValuePair<uint, string>> ComposePriceOrder()
        {
            var clOrdId = this[11].PadLeft(12, '0');
            var origClOrdId = this[41].PadLeft(12, '0');
            var bhno = $"845{this[50]}";
            var cseq = this[1].PadLeft(7, '0');
            var bs = this[54];
            if (bs == "B")
                bs = "1";
            else if (bs == "S")
                bs = "2";
            yield return new KeyValuePair<uint, string>(1, cseq);
            yield return new KeyValuePair<uint, string>(11, clOrdId);
            yield return new KeyValuePair<uint, string>(37, this[37]);
            yield return new KeyValuePair<uint, string>(41, origClOrdId);
            yield return new KeyValuePair<uint, string>(44, this[44]);
            yield return new KeyValuePair<uint, string>(50, bhno);
            yield return new KeyValuePair<uint, string>(54, bs);
            yield return new KeyValuePair<uint, string>(55, this[55]);
            yield return new KeyValuePair<uint, string>(60, DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff"));
            yield return new KeyValuePair<uint, string>(10000, "1");
            yield return new KeyValuePair<uint, string>(50001, this[20001]);
            yield return new KeyValuePair<uint, string>(50002, this[50002]);
            yield return new KeyValuePair<uint, string>(50003, this[10000]);
            yield return new KeyValuePair<uint, string>(50008, "3");
            yield return new KeyValuePair<uint, string>(50009, this[57]);
        }
    }
}
