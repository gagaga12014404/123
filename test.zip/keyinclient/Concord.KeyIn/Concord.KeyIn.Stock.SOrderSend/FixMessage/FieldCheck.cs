﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public abstract class FieldCheckBase
    {
        public uint Tag { get; }
        public string ECODE { get; protected set; }
        public string EMSG { get; protected set; }

        public FieldCheckBase(uint tag)
        {
            Tag = tag;
        }

        public abstract bool DoCheck(IDictionary<uint, string> dicMessage);
    }

    /// <summary>
    /// 臨時風控：不可改價
    /// </summary>
    public class PriceCheck : FieldCheckBase
    {
        public PriceCheck(uint tag = 0) : base(tag) { }

        public override bool DoCheck(IDictionary<uint, string> dicMessage)
        {
            ECODE = "T025";
            EMSG = "暫不支援改價";
            return false;
        }
    }
}
