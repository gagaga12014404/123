﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class FiisSettings : ConfigurationSection
    {
        [ConfigurationProperty("QuoteSetting")]
        public QuoteSettingElement QuoteSetting
        {
            get { return (QuoteSettingElement)this["QuoteSetting"]; }
            set { this["QuoteSetting"] = value; }
        }
    }

    public class QuoteSettingElement : ConfigurationElement
    {
        [ConfigurationProperty("IP", DefaultValue = "192.168.199.145", IsRequired = true)]
        public string IP
        {
            get { return (string)this["IP"]; }
            set { this["IP"] = value; }
        }

        [ConfigurationProperty("Port", DefaultValue = 8061, IsRequired = true)]
        public int Port
        {
            get { return (int)this["Port"]; }
            set { this["Port"] = value; }
        }

        [ConfigurationProperty("UserName", DefaultValue = "SFIF", IsRequired = true)]
        public string UserName
        {
            get { return (string)this["UserName"]; }
            set { this["UserName"] = value; }
        }

        [ConfigurationProperty("Password", DefaultValue = "SFIF", IsRequired = true)]
        public string Password
        {
            get { return (string)this["Password"]; }
            set { this["Password"] = value; }
        }

        [ConfigurationProperty("Group", DefaultValue = "SYSTEX", IsRequired = true)]
        public string Group
        {
            get { return (string)this["Group"]; }
            set { this["Group"] = value; }
        }

        [ConfigurationProperty("ReconnectCount", DefaultValue = 3, IsRequired = true)]
        public int ReconnectCount
        {
            get { return (int)this["ReconnectCount"]; }
            set { this["ReconnectCount"] = value; }
        }

        [ConfigurationProperty("ConnectFrequency", DefaultValue = 10.0, IsRequired = true)]
        public double ConnectFrequency
        {
            get { return (double)this["ConnectFrequency"]; }
            set { this["ConnectFrequency"] = value; }
        }
    }
}
