﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class FiisQuote : IDisposable
    {
        #region 參數設定
        private static FiisSettings m_config = (FiisSettings)ConfigurationManager.GetSection("fiisSettings");
        private string m_fiisHost = m_config.QuoteSetting.IP;
        private int m_fiisPort = m_config.QuoteSetting.Port;
        private string m_fiisUserName = m_config.QuoteSetting.UserName;
        private string m_fiisPassword = m_config.QuoteSetting.Password;
        private string m_fiisGroup = m_config.QuoteSetting.Group;
        private int m_reconnectCountMax = m_config.QuoteSetting.ReconnectCount;
        private double m_connectFrequency = m_config.QuoteSetting.ConnectFrequency;
        #endregion

        #region 物件宣告
        private readonly SystexApiPort m_pSFIFOBJ = new SystexApiPort();
        private volatile bool m_bConnect = false;
        private volatile bool m_bInitialize = false;
        private int m_reconnectCount = 0;
        private IntPtr m_recvBuffer = Marshal.StringToBSTR(new string(' ', SystexApiPort.SFIF_MAXPKTSIZE));

        public bool IsConnected { get { return m_bInitialize ? m_bConnect : m_bInitialize; } }

        public event Action<int, string> OnConnectionStatusChanged;
        public event Action<string> OnReceiveMessage;
        #endregion

        #region FIIS 連線設定
        public bool Initialize(ref int errorCode)
        {
            if (m_bInitialize)
                return true;
            errorCode = m_pSFIFOBJ.initialize(SystexApiPort.MOB_BUFFER_MAX);
            if (errorCode == SystexApiPort.SFIF_OK)
            {
                m_bInitialize = true;
            }
            else if (errorCode == SystexApiPort.SFIF_TCP_WSA_ERROR)
            {
                errorCode = m_pSFIFOBJ.getLastError();
            }
            return m_bInitialize;
        }

        public bool Connect(ref int errorCode)
        {
            return Connect(m_fiisHost, m_fiisPort, m_fiisUserName, m_fiisPassword, m_fiisGroup, ref errorCode);
        }

        public bool Connect(string host, int port, string userName, string password, string group, ref int errorCode)
        {
            if (!m_bInitialize)
                return m_bConnect = false;
            else if (m_bConnect)
                return true;
            m_fiisHost = host;
            m_fiisPort = port;
            m_fiisUserName = userName;
            m_fiisPassword = password;
            m_fiisGroup = group;
            errorCode = m_pSFIFOBJ.connect(host, port, userName, password, group);
            if (errorCode == SystexApiPort.SFIF_OK)
            {
                m_bConnect = true;
                m_reconnectCount = 0;
                Task.Run(() => Receive());
            }
            else if (errorCode == SystexApiPort.SFIF_TCP_WSA_ERROR)
            {
                errorCode = m_pSFIFOBJ.getLastError();
            }
            else if (errorCode == SystexApiPort.SFIF_UNEXPECTED_CALL)
            {
                m_bInitialize = false;
            }
            return m_bConnect;
        }

        public bool Reconnect()
        {
            if (!m_bInitialize)
                return m_bConnect = false;
            else if (m_bConnect)
                return true;
            var ret = m_pSFIFOBJ.connect(m_fiisHost, m_fiisPort, m_fiisUserName, m_fiisPassword, m_fiisGroup);
            if (ret == SystexApiPort.SFIF_OK)
            {
                m_bConnect = true;
                m_reconnectCount = 0;
            }
            else if (ret == SystexApiPort.SFIF_UNEXPECTED_CALL)
            {
                m_bInitialize = false;
            }
            return m_bConnect;
        }

        public void Disconnect()
        {
            m_pSFIFOBJ.disconnect();
            m_bConnect = false;
        }

        public void Deinitialize()
        {
            m_pSFIFOBJ.deinitialize();
            m_bInitialize = false;
        }
        #endregion

        #region FIIS 電文收送
        public void Send(IEnumerable<KeyValuePair<uint, string>> pairs)
        {
            var message = pairs.Aggregate(
                "",
                (m, kvp) => $"{m}{kvp.Key}={kvp.Value}\u0001",
                m => $"8=SFIF1.0\u00019={Encoding.UTF8.GetByteCount(m)}\u0001{m}10={CalculateCheckSum(Encoding.UTF8.GetBytes(m))}\u0001");
            m_pSFIFOBJ.request(Encoding.UTF8.GetBytes(message), Encoding.UTF8.GetByteCount(message));
        }

        public bool Subscribe(int marketType, string symbol)
        {
            return m_pSFIFOBJ.subscribe(marketType, symbol) >= 0;
        }

        public async Task Receive()
        {
            while (true)
            {
                if (m_bInitialize)
                {
                    var ret = m_pSFIFOBJ.recv(m_recvBuffer, SystexApiPort.SFIF_MAXPKTSIZE);
                    if (ret > 0)
                    {
                        var message = Marshal.PtrToStringAnsi(m_recvBuffer, ret);
                        OnReceiveMessage?.Invoke(message);
                    }
                    else if (ret == SystexApiPort.SFIF_DISCONNECT)
                    {
                        m_bConnect = false;
                        OnConnectionStatusChanged?.Invoke(ret, "沒有連線");
                        if (m_reconnectCountMax >= m_reconnectCount)
                        {
                            if (Reconnect())
                            {
                                OnConnectionStatusChanged?.Invoke(SystexApiPort.SFIF_OK, "重新連線成功");
                            }
                            else
                            {
                                Interlocked.Increment(ref m_reconnectCount);
                                OnConnectionStatusChanged?.Invoke(ret, "重新連線失敗");
                                await Task.Delay(TimeSpan.FromSeconds(m_connectFrequency));
                            }
                        }
                        else
                        {
                            OnConnectionStatusChanged?.Invoke(ret, "嘗試連線失敗次數已超出預設值");
                        }
                    }
                    else await Task.Delay(1);
                }
                else if (disposed) break;
            }
        }

        private int CalculateCheckSum(byte[] data)
        {
            return data.Aggregate(0, (i, b) => i + b, s => s % 256);
        }
        #endregion

        #region IDisposable Support
        private bool disposed = false; // 偵測多餘的呼叫

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TODO: 處置 Managed 狀態 (Managed 物件)。
                    OnConnectionStatusChanged = null;
                    OnReceiveMessage = null;
                    if (m_bConnect)
                        Disconnect();
                    if (m_bInitialize)
                        Deinitialize();
                }

                // TODO: 釋放 Unmanaged 資源 (Unmanaged 物件) 並覆寫下方的完成項。
                // TODO: 將大型欄位設為 null。
                Marshal.FreeBSTR(m_recvBuffer);
                m_recvBuffer = IntPtr.Zero;
                disposed = true;
            }
        }

        // TODO: 僅當上方的 Dispose(bool disposing) 具有會釋放 Unmanaged 資源的程式碼時，才覆寫完成項。
        ~FiisQuote()
        {
            // 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
            Dispose(false);
        }

        // 加入這個程式碼的目的在正確實作可處置的模式。
        public void Dispose()
        {
            // 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
            Dispose(true);
            // TODO: 如果上方的完成項已被覆寫，即取消下行的註解狀態。
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
