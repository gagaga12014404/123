﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SOrderSend
{
    public class SystexApiPort
    {
        #region SFIFAPI DLL Import
        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_initialize(int iBufferSize);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern void sfif_deinitialize();

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_connect(string szHost, int iPort, string szAccount, string szPassword, string szGroupName);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern void sfif_disconnect();

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_request(byte[] byData, int iLen);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_recv(IntPtr pbyBuf, int iBufsize);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_subscribe(int iService, string szSymbol);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_unsubscribe(int iService, string szSymbol);

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_getLastError();

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern int sfif_checkqueue();

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern long sfif_getFullCnt();

        [DllImport("SFIFAPI.dll", SetLastError = true)]
        public static extern void sfif_enableTimeLog(bool bWriteLog);
        #endregion

        #region SFIFAPI CONST Values
        public const int SFIF_OK = 0;                        // 成功
        public const int SFIF_TCP_WSA_ERROR = -1;            // Socket 層錯誤, 呼叫 sfif_getLastErrlr() 含數取得錯誤碼
        public const int SFIF_DATA_TOO_LONG = -2;            // 傳送資料太長, 最長不能超過1024 Bytes
        public const int SFIF_DISCONNECT = -3;               // 沒有連線
        public const int SFIF_SEND_FULL = -4;                // 傳送緩衝區滿溢(full)
        public const int SFIF_INVALIDED_SYMBOL = -5;         // 無效的商品代碼字串
        public const int SFIF_BUFFER_TOO_SMALL = -6;         // 緩衝區太小, 至少1024 bytes.
        public const int SFIF_DATA_ERROR = -7;               // 資料格式錯誤
        public const int SFIF_RECV_BUFFER_SIZE_ERROR = -8;   // 參數指定的buffer大小不符規定
        public const int SFIF_UNEXPECTED_CALL = -9;          // 沒有呼叫initialize就呼叫connect
        public const int SFIF_INVALIDED_SERVICE = -10;       // 無效的盤別或市場別
        public const int SFIF_INVALIDED_ITEMNO = -11;        // 無效的欄位代碼
        public const int SFIF_INVALIDED_TYPE = -12;          // 無效的資料型態
        public const int SFIF_SUBJECT_INVALIDED = -30;       // 無效的主題
        public const int SFIF_SUBJECT_TOO_LONG = -31;        // 主題長度太長, 不可超過255
        public const int SFIF_SUBJECT_OVER_LIMIT = -32;      // 主題註冊太多, 不可超過 4096
        public const int SFIF_UNAUTHORIZED = -33;            // 沒有授權
        public const int SFIF_INVALIDED_CHANNEL = -34;       // 無效的channel

        public const int MOB_BUFFER_DEFAULT = 64 * 1024;     // 64K (byte)
        public const int MOB_BUFFER_MIN = 16 * 1024;         // 16K (byte)
        public const int MOB_BUFFER_MAX = 2 * 1024 * 1024;   // 2M  (byte)
        public const int SFIF_MAXPKTSIZE = 1024;             // 1K  (byte)
        public const string SFIF_ALL = "*";                  // 註冊和反註冊時, 指定全市場資訊
        #endregion

        #region SFIFAPI Porting
        public int initialize(int iBufferSize)
        {
            return sfif_initialize(iBufferSize);
        }

        public void deinitialize()
        {
            sfif_deinitialize();
        }

        public int connect(string szHost, int iPort, string szAccount, string szPassword, string szGroupName)
        {
            return sfif_connect(szHost, iPort, szAccount, szPassword, szGroupName);
        }

        public void disconnect()
        {
            sfif_disconnect();
        }

        public int request(byte[] byData, int iLen)
        {
            return sfif_request(byData, iLen);
        }

        public int recv(System.IntPtr pbyBuf, int iBufsize)
        {
            return sfif_recv(pbyBuf, iBufsize);
        }

        public int subscribe(int iService, string szSymbol)
        {
            return sfif_subscribe(iService, szSymbol);
        }

        public int unsubscribe(int iService, string szSymbol)
        {
            return sfif_unsubscribe(iService, szSymbol);
        }

        public int getLastError()
        {
            return sfif_getLastError();
        }

        public int checkqueue()
        {
            return sfif_checkqueue();
        }

        public long getFullCnt()
        {
            return sfif_getFullCnt();
        }

        public void enableTimeLog(bool bWriteLog)
        {
            sfif_enableTimeLog(bWriteLog);
        }
        #endregion
    }
}
