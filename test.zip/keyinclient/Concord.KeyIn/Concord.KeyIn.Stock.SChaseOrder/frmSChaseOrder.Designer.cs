﻿namespace Concord.KeyIn.Stock.SChaseOrder
{
    partial class frmSChaseOrder
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.SChaseReceiveQueue = new System.Messaging.MessageQueue();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblUnFinish = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SChaseReceiveQueue
            // 
            this.SChaseReceiveQueue.MessageReadPropertyFilter.LookupId = true;
            this.SChaseReceiveQueue.SynchronizingObject = this;
            this.SChaseReceiveQueue.ReceiveCompleted += new System.Messaging.ReceiveCompletedEventHandler(this.SChaseReceiveQueue_ReceiveCompleted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "收到改價筆數：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(12, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "尚未完成筆數：";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCount.Location = new System.Drawing.Point(140, 13);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(46, 16);
            this.lblCount.TabIndex = 0;
            this.lblCount.Text = "label1";
            // 
            // lblUnFinish
            // 
            this.lblUnFinish.AutoSize = true;
            this.lblUnFinish.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUnFinish.Location = new System.Drawing.Point(140, 43);
            this.lblUnFinish.Name = "lblUnFinish";
            this.lblUnFinish.Size = new System.Drawing.Size(46, 16);
            this.lblUnFinish.TabIndex = 0;
            this.lblUnFinish.Text = "label1";
            // 
            // frmSChaseOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 72);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblUnFinish);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.label1);
            this.Name = "frmSChaseOrder";
            this.Text = "證券中台改價";
            this.Load += new System.EventHandler(this.frmSChaseOrder_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Messaging.MessageQueue SChaseReceiveQueue;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblUnFinish;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label label1;
    }
}

