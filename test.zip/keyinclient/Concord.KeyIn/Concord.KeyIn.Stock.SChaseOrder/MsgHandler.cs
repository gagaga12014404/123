﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concord.KeyIn.Stock.SChaseOrder
{
    class MsgHandler
    {
                /// <summary>
        /// 解析電文
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="dicMsg"></param>
        /// <returns></returns>
        public Boolean ParseMsg(String strMsg, Char strSplitChar, out Dictionary<Int32, String> dicMsg)
        {
            Boolean isOK = false;
            dicMsg = new Dictionary<Int32, String>();

            try
            {
                String[] strData = strMsg.Split(strSplitChar);

                foreach (String str in strData)
                {
                    String[] Data = str.Split(new Char[] { '=' }, 2);
                    dicMsg.Add(int.Parse(Data[0]), Data[1]);
                }
                isOK = true;
            }
            catch (Exception)
            {
                isOK = false;
            }
            return isOK;
        }

        /// <summary>
        /// 解析收到電文
        /// </summary>
        /// <param name="strMsg"></param>
        /// <param name="Msg"></param>
        /// <returns></returns>
        public Boolean ParseReceiveMsg(String strMsg, out _ReceiveMsg Msg)
        {
            Boolean isOK = false;
            Decimal decValue = 0;
            Dictionary<Int32, String> dicMsg;
            Msg = new _ReceiveMsg();

            try
            {
                if (ParseMsg(strMsg, '|', out dicMsg))
                {
                    Msg.ExecType = dicMsg[10002];
                    if (Msg.ExecType == "D")
                    {
                        Msg.MsgType = dicMsg[35];
                        Msg.Bhno = dicMsg[50];
                        Msg.Dseq = dicMsg[37];                    
                        Decimal.TryParse(dicMsg[20009], out decValue);
                        Msg.BQty = decValue;
                        Decimal.TryParse(dicMsg[20010], out decValue);
                        Msg.AQty = decValue;
                        Msg.ErrMsg = dicMsg[150] == "8" ? dicMsg[58] : "";
                    }

                    isOK = true;
                }
                else
                {
                    isOK = false;
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error("ParseReceiveMsg Fail", ex);
                isOK = false;
            }
            return isOK;
        }

        public Boolean ParseOrderMsg(String strMsg, out _OrderMsg Msg) 
        {
            Boolean isOK = false;
            Dictionary<Int32, String> dicMsg;
            Msg = new _OrderMsg();
            try
            {
                if (ParseMsg(strMsg, '|', out dicMsg))
                {
                    Msg.TDate = dicMsg[60];
                    Msg.Dseq = dicMsg[37];
                    Msg.Seqno = dicMsg[41];
                    Msg.Bhno = dicMsg[50];
                    Msg.Cseq = dicMsg[1];
                    Msg.MType = dicMsg[56];
                    Msg.TType = dicMsg[57];
                    Msg.OType = dicMsg[10001];
                    Msg.OCode = dicMsg[40];
                    Msg.Stock = dicMsg[55];
                    Msg.BS = dicMsg[54];
                    Msg.Price = dicMsg[44];
                    Msg.Origin = dicMsg[10000];
                    Msg.Sale = dicMsg[20001];
                    Msg.DTCode = dicMsg[20003];
                    Msg.IP = dicMsg[20000];
                    Msg.RcvTime = DateTime.Now;
                    Msg.OriginalMsg = strMsg;
                    isOK = true;
                }
                else
                {
                    isOK = false;
                }
            }
            catch (Exception ex)
            {
                Concord.SDK.Logging.ConcordLogger.Logger.Error("ParseOrderMsg Fail", ex);
                isOK = false;
            }
            return isOK;
        }

        /// <summary>
        /// 組新單電文
        /// </summary>
        /// <param name="Msg"></param>
        /// <returns></returns>
        public String ComposeNewOrderMsg(_OrderMsg Msg)
        {
            String strHead = "8=Concords|9={0}";
            String strBody = "|35=I" +
                             "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                             "|60=" + Msg.TDate +
                             "|11=" + Msg.MSeqno +
                             "|50=" + Msg.Bhno +
                             "|1=" + Msg.Cseq +
                             "|56=" + Msg.MType +
                             "|57=" + Msg.TType +
                             "|10001=" + Msg.OType +
                             "|55=" + Msg.Stock +
                             "|54=" + Msg.BS +
                             "|40=" + Msg.OCode +
                             "|38=" + Msg.Oqty +
                             "|44=" + Msg.Price +
                             "|10000=" + Msg.Origin +
                             "|20002=0" +
                             "|20001=" + Msg.Sale +
                             "|20000=" + Msg.IP +
                             "|21000=N" +
                             "|21001=" +
                             "|21002=" +
                             "|21003=" +
                             "|21004=" +
                             "|20003=" + Msg.DTCode +
                             "|20021=" + Msg.UPCode +
                             "|21037=" + Msg.Dseq;
            strHead = String.Format(strHead, Encoding.GetEncoding("Big5").GetBytes(strBody).Length.ToString().PadLeft(5, '0'));
            return strHead + strBody;
        }

        /// <summary>
        /// 組刪單電文
        /// </summary>
        /// <param name="Msg"></param>
        /// <returns></returns>
        public String ComposeDeleteOrderMsg(_OrderMsg Msg)
        {
            String strHead = "8=Concords|9={0}";
            String strBody = "|35=D" +
                             "|52=" + DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") +
                             "|60=" + Msg.TDate +
                             "|11=" + Msg.MSeqno +
                             "|41=" + Msg.Seqno +
                             "|37=" + Msg.Dseq +
                             "|50=" + Msg.Bhno +
                             "|1=" + Msg.Cseq +
                             "|56=" + Msg.MType +
                             "|57=" + Msg.TType +
                             "|10001=" + Msg.OType +
                             "|55=" + Msg.Stock +
                             "|54=" + Msg.BS +
                             "|40=" + Msg.OCode +
                             "|38=0" +
                             "|44=0" +
                             "|10000=" + Msg.Origin +
                             "|20001=" + Msg.Sale +
                             "|20000=" + Msg.IP +
                             "|21000=N" +
                             "|21001=" +
                             "|21002=" +
                             "|21003=" + 
                             "|21004=" +
                             "|20003=" + Msg.DTCode +
                             "|20021=" + Msg.UPCode;
            strHead = String.Format(strHead, Encoding.GetEncoding("Big5").GetBytes(strBody).Length.ToString().PadLeft(5, '0'));
            return strHead + strBody;
        }

        public class _OrderMsg
        {
            /// <summary>
            /// 訊息種類
            /// </summary>
            public String MsgType;
            /// <summary>
            /// 交易日期
            /// </summary>
            public String TDate;
            /// <summary>
            /// 委託書號
            /// </summary>
            public String Dseq;
            /// <summary>
            /// 網路單號
            /// </summary>
            public String MSeqno;
            /// <summary>
            /// 原網路單號
            /// </summary>
            public String Seqno;
            /// <summary>
            /// 分公司碼
            /// </summary>
            public String Bhno;
            /// <summary>
            /// 客戶帳號
            /// </summary>
            public String Cseq;
            /// <summary>
            /// 市場別
            /// </summary>
            public String MType;
            /// <summary>
            /// 交易別
            /// </summary>
            public String TType;
            /// <summary>
            /// 委託別
            /// </summary>
            public String OType;
            /// <summary>
            /// 委託方式
            /// </summary>
            public String OCode;
            /// <summary>
            /// 股票代號
            /// </summary>
            public String Stock;
            /// <summary>
            /// 買賣別
            /// </summary>
            public String BS;
            /// <summary>
            /// 委託量
            /// </summary>
            public String Oqty;
            /// <summary>
            /// 委託單價
            /// </summary>
            public String Price;
            /// <summary>
            /// 來源別
            /// </summary>
            public String Origin;
            /// <summary>
            /// 營業員代碼
            /// </summary>
            public String Sale;
            /// <summary>
            /// 現賣沖註記
            /// </summary>
            public String DTCode;
            /// <summary>
            /// 漲跌停註記
            /// </summary>
            public String UPCode;
            /// <summary>
            /// Client IP
            /// </summary>
            public String IP;
            /// <summary>
            /// 收到改價指令時間
            /// </summary>
            public DateTime RcvTime;
            /// <summary>
            /// 原始訊息
            /// </summary>
            public String OriginalMsg;
        }

        public class _ReceiveMsg
        {
            /// <summary>
            /// 訊息種類
            /// </summary>
            public String MsgType;
            /// <summary>
            /// 執行種類
            /// </summary>
            public String ExecType;
            /// <summary>
            /// 交易日期
            /// </summary>
            public String TDate;
            /// <summary>
            /// 委託書號
            /// </summary>
            public String Dseq;
            /// <summary>
            /// 分公司碼
            /// </summary>
            public String Bhno;
            /// <summary>
            /// 改量前張數
            /// </summary>
            public Decimal BQty;
            /// <summary>
            /// 改量後張數
            /// </summary>
            public Decimal AQty;
            /// <summary>
            /// 訊息
            /// </summary>
            public String ErrMsg;
        }
    }
}
