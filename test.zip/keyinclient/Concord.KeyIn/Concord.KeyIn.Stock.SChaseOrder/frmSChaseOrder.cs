﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Messaging;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SChaseOrder
{
    public partial class frmSChaseOrder : Form
    {
        #region 定義物件
        String strChaseReceiveQueue = Properties.Settings.Default.SChaseReceiveQueue;
        String strOrderSendQueue = Properties.Settings.Default.SOrderSendQueue;
        Queue qChaseOrder = Queue.Synchronized(new Queue());
        Queue qOrderReceive = Queue.Synchronized(new Queue());
        MsgHandler Msg = new MsgHandler();
        ConcurrentDictionary<String, MsgHandler._OrderMsg> dicChaseOrder = new ConcurrentDictionary<String, MsgHandler._OrderMsg>();
        int intExpireTime = Properties.Settings.Default.ExpireTime;
        String strNetNoFormat = Properties.Settings.Default.NetNoFormat; //網單格式
        Object lockObject = new Object();
        #endregion

        public frmSChaseOrder()
        {
            InitializeComponent();
        }

        private void frmSChaseOrder_Load(object sender, EventArgs e)
        {
            lblCount.Text = "0";
            lblUnFinish.Text = "0";

            SChaseReceiveQueue.Path = strChaseReceiveQueue;
            SChaseReceiveQueue.Formatter = new System.Messaging.BinaryMessageFormatter();
            SChaseReceiveQueue.BeginReceive();
            ConcordLogger.Logger.Info("初始化收MSMQ功能");
            Task tOrderDelete = new Task(OrderDeleteProcessor);
            tOrderDelete.Start();
            ConcordLogger.Logger.Info("初始化刪單功能");
            Task tOrderNew = new Task(OrderNewProcessor);
            tOrderNew.Start();
            ConcordLogger.Logger.Info("初始化新單功能");
            Task tMonitor = new Task(MonitorChaseOrder);
            tMonitor.Start();
            ConcordLogger.Logger.Info("初始化監控改價單功能");
        }

        private void OrderDeleteProcessor()
        {
            MessageQueue mOrderQueue;
            System.Messaging.Message mm;
            while (true)
            {
                try
                {
                    if (qChaseOrder.Count > 0)
                    {
                        String strMsg = qChaseOrder.Dequeue().ToString();
                        MsgHandler._OrderMsg OrderMsg;
                        Msg.ParseOrderMsg(strMsg, out OrderMsg);

                        dicChaseOrder.GetOrAdd(OrderMsg.Bhno + OrderMsg.Dseq, OrderMsg);

                        String strNetNo = NetNoHelper.GetNetNo().ToString(strNetNoFormat);
                        OrderMsg.MSeqno = strNetNo;
                        String strDeleteMsg = Msg.ComposeDeleteOrderMsg(OrderMsg);

                        mm = new System.Messaging.Message(strDeleteMsg, new BinaryMessageFormatter());

                        mOrderQueue = new MessageQueue(strOrderSendQueue);
                        mOrderQueue.Send(mm);

                        ConcordLogger.Logger.Info("送出刪單MSMQ：" + mOrderQueue.Path + "電文:" + strDeleteMsg);
                    }
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("送出刪單異常：" + ex.ToString());
                    ConcordLogger.Alert("4001", "證券改價程式 送出刪單異常", ex.ToString());
                }
                Thread.Sleep(1);
            }
        }

        private void OrderNewProcessor()
        {
            MessageQueue mOrderQueue;
            System.Messaging.Message mm;
            while (true)
            {
                try
                {
                    if (qOrderReceive.Count > 0)
                    {
                        String strMsg = qOrderReceive.Dequeue().ToString();
                        MsgHandler._ReceiveMsg ReceiveMsg;
                        Msg.ParseReceiveMsg(strMsg, out ReceiveMsg);

                        if (dicChaseOrder.ContainsKey(ReceiveMsg.Bhno + ReceiveMsg.Dseq))
                        {
                            if (ReceiveMsg.ErrMsg == "")
                            {
                                MsgHandler._OrderMsg OrderMsg = new MsgHandler._OrderMsg();
                                dicChaseOrder.TryRemove(ReceiveMsg.Bhno + ReceiveMsg.Dseq, out OrderMsg);

                                String strNetNo = NetNoHelper.GetNetNo().ToString(strNetNoFormat);
                                OrderMsg.MSeqno = strNetNo;
                                OrderMsg.Oqty = (ReceiveMsg.BQty - ReceiveMsg.AQty).ToString();
                                String strNewMsg = Msg.ComposeNewOrderMsg(OrderMsg);

                                mm = new System.Messaging.Message(strNewMsg, new BinaryMessageFormatter());
                                //需求單編號RQ20170301-020 要延後100ms送新單，避免後台還沒釋放庫存或額度
                                //因20180720還是發生後台沒釋放庫存或額度，調整延長時間為500ms
                                Thread.Sleep(500);

                                mOrderQueue = new MessageQueue(strOrderSendQueue);
                                mOrderQueue.Send(mm);

                                ConcordLogger.Logger.Info("送出新單MSMQ：" + mOrderQueue.Path + "電文:" + strNewMsg);
                            }
                            else
                            {
                                MsgHandler._OrderMsg OrderMsg;
                                dicChaseOrder.TryRemove(ReceiveMsg.Bhno + ReceiveMsg.Dseq, out OrderMsg);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("送出新單異常：" + ex.ToString());
                    ConcordLogger.Alert("4001", "證券改價程式 送出新單異常", ex.ToString());
                }
                Thread.Sleep(1);
            }
        }

        private void MonitorChaseOrder()
        {
            while (true)
            {
                Invoke(new Action(() => { lblUnFinish.Text = dicChaseOrder.Count().ToString(); }));
                foreach (KeyValuePair<String, MsgHandler._OrderMsg> ChaseOrder in dicChaseOrder)
                {
                    TimeSpan ts = DateTime.Now.Subtract(ChaseOrder.Value.RcvTime);
                    if (ts.TotalSeconds > intExpireTime)
                    {
                        MsgHandler._OrderMsg OrderMsg;
                        dicChaseOrder.TryRemove(ChaseOrder.Value.Bhno + ChaseOrder.Value.Dseq, out OrderMsg);
                        ConcordLogger.Logger.Info("改價單超過" + intExpireTime + "秒未收到刪單回報，已先行結案，電文：" + ChaseOrder.Value.OriginalMsg);
                        ConcordLogger.Alert("0001", "證券改價單超過" + intExpireTime + "秒未收到刪單回報，已先行結案", "改價單超過" + intExpireTime + "秒未收到刪單回報，已先行結案，電文：" + ChaseOrder.Value.OriginalMsg);
                    }
                }
                Thread.Sleep(5000);
            }
        }

        private void SChaseReceiveQueue_ReceiveCompleted(object sender, System.Messaging.ReceiveCompletedEventArgs e)
        {
            try
            {
                System.Messaging.Message oMessage = SChaseReceiveQueue.EndReceive(e.AsyncResult);
                oMessage.Formatter = new System.Messaging.BinaryMessageFormatter();
                string strRcvMsg = oMessage.Body.ToString();
                ConcordLogger.Logger.Debug("收MSMQ內容，strRcvMsg=" + strRcvMsg);
                if (strRcvMsg.Contains("35=P"))
                {
                    lblCount.Text = (int.Parse(lblCount.Text) + 1).ToString();
                    ConcordLogger.Logger.Info("收到改價單：" + strRcvMsg);
                    qChaseOrder.Enqueue(strRcvMsg);
                }
                else if (strRcvMsg.Contains("35=8") || (strRcvMsg.Contains("35=9")))
                {
                    ConcordLogger.Logger.Info("收到刪單回報：" + strRcvMsg);
                    qOrderReceive.Enqueue(strRcvMsg);
                }
                else
                {
                    ConcordLogger.Logger.Info("收到非預期電文：" + strRcvMsg);
                    ConcordLogger.Alert("9999", "收到非預期電文：" + strRcvMsg);
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("收單MSMQ異常：" + ex.ToString());
                ConcordLogger.Alert("4001", "證券改價程式 收單MSMQ異常", ex.ToString());
                SChaseReceiveQueue.BeginReceive();
            }
            finally
            {
                ConcordLogger.Logger.Debug("開始接收MSMQ，BeginReceive");
                SChaseReceiveQueue.BeginReceive();
            }
        }
    }
}
