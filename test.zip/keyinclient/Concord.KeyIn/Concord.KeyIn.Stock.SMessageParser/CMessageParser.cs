﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Stock.SMessageParser
{
    public partial class CMessageParser : Form
    {
        private readonly string m_queuePath = Properties.Settings.Default.strQueuePath;
        private readonly string m_queueName = Properties.Settings.Default.strQueueName;
        private readonly MessageHandler m_handler = new MessageHandler();
        private int m_count = 0;

        public CMessageParser()
        {
            InitializeComponent();
        }
        
        private void CMessageParser_Load(object sender, EventArgs e)
        {
            m_handler.Init();
            ConfigureMessageQueue();
        }

        /// <summary>
        /// MSMQ 初始化
        /// </summary>
        private void ConfigureMessageQueue()
        {
            try
            {
                CMessage_Queue.Path = m_queuePath + m_queueName;
                CMessage_Queue.Formatter = new System.Messaging.BinaryMessageFormatter();
                CMessage_Queue.BeginReceive();
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("MSMQ通訊異常：設定Queue路徑異常", ex);
                ConcordLogger.Alert("3003", "MSMQ通訊異常：設定Queue路徑異常", ex.ToString());
            }
        }

        private void CMessage_Queue_ReceiveCompleted(object sender, System.Messaging.ReceiveCompletedEventArgs e)
        {
            try
            {
                var oMessage = CMessage_Queue.EndReceive(e.AsyncResult);
                oMessage.Formatter = new System.Messaging.BinaryMessageFormatter();
                
                string messageBody = oMessage.Body.ToString();
                Interlocked.Increment(ref m_count);
                lblMsg.Text = "紀錄筆數：" + m_count.ToString() + "筆資料";
                Application.DoEvents();
                ConcordLogger.Logger.Info("MSMQ：" + messageBody);

                m_handler.AssignMessage(messageBody);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("MSMQ接收異常：接收Queue資料異常", ex);
                ConcordLogger.Alert("3004", "MSMQ接收異常：接收Queue資料異常", ex.ToString());
            }
            finally
            {
                CMessage_Queue.BeginReceive();
            }
        }
    }
}
