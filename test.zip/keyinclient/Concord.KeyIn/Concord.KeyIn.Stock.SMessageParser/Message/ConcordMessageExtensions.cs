﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SMessageParser
{
    public static class ConcordMessageExtensions
    {
        private const char cSectionSplitChar = '|';
        private const char cDataSplitChar = '=';

        public static KeyValuePair<uint, string>? GetSingleTagValue(this string section, char splitChar = cSectionSplitChar)
        {
            var pair = section.Split(new[] { cDataSplitChar }, 2);
            if (pair.Length != 2)
                return null;
            uint tag;
            if (!uint.TryParse(pair[0], out tag) || tag <= 0)
                return null;
            return new KeyValuePair<uint, string>(tag, pair[1]);
        }

        public static FixMessageDictionary ParseToDictionary(this string message, char splitChar = cSectionSplitChar)
        {
            var result = new FixMessageDictionary();
            foreach (var section in message.Split(splitChar))
            {
                var kvp = section.GetSingleTagValue() ?? new KeyValuePair<uint, string>(0, "");
                if (kvp.Key != 0)
                    result.Add(kvp.Key, kvp.Value);
            }
            return result;
        }
    }
}
