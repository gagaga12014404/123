﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concord.KeyIn.Stock.SMessageParser
{
    public class FixMessageDictionary : IDictionary<uint, string>
    {
        private readonly Dictionary<uint, string> m_dic = new Dictionary<uint, string>();

        public string this[uint key]
        {
            get
            {
                return m_dic.ContainsKey(key) ? m_dic[key] : "";
            }

            set
            {
                if (m_dic.ContainsKey(key))
                    m_dic[key] = value;
                else
                    Add(key, value);
            }
        }

        public int Count
        {
            get
            {
                return m_dic.Count;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).IsReadOnly;
            }
        }

        public ICollection<uint> Keys
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).Keys;
            }
        }

        public ICollection<string> Values
        {
            get
            {
                return ((IDictionary<uint, string>)m_dic).Values;
            }
        }

        public void Add(KeyValuePair<uint, string> item)
        {
            ((IDictionary<uint, string>)m_dic).Add(item);
        }

        public void Add(uint key, string value)
        {
            m_dic.Add(key, value);
        }

        public void Clear()
        {
            m_dic.Clear();
        }

        public bool Contains(KeyValuePair<uint, string> item)
        {
            return ((IDictionary<uint, string>)m_dic).Contains(item);
        }

        public bool ContainsKey(uint key)
        {
            return m_dic.ContainsKey(key);
        }

        public void CopyTo(KeyValuePair<uint, string>[] array, int arrayIndex)
        {
            ((IDictionary<uint, string>)m_dic).CopyTo(array, arrayIndex);
        }

        public IEnumerator<KeyValuePair<uint, string>> GetEnumerator()
        {
            return ((IDictionary<uint, string>)m_dic).GetEnumerator();
        }

        public bool Remove(KeyValuePair<uint, string> item)
        {
            return ((IDictionary<uint, string>)m_dic).Remove(item);
        }

        public bool Remove(uint key)
        {
            return m_dic.Remove(key);
        }

        public bool TryGetValue(uint key, out string value)
        {
            return m_dic.TryGetValue(key, out value);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IDictionary<uint, string>)m_dic).GetEnumerator();
        }
    }
}
