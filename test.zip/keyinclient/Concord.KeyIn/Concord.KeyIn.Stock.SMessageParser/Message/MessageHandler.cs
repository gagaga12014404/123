﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SMessageParser
{
    public class MessageHandler
    {
        private readonly bool m_isDB = Properties.Settings.Default.IsDB;

        public void Init()
        {
            DAL.GetSTMB();
        }

        public void AssignMessage(string message)
        {
            if (!m_isDB)
                return;

            //message_arr[0] SysName 系統別//
            //message_arr[1] SysType 系統類別 Stock(S) Future(F) Emerging(E)//
            //message_arr[2] InfoType 訊息類別 下單(O) 委回(OR) 成回(DR) 功能(F)//
            //message_arr[3] Msg 內部格式自定義//
            // "$" 符號間格//
            try
            {
                var message_arr = message.Split(new char[] { '$' }, 4);
                var sysName = message_arr[0];
                var btype = message_arr[1];
                var msgType = message_arr[2];
                var messageRaw = message_arr[3];
                switch (sysName)
                {
                    case "KeyIn":
                        if (btype == "S" || btype == "E")
                            ExecuteStock(btype, msgType, messageRaw);
                        break;
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("資料格式錯誤", ex);
                ConcordLogger.Alert("9001", "資料格式錯誤", ex.ToString());
            }
        }

        private void ExecuteStock(string btype, string msgType, string messageRaw)
        {
            ConcordLogger.Logger.Info("Execute 開始");
            //把半形逗點改為全型逗點
            var message = messageRaw.Replace(',', '，').ParseToDictionary();

            switch (msgType)
            {
                case "O":
                    DAL.ProcessOrderMessage(btype, message);
                    break;
                case "OR":
                    DAL.ProcessOrderReceiveMessage(btype, message);
                    break;
                case "DR":
                    DAL.ProcessDealMessage(btype, message);
                    break;
                default:
                    break;
            }
            ConcordLogger.Logger.Info("Execute 結束");
        }
    }
}
