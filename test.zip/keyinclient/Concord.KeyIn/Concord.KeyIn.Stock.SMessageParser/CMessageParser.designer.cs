﻿namespace Concord.KeyIn.Stock.SMessageParser
{
    partial class CMessageParser
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMsg = new System.Windows.Forms.Label();
            this.CMessage_Queue = new System.Messaging.MessageQueue();
            this.SuspendLayout();
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblMsg.Location = new System.Drawing.Point(12, 7);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(146, 20);
            this.lblMsg.TabIndex = 2;
            this.lblMsg.Text = "紀錄筆數：0筆資料";
            // 
            // CMessage_Queue
            // 
            this.CMessage_Queue.MessageReadPropertyFilter.LookupId = true;
            this.CMessage_Queue.SynchronizingObject = this;
            this.CMessage_Queue.ReceiveCompleted += new System.Messaging.ReceiveCompletedEventHandler(this.CMessage_Queue_ReceiveCompleted);
            // 
            // CMessageParser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 36);
            this.Controls.Add(this.lblMsg);
            this.Name = "CMessageParser";
            this.Text = "SMessageParser";
            this.Load += new System.EventHandler(this.CMessageParser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMsg;
        private System.Messaging.MessageQueue CMessage_Queue;
    }
}

