﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Concord.SDK.Logging;
using Concord.SDK.Utility;

namespace Concord.KeyIn.Stock.SMessageParser
{
    public static class DAL
    {
        private static readonly string m_sqlConn = Properties.Settings.Default.strConnection;
        private static readonly string m_sysName = Properties.Settings.Default.SysName;
        private static readonly Dictionary<string, int> m_dicSTMB = new Dictionary<string, int>();

        public static void GetSTMB()
        {
            ConcordLogger.Logger.Info("GetSTMB 開始");
            string sqlCmd = "";
            if (m_sysName == "BC")
            {
                sqlCmd = "SELECT LTRIM(RTRIM(STOCK)) AS stock, ISNULL(UNIT,1000) AS share FROM [dbo].[Basic_STMB]";
            }
            else if (m_sysName == "TC")
            {
                sqlCmd = "SELECT LTRIM(RTRIM(stock)) AS stock, ISNULL(UNIT,1000) AS share FROM [dbo].[BSTMB]";
            }
            else if (m_sysName == "KeyIn")
            {
                sqlCmd = "SELECT LTRIM(RTRIM([STOCK])) AS stock, ISNULL([UNIT],1000) AS share FROM [dbo].[S_Basic_STMB]";
            }
            else
            {
                ConcordLogger.Logger.Error("取得股票基本資料失敗，系統名稱指定錯誤 !");
                ConcordLogger.Alert("9999", "取得股票基本資料失敗，系統名稱指定錯誤 !");
            }
            string errorMessage = "";
            try
            {
                DataTable dtSTMB = new DataTable();
                dtSTMB = DBHelper.QueryData("CM", sqlCmd, m_sqlConn, new SqlParameter[] { }, ref errorMessage);
                if (errorMessage == "")
                {
                    ConcordLogger.Logger.Info("GetSTMB 成功!");
                    foreach (var row in dtSTMB.AsEnumerable())
                    {
                        var stock = row.Field<string>("stock").Trim();
                        var share = decimal.ToInt32(row.Field<decimal>("share"));
                        if (!m_dicSTMB.ContainsKey(stock))
                            m_dicSTMB.Add(stock, share);
                        else
                            m_dicSTMB[stock] = share;
                    }
                }
                else
                {
                    ConcordLogger.Logger.Error("GetSTMB 失敗：" + errorMessage);
                    ConcordLogger.Alert("9999", "GetSTMB 失敗!", errorMessage);
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GetSTMB 失敗：" + ex.ToString());
                ConcordLogger.Alert("9999", "GetSTMB 失敗!", ex.ToString());
            }
            ConcordLogger.Logger.Info("GetSTMB 結束");
        }

        public static void ProcessOrderMessage(string btype, FixMessageDictionary message)
        {
            string CDI = message[35];
            string MSEQNO = message[11];
            string SEQNO = message[41];
            //新單未提供tag41:原網單, 需以新網單補上
            SEQNO = string.IsNullOrEmpty(SEQNO) ? MSEQNO : SEQNO;
            string DSEQ = message[37];
            string BHNO = message[50];
            string CSEQ = message[1].PadLeft(7, '0');
            string MTYPE = message[56];
            string ECODE = message[57];
            string OTYPE = message[10001];
            string STOCK = message[55];
            string BS = message[54];
            string ORDTYPE = message[40];
            string TIF = message[59];
            int OQTY = int.Parse(string.IsNullOrWhiteSpace(message[38]) ? "0" : message[38]);
            int Unit = m_dicSTMB.ContainsKey(STOCK) ? m_dicSTMB[STOCK] : 1000;
            if (ECODE != "2" && ECODE != "7" && btype != "E")
            {
                OQTY = OQTY * Unit;
            }
            decimal PRICE = decimal.Parse(message[44]);
            string TDATE = DateTime.Now.ToString("yyyyMMdd");
            string TTIME = DateTime.Now.ToString("HHmmssfff");
            string ORIGN = message[10000];
            string BROKER = message[20001];
            string DTrade = string.IsNullOrWhiteSpace(message[20003]) ? "N" : message[20003];
            string SIP = string.IsNullOrWhiteSpace(message[20004]) ? "N" : message[20004];
            string errorMessage = "";
            string STATUS = "9";
            string ClientIP = message[20000];
            string PDSEQ = message[21037];
            string KEYIN = message[50002];
            string ForceFlag = message[60005];

            string[] ParamsName = { "TDATE", "MSEQNO", "SEQNO", "TTIME", "DSEQ", "BHNO", "CSEQ", "CDI", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "PRICE", "STATUS", "BROKER", "ORIGN", "DTRADE", "SIP", "ETYPE", "EMSG", "ClientIP", "PDSEQ" };
            string[] ParamsValue = { TDATE, MSEQNO, SEQNO, TTIME, DSEQ, BHNO, CSEQ, CDI, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), PRICE.ToString(), STATUS, BROKER, ORIGN, DTrade, SIP, "", "", ClientIP, PDSEQ };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("新單呼叫sp_UpdateS_TDORD");
            DBHelper.ExecProc("CM", "sp_UpdateS_TDORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            // sp_UpdateS_KeyInTDORD
            ParamsName = new string[] { "TDATE", "MSEQNO", "TTIME", "DSEQ", "BHNO", "CSEQ", "CDI", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "BQTY", "AQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ETYPE", "EMSG", "ClientIP", "KeyInNo" };
            ParamsValue = new string[] { TDATE, MSEQNO, TTIME, DSEQ, BHNO, CSEQ, CDI, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), "0", "0", "0", PRICE.ToString(), STATUS, BROKER, "", "", ClientIP, KEYIN };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("新單呼叫sp_UpdateS_KeyInTDORD");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_KeyInTDORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            ParamsName = new string[] { "TDATE", "MSEQNO", "SEQNO", "DSEQ", "TTIME", "BHNO", "CSEQ", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ORIGN", "ETYPE", "EMSG", "DTRADE", "SIP", "ClientIP", "ForceFlag", "CDI" };
            ParamsValue = new string[] { TDATE, MSEQNO, SEQNO, DSEQ, TTIME, BHNO, CSEQ, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), "0", PRICE.ToString(), STATUS, BROKER, ORIGN, "", "", DTrade, SIP, ClientIP, ForceFlag, CDI };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("新單呼叫sp_UpdateS_TMORD");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_TMORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);
        }

        public static void ProcessOrderReceiveMessage(string btype, FixMessageDictionary message)
        {
            string strDetailStatus = "";
            string CDI = message[10002];
            string MSGTYPE = message[35];
            string MSEQNO = message[11];
            string SEQNO = message[41];
            string STATUS = message[150];
            string DSEQ = message[37];
            string BHNO = message[50];
            string CSEQ = message[1].PadLeft(7, '0');
            string MTYPE = message[56];
            string ECODE = message[57];
            string OTYPE = message[10001];
            string STOCK = message[55];
            string BS = message[54];
            string ORDTYPE = message[40];
            string TIF = message[59];
            int Unit = m_dicSTMB.ContainsKey(STOCK) ? m_dicSTMB[STOCK] : 1000;
            int OQTY = int.Parse(string.IsNullOrWhiteSpace(message[38]) ? "0" : message[38]);
            decimal PRICE = decimal.Parse(message[44]);
            string ETYPE = message[103];
            string EMSG = message[58].Replace("'", @"""");
            string TDATE = message[60].Substring(0, 8);
            string TTIME = message[60].Substring(9, 9);
            string ORIGN = message[10000];
            string BROKER = message[20001];
            string DTrade = message[20003];
            string SIP = message[20004];
            int BFQTY = int.Parse(message[20009]);
            int AFQTY = int.Parse(message[20010]);
            if (ECODE != "2" && ECODE != "7" && btype != "E")
            {
                OQTY = OQTY * Unit;
                BFQTY = BFQTY * Unit;
                AFQTY = AFQTY * Unit;
            }
            switch (STATUS)
            {
                case "0":
                case "4":
                case "5":
                case "M":
                    strDetailStatus = "0";
                    break;
                case "8":
                    strDetailStatus = "8";
                    break;
            }
            string KEYIN = message[50002];
            string errorMessage = "";

            string[] ParamsName = { "TDATE", "MSEQNO", "SEQNO", "TTIME", "DSEQ", "BHNO", "CSEQ", "CDI", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "PRICE", "STATUS", "BROKER", "ORIGN", "DTRADE", "SIP", "ETYPE", "EMSG", "ClientIP", "PDSEQ" };
            string[] ParamsValue = { TDATE, MSEQNO, SEQNO, TTIME, DSEQ, BHNO, CSEQ, CDI, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), PRICE.ToString(), strDetailStatus, BROKER, ORIGN, DTrade, SIP, ETYPE, EMSG, "", "" };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("委回呼叫sp_UpdateS_TDORD");
            DBHelper.ExecProc("CM", "sp_UpdateS_TDORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            // sp_UpdateS_KeyInTDORD
            ParamsName = new string[] { "TDATE", "MSEQNO", "TTIME", "DSEQ", "BHNO", "CSEQ", "CDI", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "BQTY", "AQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ETYPE", "EMSG", "ClientIP", "KeyInNo" };
            ParamsValue = new string[] { TDATE, MSEQNO, TTIME, DSEQ, BHNO, CSEQ, CDI, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), BFQTY.ToString(), AFQTY.ToString(), "0", PRICE.ToString(), strDetailStatus, BROKER, ETYPE, EMSG, "", KEYIN };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("委回呼叫sp_UpdateS_KeyInTDORD");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_KeyInTDORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            if (MSGTYPE == "8")
            {
                ParamsName = new string[] { "TDATE", "MSEQNO", "SEQNO", "DSEQ", "TTIME", "BHNO", "CSEQ", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ORIGN", "ETYPE", "EMSG", "DTRADE", "SIP", "ClientIP", "ForceFlag", "CDI" };
                ParamsValue = new string[] { TDATE, MSEQNO, SEQNO, DSEQ, TTIME, BHNO, CSEQ, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, OQTY.ToString(), "", PRICE.ToString(), STATUS, BROKER, ORIGN, ETYPE, EMSG, DTrade, SIP, "", "", "" };
                ConcordLogger.Logger.Info(string.Join(",", ParamsName));
                ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
                ConcordLogger.Logger.Info("委回呼叫sp_UpdateS_TMORD");
                errorMessage = "";
                DBHelper.ExecProc("CM", "sp_UpdateS_TMORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
                if (!string.IsNullOrEmpty(errorMessage))
                    ConcordLogger.Logger.Error(errorMessage);
            }
        }

        public static void ProcessDealMessage(string btype, FixMessageDictionary message)
        {
            string MSGTYPE = message[35];
            string TSENO = message[17];
            string SEQNO = message[41];
            string STATUS = message[150];
            string DSEQ = message[37];
            string BHNO = message[50];
            string CSEQ = message[1].PadLeft(7, '0');
            string MTYPE = message[56];
            string ECODE = message[57];
            string OTYPE = message[10001];
            string STOCK = message[55];
            string BS = message[54];
            string ORDTYPE = message[40];
            string TIF = message[59];
            int Unit = m_dicSTMB.ContainsKey(STOCK) ? m_dicSTMB[STOCK] : 1000;
            int DQTY = int.Parse(message[32]);
            if (ECODE != "2" && ECODE != "7" && btype != "E")
            {
                DQTY = DQTY * Unit;
            }
            decimal PRICE = decimal.Parse(message[31]);
            string TDATE = message[60].Substring(0, 8);
            string TTIME = message[60].Substring(9, 9);
            string ORIGN = message[10001];
            string DTRDAE = message[20003];
            string SIP = message[20004];
            string BROKER = message[20001];
            string KEYIN = message[50002];
            string errorMessage = "";

            string sqlCmd = string.Format(
                            "INSERT INTO S_TDDEAL("
                          + "[TDATE],[SEQNO],[DSEQ],[BHNO],[CSEQ],[BTYPE],[MTYPE],[OTYPE],[ECODE],[ORDTYPE],[TIF],[STOCK],[BS],[DQTY],[DPRICE],[BROKER],[ORIGN],[DTRADE],[SIP],[TSENO],[DTIME]) "
                          + "VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}',"
                          + "{13},{14},'{15}','{16}','{17}','{18}','{19}','{20}')",
                            TDATE, SEQNO, DSEQ, BHNO, CSEQ, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS,
                            DQTY, PRICE, BROKER, ORIGN, DTRDAE, SIP, TSENO, TTIME);
            DBHelper.InsertData("CM", sqlCmd, m_sqlConn, new SqlParameter[] { }, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            string[] ParamsName = { "TDATE", "SEQNO", "BHNO", "CSEQ", "ECODE", "OTYPE", "ORDTYPE", "TIF", "STOCK", "BS", "DSEQ", "DPRICE", "DQTY" };
            string[] ParamsValue = { TDATE, SEQNO, BHNO, CSEQ, ECODE, OTYPE, ORDTYPE, TIF, STOCK, BS, DSEQ, PRICE.ToString(), DQTY.ToString() };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("成回呼叫sp_UpdateS_KeyInTDDEAL");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_KeyInTDDEAL", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            ParamsName = new[] { "TDATE", "MSEQNO", "TTIME", "DSEQ", "BHNO", "CSEQ", "CDI", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "BQTY", "AQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ETYPE", "EMSG", "ClientIP", "KeyInNo" };
            ParamsValue = new[] { TDATE, SEQNO, TTIME, DSEQ, BHNO, CSEQ, "I", btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, "0", "0", "0", DQTY.ToString(), PRICE.ToString(), STATUS, BROKER, "", "", "", KEYIN };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("成回呼叫sp_UpdateS_KeyInTDORD");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_KeyInTDORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);

            ParamsName = new[] { "TDATE", "MSEQNO", "SEQNO", "DSEQ", "TTIME", "BHNO", "CSEQ", "BTYPE", "MTYPE", "OTYPE", "ECODE", "ORDTYPE", "TIF", "STOCK", "BS", "OQTY", "DQTY", "PRICE", "STATUS", "BROKER", "ORIGN", "ETYPE", "EMSG", "DTRADE", "SIP", "ClientIP", "ForceFlag", "CDI" };
            ParamsValue = new[] { TDATE, "", SEQNO, DSEQ, TTIME, BHNO, CSEQ, btype, MTYPE, OTYPE, ECODE, ORDTYPE, TIF, STOCK, BS, DQTY.ToString(), DQTY.ToString(), PRICE.ToString(), STATUS, BROKER, ORIGN, "", "", DTRDAE, SIP, "", "", "" };
            ConcordLogger.Logger.Info(string.Join(",", ParamsName));
            ConcordLogger.Logger.Info(string.Join(",", ParamsValue));
            ConcordLogger.Logger.Info("成回呼叫sp_UpdateS_TMORD");
            errorMessage = "";
            DBHelper.ExecProc("CM", "sp_UpdateS_TMORD", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
                ConcordLogger.Logger.Error(errorMessage);
        }
    }
}
