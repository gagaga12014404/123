﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public abstract class ServiceBase
    {
        /// <summary>
        /// 查詢函數
        /// </summary>
        /// <param name="reqList">輸入資料欄位</param>
        /// <param name="svcType">來源代碼</param>
        /// <param name="respList">輸出資料欄位</param>
        /// <param name="strCustomerMsg">自定義回傳訊息</param>
        /// <returns>查詢結果代碼</returns>
        public abstract string Query(
            IEnumerable<string> reqList,
            string svcType,
            ref List<string> respList,
            ref string strCustomerMsg);
    }
}