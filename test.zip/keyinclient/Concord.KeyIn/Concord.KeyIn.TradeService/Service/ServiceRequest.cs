﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public class ServiceRequest
    {
        public RequestDetails r { get; set; } = new RequestDetails();
    }

    public class RequestDetails
    {
        public string svcType { get; set; }
        public string svcToken { get; set; }
        public string reqdate { get; set; }
        public string reqtime { get; set; }
        public string tcode { get; set; }
        public RequestDataList datalist { get; set; } = new RequestDataList();
    }

    public class RequestDataList
    {
        public IEnumerable<string> l { get; set; }
    }
}