﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class S_QSLAB : ServiceBase
    {
        public override string Query(IEnumerable<string> reqList, string svcType, ref List<string> respList, ref string strCustomerMsg)
        {
            try
            {
                var data = reqList.Single().Split(',');
                if (data.Length != 1)
                {
                    strCustomerMsg = data.Length.ToString();
                    return "902";
                }
                return DAL.Query_S_QSLAB(data[0], ref respList, ref strCustomerMsg);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("Unexpected error", ex);
                return "999";
            }
        }
    }
}