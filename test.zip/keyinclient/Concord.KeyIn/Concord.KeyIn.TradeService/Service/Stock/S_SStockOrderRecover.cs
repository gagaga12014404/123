﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Messaging;
using System.Text;
using System.Web;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class S_SStockOrderRecover : ServiceBase
    {
        private static readonly string m_orderRecoverQueuePath = ConfigurationManager.AppSettings["OrderRecoverQueuePath"];
        private static readonly string m_orderRecoverQueueName = ConfigurationManager.AppSettings["OrderRecoverQueueName"];

        public override string Query(IEnumerable<string> reqList, string svcType, ref List<string> respList, ref string strCustomerMsg)
        {
            try
            {
                var data = reqList.Single().Split(',');
                var emno = data[0];
                var ls = new List<S_SStockOrderRecoverModel>();
                var ret = DAL.Query_S_SStockOrderRecover(data, ref ls);
                if (ret == "000")
                {
                    respList.Add(ls.Count(o => o.RegisterCode != "*").ToString());
                    var fullPath = m_orderRecoverQueuePath + m_orderRecoverQueueName;
                    //var mq = new MessageQueue(fullPath);
                    var mq = m_orderRecoverQueuePath.Split(';')
                        .Select(s => new MessageQueue(s + m_orderRecoverQueueName))
                        .ToList();
                    foreach (var o in ls)
                    {
                        var pushBody = string.Format(o.PushMsg, o.SerialNO);
                        var pushMessage = $"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(pushBody)}" + pushBody;
                        var msgType = o.RegisterCode == "*" ? "LastFill" : "OrderReceive";
                        var body = $"|35={msgType}"
                                 + $"|52={DateTime.Now:yyyyMMdd-HH:mm:ss.fff}"
                                 + $"|20100={emno}"
                                 + $"|20101=Y"
                                 + $"|20102={pushMessage.Replace('|', '^')}";
                        var mm = new Message($"8=Concords|9={Encoding.GetEncoding("Big5").GetByteCount(body):D5}" + body, new BinaryMessageFormatter());
                        mq.ForEach(q => q.Send(mm));
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("Unexpected error", ex);
                return "999";
            }
        }
    }
}