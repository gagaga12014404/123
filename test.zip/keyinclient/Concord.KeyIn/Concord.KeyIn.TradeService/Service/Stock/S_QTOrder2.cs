﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class S_QTOrder2 : ServiceBase
    {
        public override string Query(IEnumerable<string> reqList, string svcType, ref List<string> respList, ref string strCustomerMsg)
        {
            try
            {
                var data = reqList.Single().Split(',');
                if (data.Length != 4)
                {
                    strCustomerMsg = data.Length.ToString();
                    return "902";
                }
                var input = new S_QTOrderModel2
                {
                    BHNO = data[0],
                    CSEQ = data[1],
                    STNO = data[2],
                    OrderType = data[3]
                };
                return DAL.Query_S_QTOrder2(input, ref respList, ref strCustomerMsg);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("Unexpected error", ex);
                return "999";
            }
        }
    }
}