﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class S_QTOrderDetail : ServiceBase
    {
        public override string Query(IEnumerable<string> reqList, string svcType, ref List<string> respList, ref string strCustomerMsg)
        {
            try
            {
                var data = reqList.Single().Split(',');
                if (data.Length != 4)
                {
                    strCustomerMsg = data.Length.ToString();
                    return "902";
                }
                var input = new S_QTOrderDetailModel
                {
                    BHNO = data[0],
                    DSEQ = data[1],
                    SEQNO = data[2],
                    BTYPE = data[3]
                };
                return DAL.Query_S_QTOrderDetail(input, ref respList, ref strCustomerMsg);
            }
            catch (Exception ex)
            {
                respList.Clear();
                ConcordLogger.Logger.Error("Unexpected error", ex);
                return "999";
            }
        }
    }
}