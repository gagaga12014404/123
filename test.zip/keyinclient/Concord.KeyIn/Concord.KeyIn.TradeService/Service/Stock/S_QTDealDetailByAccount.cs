﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class S_QTDealDetailByAccount : ServiceBase
    {
        public override string Query(IEnumerable<string> reqList, string svcType, ref List<string> respList, ref string strCustomerMsg)
        {
            try
            {
                var data = reqList.Single().Split(',');
                if (data.Length != 3)
                {
                    strCustomerMsg = data.Length.ToString();
                    return "902";
                }
                var input = new S_QTDealDetailByAccountModel
                {
                    BHNO = data[0],
                    CSEQ = data[1],
                    BTYPE = data[2]
                };
                return DAL.Query_S_QTDealDetailByAccount(input, ref respList, ref strCustomerMsg);
            }
            catch (Exception ex)
            {
                respList.Clear();
                ConcordLogger.Logger.Error("Unexpected error", ex);
                return "999";
            }
        }
    }
}