﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public class ServiceResponse
    {
        public ResponseDetails r { get; set; } = new ResponseDetails();

        public override string ToString()
        {
            return ToString(true);
        }

        public string ToString(bool formatting)
        {
            XElement dlEle = new XElement("datalist");
            if (r.datalist.l != null && r.datalist.l.Count() > 0)
            {
                foreach (var s in r.datalist.l)
                {
                    var ns = new string(s.Where(c => XmlConvert.IsXmlChar(c)).ToArray());
                    dlEle.Add(new XElement("l", ns));
                }
            }
            var xmlEle =
                new XElement("r",
                    new XElement("svcType", r.svcType),
                    new XElement("svcToken", r.svcToken),
                    new XElement("reqdate"),
                    new XElement("reqtime"),
                    new XElement("sid"),
                    new XElement("tcode"),
                    new XElement("respcode", r.respcode),
                    new XElement("respmsg", r.respmsg),
                    new XElement("respdate", r.respdate),
                    new XElement("resptime", r.resptime),
                    dlEle);
            return xmlEle.ToString(formatting ? SaveOptions.None : SaveOptions.DisableFormatting);
        }
    }

    public class ResponseDetails
    {
        public string svcType { get; set; }
        public string svcToken { get; set; }
        public string respcode { get; set; }
        public string respmsg { get; set; }
        public string respdate { get; set; }
        public string resptime { get; set; }
        public ResponseDataList datalist { get; set; } = new ResponseDataList();
    }

    public class ResponseDataList
    {
        public IEnumerable<string> l { get; set; }
    }
}