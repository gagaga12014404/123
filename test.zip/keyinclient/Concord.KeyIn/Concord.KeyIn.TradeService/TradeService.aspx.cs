﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Concord.SDK.Logging;

namespace Concord.KeyIn.TradeService
{
    public partial class TradeService : System.Web.UI.Page
    {
        #region 共用參數
        private readonly ServiceRequest m_objReq = new ServiceRequest();
        private readonly ServiceResponse m_objResp = new ServiceResponse();
        private string m_strReqIP = "";
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            ConcordLogger.Logger.Info("TradeService Start");
            try
            {
                //取得遠端來源IP
                m_strReqIP = Request.UserHostAddress;
                //取得Request字串
                string strRequest = GetReqStr();
                if (!string.IsNullOrEmpty(strRequest))
                {
                    //解析Request字串
                    if (DeserializeStr(strRequest))
                    {
                        //檢查服務啟用狀態
                        if (DAL.GetTokenIsEnable(m_objReq.r.svcToken))
                        {
                            if (CompareCode()) //驗證認證碼
                            {
                                //以服務收到時間為準
                                m_objReq.r.reqtime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                                //設定查詢函數並查詢
                                m_objResp.r.datalist.l = SetFunction();
                                ConcordLogger.Logger.Info("SendRespStr");
                            }
                            else
                            {
                                //tcode驗證錯誤
                                SetRespMsg("919", "");
                            }
                        }
                        else
                        {
                            //此功能暫停服務
                            SetRespMsg("900", "");
                        }
                    }
                    else
                    {
                        //要求資訊錯誤
                        SetRespMsg("903", "");
                    }
                }
                else
                {
                    //要求資訊錯誤
                    SetRespMsg("903", "");
                }
                ConcordLogger.Logger.Info("Service End");
            }
            catch (Exception ex)
            {
                //非預期錯誤
                SetRespMsg("999", "");
                ConcordLogger.Alert("9999", "QueryService Error", ex.ToString());
                ConcordLogger.Logger.Error("QueryService Error", ex);
            }
            finally
            {
                SendRespStr();
                Response.End();
            }
        }

        #region 取得Request字串
        /// <summary>
        /// 取得Request字串
        /// </summary>
        private string GetReqStr()
        {
            try
            {
                string _TmpStr = "", _ReturnStr = "";
                char _EndPoint = '\0';
                int _BufferLength = 1024;
                char[] _Buffer = new char[_BufferLength];
                StreamReader _ResponseStream = new StreamReader(Request.InputStream, Encoding.UTF8);
                int _DataReadCount = _ResponseStream.Read(_Buffer, 0, _BufferLength);
                do
                {
                    _TmpStr = new string(_Buffer).TrimEnd(_EndPoint);
                    Array.Clear(_Buffer, 0, _Buffer.Length);
                    _ReturnStr += _TmpStr;
                    _DataReadCount = _ResponseStream.Read(_Buffer, 0, _BufferLength);
                } while (_DataReadCount > 0);
                ConcordLogger.Logger.Info("ReqString：" + _ReturnStr);
                return _ReturnStr;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("取得Request字串 Error", ex);
                return "";
            }
        }
        #endregion

        #region 解析Request字串
        /// <summary>
        /// 解析Request字串
        /// </summary>
        /// <param name="strReqStr"></param>
        private bool DeserializeStr(string strReqStr)
        {
            bool bValid = false;
            try
            {
                var doc = new XmlDocument();
                doc.LoadXml(strReqStr);
                var root = doc.DocumentElement;
                m_objReq.r.svcType = root.SelectSingleNode("/r/svcType").InnerText;
                m_objReq.r.svcToken = root.SelectSingleNode("/r/svcToken").InnerText;
                m_objReq.r.reqdate = root.SelectSingleNode("/r/reqdate").InnerText;
                m_objReq.r.reqtime = root.SelectSingleNode("/r/reqtime").InnerText;
                m_objReq.r.tcode = root.SelectSingleNode("/r/tcode").InnerText;
                m_objReq.r.datalist.l = root.SelectNodes("/r/datalist//l").Cast<XmlNode>().Select(node => node.InnerText);
                bValid = true;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("DeserializeStr Request字串 Error", ex);
            }
            return bValid;
        }
        #endregion

        #region 驗證認證碼
        /// <summary>
        /// 驗證認證碼
        /// </summary>
        /// <returns></returns>
        private bool CompareCode()
        {
            bool isValid = false;
            try
            {
                string _ReturnMD5 = "", _InputStr = m_objReq.r.svcType + m_objReq.r.svcToken + m_objReq.r.reqdate + m_objReq.r.reqtime + "CONCORDS";
                byte[] _Original = Encoding.UTF8.GetBytes(_InputStr);
                MD5CryptoServiceProvider MD5 = new MD5CryptoServiceProvider();
                byte[] _After = MD5.ComputeHash(_Original);
                MD5.Clear();

                foreach (byte item in _After)
                {
                    _ReturnMD5 += item.ToString("x").PadLeft(2, '0');
                }
                isValid = _ReturnMD5 == m_objReq.r.tcode;
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("CompareCode Error", ex);
            }
            return isValid;
        }
        #endregion

        #region 設定查詢資料Function
        /// <summary>
        /// 設定查詢資料Function
        /// </summary>
        /// <returns></returns>
        private IEnumerable<string> SetFunction()
        {
            var lsResult = new List<string>();
            var strMsgCode = "999"; //查詢結果訊息碼
            var strCustomerMsg = ""; //查詢結果自訂訊息
            try
            {
                ConcordLogger.Logger.Info("查詢" + m_objReq.r.svcToken + "開始");
                switch (m_objReq.r.svcToken)
                {
                    default:
                        Type t = typeof(ServiceBase);
                        Type qt = Type.GetType($"Concord.KeyIn.TradeService.{m_objReq.r.svcToken}, {t.Assembly.FullName}");
                        if (qt == null)
                        {
                            //尚未提供此服務
                            strMsgCode = "904";
                        }
                        else
                        {
                            ServiceBase svc = Activator.CreateInstance(qt) as ServiceBase;
                            strMsgCode = svc.Query(m_objReq.r.datalist.l, m_objReq.r.svcType, ref lsResult, ref strCustomerMsg);
                        }
                        break;
                }
                SetRespMsg(strMsgCode, strCustomerMsg);
                ConcordLogger.Logger.Info("查詢" + m_objReq.r.svcToken + "結束");
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("SetFunction Error", ex);
                ConcordLogger.Alert("9999", "SetFunction Error", ex.ToString());
            }
            return lsResult;
        }
        #endregion

        #region 設定Response訊息碼
        /// <summary>
        /// 設定Response訊息碼
        /// </summary>
        /// <param name="strMsgCode"></param>
        public void SetRespMsg(string strMsgCode, string strCustomerMsg)
        {
            try
            {
                if (strMsgCode == "901")
                {
                    m_objResp.r.respcode = strMsgCode;
                    m_objResp.r.respmsg = strCustomerMsg;
                }
                else if (strMsgCode == "902")
                {
                    m_objResp.r.respcode = strMsgCode;
                    m_objResp.r.respmsg = DAL.GetMsgDesc(strMsgCode) + ": " + strCustomerMsg;
                }
                else
                {
                    m_objResp.r.respcode = strMsgCode;
                    m_objResp.r.respmsg = DAL.GetMsgDesc(strMsgCode);
                }
                if (m_objResp.r.datalist.l == null)
                    m_objResp.r.datalist.l = new List<string>();
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("SetRespMsg Error", ex);
            }
        }
        #endregion

        #region 組合Response字串
        /// <summary>
        /// 組合Response字串
        /// </summary>
        /// <returns></returns>
        private string GenRespStr()
        {
            string strRtn = "";
            try
            {
                DateTime _SvcDateTime = DateTime.Now;
                m_objResp.r.svcType = m_objReq.r.svcType;
                m_objResp.r.svcToken = m_objReq.r.svcToken;
                m_objResp.r.respdate = _SvcDateTime.ToString("yyyyMMdd");
                m_objResp.r.resptime = _SvcDateTime.ToString("HHmmss");
                strRtn = m_objResp.ToString(false);

                //還需紀錄Service Log, 因此產生response後再將時間壓回
                m_objResp.r.resptime = _SvcDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
                m_objResp.r.datalist.l = new List<string> { m_objResp.r.datalist.l.Count().ToString() };
                ConcordLogger.Logger.Debug("RespString：" + m_objResp.ToString(false));
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GenRespStr Error", ex);
            }
            return strRtn;
        }
        #endregion

        #region 送出Response字串
        /// <summary>
        /// 送出Response字串
        /// </summary>
        private void SendRespStr()
        {
            try
            {
                string strResult = GenRespStr();
                Response.Clear();
                Response.Write(strResult);

                WriteServiceLog();
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("SendRespStr Error", ex);
            }
        }
        #endregion

        #region 寫入ServiceLog
        /// <summary>
        /// 寫入ServiceLog
        /// </summary>
        private void WriteServiceLog()
        {
            try
            {
                DAL.Insert_ServiceLog(m_objReq, m_objResp, m_strReqIP);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("Insert_ServiceLog Error", ex);
            }
        }
        #endregion
    }
}