﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using System.Xml;
using System.Text;

namespace Concord.KeyIn.TradeService
{
    public static class DAL
    {
        #region 變數設定
        private static readonly string m_userId = ConfigurationManager.AppSettings["DBUserID"];
        private static readonly string m_sqlConn = ConfigurationManager.ConnectionStrings["KeyIn"]?.ConnectionString ?? "";
        private static readonly Dictionary<string, string> m_dicMsgCode = new Dictionary<string, string>();
        private static readonly Dictionary<string, string> m_dicSvcList = new Dictionary<string, string>();
        #endregion

        #region 服務共用設定
        public static void Insert_ServiceLog(ServiceRequest objReq, ServiceResponse objResp, string strReqIP)
        {
            //計算查詢回覆時間差
            TimeSpan ts = DateTime.Parse(objResp.r.resptime) - DateTime.Parse(objReq.r.reqtime);
            string span = (ts.TotalMilliseconds / 1000).ToString("F3");

            string strSqlCmd = "INSERT INTO [KeyIn].[dbo].[SYS_ServiceLog] "
                             + "([SvcToken],[Source],[ReqIP],[ReqTime],[RespTime],[TimeSpan],[RespCode],[RespMsg]) "
                             + "VALUES (@SvcToken,@SvcType,@ReqIP,@ReqTime,@RespTime,@TimeSpan,@RespCode,@RespMsg)";
            SqlParameter[] arParam = new SqlParameter[]
            {
                new SqlParameter("@SvcToken", objReq.r.svcToken),
                new SqlParameter("@SvcType", objReq.r.svcType),
                new SqlParameter("@ReqIP", strReqIP),
                new SqlParameter("@ReqTime", objReq.r.reqtime),
                new SqlParameter("@RespTime", objResp.r.resptime),
                new SqlParameter("@TimeSpan", span),
                new SqlParameter("@RespCode", objResp.r.respcode),
                new SqlParameter("@RespMsg", objResp.r.respmsg)
            };
            string strErrMsg = "";
            DBHelper.InsertData(m_userId, strSqlCmd, m_sqlConn, arParam, ref strErrMsg);
            if (!string.IsNullOrEmpty(strErrMsg))
            {
                ConcordLogger.Logger.Error(objReq.r.svcToken + " ServiceLog Insert異常: " + strErrMsg);
                ConcordLogger.Alert("9999", objReq.r.svcToken + " ServiceLog Insert異常: " + strErrMsg);
            }
        }

        /// <summary>
        /// 取得訊息碼對應中文
        /// </summary>
        /// <param name="MsgCode">訊息碼</param>
        /// <returns>對應訊息中文</returns>
        public static string GetMsgDesc(string MsgCode)
        {
            string strResult = "非預期的錯誤代碼";
            try
            {
                if (HttpRuntime.Cache["MsgCode"] != null)
                {
                    if (m_dicMsgCode.ContainsKey(MsgCode))
                    {
                        strResult = m_dicMsgCode[MsgCode];
                    }
                    else
                    {
                        ConcordLogger.Logger.Warn(MsgCode + "不存在於Dictionary");
                        ConcordLogger.Alert("9999", "無法取得訊息碼對應中文", MsgCode + "不存在於Dictionary");
                    }
                }
                else
                {
                    if (GetMessageCodeFromDB())
                    {
                        HttpRuntime.Cache.Insert("MsgCode", m_dicMsgCode, null, System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration);
                        strResult = ((Dictionary<string, string>)HttpRuntime.Cache["MsgCode"])[MsgCode];
                    }
                    else
                    {
                        if (MsgCode == "000") strResult = "成功";
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GetMsgDesc Error: KEY = " + MsgCode + " - " + ex.ToString());
                ConcordLogger.Alert("9999", "GetMsgDesc Error", "KEY = " + MsgCode + " - " + ex.ToString());
            }
            return strResult;
        }

        /// <summary>
        /// 取得MessageCode清單
        /// </summary>
        /// <returns>成功/失敗</returns>
        private static bool GetMessageCodeFromDB()
        {
            bool blnResult = false;
            string strErrorMsg = "";
            string strCmd = "SELECT [CodeId], [CodeDescription] FROM [KeyIn].[dbo].[SYS_MessageCode]";
            DataTable dt = new DataTable();
            dt = DBHelper.QueryData(m_userId, strCmd, m_sqlConn, new SqlParameter[] { }, ref strErrorMsg);
            if (string.IsNullOrEmpty(strErrorMsg))
            {
                try
                {
                    lock (m_dicMsgCode)
                    {
                        foreach (DataRow dr in dt.AsEnumerable())
                        {
                            if (m_dicMsgCode.ContainsKey(dr[0].ToString()))
                                m_dicMsgCode[dr[0].ToString()] = dr[1].ToString();
                            else
                                m_dicMsgCode.Add(dr[0].ToString(), dr[1].ToString());
                        }
                    }
                    blnResult = true;
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("dicMsgCode.Add Error: " + ex.ToString());
                    ConcordLogger.Alert("9999", "dicMsgCode.Add Error", ex.ToString());
                }
            }
            else
            {
                ConcordLogger.Logger.Error("GetMessageCode Error: " + strErrorMsg);
                ConcordLogger.Alert("9999", "GetMessageCode Error", strErrorMsg);
            }
            return blnResult;
        }

        /// <summary>
        /// 取得服務啟用狀態
        /// </summary>
        /// <param name="Token"></param>
        /// <returns>啟用/未啟用</returns>
        public static bool GetTokenIsEnable(string Token)
        {
            bool blnResult = true;
            try
            {
                if (HttpRuntime.Cache["SvcList"] != null)
                {
                    if (m_dicSvcList.ContainsKey(Token))
                    {
                        blnResult = m_dicSvcList[Token] == "Y";
                    }
                    else
                    {
                        ConcordLogger.Logger.Warn(Token + "不存在於Dictionary");
                        ConcordLogger.Alert("9999", "無法取得服務啟用狀態", Token + "不存在於Dictionary");
                    }
                }
                else
                {
                    if (GetServiceListFromDB())
                    {
                        HttpRuntime.Cache.Insert("SvcList", m_dicSvcList, null, System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration);
                        blnResult = ((Dictionary<string, string>)HttpRuntime.Cache["SvcList"])[Token] == "Y";
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("GetTokenIsEnable Error: KEY = " + Token + " - " + ex.ToString());
                ConcordLogger.Alert("9999", "GetTokenIsEnable Error", "KEY = " + Token + " - " + ex.ToString());
            }
            return blnResult;
        }

        /// <summary>
        /// 取得ServiceList清單
        /// </summary>
        /// <returns>成功/失敗</returns>
        private static bool GetServiceListFromDB()
        {
            bool blnResult = false;
            string strErrorMsg = "";
            string strCmd = "SELECT [SvcToken], [SvcEnable] FROM [KeyIn].[dbo].[SYS_ServiceList]";
            DataTable dt = DBHelper.QueryData(m_userId, strCmd, m_sqlConn, new SqlParameter[] { }, ref strErrorMsg);
            if (string.IsNullOrEmpty(strErrorMsg))
            {
                try
                {
                    lock (m_dicSvcList)
                    {
                        foreach (DataRow dr in dt.AsEnumerable())
                        {
                            if (m_dicSvcList.ContainsKey(dr[0].ToString()))
                                m_dicSvcList[dr[0].ToString()] = dr[1].ToString();
                            else
                                m_dicSvcList.Add(dr[0].ToString(), dr[1].ToString());
                        }
                    }
                    blnResult = true;
                }
                catch (Exception ex)
                {
                    ConcordLogger.Logger.Error("dicSvcList.Add Error: " + ex.ToString());
                    ConcordLogger.Alert("9999", "dicSvcList.Add Error", ex.ToString());
                }
            }
            else
            {
                ConcordLogger.Logger.Error("GetServiceListFromDB Error: " + strErrorMsg);
                ConcordLogger.Alert("9999", "GetServiceListFromDB Error", strErrorMsg);
            }
            return blnResult;
        }
        #endregion

        #region 系統功能
        public static string Query_SYS_KeyInLogin(SYS_KeyInLoginModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * FROM [KeyIn].[dbo].[SYS_RSettingKeyIn] "
                           + "WHERE [EMNO]=@EMNO";
            var sqlParams = new[] { new SqlParameter("@EMNO", input.EMNO) };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_SYS_KeyInLogin DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_SYS_KeyInLogin DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_SYS_KeyInLogin 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    if (row.Field<string>("IP") == input.IP)
                    {
                        var arr = new[]
                        {
                            row.Field<string>("BHNO"),
                            true.ToString(),
                            row.Field<string>("Authority"),
                            row.Field<string>("TERM"),
                            row.Field<string>("IsBack"),
                            row.Field<string>("IsSplitLot"),
                            row.Field<string>("IsBatchOddLot")
                        };
                        result.Add(string.Join("|", arr));
                    }
                }
                if (result.Count <= 0)
                {
                    msgCode = "901";
                    customMessage = "登入 IP 錯誤";
                }
            }
            return msgCode;
        }

        public static string Query_SYS_CheckPWD(SYS_CheckPWDModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT [PWD] FROM [KeyIn].[dbo].[SYS_BHNOPWD] WHERE [BHNO] = @BHNO";
            var sqlParams = new[] { new SqlParameter("@BHNO", input.BHNO) };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_SYS_CheckPWD DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_SYS_CheckPWD DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_SYS_CheckPWD 查無資料");
            }
            else if (input.PWD != dt.Rows[0]["PWD"].ToString())
            {
                msgCode = "901";
                customMessage = "密碼錯誤";
            }
            return msgCode;
        }

        public static string Query_SYS_GetBHNOList(ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * FROM [KeyIn].[dbo].[StockBranch]";
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, new SqlParameter[] { }, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_SYS_GetBHNOList DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_SYS_GetBHNOList DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_SYS_GetBHNOList 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("BranchCode"),
                        row.Field<string>("BranchName")
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_SYS_QOrderSetting(ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * FROM [KeyIn].[dbo].[SYS_OrderSetting]";
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, new SqlParameter[] { }, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_SYS_QOrderSetting DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_SYS_QOrderSetting DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_SYS_QOrderSetting 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<int>("ECODE").ToString(),
                        row.Field<string>("STime").Trim(),
                        row.Field<string>("ETime").Trim(),
                        row.Field<bool>("IsTrade").ToString()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Update_SYS_SCheckOrder(SYS_SCheckOrderModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "";
            if (input.Status == "*")
            {
                //部分成交
                sqlCommand = "UPDATE [KeyIn].[dbo].[S_KeyInTDDEAL] SET [CheckStatus] = '*' WHERE [No] = @NO";
                DBHelper.UpdateData(m_userId, sqlCommand, m_sqlConn, new[] { new SqlParameter("@NO", input.No) }, ref errorMessage);
            }
            else if (input.Status == "**")
            {
                //完全成交
                sqlCommand = "UPDATE [KeyIn].[dbo].[S_KeyInTDDEAL] SET [CheckStatus] = '**' "
                           + "WHERE [TDATE] = @TDATE AND [BHNO] = @BHNO AND [DSEQ] = @DSEQ";
                DBHelper.UpdateData(m_userId, sqlCommand, m_sqlConn, new[] { new SqlParameter("@TDATE", DateTime.Today.ToString("yyyyMMdd")), new SqlParameter("@BHNO", input.BHNO), new SqlParameter("@DSEQ", input.DSEQ) }, ref errorMessage);
            }
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Update_SYS_SCheckOrder DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Update_SYS_SCheckOrder DB 錯誤", errorMessage);
            }
            return msgCode;
        }
        #endregion

        #region 證券基本資料
        public static string Query_S_QSTMB(ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT [STOCK],[CNAME],[MTYPE],[STYPE],"
                           + "[CPRICE],[TPRICE],[BPRICE],[UNIT],"
                           + "[DTCODE],[CRMARK],[DBMARK],[TMMARK],"
                           + "[CreditTradeState],[FTState],[StockTradeState],[FT98State] "
                           + "FROM [KeyIn].[dbo].[S_Basic_STMB] "
                           + "WHERE [TSDate]=@TDATE";
            var sqlParams = new[] { new SqlParameter("@TDATE", DateTime.Today.ToString("yyyyMMdd")) };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QSTMB DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QSTMB DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QSTMB 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("CNAME").Trim(),
                        row.Field<string>("MTYPE").Trim(),
                        row.Field<string>("STYPE").Trim(),
                        row.Field<decimal>("CPRICE").ToString("0.00##"),
                        row.Field<decimal>("TPRICE").ToString("0.00##"),
                        row.Field<decimal>("BPRICE").ToString("0.00##"),
                        row.Field<decimal>("UNIT").ToString(),
                        row.Field<string>("DTCODE"),
                        row.Field<string>("CRMARK"),
                        row.Field<string>("DBMARK"),
                        row.Field<string>("TMMARK"),
                        row.Field<string>("CreditTradeState")?.Trim() ?? "",
                        row.Field<string>("FTState")?.Trim() ?? "",
                        row.Field<string>("StockTradeState")?.Trim() ?? "",
                        row.Field<string>("FT98State")?.Trim() ?? ""
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QCUMB(string bhno, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * FROM [KeyIn].[dbo].[S_Basic_CUMB] WHERE [BHNO]=@BHNO";
            var sqlParams = new[] { new SqlParameter("@BHNO", $"845{bhno}") };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QCUMB DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QCUMB DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QCUMB 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        row.Field<string>("IDNO").Trim(),
                        row.Field<string>("IB")?.Trim() ?? "",
                        row.Field<string>("SNAME").Trim(),
                        row.Field<string>("TSALE").Trim(),
                        row.Field<string>("CCODE")?.Trim() ?? "",
                        row.Field<string>("CreditAccountState").Trim(),
                        row.Field<string>("DTAccountState").Trim()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QSLAB(string bhno, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT [BHNO],[SALE],[NAME],[LCN] "
                           + "FROM [KeyIn].[dbo].[S_Basic_SLAB] "
                           + "WHERE [BHNO]=@BHNO";
            var sqlParams = new[] { new SqlParameter("@BHNO", $"845{bhno}") };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QSLAB DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QSLAB DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QSLAB 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("SALE").Trim(),
                        row.Field<string>("NAME").Trim(),
                        row.Field<string>("LCN").Trim()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }
        #endregion

        #region 證券下單
        public static string Query_S_QErrorAccountDSEQ(ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";

            var TERM = "Q"; //錯帳固定使用 Q 櫃
            var ParamsName = new[] { "TERM" };
            var ParamsValue = new[] { TERM };
            var dt = DBHelper.ExecProcData(m_userId, "sp_UpdateErrAccountOrder", m_sqlConn, ParamsName, ParamsValue, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QErrorAccountDSEQ DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QErrorAccountDSEQ DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QErrorAccountDSEQ 查無資料");
            }
            else
            {
                msgCode = "000";
                var DSEQ = Convert.ToInt32(dt.Rows[0][0]);
                result.Add($"{TERM}{DSEQ:0000}");
            }
            return msgCode;
        }
        #endregion

        #region 證券(含興櫃)委成回
        public static string Query_S_QTOrder(S_QTOrderModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * "
                           + "FROM [KeyIn].[dbo].[S_TMORD] "
                           + "WHERE BHNO=@BHNO AND CSEQ=@CSEQ";
            var sqlParams = new[]
            {
                new SqlParameter("@BHNO", input.BHNO),
                new SqlParameter("@CSEQ", input.CSEQ),
            };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QTOrder DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QTOrder DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QTOrder 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("TDATE").Trim(),
                        row.Field<string>("SEQNO").Trim(),
                        row.Field<string>("OTIME").Trim(),
                        row.Field<string>("DSEQ").Trim(),
                        row.Field<string>("RTIME").Trim(),
                        row.Field<string>("KTIME").Trim(),
                        row.Field<string>("CTIME").Trim(),
                        row.Field<string>("DTIME").Trim(),
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        row.Field<string>("BTYPE").Trim(),
                        row.Field<string>("MTYPE").Trim(),
                        row.Field<string>("OTYPE").Trim(),
                        row.Field<string>("ECODE").Trim(),
                        row.Field<string>("ORDTYPE").Trim(),
                        row.Field<string>("TIF").Trim(),
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("BS").Trim(),
                        row.Field<decimal>("OQTY").ToString(),
                        row.Field<decimal>("SQTY").ToString(),
                        row.Field<decimal>("CQTY").ToString(),
                        row.Field<decimal>("DQTY").ToString(),
                        row.Field<decimal>("OPRICE").ToString("0.00##"),
                        row.Field<decimal>("DPRICE").ToString("0.00##"),
                        row.Field<string>("STATUS").Trim(),
                        row.Field<string>("BROKER").Trim(),
                        row.Field<string>("ORIGN").Trim(),
                        row.Field<string>("DTRADE").Trim(),
                        row.Field<string>("ETYPE").Trim(),
                        row.Field<string>("EMSG").Trim(),
                        row.Field<DateTime>("CreateDate").ToString("yyyyMMdd-HHmmssfff"),
                        row.Field<string>("SIP").Trim()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QTOrder2(S_QTOrderModel2 input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            string strResult = "";
            try
            {
                string tUrl = ConfigurationManager.AppSettings["TCURL"];
                string tType = "KeyIn";
                string tToken = "S_QTOrder2";
                string[] tParam = { input.BHNO, input.CSEQ, input.STNO, input.OrderType };
                //1.服務URL,2.AE,3.服務名稱,4.查詢條件
                string strData = BillCenterHelper.GetBillData(tUrl, tType, tToken, tParam);

                ConcordLogger.Logger.Debug("測試" + strData);
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strData);
                XmlNodeList xmlList = xmlDoc.SelectNodes("/r/datalist/l");
                StringBuilder sb = new StringBuilder();

                foreach (XmlNode nd in xmlList)
                {
                    sb.Append(nd.InnerText + "~");
                    strResult = sb.ToString();
                }
                strResult = sb.ToString().TrimEnd('~');

                result.Add(strResult);
            }
            catch (Exception ex)
            {
                ConcordLogger.Logger.Error("S_QTOrder2 Error!! 錯誤原因:" + ex.ToString());
                msgCode = "201";
            }        
            return msgCode;
        }



        public static string Query_S_QTOrderDetail(S_QTOrderDetailModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * "
                           + "FROM [KeyIn].[dbo].[S_TDORD] "
                           + "WHERE [BHNO]=@BHNO AND [DSEQ]=@DSEQ "
                           + "AND [SEQNO]=@SEQNO AND [BTYPE]=@BTYPE";
            var sqlParams = new[]
            {
                new SqlParameter("@BHNO", input.BHNO),
                new SqlParameter("@DSEQ", input.DSEQ),
                new SqlParameter("@SEQNO", input.SEQNO),
                new SqlParameter("@BTYPE", input.BTYPE)
            };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QTOrderDetail DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QTOrderDetail DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QTOrderDetail 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("TDATE").Trim(),
                        row.Field<string>("MSEQNO").Trim(),
                        row.Field<string>("SEQNO").Trim(),
                        row.Field<string>("OTIME").Trim(),
                        row.Field<string>("DSEQ").Trim(),
                        row.Field<string>("RTIME").Trim(),
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        row.Field<string>("CDI").Trim(),
                        row.Field<string>("BTYPE").Trim(),
                        row.Field<string>("MTYPE").Trim(),
                        row.Field<string>("OTYPE").Trim(),
                        row.Field<string>("ECODE").Trim(),
                        row.Field<string>("ORDTYPE").Trim(),
                        row.Field<string>("TIF").Trim(),
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("BS").Trim(),
                        row.Field<decimal>("OQTY").ToString(),
                        row.Field<decimal>("PRICE").ToString("0.00##"),
                        row.Field<string>("STATUS").Trim(),
                        row.Field<string>("BROKER").Trim(),
                        row.Field<string>("ORIGN").Trim(),
                        row.Field<string>("DTRADE").Trim(),
                        row.Field<string>("ETYPE").Trim(),
                        row.Field<string>("EMSG").Trim(),
                        row.Field<DateTime>("CreateDate").ToString("yyyyMMdd-HHmmssfff"),
                        row.Field<string>("SIP").Trim()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QTDealDetailByAccount(S_QTDealDetailByAccountModel input, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * "
                           + "FROM [KeyIn].[dbo].[S_TDORD] "
                           + "WHERE [BHNO]=@BHNO AND [CSEQ]=@CSEQ AND [BTYPE]=@BTYPE";
            var sqlParams = new[]
            {
                new SqlParameter("@BHNO", input.BHNO),
                new SqlParameter("@CSEQ", input.CSEQ),
                new SqlParameter("@BTYPE", input.BTYPE)
            };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QTOrderDetail DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QTOrderDetail DB 錯誤", errorMessage);
            }
            else if (dt.Rows.Count <= 0)
            {
                msgCode = "925";
                ConcordLogger.Logger.Warn("Query_S_QTOrderDetail 查無資料");
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<string>("TDATE").Trim(),
                        row.Field<string>("SEQNO").Trim(),
                        row.Field<string>("DSEQ").Trim(),
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        row.Field<string>("BTYPE").Trim(),
                        row.Field<string>("MTYPE").Trim(),
                        row.Field<string>("OTYPE").Trim(),
                        row.Field<string>("ECODE").Trim(),
                        row.Field<string>("ORDTYPE").Trim(),
                        row.Field<string>("TIF").Trim(),
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("BS").Trim(),
                        row.Field<decimal>("DQTY").ToString(),
                        row.Field<decimal>("DPRICE").ToString("0.00##"),
                        row.Field<string>("BROKER").Trim(),
                        row.Field<string>("ORIGN").Trim(),
                        row.Field<string>("DTRADE").Trim(),
                        row.Field<string>("TSENO").Trim(),
                        row.Field<string>("DTIME").Trim(),
                        row.Field<DateTime>("CreateDate").ToString("yyyyMMdd-HHmmssfff"),
                        row.Field<string>("SIP").Trim()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QKeyInTOrderDetail(string ip, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT * FROM [KeyIn].[dbo].[S_KeyInTDORD] WHERE [ClientIP]=@IP";
            var sqlParams = new[] { new SqlParameter("@IP", ip) };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QKeyInTOrderDetail DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QKeyInTOrderDetail DB 錯誤", errorMessage);
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    //改量才會送改前數量
                    var CDI = row.Field<string>("CDI").Trim();
                    var BQTY = (CDI == "C" || CDI == "P") ? row.Field<decimal>("BQTY").ToString() : "0";
                    var arr = new[]
                    {
                        row.Field<string>("MSEQNO").Trim(),
                        row.Field<string>("RTIME").Trim(),
                        row.Field<string>("DSEQ").Trim(),
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        CDI,
                        row.Field<string>("BTYPE").Trim(),
                        row.Field<string>("MTYPE").Trim(),
                        row.Field<string>("OTYPE").Trim(),
                        row.Field<string>("ECODE").Trim(),
                        row.Field<string>("ORDTYPE").Trim(),
                        row.Field<string>("TIF").Trim(),
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("BS").Trim(),
                        BQTY,
                        row.Field<decimal>("OQTY").ToString(),
                        row.Field<decimal>("DQTY").ToString(),
                        row.Field<decimal>("PRICE").ToString("0.00##"),
                        row.Field<string>("STATUS").Trim(),
                        row.Field<string>("BROKER").Trim(),
                        row.Field<string>("ETYPE").Trim(),
                        row.Field<string>("EMSG").Trim(),
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_QKeyInTDDEAL(string ip, ref List<string> result, ref string customMessage)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlCommand = "SELECT D.No, D.BHNO, D.CSEQ, D.ECODE, D.OTYPE, D.STOCK, D.BS, D.DSEQ,"
                           + "D.CheckStatus, D.DPRICE, D.DQTY, D.AllDQTY, "
                           + "M.ORDTYPE, M.TIF, M.OPRICE, M.OQTY, S.CNAME, M.ClientIP "
                           + "FROM [KeyIn].[dbo].[S_KeyInTDDEAL] D "
                           + "JOIN [KeyIn].[dbo].[S_TMORD] M ON (CASE "
                           + "WHEN D.SEQNO != '000000' AND D.SEQNO = M.SEQNO THEN 1 "
                           + "WHEN D.SEQNO = '000000' AND D.BHNO = M.BHNO AND D.DSEQ = M.DSEQ THEN 1 "
                           + "ELSE 0 END) = 1 AND M.[STATUS] != '8' "
                           + "JOIN [KeyIn].[dbo].[S_Basic_STMB] S ON D.STOCK = S.STOCK "
                           + "WHERE [ClientIP] = @IP";
            var sqlParams = new[] { new SqlParameter("@IP", ip) };
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_QKeyInTDDEAL DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_QKeyInTDDEAL DB 錯誤", errorMessage);
            }
            else
            {
                msgCode = "000";
                foreach (var row in dt.AsEnumerable())
                {
                    var arr = new[]
                    {
                        row.Field<int>("No").ToString(),
                        row.Field<string>("BHNO").Trim(),
                        row.Field<string>("CSEQ").Trim(),
                        row.Field<string>("ECODE").Trim(),
                        row.Field<decimal>("OPRICE").ToString("0.00##"),
                        row.Field<decimal>("OQTY").ToString(),
                        row.Field<string>("OTYPE").Trim(),
                        row.Field<string>("ORDTYPE").Trim(),
                        row.Field<string>("TIF").Trim(),
                        row.Field<string>("STOCK").Trim(),
                        row.Field<string>("CNAME").Trim(),
                        row.Field<string>("BS").Trim(),
                        row.Field<string>("DSEQ").Trim(),
                        row.Field<string>("CheckStatus").Trim(),
                        row.Field<decimal>("DPRICE").ToString("0.00##"),
                        row.Field<decimal>("DQTY").ToString(),
                        row.Field<decimal>("AllDQTY").ToString()
                    };
                    result.Add(string.Join("|", arr));
                }
            }
            return msgCode;
        }

        public static string Query_S_SStockOrderRecover(IEnumerable<string> regcodes, ref List<S_SStockOrderRecoverModel> result)
        {
            var msgCode = "000";
            var errorMessage = "";
            var sqlParams = regcodes.Select((code, i) => new SqlParameter($"@RegCode{i}", code)).ToArray();
            var sqlCommand = "SELECT [TDATE],[SerialNO],[RegisterCode],[PushMsg] "
                           + "FROM [KeyIn].[dbo].[S_OrderReceive] "
                           + "WHERE [RegisterCode] IN (" + string.Join(",", sqlParams.Select(p => p.ParameterName)) + ") "
                           + "ORDER BY [SerialNO]";
            var dt = DBHelper.QueryData(m_userId, sqlCommand, m_sqlConn, sqlParams, ref errorMessage);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                msgCode = "201";
                ConcordLogger.Logger.Error($"Query_S_SStockOrderRecover DB 錯誤 {errorMessage}");
                ConcordLogger.Alert("9999", "Query_S_SStockOrderRecover DB 錯誤", errorMessage);
            }
            else
            {
                msgCode = "000";
                result.AddRange(dt.AsEnumerable()
                    .Select(row => new S_SStockOrderRecoverModel
                    {
                        TDATE = row.Field<string>("TDATE"),
                        SerialNO = row.Field<int>("SerialNO"),
                        RegisterCode = row.Field<string>("RegisterCode"),
                        PushMsg = row.Field<string>("PushMsg")
                    }));
            }
            return msgCode;
        }
        #endregion
    }
}