﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public class S_QTOrderDetailModel
    {
        public string BHNO { get; set; }
        public string DSEQ { get; set; }
        public string SEQNO { get; set; }
        public string BTYPE { get; set; }
    }
}