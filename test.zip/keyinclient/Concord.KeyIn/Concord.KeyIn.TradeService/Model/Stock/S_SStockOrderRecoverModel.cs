﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public class S_SStockOrderRecoverModel
    {
        public string TDATE { get; set; }
        public int SerialNO { get; set; }
        public string RegisterCode { get; set; }
        public string PushMsg { get; set; }
    }
}