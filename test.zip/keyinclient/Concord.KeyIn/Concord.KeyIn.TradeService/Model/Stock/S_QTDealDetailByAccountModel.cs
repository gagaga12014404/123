﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public class S_QTDealDetailByAccountModel
    {
        public string BHNO { get; set; }
        public string CSEQ { get; set; }
        public string BTYPE { get; set; }
    }
}