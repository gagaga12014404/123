﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Concord.KeyIn.TradeService
{
    public class SYS_SCheckOrderModel
    {
        public string No { get; set; }
        public string BHNO { get; set; }
        public string DSEQ { get; set; }
        public string Status { get; set; }
    }
}