﻿using Concord.KeyIn.Client.Properties;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Xml.Linq;

namespace Concord.KeyIn.Client
{
    public class HttpReqHandler
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        private static string _KeyInSvrUrl = "";
        private static string _BOSSvrUrl = "";

        /// <summary>
        /// 設定HTTP Server 連線主機環境
        /// </summary>
        /// <param name="model"></param>
        public static void SetKeyInSvrUrl(int envirm)
        {
            switch (envirm)
            {
                case 1:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl;
                    break;
                case 2:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl_Test;
                    break;
                case 3:
                    _KeyInSvrUrl = Settings.Default.HttpKeyInSvrUrl_Remote;
                    break;
                case 4:
                    _KeyInSvrUrl = Settings.Default.COLO_tradeservice;
                    break;
            }
            Logger.Info($"[Login] 連線Gateway資訊: {_KeyInSvrUrl}");
        }
        public static void SetBOSSvrUrl(int envirm, int model)
        {
            switch (envirm)
            {
                case 1:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl : Settings.Default.HttpPropBOSSvrUrl;
                    break;
                case 2:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl_Test : Settings.Default.HttpPropBOSSvrUrl_Test;
                    break;
                case 3:
                    _BOSSvrUrl = model == 1 ? Settings.Default.HttpBOSSvrUrl_Remote : Settings.Default.HttpPropBOSSvrUrl_Remote;
                    break;
                case 4:
                    _BOSSvrUrl = Settings.Default.COLO_infoserver;
                    break;
            }
            Logger.Info($"[Login] 連線後台資訊: {_BOSSvrUrl}");
        }
        /// <summary>
        /// KeyIn Gateway HTTP 服務查詢
        /// </summary>
        /// <param name="token"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static HttpResponse Get_HttpKeyInService(string token, string[] parameters)
        {
            Logger.Info($"[HttpReq-KeyIn] {token} 開始");
            Logger.Info($"[HttpReq-KeyIn] {token} 參數: {string.Join(",", parameters)}");

            string content = "", svr_rCode = "-1";
            HttpResponse result = new HttpResponse();
            try
            {
                var response = BillCenterHelper.GetBillData(_KeyInSvrUrl, "KeyIn", token, parameters);
                Logger.Info($"[HttpReq-KeyIn] {token} 取得 result");
                var doc = XDocument.Parse(response);
                svr_rCode = doc.Descendants().FirstOrDefault(node => node.Name.ToString() == "respcode").Value;
                if (svr_rCode.Equals("000"))
                {
                    foreach (var xn in doc.Descendants("l"))
                    {
                        result.Deatils.Add(xn.Value);
                    }
                    Logger.Info($"[HttpReq-KeyIn] {token} 完成, 取得資料筆數: {result.Deatils.Count}");
                }
                else
                {
                    content = doc.Descendants().FirstOrDefault(node => node.Name.ToString() == "respmsg").Value;
                    Logger.Error($"[HttpReq-KeyIn] {token} 錯誤[{svr_rCode}]: {content}");
                    ConcordLogger.Alert(svr_rCode, $"[HttpReq-KeyIn] {token} 錯誤[{svr_rCode}]", content);
                }
            }
            catch (Exception ex)
            {
                svr_rCode = "999";
                content = ex.ToString();
                Logger.Error($"Get_HttpKeyInService Err: {ex}");
                ConcordLogger.Alert(svr_rCode, "Get_HttpKeyInService Err", content);
            }
            finally
            {
                result.StatusCode = (rCode)Enum.Parse(typeof(rCode), svr_rCode);
                result.CodeDesc = $"{result.StatusCode.ToString()} : {content}";
            }
            return result;
        }
        public static List<CRDB> Get_CRDBQty_Service(HttpReqData parameters)
        {
            Logger.Info($"[HttpReq-BOS] getcrdbQty 開始");
            CRDBQtyResult jsonResult = new CRDBQtyResult();
            try
            {
                string reqData = JsonConvert.SerializeObject(parameters);
                Logger.Info($"[HttpReq-BOS] getcrdbQty 參數: {reqData}");
                HttpClient client = new HttpClient();
                HttpContent post = new StringContent(($"[{reqData}]"), Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync($"{_BOSSvrUrl}POST/getcrdbQty", post).Result;
                var tmp = response.Content.ReadAsStringAsync().Result;
                tmp = tmp.TrimStart('[');
                tmp = tmp.TrimEnd('\n');
                tmp = tmp.TrimEnd(']');
                jsonResult = JsonConvert.DeserializeObject<CRDBQtyResult>(tmp);
                Logger.Info($"[HttpReq-BOS] getcrdbQty 完成, 資料數[{jsonResult.resault.Count}]: {tmp}");
            }
            catch (Exception ex)
            {
                Logger.Error($"[HttpReq-BOS] getcrdbQty 錯誤");
                ConcordLogger.Alert(jsonResult.resault[0].RespCode, "Get_HttpBOSService Err", ex.ToString());
            }

            return jsonResult.resault;
        }

    }
}
