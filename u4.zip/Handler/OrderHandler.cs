﻿using Concord.SDK.Logging;
using log4net.Repository.Hierarchy;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class OrderHandler
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        static readonly char delimiter = '\u0001';
        /// <summary>
        /// 委託書流水序號
        /// </summary>
        private int _DSEQ;
        /// <summary>
        /// 標借標購拍賣流水序號
        /// </summary>
        private int _FuncDSEQ;
        /// <summary>
        /// 開收盤時間 (盤別, 開收盤時間)
        /// </summary>
        private Dictionary<int, List<int>> _TRADE_TIME;
        public readonly static object _dseqLock = new object();

        public OrderHandler()
        {
            _TRADE_TIME = new Dictionary<int, List<int>>();
            _TRADE_TIME[-1] = new List<int> { 830, 1600 };
            _TRADE_TIME[0] = new List<int> { 828, 1330 };
            _TRADE_TIME[2] = new List<int> { 1340, 1430 };
            _TRADE_TIME[3] = new List<int> { 1400, 1430 };
            _TRADE_TIME[4] = new List<int> { 900, 1210 };
            _TRADE_TIME[5] = new List<int> { 1500, 1600 };
            _TRADE_TIME[6] = new List<int> { 1500, 1600 };
            _TRADE_TIME[7] = new List<int> { 900, 1330 };
            _TRADE_TIME[8] = new List<int> { 1430, 1500 };
            _DSEQ = 1;
            _FuncDSEQ = 1;
        }

        /// <summary>
        /// 委託序號
        /// </summary>
        public int DSEQ
        {
            get
            {
                return _DSEQ;
            }
            set
            {
                if (value != _DSEQ)
                    _DSEQ = value;
            }
        }
        /// <summary>
        /// 標借標購拍賣流水序號
        /// </summary>
        public int FuncDSEQ
        {
            get
            {
                return _FuncDSEQ;
            }
            set
            {
                if (value != FuncDSEQ)
                    _FuncDSEQ = value;
            }
        }

        /// <summary>
        /// 取得委託書號
        /// </summary>
        /// <param name="term"></param>
        /// <param name="dseq"></param>
        /// <returns></returns>
        public string GetNowDSEQ(string term, string dseq)
        {
            lock (_dseqLock)//lock可能會比較安全
                return UserInfo._TRAM + _DSEQ.ToString().PadLeft(4, '0');
        }

        public string GetNowDSEQ()
        {
            lock (_dseqLock)//lock可能會比較安全
                return UserInfo._TRAM + _DSEQ++.ToString().PadLeft(4, '0');
        }
        public void GetNowDSEQ(string dseq)
        {
            try
            {
                if (dseq.Substring(0, 1) != UserInfo._TRAM) return;//防呆
                lock (_dseqLock)//lock可能會比較安全
                {
                    int tmpdseq = int.Parse(dseq.Substring(1));
                    if (tmpdseq > _DSEQ)
                        _DSEQ = tmpdseq;
                    else if (tmpdseq == _DSEQ)
                        _DSEQ++;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[GetNowDSEQ] {ex}");
            }
        }
        public void FuncDSEQAdd1(string dseq)
        {
            try
            {
                if (dseq.Substring(0, 1) != "Z") return;//防呆
                int tmpdseq = int.Parse(dseq.Substring(1));
                if (tmpdseq > _FuncDSEQ)
                    _FuncDSEQ = tmpdseq;
                else if (tmpdseq == _FuncDSEQ)
                    _FuncDSEQ++;
            }
            catch (Exception ex)
            {
                Logger.Error($"[GetNowDSEQ] {ex}");
            }
        }

        /// <summary>
        /// 取得標借標購拍賣委託書號
        /// </summary>
        /// <param name="term"></param>
        /// <param name="dseq"></param>
        /// <returns></returns>
        public string GetNowFuncDSEQ(string term, string dseq)
        {
            string Dseq = term + dseq.PadLeft(4, '0');
            _FuncDSEQ = int.Parse(dseq) + 1;
            return Dseq;
        }
        // /// <summary>
        // /// 取得錯帳專戶委託書號
        // /// </summary>
        // /// <returns></returns>
        // public string GetErrAccountOrderDSEQ()
        // {
        //     string dseq = "";

        //     string[] parameters = { UserInfo._UserIP };
        //     HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QErrorAccountDSEQ", parameters);
        //     if (result.StatusCode == rCode.Success)
        //     {
        //         dseq = result.Deatils[0];
        //     }
        //     else
        //     {
        //         MessageBox.Show("取得委託序號失敗，請立即聯繫資訊部", "錯帳功能錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //         Logger.Error($"[Order] 錯帳取S_QErrorAccountDSEQ服務 失敗: [{result.StatusCode}]{result.CodeDesc}");
        //         ConcordLogger.Alert(result.StatusCode.ToString(), "錯帳取S_QErrorAccountDSEQ服務 失敗", result.CodeDesc);
        //     }
        //     return dseq;
        // }

        /// <summary>
        /// 建立新單
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public static string NewOrder(Order order)
        {
            string side = order.Side == Side.BUY ? "B" : "S";
            string 是否使用檔數 = "N";
            if (order.PriceRange_setting != "")
                是否使用檔數 = "Y";
            string body = $"35=999{delimiter}50008=1" +
                           $"{delimiter}1={order.CSEQ.Trim()}" +
                           $"{delimiter}37={order.DSEQ.Trim()}" +
                           $"{delimiter}38={order.OrdQty}" +
                           $"{delimiter}40={order.OrdType.Trim()}" +
                           $"{delimiter}44={order.OrdPrice.Trim()}" +
                           $"{delimiter}50=845{order.BHNO.Trim()}" +
                           //    $"|52={DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff")}" +
                           $"{delimiter}54={side.Trim()}" +
                           $"{delimiter}55={order.Symbol.Trim()}" +
                           $"{delimiter}56={order.MType.Trim()}" +
                           $"{delimiter}59={order.TimeInForce.Trim()}" +
                           $"{delimiter}60={DateTime.Now.ToString("yyyyMMddHHmmssfff")}" +
                           //"|11=" +
                           //    $"{delimiter}57={order.ECode.Trim()}" +
                           $"{delimiter}10000=1" +//委託來源，舊的填空白，新的填1
                           $"{delimiter}10001={order.OType.Trim()}" +
                           //    $"{delimiter}20002=0" +
                           $"{delimiter}50001={order.Sale}" +
                           $"{delimiter}20000={UserInfo._UserIP}" +
                           //    $"{delimiter}20103={order.Guid}" +
                           $"{delimiter}9487={是否使用檔數}" +
                           $"{delimiter}9488={order.PriceRange_setting}" +
                           $"{delimiter}50002={order.KeyIn}" +
                           $"{delimiter}50003= " +//ocode,keyin空白
                           $"{delimiter}50004={order.DayTradeFlag}" +
                           $"{delimiter}50005=N" +//????????????????????????????????????
                           $"{delimiter}50009={order.ECode.Trim()}" +
                           $"{delimiter}100={order.f100}" +
                           $"{delimiter}107031={OrderStore.GF}" +
                           $"{delimiter}1080={order.G_stk_seq_no}";
            Logger.Debug($"[Order] 新單組成:{body}");
            return body + $"{delimiter}\n";
        }
        /// <summary>
        /// 建立改量單
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public static string ChangeQtyOrder(Order order)
        {
            string BS = order.Side == Side.BUY ? "B" : "S";
            string body = $"35=999{delimiter}50008=2" +
                         //  $"|52={DateTime.Now.ToString("yyyyMMddHHmmssfff")}" +
                         $"{delimiter}60={DateTime.Now.ToString("yyyyMMddHHmmssfff")}" +
                         //$"|11=" +
                         $"{delimiter}41={order.OrigClOrdID}" +
                         $"{delimiter}37={order.DSEQ}" +
                         $"{delimiter}50={order.BHNO}" +
                         $"{delimiter}1={order.CSEQ}" +
                         $"{delimiter}56={order.MType}" +
                         //  $"{delimiter}57={order.ECode}" +
                         $"{delimiter}10001={order.OType}" +
                         $"{delimiter}55={order.Symbol}" +
                         $"{delimiter}54={BS}" +
                         $"{delimiter}40={order.OrdType}" +
                         $"{delimiter}59={order.TimeInForce}" +
                         $"{delimiter}38={order.OrdQty}" +
                         $"{delimiter}44={order.OrdPrice.Trim()}" +
                         $"{delimiter}10000=1" +
                         $"{delimiter}50001={order.Sale}" +
                         $"{delimiter}50003= " +//ocode,keyin空白
                         $"{delimiter}20000={UserInfo._UserIP}" +
                         $"{delimiter}50004={order.DayTradeFlag}" +
                         $"{delimiter}50009={order.ECode}" +
                         $"{delimiter}107031={OrderStore.GF}" +
                         $"{delimiter}50002={order.KeyIn}";
            Logger.Debug($"[Order] 改量單組成:{body}");
            return body + $"{delimiter}\n";
        }
        /// <summary>
        /// 建立改價單
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public static string ChangePriceOrder(Order order)
        {
            string BS = order.Side == Side.BUY ? "B" : "S";
            string body =
                         $"35=999{delimiter}1={order.CSEQ}" +
                         $"{delimiter}37={order.DSEQ}" +
                         $"{delimiter}40={order.OrdType}" +
                         $"{delimiter}41={order.OrigClOrdID}" +
                         $"{delimiter}50={order.BHNO}" +
                         $"{delimiter}54={BS}" +
                         $"{delimiter}55={order.Symbol}" +
                         $"{delimiter}59={order.TimeInForce}" +
                         $"{delimiter}60={DateTime.Now.ToString("yyyyMMddHHmmssfff")}" +
                         $"{delimiter}10000=1" +
                         $"{delimiter}50001={order.Sale}" +
                         $"{delimiter}50002={order.KeyIn}" +
                         $"{delimiter}50003= " +//ocode,keyin空白
                         $"{delimiter}50008=3" +
                         $"{delimiter}50009={order.ECode}" +
                         //  $"|52={DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff")}" +
                         // $"|11=" +
                         $"{delimiter}56={order.MType}" +
                         //  $"{delimiter}57={order.ECode}" +
                         $"{delimiter}10001={order.OType}" +
                         $"{delimiter}44={order.OrdPrice.Trim()}" +
                         $"{delimiter}20000={UserInfo._UserIP}" +
                         $"{delimiter}107031={OrderStore.GF}";
            Logger.Debug($"[Order] 改價單組成:{body}");
            return body + $"{delimiter}\n";
        }
        /// <summary>
        /// 建立刪單電文
        /// </summary>
        /// <param name="order">委託物件</param>
        /// <returns></returns>
        public static string DeleteOrder(Order order)
        {
            string BS = order.Side == Side.BUY ? "B" : "S";
            string body = $"35=999{delimiter}50008=4" +
                         //  $"|52={DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff")}" +
                         $"{delimiter}60={DateTime.Now.ToString("yyyyMMddHHmmssfff")}" +
                         //$"|11=" +
                         $"{delimiter}41={order.OrigClOrdID}" +
                         $"{delimiter}37={order.DSEQ}" +
                         $"{delimiter}50={order.BHNO}" +
                         $"{delimiter}1={order.CSEQ}" +
                         $"{delimiter}56={order.MType}" +
                         //  $"{delimiter}57={order.ECode}" +
                         $"{delimiter}10001={order.OType}" +
                         $"{delimiter}55={order.Symbol}" +
                         $"{delimiter}54={BS}" +
                         $"{delimiter}40={order.OrdType}" +
                         $"{delimiter}59={order.TimeInForce}" +
                         $"{delimiter}38={order.OrdQty}" +
                         $"{delimiter}50003= " +//ocode,keyin空白
                         $"{delimiter}44={order.OrdPrice.Trim()}" +
                         $"{delimiter}10000=1" +
                         $"{delimiter}50001={order.Sale}" +
                         $"{delimiter}50002={order.KeyIn}" +
                         $"{delimiter}107031={OrderStore.GF}" +
                         $"{delimiter}50009={order.ECode}";
            //60004標購 or 證金標購 時才需填此欄位
            //  $"{delimiter}50002={UserInfo._UserIP}" +
            //  $"{delimiter}50004={order.DayTradeFlag}" +
            //  $"{delimiter}20103={order.Guid}" +
            Logger.Debug($"[Order] 刪單組成:{body}");
            return body + $"{delimiter}\n";
        }
        /// <summary>
        /// 初始設定開收盤時間
        /// </summary>
        /// <param name="ECode"></param>
        /// <param name="open"></param>
        /// <param name="close"></param>
        /// <param name="IsTrade"></param>
        public void Set_Trade_Time(string ECode, string open, string close, string IsTrade)
        {
            int ecode = 0, otime = 0, ctime = 0;
            int.TryParse(ECode, out ecode);
            if (IsTrade == "True")
            {
                int.TryParse(open, out otime);
                int.TryParse(close, out ctime);
            }
            if (!_TRADE_TIME.ContainsKey(ecode))
                _TRADE_TIME.Add(ecode, new List<int> { 0, 0 });
            _TRADE_TIME[ecode][0] = otime;
            _TRADE_TIME[ecode][1] = ctime;
        }
        /// <summary>
        /// 取得開收盤時間
        /// </summary>
        /// <param name="ECode"></param>
        /// <param name="model"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public int Get_Trade_Time(int ECode, int index)
        {
            return _TRADE_TIME[ECode][index];
        }
        /// <summary>
        /// 拆單邏輯
        /// </summary>
        /// <param name="ordQty"></param>
        /// <returns></returns>
        public List<int> GetShipments(int ordQty)
        {
            List<int> shipments = new List<int>();
            int temp = ordQty;
            do
            {
                if (ordQty <= 499)
                    break;

                temp -= 499;
                shipments.Add(499);
            } while (temp > 499);
            // 加入剩餘數量
            shipments.Add(temp);
            return shipments;
        }
        public static string CheckCSEQ(string cseq, string bhno)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=200");
            sb.Append(delimiter);
            sb.Append("1=" + cseq.PadLeft(7, '0')); //客戶固定7碼
            sb.Append(delimiter);
            sb.Append("76=" + bhno);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public static string CheckStock(string stock, string ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=201");
            sb.Append(delimiter);
            sb.Append("55=" + stock.PadRight(6));
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();

        }
    }
}
