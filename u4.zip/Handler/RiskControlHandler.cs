﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class RiskControlHandler
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        /// <summary>
        /// 保留顧客資訊
        /// </summary>
        public static bool _IsKeepCusAccount = false;
        /// <summary>
        /// 客戶帳號風控通過註記
        /// </summary>
        public static bool _CSEQChecked = false;
        /// <summary>
        /// 股票代號風控通過註記
        /// </summary>
        public static bool _StockNoChecked = false;
        /// <summary>
        /// 委託數量風控通過註記
        /// </summary>
        public static bool _OrdQtyChecked = false;
        /// <summary>
        /// 拆單功能開啟註記
        /// </summary>
        public static bool _SplitLotEnable = false;

        /// <summary>
        /// 開啟萬能強制下單視窗
        /// 參數一 : 下單物件
        /// 參數二 : 風控剔退訊息
        /// 參數三 : 是否為萬能強制
        /// </summary>
        public Action<string> _evntForceOrder;

        /// <summary>
        /// 當需強制下單時所暫存之下單物件
        /// </summary>
        private Order _ForceOrderObject = null;

        /// <summary>
        /// 建構子
        /// </summary>
        /// <param name="enable">拆單啟用與否</param>
        public RiskControlHandler()
        {
        }
        /// <summary>
        /// 執行下單風控
        /// </summary>
        /// <param name="cseq"></param>
        /// <param name="stock"></param>
        /// <param name="ordType"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        public bool Execute(OrderTabViewModel info, Side side)
        {
            // 自營版本不控
            if (frmMain._Model == 2)
                return true;

            #region 檢查是否為現沖卻買進
            if ((info.OType == "5" ||
                 info.OType == "6" ||
                 info.OType == "9") && side == Side.BUY)
            {
                MessageBox.Show("該委託類別不可買進", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Info("[Order] 委託類為現賣沖，不可買進");
                return false;
            }
            #endregion

            if (!CheckUIControlInputData(info.ECode))
                return false;
            if (info.TimeInForce != "0" && info.TimeInForce != "3" && info.TimeInForce != "4")
            {
                MessageBox.Show("委託條件錯誤", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #region 驗證特定帳號和關係企業股票買賣
            if (info.BHNO == "0" && info.CSEQ == "1377737" &&
                STMBStore.CheckRelatedCompanyStock(info.Symbol, side, info.OType))
            {
                MessageBox.Show("關係企業股票不可買進", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Info("[Order] 關係企業股票不可買進");
                return false;
            }
            #endregion

            return true;
        }
        /// <summary>
        /// 股票代號欄位風控控制邏輯
        /// 1. STMB檔案是否包含 2.是否為興櫃股票
        /// </summary>
        /// <param name="symbol">股票代號</param>
        /// <param name="info">股票資訊</param>
        /// <returns></returns>
        public bool CheckSymbol(string symbol, out StockInfo info)
        {
            info = null;
            _StockNoChecked = false;
            info = STMBStore.Get_SymbolInfo(symbol);
            if (info == null)
                return false;
            if (info.MTYPE.Equals("E"))
            {
                MessageBox.Show($"{info.CNAME} 興櫃股票不可輸入", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Info($"[Order] {info.CNAME} 興櫃股票不可輸入");
                return false;
            }
            _StockNoChecked = true;
            return true;
        }
        /// <summary>
        /// 委託數量欄位風險控制邏輯
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool CheckStockQty(string text, string eCode)
        {
            _OrdQtyChecked = false;
            uint qty = 0;
            if (text.Length > 0 && !uint.TryParse(text.Trim(), out qty))
            {
                MessageBox.Show("委託數量非數字", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Debug($"[Order] CheckStockQty風控:委託數量非數字{text}");
                return false;
            }
            else if (qty == 0)
            {
                MessageBox.Show("委託數量不得為0", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Debug($"[Order] CheckStockQty風控:委託數量不得為0");
                return false;
            }
            else if ((eCode == "2" || eCode == "7") && qty > 999)
            {
                MessageBox.Show("零股委託數量不得超過999股", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Debug($"[Order] CheckStockQty風控:零股委託數量不得超過999股");
                return false;
            }
            else if (qty > 499 && !_SplitLotEnable && (eCode == "0" || eCode == "3"))
            {
                MessageBox.Show("委託數量不得超過499張", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Debug($"[Order] CheckStockQty風控:委託數量不得超過499張");
                return false;
            }
            _OrdQtyChecked = true;
            return true;
        }
        /// <summary>
        /// 委託價格欄位風險控制邏輯
        /// 邏輯: 1.數字格式驗證 2.價格是否可輸入0 3.漲跌幅範圍區間檢查 4.價格Tick區間檢查
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool CheckStockPrice(OrderTabViewModel orderInfo, StockInfo symbolInfo)
        {
            decimal price = 0;
            var decimalPoing = orderInfo.OrderPrice.Split('.');
            if (decimalPoing.Length == 2 && decimalPoing[1].Length > 4)
            {
                MessageBox.Show("小數位數超過4位", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            NumberStyles style = NumberStyles.Number | NumberStyles.AllowDecimalPoint;
            if (!decimal.TryParse(orderInfo.OrderPrice, style, null, out price))
            {
                MessageBox.Show("非正確價格數字格式", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Debug($"[Order] CheckStockPrice風控:非正確價格數字格式 - {orderInfo.OrderPrice}");
                return false;
            }
            orderInfo.OrderPrice = price.ToString("0.####");
            switch (orderInfo.ECode) // 定盤/標借/標購/拍賣不需驗證
            {
                case "0":
                case "2":
                case "7":
                    decimal price_tick = StockInfoHandler.GetStockPriceTick(symbolInfo.STYPE, price);
                    if (price % price_tick != 0)
                    {
                        MessageBox.Show($"價格檔數錯誤，區間應為 {price_tick}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        Logger.Debug($"[Order] CheckStockPrice風控:價格檔數錯誤 - {price}");
                        return false;
                    }
                    if (symbolInfo.BPRICE == 9995)
                    {
                        if (price == 0)
                        {
                            MessageBox.Show("無漲跌幅限制股票,價格不可為0", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Logger.Debug($"[Order] CheckStockPrice風控:無漲跌幅限制股票,價格不可為0");
                            return false;
                        }
                    }
                    if (orderInfo.OrdType == "2" && (price > symbolInfo.TPRICE || price < symbolInfo.BPRICE))
                    {
                        MessageBox.Show($"價格超出漲跌幅限制 漲停價: {symbolInfo.TPRICE}, 跌停價: {symbolInfo.BPRICE}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        Logger.Debug($"[Order] CheckStockPrice風控:價格超出漲跌幅限制 - OrdPrice{price}");
                        return false;
                    }
                    break;
            }
            return true;
        }
        /// <summary>
        /// 客戶帳號後台風控邏輯確認
        /// </summary>
        /// <param name="cseq"></param>
        /// <returns></returns>
        public bool CheckCSEQ(string cseq)
        {
            _CSEQChecked = false;

            if (string.IsNullOrEmpty(cseq) || cseq.Length < 7)
                return false;
            _CSEQChecked = true;
            return true;
        }
        /// <summary>
        /// 確認使用者下單權限(是否為KeyIn人員)
        /// </summary>
        /// <returns></returns>
        public bool CheckUserOrderAuthority(int enviroment)
        {
            if (enviroment == 2) // 測試環境不檔
                return true;

            if (UserInfo._UserAuthority == UserAuthority.KeyIn || UserInfo._UserAuthority == UserAuthority.KeyInIB)
                return true;
            else
            {
                Logger.Info($"[Order] User-{UserInfo._EMNO},Authority-{UserInfo._UserAuthority} : 非KeyIn人員無法操作");
                MessageBox.Show("非KeyIn人員無法操作", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }
        /// <summary>
        /// 後台股票商品風控查詢
        /// </summary>
        /// <returns></returns>
        public bool CheckBOSSymbol(OrderTabViewModel view)
        {
            // 自營不控
            if (frmMain._Model == 2)
                return true;

            string TType = view.ECode;
            if (TType == "")
            {
                MessageBox.Show($"交易別錯誤: {view.ECode}", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(view.CSEQ))
            {
                MessageBox.Show($"請輸入正確客戶帳號", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        /// <summary>
        /// 確認輸入控制項簡易風控是否完成
        /// </summary>
        /// <returns></returns>
        public bool CheckUIControlInputData(string ECode)
        {
            if (!_CSEQChecked)
            {
                DialogResult dialogResult = MessageBox.Show($"客戶帳號欄位未確認完成，是否強制跳過", "強制確認", MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button2);
                Logger.Info("[CheckUIControlInputData] 客戶帳號欄位未確認完成");
                if (dialogResult == DialogResult.Yes)
                {
                    Logger.Info("強制[CheckUIControlInputData] 客戶帳號欄位未確認完成");
                }
                else
                    return false;
            }
            if (!_StockNoChecked)
            {
                MessageBox.Show("股票代號欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Info("[Order] 股票代號欄位未確認完成");
                return false;
            }
            if (!_OrdQtyChecked)
            {
                MessageBox.Show("委託數量欄位未確認完成", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Logger.Info("[Order] 委託數量欄位未確認完成");
                return false;
            }
            return true;
        }
        /// <summary>
        /// 後台風控 (並在CheckForcedSendOut 檢查是否強制下單)
        /// </summary>
        /// <returns></returns>
        public bool CheckResult(Order order)
        {
            _ForceOrderObject = order;
            if (UserInfo._UserIP == frmMain._richIP)
                return true;

            //if (!CheckBOSOrdPrice(order))
            //    return false;
            // if (!CheckForcedSendOut(order))
            //     return false;

            return true;
        }
        /// <summary>
        /// 重新設定風控指標
        /// </summary>
        public void Reset()
        {
            if (!_IsKeepCusAccount)
                _CSEQChecked = false;
            _StockNoChecked = false;
            _OrdQtyChecked = false;
            _ForceOrderObject = null;
        }
        /// <summary>
        /// 取得當下退回強制單委託資訊
        /// </summary>
        /// <returns></returns>
        public Order GetForceOrderObject()
        {
            return _ForceOrderObject;
        }
        /// <summary>
        /// 擁有分時分量權限的客戶
        /// </summary>
        public bool TimeSharingPermissions(string cseq)
        {
            Customer c = CUMBStore.Get_CustomerInfo(cseq);
            if (c == null)
                return false;
            return c.TimeSharingPermission;
        }
        public bool CheckCanBeForced(string str_code, string f100)
        {
            int code = 0;
            int.TryParse(str_code, out code);
            if (_ForceOrderObject == null)
                return false;
            // if (code == 1027 || code == 1031 || code == 1073 || code == 1302)聽說改代碼
            if (code == 3013 || code == 3015 ||
                code == 1027 || code == 1028 || code == 1029 || code == 1031 ||
                code == 1101 || code == 1102 || code == 1103 || code == 1104)
            {
                _ForceOrderObject.f100 = f100;//強制單問答模式，用SeqenceFlag當作過關註記
                return true;
            }
            _ForceOrderObject.AllForceFlag = "Y";
            return true;
        }
    }
}
