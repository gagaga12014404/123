﻿using Concord.SDK.Logging;
using System.Collections.Generic;

namespace Concord.KeyIn.Client
{
    public class StockInfoHandler
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        /// <summary>
        /// 取得商品價格Tick區間
        /// </summary>
        /// <param name="type"></param>
        /// <param name="price"></param>
        /// <returns></returns>
        public static decimal GetStockPriceTick(string type, decimal price)
        {
            decimal price_tick = 0;

            switch (type)
            {
                #region 股票
                case "1": // 第一類
                case "2": // 第二類
                case "3": // 全額
                case "7": // 存託憑證
                case "8": // 外國股票
                    if (price < 10)
                    {
                        price_tick = 0.01m;
                    }
                    else if (price >= 10 && price < 50)
                    {
                        price_tick = 0.05m;
                    }
                    else if (price >= 50 && price < 100)
                    {
                        price_tick = 0.1m;
                    }
                    else if (price >= 100 && price < 500)
                    {
                        price_tick = 0.5m;
                    }
                    else if (price >= 500 && price < 1000)
                    {
                        price_tick = 1;
                    }
                    else
                    {
                        price_tick = 5;
                    }
                    break;
                #endregion
                #region 基金( ETF & REITs)
                case "4":
                    if (price < 50)
                    {
                        price_tick = 0.01m;
                    }
                    else
                    {
                        price_tick = 0.05m;
                    }
                    break;
                #endregion
                #region 轉換公司債
                case "5":
                    if (price < 150)
                    {
                        price_tick = 0.05m;
                    }
                    else if (price >= 150 && price < 1000)
                    {
                        price_tick = 1;
                    }
                    else
                    {
                        price_tick = 5;
                    }
                    break;
                #endregion
                #region 權證
                case "6":
                    if (price < 5)
                    {
                        price_tick = 0.01m;
                    }
                    else if (price >= 5 && price < 10)
                    {
                        price_tick = 0.05m;
                    }
                    else if (price >= 10 && price < 50)
                    {
                        price_tick = 0.1m;
                    }
                    else if (price >= 50 && price < 100)
                    {
                        price_tick = 0.5m;
                    }
                    else if (price >= 100 && price < 500)
                    {
                        price_tick = 1;
                    }
                    else
                    {
                        price_tick = 5;
                    }
                    break;
                #endregion
                #region 上櫃金價
                case "9":
                    price_tick = 0.1m;
                    break;
                    #endregion
            }
            if (price_tick == 0)
            {
                Logger.Error($"GetStockPriceTick value is zero!! Type: {type}, Price: {price}");
                ConcordLogger.Alert("999", "GetStockPriceTick value Error", $"GetStockPriceTick value is zero!! Type: {type}, Price: {price}");
                price_tick = price;
            }
            return price_tick;
        }

        /// <summary>
        /// ECode值轉中文
        /// </summary>
        /// <param name="eCode"></param>
        /// <returns></returns>
        public static string GetECodeText(string eCode)
        {
            switch (eCode)
            {
                case "0":
                    return "整股";
                case "1":
                    return "鉅額";
                case "2":
                    return "零股";
                case "3":
                    return "定價";
                case "4":
                    return "標借";
                case "5":
                    return "拍賣";
                case "6":
                    return "標購";
                case "7":
                    return "盤中零股";
                case "8":
                    return "證金標購";
                case "9":
                    return "黃金";
                default:
                    ConcordLogger.Alert("998", "GetECodeText 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{eCode}");
                    Logger.Error($"GetECodeText 解析錯誤，未知數值: {eCode}");
                    return "";
            }
        }
        /// <summary>
        /// ECode中文值轉數值
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetECodeValue(string text)
        {
            switch (text)
            {
                case "整股":
                    return "0";
                case "鉅額":
                    return "1";
                case "零股":
                    return "2";
                case "定價":
                    return "3";
                case "標借":
                    return "4";
                case "拍賣":
                    return "5";
                case "標購":
                    return "6";
                case "盤中零股":
                    return "7";
                case "證金標購":
                    return "8";
                case "黃金":
                    return "9";
                default:
                    //ConcordLogger.Alert("998", "GetECodeValue 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{text}");
                    Logger.Error($"GetECodeValue 解析錯誤，未知值: {text}");
                    return "";
            }
        }
        /// <summary>
        /// Order Type值轉中文
        /// </summary>
        /// <param name="ordType"></param>
        /// <returns></returns>
        public static string GetOrderTypeText(string ordType)
        {
            switch (ordType)
            {
                case "0":
                case "9":
                    return "現";
                case "3":
                    return "資";
                case "4":
                    return "券";
                case "5":
                    return "借券5";
                case "6":
                    return "借券6";
                default:
                    ConcordLogger.Alert("998", "GetOrderTypeText 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{ordType}");
                    Logger.Error($"GetOrderTypeText 解析錯誤，未知數值: {ordType}");
                    return ""; ;
            }
        }
        /// <summary>
        /// Order Type中文轉數值
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetOrderTypeValue(string text)
        {
            switch (text)
            {
                case "現":
                    return "0";
                case "資":
                    return "3";
                case "券":
                    return "4";
                case "借券5":
                    return "5";
                case "借券6":
                    return "6";
                default:
                    Logger.Error($"GetOrderTypeValue 解析錯誤，未知數值: {text}");
                    return ""; ;
            }
        }
        /// <summary>
        /// 委託方式數值轉中文
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetOrdTypeText(string value)
        {
            switch (value)
            {
                case "1":
                    return "市";
                case "2":
                    return "限";
                default:
                    Logger.Error($"GetOrdTypeText 解析錯誤，未知數值: {value}");
                    return "";
            }
        }
        /// <summary>
        /// 委託方式中文轉數值
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetOrdTypeValue(string text)
        {
            switch (text)
            {
                case "市":
                    return "1";
                case "限":
                    return "2";
                default:
                    //ConcordLogger.Alert("998", "GetOrdTypeValue 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{text}");
                    Logger.Error($"GetOrdTypeValue 解析錯誤，未知數值: {text}");
                    return "";
            }
        }
        /// <summary>
        /// 委託條件數值中文轉數值
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetTimInForceValue(string text)
        {
            switch (text)
            {
                case "ROD":
                    return "0";
                case "IOC":
                    return "3";
                case "FOK":
                    return "4";
                default:
                    ConcordLogger.Alert("998", "GetTimInForceValue 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{text}");
                    Logger.Error($"GetTimInForceValue 解析錯誤，未知數值: {text}");
                    return "";
            }
        }
        /// <summary>
        /// 委託條件數值轉中文呈現
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetTimeInForceText(string value)
        {
            switch (value)
            {
                case "0":
                case "-1":
                    return "ROD";
                case "3":
                    return "IOC";
                case "4":
                    return "FOK";
                default:
                    //ConcordLogger.Alert("998", "GetTimeInForceText 解析錯誤", $"User: {UserInfo._EMNO}, 接收未知數值:{value}");
                    Logger.Error($"GetTimeInForceText 解析錯誤，未知數值: {value}");
                    return "";
            }
        }

    }
}
