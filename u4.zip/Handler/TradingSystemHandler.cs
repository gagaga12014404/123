﻿using Concord.SDK.IOCPHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace Concord.KeyIn.Client
{
    public class TradingSystemHandler
    {
        static char delimiter = '\u0001';
        public bool isConnected = false;

        public string CheckAccount(string account_no, string broker_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=200");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.PadLeft(7, '0')); //客戶固定7碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckStock(string stock_no, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=201");
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckOrderQty(string account_no, string broker_id, string stock_no, string qty, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=202");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.PadLeft(7, '0')); //客戶固定7碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("38=" + qty);
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckOrderPrice(string account_no, string broker_id, string stock_no, string qty, string price, int ECode)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=203");
            sb.Append(delimiter);
            sb.Append("1=" + account_no.Substring(0, account_no.Length - 1)); //風控不使用帳號檢查碼
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("55=" + stock_no.PadRight(6));
            sb.Append(delimiter);
            sb.Append("38=" + qty);
            sb.Append(delimiter);
            sb.Append("44=" + price);
            sb.Append(delimiter);
            sb.Append("81001=");
            sb.Append(ECode);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Login()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=88");
            sb.Append(delimiter);
            sb.Append("1=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("20000=" + UserInfo._UserIP);
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Recover(string broker_id, string dseq)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=206");
            sb.Append(delimiter);
            sb.Append("50002=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("117=" + dseq);
            sb.Append(delimiter);
            sb.Append("118=Y");
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }

        public string Order(Order order)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=1");
            sb.Append(delimiter + "1=" + order.CSEQ);//客戶
            sb.Append(delimiter + "76=" + order.BHNO);//分公司
            sb.Append(delimiter + "117=" + order.DSEQ);//委託書號
            sb.Append(delimiter + "55=" + order.Symbol.PadRight(6));//股票代號
            sb.Append(delimiter + "38=");//委託數量
            sb.Append(order.OrdQty);
            sb.Append(delimiter + "44=" + order.OrdPrice);//委託價錢
            string side = order.Side == Side.BUY ? "1" : "2";
            sb.Append(delimiter + "54=" + side);//買或賣
            sb.Append(delimiter + "80024=" + DateTime.Now.ToString("yyyyMMddHHmmssfff"));//委託時間
            sb.Append(delimiter + "81001=" + order.ECode);//整股零股
            sb.Append(delimiter + "81008=" + order.ExecType);//IDCP
            sb.Append(delimiter + "20000=" + UserInfo._UserIP);
            sb.Append(delimiter + "50001=" + order.Sale);//營業員
            sb.Append(delimiter + "50003= "); //興櫃來源別 KEY IN為空白
            sb.Append(delimiter + "50002=" + UserInfo._EMNO);//keyin人員員編
            sb.Append(delimiter + "107031=" + OrderStore.GF);
            sb.Append(delimiter + "60005=" + order.AllForceFlag);
            sb.Append(delimiter + "20002=" + order.OrigClOrdID);
            sb.Append(delimiter);
            if (order.f100 != "N")//強制單通關用
            {
                sb.Append("100=" + order.f100);
                sb.Append(delimiter);
            }
            sb.Append('\u000a');
            return sb.ToString();
        }
        public string CheckDseq(string broker_id, string dseq)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("35=206");
            sb.Append(delimiter);
            sb.Append("50002=" + UserInfo._EMNO);
            sb.Append(delimiter);
            sb.Append("76=" + broker_id);
            sb.Append(delimiter);
            sb.Append("117=" + dseq);
            sb.Append(delimiter);
            sb.Append("118=N");
            sb.Append(delimiter);
            sb.Append('\u000a');
            return sb.ToString();
        }
        public static string ComposeHeartBeatMessage()
        {

            return "35=880714" + delimiter + '\u000a';
        }
    }
}
