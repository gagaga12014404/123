﻿using Concord.KeyIn.Client.Properties;
using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using Concord.SDK.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.Xml;
using System.Text;
using System.ComponentModel;
using Equin.ApplicationFramework;
using System.Collections.Concurrent;

namespace Concord.KeyIn.Client
{
    /// <summary>
    /// 關閉主畫面
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void dlgCloseMainForm(object sender, EventArgs e);
    /// <summary>
    /// 新增KeyIn明細列
    /// </summary>
    /// <param name="dr"></param>
    public delegate void dlgAddKeyInReport(DataRow dr);
    public delegate void dlgUpdateKeyInReport(Report report);
    public delegate void EMdlgAddKeyInReport(DataRow dr);
    public delegate void EMdlgUpdateKeyInReport(Report report);

    public partial class frmMain : Form
    {
        #region Variable & Field

        /// <summary>
        /// 關閉主程式視窗確認委派事件
        /// </summary>
        public event dlgCloseMainForm _CloseMainFormEvent;
        private Action<string> 回傳強制單密碼;
        private readonly string _ServerIP = "";
        private readonly int _SOrderPort;
        private readonly int _PusgGWPort = Settings.Default.PushServerPort;
        private readonly string _LogUploadPath = Settings.Default.LogUploadPath;
        private readonly string _LogUploadPath_Test = Settings.Default.LogUploadPath_Test;
        private readonly string _LogUploadPath_Remote = Settings.Default.LogUploadPath_Remote;
        private readonly string _TradingSystemIP = "";
        private readonly int _TradingSystemPort;
        private readonly string Start_Date = "";
        public static readonly string _richIP = Settings.Default.RichIP;

        /// <summary>
        /// 登入的環境
        /// 1: 正式環境
        /// 2: 測試環境
        /// 3: 異地備援環境
        /// </summary>
        private int _Environment = -1;
        /// <summary>
        /// 操作模式
        /// 1: 經紀
        /// 2: 自營
        /// </summary>
        public static int _Model = -1;
        // /// <summary>
        // /// 委託畫面By帳號,股票過濾條件
        // /// </summary>
        // private string _DGVRequest_AccountOrStockFilter = "ISNULL(Origin , '') = ''";
        // /// <summary>
        // /// 委託畫面By成交條件過濾條件
        // /// </summary>
        // private string _DGVRequest_DealStatusFilter = "";
        // /// <summary>
        // /// 被動委託查詢By成交條件過濾條件
        // /// </summary>
        // private string _DGVPasRequest_DealStatusFilter = "";
        BindingListView<Report> 明細View;
        BindingListView<Report> 回報View;
        BindingListView<CheckDeal> 勾單View;
        /// <summary>
        /// 錯帳專戶
        /// </summary>
        private static readonly string _ERRORACCOUNT = "0003332";

        /// <summary>
        /// SOrderSend Gateway IOCP Client物件
        /// </summary>
        private SocketSessionHandler _SOrderSession;
        /// <summary>
        /// Push Server IOCP Client物件
        /// </summary>
        private SocketSessionHandler _PushGWSession;
        /// <summary>
        /// 分公司客戶資訊
        /// </summary>
        private CUMBStore _CustomerStore;
        /// <summary>
        /// 營業員資訊
        /// </summary>
        private SLABStore _SLABStore;
        /// <summary>
        /// 委託資訊
        /// </summary>
        private OrderStore _OrderStore;
        /// <summary>
        /// 委託相關邏輯物件
        /// </summary>
        private OrderHandler _OrderHandler;
        /// <summary>
        /// 委託相關邏輯物件
        /// </summary>
        private TradingSystemHandler _TradingSystemHandler;
        /// <summary>
        /// 個人化設定物件
        /// </summary>
        private PersonalSetting _Setting;
        /// <summary>
        /// 風險控管邏輯物件
        /// </summary>
        private RiskControlHandler _RiskControlHandler;

        /// <summary>
        /// 關閉主畫面確認視窗物件
        /// </summary>
        private frmCloseSYS _FrmCloseSYS;
        /// <summary>
        /// 改單視窗物件
        /// </summary>
        private frmStockChangeConfirm _FrmChangeCheck;
        // /// <summary>
        // /// 被動改單視窗物件
        // /// </summary>
        // private frmStockChangeConfirm _FrmPasChangeCheck;
        /// <summary>
        /// 個人設定視窗物件
        /// </summary>
        private frmStockPersionalSetting _FrmPersionSetting;
        /// <summary>
        /// 個人設定視窗物件
        /// </summary>
        private frmTimeSharing _frmTimeSharing;

        /// <summary>
        /// 萬能強制下單確認視窗物件
        /// </summary>
        private frmForceOrder _FrmForceOrd;
        /// <summary>
        /// 零股批次下單確認視窗物件
        /// </summary>
        private frmOddLotBatchOrder _FrmOddLotBatchOrd;
        /// <summary>
        /// 零股批次刪單確認視窗物件
        /// </summary>
        private frmOddLotBatchDelete _FrmOddLotBatchDle;

        /// <summary>
        /// 心跳訊息初始間距
        /// </summary>
        private int _HeartBtInt = Settings.Default.HeartBtInt;
        /// <summary>
        /// 心跳訊息 Timer 物件
        /// </summary>
        private System.Timers.Timer _HeartBeat_Timer;
        /// <summary>
        /// 跨日程式關閉 Timer 物件
        /// </summary>
        private System.Timers.Timer _Close_Timer;
        /// <summary>
        /// 傳送訊息給Socket Timer
        /// </summary>
        private System.Timers.Timer _SendMessage_Timer;
        /// <summary>
        /// ViewControlInfo 類別
        /// </summary>
        private ViewControlInfoStore _ViewControlInfoStore;
        /// <summary>
        /// 勾單作業 回報數查詢 最大筆數控制項集合
        /// </summary>
        private Dictionary<int, List<Label>> _ChkDealQueryCountControls;
        // /// <summary>
        // /// 興櫃後台交易主機客戶端
        // /// </summary>
        // private SocketSessionHandler _TradingSystemSession;
        /// <summary>
        /// 興櫃風險控管邏輯物件
        /// </summary>
        private EMRiskControlHandler _EMRiskControlHandler;
        /// <summary>
        /// 紀錄目前鎖定欄位
        /// </summary>
        private int currentFocus;
        private ConcurrentDictionary<string, string> onControlClearDict;
        private Queue<Order> 拆單Queue;
        #endregion

        #region 主畫面/主程式相關
        public frmMain(int envirm, SocketSessionHandler loginsocket, int dseq, int emdseq)
        {
            Thread.CurrentThread.Name = "Main";

            InitializeComponent();

            // panel_Recover.BringToFront();
            //先註冊event
            tab_Order.KeyUp += new KeyEventHandler(tab_Order_KeyUp);

            #region 正/測試環境 執行模式 設定值設定
            //原上市櫃連接1個IP、2個port，興櫃1個IP、1個port
            //因上市櫃與興櫃合併，僅連接單一IP與port(設定檔先不進行更動)
            _Environment = envirm;
            _Model = 1;//強制設成1(經紀)
            _SOrderPort = Settings.Default.TradingSystemPort;
            // _TradingSystemPort = Settings.Default.TradingSystemPort;
            switch (_Environment)
            {
                case 1:
                    tSLEnvironment.Text = $"總公司環境   版號:{FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}";
                    _ServerIP = Settings.Default.ServerIP;
                    // _TradingSystemIP = Settings.Default.TradingSystemIP;
                    break;
                case 2:
                    tSLEnvironment.Text = $"測試環境   版號:{FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}";
                    _ServerIP = Settings.Default.TradingSystemIP_Test;//之後興櫃跟上市櫃會相同IP
                    // _TradingSystemIP = Settings.Default.TradingSystemIP_Test;
                    break;
                case 3:
                    tSLEnvironment.Text = $"復北環境   版號:{FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}";
                    _ServerIP = Settings.Default.ServerIP_Remote;
                    // _TradingSystemIP = Settings.Default.TradingSystemPort_Remote;
                    break;
                case 4:
                    tSLEnvironment.Text = $"異地環境   版號:{FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString()}";
                    _ServerIP = Settings.Default.COLOIP;
                    _TradingSystemIP = Settings.Default.COLO_TradingSystem;
                    break;
            }
            HttpReqHandler.SetBOSSvrUrl(_Environment, _Model);
            #endregion

            #region IOCP 物件
            // DnsEndPoint orderEndPoint = new DnsEndPoint(_ServerIP, _SOrderPort);
            // DnsEndPoint recevEndPoint = new DnsEndPoint(_ServerIP, _PusgGWPort);
            // DnsEndPoint trading_system_end_point = new DnsEndPoint(_TradingSystemIP, _TradingSystemPort);
            // SOrderSend Client Session
            _SOrderSession = loginsocket;
            _SOrderSession.OnConnect += OnOrderConnected;
            _SOrderSession.OnConnectFail += OnOrderConnectFail;
            _SOrderSession.OnReceiveMsg += OnReceveivedOrdSendGW;
            _SOrderSession.OnSendMsg += OnSendToOrdSendGW;
            _SOrderSession.OnSendFailMsg += OnSendToOrdSendGWFail;

            // Push Gateway Client Session
            // _PushGWSession = new SocketSessionHandler(recevEndPoint);
            // _PushGWSession.OnConnect = OnPushConnected;
            // _PushGWSession.OnConnectFail = OnPushConnectFail;
            // _PushGWSession.OnReceiveMsg = OnReceivedPushGW;
            // _PushGWSession.OnSendMsg = OnSendToPushGW;
            // _PushGWSession.OnSendFailMsg = OnSendToPushGWFail;
            //TS
            // _TradingSystemSession = new SocketSessionHandler(trading_system_end_point);
            // _TradingSystemSession.OnConnect = OnTradingSystemConnected;
            // _TradingSystemSession.OnConnectFail = OnTradingSystemConnectFail;
            // _TradingSystemSession.OnReceiveMsg = OnReceivedTradingSystem;
            // _TradingSystemSession.OnSendMsg = OnSendToTradingSystem;
            // _TradingSystemSession.OnSendFailMsg = OnSendToTradingSystemFail;
            #endregion

            #region Tab page View Model建立
            _ViewControlInfoStore = new ViewControlInfoStore();

            #region tabPage 控制項儲存
            Dictionary<int, Control> RoundLotPageControl = new Dictionary<int, Control>()
            {
                 #region 普通交易控制項集合
                {RL_TxbTERM.TabIndex, RL_TxbTERM },
                {RL_TxbDSEQ.TabIndex, RL_TxbDSEQ },
                {RL_TxbCSEQ.TabIndex, RL_TxbCSEQ },
                {RL_TxbOType.TabIndex, RL_TxbOType },
                {RL_TxbStockNo.TabIndex, RL_TxbStockNo },
                {RL_TxbStockQty.TabIndex, RL_TxbStockQty },
                {RL_TxbPrice.TabIndex, RL_TxbPrice },
                {RL_TxbOrdType.TabIndex,RL_TxbOrdType },
                {RL_TxbSale.TabIndex, RL_TxbSale }
                #endregion
            };
            Dictionary<int, Control> OddLotPageControl = new Dictionary<int, Control>()
            {
                #region 零股交易控制項集合
                {OD_TxbTERM.TabIndex, OD_TxbTERM },
                {OD_TxbDSEQ.TabIndex, OD_TxbDSEQ },
                {OD_TxbCSEQ.TabIndex, OD_TxbCSEQ },
                {OD_TxbStockNo.TabIndex, OD_TxbStockNo },
                {OD_TxbStockQty.TabIndex, OD_TxbStockQty },
                {OD_TxbPrice.TabIndex, OD_TxbPrice },
                {OD_TxbSale.TabIndex, OD_TxbSale }
                #endregion
            };
            Dictionary<int, Control> FixedPricePageControl = new Dictionary<int, Control>()
            {
                #region 定價交易控制項集合
                {FP_TxbTERM.TabIndex, FP_TxbTERM },
                {FP_TxbDSEQ.TabIndex, FP_TxbDSEQ },
                {FP_TxbCSEQ.TabIndex, FP_TxbCSEQ },
                {FP_TxbOType.TabIndex, FP_TxbOType },
                {FP_TxbStockNo.TabIndex, FP_TxbStockNo },
                {FP_TxbStockQty.TabIndex, FP_TxbStockQty },
                {FP_TxbPrice.TabIndex, FP_TxbPrice },
                {FP_TxbSale.TabIndex, FP_TxbSale }
                #endregion
            };
            Dictionary<int, Control> StockBorrowPageControl = new Dictionary<int, Control>()
            {
                #region 股票標借控制項集合
                {SB_TxbTERM.TabIndex, SB_TxbTERM },
                {SB_TxbDSEQ.TabIndex, SB_TxbDSEQ },
                {SB_TxbCSEQ.TabIndex, SB_TxbCSEQ },
                //{SB_TxbTDCC.TabIndex, SB_TxbTDCC },
                {SB_TxbStockNo.TabIndex, SB_TxbStockNo },
                {SB_TxbStockQty.TabIndex, SB_TxbStockQty },
                {SB_TxbPrice.TabIndex, SB_TxbPrice }
                #endregion
            };
            Dictionary<int, Control> StockPurchasePageControl = new Dictionary<int, Control>()
            {
                #region 股票標購控制項集合
                {SP_TxbTERM.TabIndex, SP_TxbTERM },
                {SP_TxbDSEQ.TabIndex, SP_TxbDSEQ },
                {SP_TxbCSEQ.TabIndex, SP_TxbCSEQ },
                {SP_TxbStockNo.TabIndex, SP_TxbStockNo },
                {SP_TxbSerialNum.TabIndex, SP_TxbSerialNum },
                {SP_TxbStockQty.TabIndex, SP_TxbStockQty },
                {SP_TxbPrice.TabIndex, SP_TxbPrice }
                #endregion
            };
            Dictionary<int, Control> StockPurchase2PageControl = new Dictionary<int, Control>()
            {
                #region 證金標購控制項集合
                {SP2_TxbTERM.TabIndex, SP2_TxbTERM },
                {SP2_TxbDSEQ.TabIndex, SP2_TxbDSEQ },
                {SP2_TxbCSEQ.TabIndex, SP2_TxbCSEQ },
                {SP2_TxbStockNo.TabIndex, SP2_TxbStockNo },
                {SP2_TxbSerialNum.TabIndex, SP2_TxbSerialNum },
                {SP2_TxbStockQty.TabIndex, SP2_TxbStockQty },
                {SP2_TxbPrice.TabIndex, SP2_TxbPrice }
                #endregion
            };
            Dictionary<int, Control> StockAuctionPageControl = new Dictionary<int, Control>()
            {
                #region 股票拍賣控制項集合
                {SA_TxbTERM.TabIndex, SA_TxbTERM },
                {SA_TxbDSEQ.TabIndex, SA_TxbDSEQ },
                {SA_TxbCSEQ.TabIndex, SA_TxbCSEQ },
                {SA_TxbStockNo.TabIndex, SA_TxbStockNo },
                {SA_TxbStockQty.TabIndex, SA_TxbStockQty },
                {SA_TxbPrice.TabIndex, SA_TxbPrice }
                #endregion
            };
            Dictionary<int, Control> ErrAccountPageControl = new Dictionary<int, Control>()
            {
                #region 錯帳功能控制項集合
                {ER_TxbTERM.TabIndex, ER_TxbTERM },
                {ER_TxbDSEQ.TabIndex, ER_TxbDSEQ },
                {ER_TxbECode.TabIndex, ER_TxbECode },
                {ER_TxbStockNo.TabIndex, ER_TxbStockNo },
                {ER_TxbStockQty.TabIndex, ER_TxbStockQty },
                {ER_TxbPrice.TabIndex, ER_TxbPrice },
                {ER_TxbOrdType.TabIndex, ER_TxbOrdType }
                #endregion
            };
            Dictionary<int, Control> EmstPageControl = new Dictionary<int, Control>()
            {
                #region 興櫃tab交易控制項集合
                {EM_TxbTERM.TabIndex, EM_TxbTERM },
                {EM_TxbDSEQ.TabIndex, EM_TxbDSEQ },
                {EM_TxbCSEQ.TabIndex, EM_TxbCSEQ },
                {EM_TxbStockNo.TabIndex, EM_TxbStockNo },
                {EM_TxbStockQty.TabIndex, EM_TxbStockQty },
                {EM_TxbPrice.TabIndex, EM_TxbPrice }
                #endregion
            };
            Dictionary<int, Control> EmstErrAccountPageControl = new Dictionary<int, Control>()
            {
                #region 興櫃錯帳tab交易控制項集合
                {EMER_TxbDSEQ.TabIndex, EMER_TxbDSEQ },
                {EMER_TxbStockNo.TabIndex, EMER_TxbStockNo },
                {EMER_TxbStockQty.TabIndex, EMER_TxbStockQty },
                {EMER_TxbPrice.TabIndex, EMER_TxbPrice }
                #endregion
            };
            _ViewControlInfoStore.AddOrderTabPageControlStore("RoundLot", RoundLotPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("OddLot", OddLotPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("FixedPrice", FixedPricePageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("StockBorrow", StockBorrowPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("StockPurchase", StockPurchasePageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("StockAuction", StockAuctionPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("ErrAccount", ErrAccountPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("StockPurchase2", StockPurchase2PageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("Emst", EmstPageControl);
            _ViewControlInfoStore.AddOrderTabPageControlStore("EmstErrAccount", EmstErrAccountPageControl);
            #endregion

            #region 普通交易頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel RoundLotPageViewModel = new OrderTabViewModel();
            RL_LabTDate.DataBindings.Add(nameof(RL_LabTDate.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.TDATE));
            RL_LabBHNO.DataBindings.Add(nameof(RL_LabBHNO.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.BHNO));
            RL_TxbTERM.DataBindings.Add(nameof(RL_TxbTERM.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.TERM));
            RL_TxbDSEQ.DataBindings.Add(nameof(RL_TxbDSEQ.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.DSEQ));
            RL_TxbCSEQ.DataBindings.Add(nameof(RL_TxbCSEQ.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.CSEQ));
            RL_LabCSEQName.DataBindings.Add(nameof(RL_LabCSEQName.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.CSEQ_Name));
            RL_TxbOType.DataBindings.Add(nameof(RL_TxbOType.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.OType));
            RL_LabOType.DataBindings.Add(nameof(RL_LabOType.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.OType_Text));
            RL_TxbStockNo.DataBindings.Add(nameof(RL_TxbStockNo.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.Symbol));
            RL_LabStockName.DataBindings.Add(nameof(RL_LabStockName.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.Symbol_Name));
            RL_LabStockState.DataBindings.Add(nameof(RL_LabStockState.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.Symbol_State));
            RL_LabFinanceState.DataBindings.Add(nameof(RL_LabFinanceState.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.FinanceState));
            RL_LabMType.DataBindings.Add(nameof(RL_LabMType.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.Symbol_MType));
            RL_TxbStockQty.DataBindings.Add(nameof(RL_TxbStockQty.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.OrderQty));
            RL_TxbPrice.DataBindings.Add(nameof(RL_TxbPrice.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.OrderPrice));

            RL_TxbOrdType.DataBindings.Add(nameof(RL_TxbOrdType.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.TimeInForce));
            RL_LabOrdType.DataBindings.Add(nameof(RL_LabOrdType.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.TimeInForce_Text));

            RL_LabCancelQty.DataBindings.Add(nameof(RL_LabCancelQty.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.CancelledQty));
            RL_TxbSale.DataBindings.Add(nameof(RL_TxbSale.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.Sale));
            RL_LabQueryLaveQty.DataBindings.Add(nameof(RL_LabQueryLaveQty.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.QueryLaveQty));
            RL_LabQueryDealQty.DataBindings.Add(nameof(RL_LabQueryDealQty.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.QueryDealQty));
            RL_LanWarText.DataBindings.Add(nameof(RL_LanWarText.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.StockWarnInfo));
            RL_LabInfo.DataBindings.Add(nameof(RL_LabInfo.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.OrdInfoText));
            RL_LabCCodeText.DataBindings.Add(nameof(RL_LabCCodeText.Text), RoundLotPageViewModel, nameof(RoundLotPageViewModel.CCODE_Text));
            #endregion
            #region 零股交易頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel OddLotPageViewModel = new OrderTabViewModel();
            OD_LabTDate.DataBindings.Add(nameof(OD_LabTDate.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.TDATE));
            OD_LabBHNO.DataBindings.Add(nameof(OD_LabBHNO.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.BHNO));
            OD_TxbTERM.DataBindings.Add(nameof(OD_TxbTERM.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.TERM));
            OD_TxbDSEQ.DataBindings.Add(nameof(OD_TxbDSEQ.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.DSEQ));
            OD_TxbCSEQ.DataBindings.Add(nameof(OD_TxbCSEQ.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.CSEQ));
            OD_LabCSEQName.DataBindings.Add(nameof(OD_LabCSEQName.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.CSEQ_Name));
            OD_TxbStockNo.DataBindings.Add(nameof(OD_TxbStockNo.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.Symbol));
            OD_LabStockName.DataBindings.Add(nameof(OD_LabStockName.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.Symbol_Name));
            OD_LabStockState.DataBindings.Add(nameof(OD_LabStockState.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.Symbol_State));
            OD_LabFinanceState.DataBindings.Add(nameof(OD_LabFinanceState.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.FinanceState));
            OD_LabMType.DataBindings.Add(nameof(OD_LabMType.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.Symbol_MType));
            OD_TxbECode.DataBindings.Add(nameof(OD_TxbECode.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.ECode));
            OD_TxbStockQty.DataBindings.Add(nameof(OD_TxbStockQty.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.OrderQty));
            OD_TxbPrice.DataBindings.Add(nameof(OD_TxbPrice.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.OrderPrice));
            OD_LabCancelQty.DataBindings.Add(nameof(OD_LabCancelQty.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.CancelledQty));
            OD_TxbSale.DataBindings.Add(nameof(OD_TxbSale.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.Sale));
            OD_LabQueryLaveQty.DataBindings.Add(nameof(OD_LabQueryLaveQty.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.QueryLaveQty));
            OD_LanWarText.DataBindings.Add(nameof(OD_LanWarText.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.StockWarnInfo));
            OD_LabInfo.DataBindings.Add(nameof(OD_LabInfo.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.OrdInfoText));
            OD_LabCCodeText.DataBindings.Add(nameof(OD_LabCCodeText.Text), OddLotPageViewModel, nameof(OddLotPageViewModel.CCODE_Text));
            #endregion
            #region 定價交易頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel FixedPricePageViewModel = new OrderTabViewModel();
            FP_LabTDate.DataBindings.Add(nameof(FP_LabTDate.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.TDATE));
            FP_LabBHNO.DataBindings.Add(nameof(FP_LabBHNO.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.BHNO));
            FP_TxbTERM.DataBindings.Add(nameof(FP_TxbTERM.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.TERM));
            FP_TxbDSEQ.DataBindings.Add(nameof(FP_TxbDSEQ.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.DSEQ));
            FP_TxbCSEQ.DataBindings.Add(nameof(FP_TxbCSEQ.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.CSEQ));
            FP_LabCSEQName.DataBindings.Add(nameof(FP_LabCSEQName.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.CSEQ_Name));
            FP_TxbOType.DataBindings.Add(nameof(FP_TxbOType.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.OType));
            FP_LabOType.DataBindings.Add(nameof(FP_LabOType.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.OType_Text));
            FP_TxbStockNo.DataBindings.Add(nameof(FP_TxbStockNo.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.Symbol));
            FP_LabStockName.DataBindings.Add(nameof(FP_LabStockName.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.Symbol_Name));
            FP_LabStockState.DataBindings.Add(nameof(FP_LabStockState.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.Symbol_State));
            FP_LabFinanceState.DataBindings.Add(nameof(FP_LabFinanceState.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.FinanceState));
            FP_LabMType.DataBindings.Add(nameof(FP_LabMType.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.Symbol_MType));
            FP_TxbStockQty.DataBindings.Add(nameof(FP_TxbStockQty.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.OrderQty));
            //FP_TxbPrice.DataBindings.Add(nameof(FP_TxbPrice.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.OrderPrice));
            FP_LabCancelQty.DataBindings.Add(nameof(FP_LabCancelQty.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.CancelledQty));
            FP_TxbSale.DataBindings.Add(nameof(FP_TxbSale.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.Sale));
            FP_LabQueryLaveQty.DataBindings.Add(nameof(FP_LabQueryLaveQty.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.QueryLaveQty));
            FP_LabQueryDealQty.DataBindings.Add(nameof(FP_LabQueryDealQty.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.QueryDealQty));
            FP_LanWarText.DataBindings.Add(nameof(FP_LanWarText.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.StockWarnInfo));
            FP_LabInfo.DataBindings.Add(nameof(FP_LabInfo.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.OrdInfoText));
            FP_LabCCodeText.DataBindings.Add(nameof(FP_LabCCodeText.Text), FixedPricePageViewModel, nameof(FixedPricePageViewModel.CCODE_Text));
            #endregion
            #region 股票標借頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel StockBorrowPageViewModel = new OrderTabViewModel();
            SB_LabTDate.DataBindings.Add(nameof(SB_LabTDate.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.TDATE));
            SB_LabBHNO.DataBindings.Add(nameof(SB_LabBHNO.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.BHNO));
            SB_TxbTERM.DataBindings.Add(nameof(SB_TxbTERM.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.TERM));
            SB_TxbDSEQ.DataBindings.Add(nameof(SB_TxbDSEQ.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.DSEQ));
            SB_TxbCSEQ.DataBindings.Add(nameof(SB_TxbCSEQ.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.CSEQ));
            SB_LabCSEQName.DataBindings.Add(nameof(SB_LabCSEQName.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.CSEQ_Name));
            SB_TxbStockNo.DataBindings.Add(nameof(SB_TxbStockNo.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.Symbol));
            SB_LabStockName.DataBindings.Add(nameof(SB_LabStockName.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.Symbol_Name));
            SB_TxbStockQty.DataBindings.Add(nameof(SB_TxbStockQty.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.OrderQty));
            SB_TxbPrice.DataBindings.Add(nameof(SB_TxbPrice.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.OrderPrice));
            SB_LabCancelQty.DataBindings.Add(nameof(SB_LabCancelQty.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.CancelledQty));
            SB_LabQueryLaveQty.DataBindings.Add(nameof(SB_LabQueryLaveQty.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.QueryLaveQty));
            SB_TxbSale.DataBindings.Add(nameof(SB_TxbSale.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.Sale));
            SB_LabCCodeText.DataBindings.Add(nameof(SB_LabCCodeText.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.CCODE_Text));
            StockBorrow_LabInfo.DataBindings.Add(nameof(StockBorrow_LabInfo.Text), StockBorrowPageViewModel, nameof(StockBorrowPageViewModel.OrdInfoText));
            #endregion
            #region 股票標購頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel StockPurchasePageViewModel = new OrderTabViewModel();
            SP_LabTDate.DataBindings.Add(nameof(SP_LabTDate.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.TDATE));
            SP_LabBHNO.DataBindings.Add(nameof(SP_LabBHNO.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.BHNO));
            SP_TxbTERM.DataBindings.Add(nameof(SP_TxbTERM.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.TERM));
            SP_TxbDSEQ.DataBindings.Add(nameof(SP_TxbDSEQ.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.DSEQ));
            SP_TxbCSEQ.DataBindings.Add(nameof(SP_TxbCSEQ.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.CSEQ));
            SP_LabCSEQName.DataBindings.Add(nameof(SP_LabCSEQName.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.CSEQ_Name));
            SP_TxbStockNo.DataBindings.Add(nameof(SP_TxbStockNo.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.Symbol));
            SP_LabStockName.DataBindings.Add(nameof(SP_LabStockName.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.Symbol_Name));
            SP_TxbStockQty.DataBindings.Add(nameof(SP_TxbStockQty.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.OrderQty));
            SP_TxbPrice.DataBindings.Add(nameof(SP_TxbPrice.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.OrderPrice));
            SP_LabCancelQty.DataBindings.Add(nameof(SP_LabCancelQty.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.CancelledQty));
            SP_LabQueryLaveQty.DataBindings.Add(nameof(SP_LabQueryLaveQty.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.QueryLaveQty));
            SP_LabQueryDealQty.DataBindings.Add(nameof(SP_LabQueryDealQty.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.QueryDealQty));
            SP_LabCCodeText.DataBindings.Add(nameof(SP_LabCCodeText.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.CCODE_Text));
            StockPurchase_LabInfo.DataBindings.Add(nameof(StockPurchase_LabInfo.Text), StockPurchasePageViewModel, nameof(StockPurchasePageViewModel.OrdInfoText));
            #endregion
            #region 證金標購頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel StockPurchase2PageViewModel = new OrderTabViewModel();
            SP2_LabTDate.DataBindings.Add(nameof(SP2_LabTDate.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.TDATE));
            SP2_LabBHNO.DataBindings.Add(nameof(SP2_LabBHNO.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.BHNO));
            SP2_TxbTERM.DataBindings.Add(nameof(SP2_TxbTERM.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.TERM));
            SP2_TxbDSEQ.DataBindings.Add(nameof(SP2_TxbDSEQ.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.DSEQ));
            SP2_TxbCSEQ.DataBindings.Add(nameof(SP2_TxbCSEQ.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.CSEQ));
            SP2_LabCSEQName.DataBindings.Add(nameof(SP2_LabCSEQName.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.CSEQ_Name));
            SP2_TxbStockNo.DataBindings.Add(nameof(SP2_TxbStockNo.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.Symbol));
            SP2_LabStockName.DataBindings.Add(nameof(SP2_LabStockName.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.Symbol_Name));
            SP2_TxbStockQty.DataBindings.Add(nameof(SP2_TxbStockQty.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.OrderQty));
            SP2_TxbPrice.DataBindings.Add(nameof(SP2_TxbPrice.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.OrderPrice));
            SP2_LabCancelQty.DataBindings.Add(nameof(SP2_LabCancelQty.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.CancelledQty));
            SP2_LabQueryLaveQty.DataBindings.Add(nameof(SP2_LabQueryLaveQty.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.QueryLaveQty));
            SP2_LabQueryDealQty.DataBindings.Add(nameof(SP2_LabQueryDealQty.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.QueryDealQty));
            SP2_LabCCodeText.DataBindings.Add(nameof(SP2_LabCCodeText.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.CCODE_Text));
            StockPurchase2_LabInfo.DataBindings.Add(nameof(StockPurchase2_LabInfo.Text), StockPurchase2PageViewModel, nameof(StockPurchase2PageViewModel.OrdInfoText));
            #endregion
            #region 股票拍賣頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel StockAuctionPageViewModel = new OrderTabViewModel();
            SA_LabTDate.DataBindings.Add(nameof(SA_LabTDate.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.TDATE));
            SA_LabBHNO.DataBindings.Add(nameof(SA_LabBHNO.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.BHNO));
            SA_TxbTERM.DataBindings.Add(nameof(SA_TxbTERM.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.TERM));
            SA_TxbDSEQ.DataBindings.Add(nameof(SA_TxbDSEQ.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.DSEQ));
            SA_TxbCSEQ.DataBindings.Add(nameof(SA_TxbCSEQ.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.CSEQ));
            SA_LabCSEQName.DataBindings.Add(nameof(SA_LabCSEQName.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.CSEQ_Name));
            SA_TxbStockNo.DataBindings.Add(nameof(SA_TxbStockNo.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.Symbol));
            SA_LabStockName.DataBindings.Add(nameof(SA_LabStockName.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.Symbol_Name));
            SA_TxbStockQty.DataBindings.Add(nameof(SA_TxbStockQty.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.OrderQty));
            SA_TxbPrice.DataBindings.Add(nameof(SA_TxbPrice.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.OrderPrice));
            SA_LabCancelQty.DataBindings.Add(nameof(SA_LabCancelQty.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.CancelledQty));
            SA_LabQueryLaveQty.DataBindings.Add(nameof(SA_LabQueryLaveQty.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.QueryLaveQty));
            SA_LabQueryDealQty.DataBindings.Add(nameof(SA_LabQueryDealQty.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.QueryDealQty));
            SA_LabCCodeText.DataBindings.Add(nameof(SA_LabCCodeText.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.CCODE_Text));
            StockAuction_LabInfo.DataBindings.Add(nameof(StockAuction_LabInfo.Text), StockAuctionPageViewModel, nameof(StockAuctionPageViewModel.OrdInfoText));
            #endregion
            #region 錯帳功能頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel ErrAccountPageViewModel = new OrderTabViewModel();
            ER_LabTDate.DataBindings.Add(nameof(ER_LabTDate.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.TDATE));
            ER_LabBHNO.DataBindings.Add(nameof(ER_LabBHNO.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.BHNO));
            ER_TxbTERM.DataBindings.Add(nameof(ER_TxbTERM.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.TERM));
            ER_TxbDSEQ.DataBindings.Add(nameof(ER_TxbDSEQ.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.DSEQ));
            ER_TxbECode.DataBindings.Add(nameof(ER_TxbECode.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.ECode));
            ER_TxbStockNo.DataBindings.Add(nameof(ER_TxbStockNo.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.Symbol));
            ER_LabStockName.DataBindings.Add(nameof(ER_LabStockName.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.Symbol_Name));
            ER_TxbStockQty.DataBindings.Add(nameof(ER_TxbStockQty.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.OrderQty));
            ER_TxbPrice.DataBindings.Add(nameof(ER_TxbPrice.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.OrderPrice));
            ER_TxbOrdType.DataBindings.Add(nameof(ER_TxbOrdType.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.TimeInForce));
            ER_LabOrdType.DataBindings.Add(nameof(ER_LabOrdType.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.TimeInForce_Text));
            ER_LabCancelQty.DataBindings.Add(nameof(ER_LabCancelQty.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.CancelledQty));
            ER_LabQueryLaveQty.DataBindings.Add(nameof(ER_LabQueryLaveQty.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.QueryLaveQty));
            ER_LabQueryDealQty.DataBindings.Add(nameof(ER_LabQueryDealQty.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.QueryDealQty));
            ER_LanWarText.DataBindings.Add(nameof(ER_LanWarText.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.StockWarnInfo));
            ER_LabInfo.DataBindings.Add(nameof(ER_LabInfo.Text), ErrAccountPageViewModel, nameof(ErrAccountPageViewModel.OrdInfoText));
            #endregion
            #region 興櫃交易頁面 ViewModel Data Bindings 初始化動作
            //因為它有很多的tab，所以才需要viewcontrol，用dict加入進去控制
            OrderTabViewModel EmstPageViewModel = new OrderTabViewModel();
            EM_LabTDate.DataBindings.Add(nameof(EM_LabTDate.Text), EmstPageViewModel, nameof(EmstPageViewModel.TDATE));
            EM_LabBHNO.DataBindings.Add(nameof(EM_LabBHNO.Text), EmstPageViewModel, nameof(EmstPageViewModel.BHNO));                //分公司
            EM_TxbTERM.DataBindings.Add(nameof(EM_TxbTERM.Text), EmstPageViewModel, nameof(EmstPageViewModel.TERM));                //櫃號
            EM_TxbDSEQ.DataBindings.Add(nameof(EM_TxbDSEQ.Text), EmstPageViewModel, nameof(EmstPageViewModel.DSEQ));                //委託序號
            EM_TxbCSEQ.DataBindings.Add(nameof(EM_TxbCSEQ.Text), EmstPageViewModel, nameof(EmstPageViewModel.CSEQ));                //客戶帳號
            EM_LabCSEQName.DataBindings.Add(nameof(EM_LabCSEQName.Text), EmstPageViewModel, nameof(EmstPageViewModel.CSEQ_Name));   //客戶姓名
            EM_LabCCodeText.DataBindings.Add(nameof(EM_LabCCodeText.Text), EmstPageViewModel, nameof(EmstPageViewModel.CCODE_Text));//客戶開戶狀態
            EM_Sales.DataBindings.Add(nameof(EM_Sales.Text), EmstPageViewModel, nameof(EmstPageViewModel.Sale));                    //營業員
            EM_TxbStockNo.DataBindings.Add(nameof(EM_TxbStockNo.Text), EmstPageViewModel, nameof(EmstPageViewModel.Symbol));        //股票代號
            EM_LabStockName.DataBindings.Add(nameof(EM_LabStockName.Text), EmstPageViewModel, nameof(EmstPageViewModel.Symbol_Name));//股票名字
            EM_LabStockState.DataBindings.Add(nameof(EM_LabStockState.Text), EmstPageViewModel, nameof(EmstPageViewModel.Symbol_State));//信用狀態
            EM_LabelUnit.DataBindings.Add(nameof(EM_LabelUnit.Text), EmstPageViewModel, nameof(EmstPageViewModel.Unit));            //unit單位
            EM_TxbStockQty.DataBindings.Add(nameof(EM_TxbStockQty.Text), EmstPageViewModel, nameof(EmstPageViewModel.OrderQty));    //委託數量
            EM_TxbPrice.DataBindings.Add(nameof(EM_TxbPrice.Text), EmstPageViewModel, nameof(EmstPageViewModel.OrderPrice));        //委託價格
            EM_LanWarText.DataBindings.Add(nameof(EM_LanWarText.Text), EmstPageViewModel, nameof(EmstPageViewModel.StockWarnInfo)); //處置股訊息
            EM_Message.DataBindings.Add(nameof(EM_Message.Text), EmstPageViewModel, nameof(EmstPageViewModel.OrdInfoText));         //錯誤訊息
            EM_Search.DataBindings.Add(nameof(EM_Search.Text), EmstPageViewModel, nameof(EmstPageViewModel.SearchResult));          //查詢結果
            EM_LabCancelQty.DataBindings.Add(nameof(EM_LabCancelQty.Text), EmstPageViewModel, nameof(EmstPageViewModel.CancelledQty));
            EM_BasicPrice.DataBindings.Add(nameof(EM_BasicPrice.Text), EmstPageViewModel, nameof(EmstPageViewModel.BasicPrice));
            #endregion
            #region 興櫃交易頁面 ViewModel Data Bindings 初始化動作
            OrderTabViewModel EmstErrAccountViewModel = new OrderTabViewModel();
            EMER_LabTDate.DataBindings.Add(nameof(EMER_LabTDate.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.TDATE));
            EMER_LabBHNO.DataBindings.Add(nameof(EMER_LabBHNO.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.BHNO));
            EMER_TxbTERM.DataBindings.Add(nameof(EMER_TxbTERM.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.TERM));
            EMER_TxbDSEQ.DataBindings.Add(nameof(EMER_TxbDSEQ.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.DSEQ));
            EMER_TxbStockNo.DataBindings.Add(nameof(EMER_TxbStockNo.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.Symbol));
            EMER_LabStockName.DataBindings.Add(nameof(EMER_LabStockName.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.Symbol_Name));
            EMER_TxbStockQty.DataBindings.Add(nameof(EMER_TxbStockQty.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.OrderQty));
            EMER_TxbPrice.DataBindings.Add(nameof(EMER_TxbPrice.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.OrderPrice));
            EMER_LabelUnit.DataBindings.Add(nameof(EMER_LabelUnit.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.Unit));
            EMER_LabQueryLaveQty.DataBindings.Add(nameof(EMER_LabQueryLaveQty.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.QueryLaveQty));
            EMER_LabQueryDealQty.DataBindings.Add(nameof(EMER_LabQueryDealQty.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.QueryDealQty));
            EMER_LanWarText.DataBindings.Add(nameof(EMER_LanWarText.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.StockWarnInfo));
            EMER_LabInfo.DataBindings.Add(nameof(EMER_LabInfo.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.OrdInfoText));
            EMER_BasicPrice.DataBindings.Add(nameof(EMER_BasicPrice.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.BasicPrice));
            label168.DataBindings.Add(nameof(label168.Text), EmstErrAccountViewModel, nameof(EmstErrAccountViewModel.CancelledQty));//顯示已刪除數量，不知道該label在哪裡，用label168
            #endregion

            _ViewControlInfoStore.AddTabPageInfo("RoundLot", RoundLotPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("OddLot", OddLotPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("FixedPrice", FixedPricePageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("StockBorrow", StockBorrowPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("StockPurchase", StockPurchasePageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("StockAuction", StockAuctionPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("ErrAccount", ErrAccountPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("StockPurchase2", StockPurchase2PageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("Emst", EmstPageViewModel);
            _ViewControlInfoStore.AddTabPageInfo("EmstErrAccount", EmstErrAccountViewModel);
            #endregion

            #region 共用物件初始化 
            拆單Queue = new Queue<Order>();
            onControlClearDict = new ConcurrentDictionary<string, string>();
            _frmTimeSharing = new frmTimeSharing();
            _frmTimeSharing._AskMainToSend = DoSendTimeSharing;
            _EMRiskControlHandler = new EMRiskControlHandler();
            _RiskControlHandler = new RiskControlHandler();
            _RiskControlHandler._evntForceOrder += OnForceOrder;
            _OrderHandler = new OrderHandler();
            _TradingSystemHandler = new TradingSystemHandler();
            _OrderStore = new OrderStore();
            _OrderStore.Start_ProcessReport();
            _OrderHandler.DSEQ = dseq;
            _OrderStore.興櫃委託書號 = emdseq;
            _CustomerStore = new CUMBStore();
            _SLABStore = new SLABStore();
            _Setting = new PersonalSetting();
            _ChkDealQueryCountControls = new Dictionary<int, List<Label>>()
            {
                { 0, new List<Label> { LabChkDealQT1, LabChkDealQR1 } },
                { 1, new List<Label> { LabChkDealQT2, LabChkDealQR2 } },
                { 2, new List<Label> { LabChkDealQT3, LabChkDealQR3 } },
                { 3, new List<Label> { LabChkDealQT4, LabChkDealQR4 } },
                { 4, new List<Label> { LabChkDealQT5, LabChkDealQR5 } },
            };
            #endregion
            #region 視窗物件初始化
            _FrmCloseSYS = new frmCloseSYS();
            _FrmChangeCheck = new frmStockChangeConfirm();
            // _FrmPasChangeCheck = new frmStockChangeConfirm();
            _FrmChangeCheck.SendChangeQtyOrd += SendOutChangeQty;
            _FrmChangeCheck.SendChangePriceOrd += SendOutChangePrice;
            // _FrmPasChangeCheck.SendChangeQtyOrd += SendOutPasChangeQty;
            // _FrmPasChangeCheck.SendChangePriceOrd += SendOutPasChangePrice;
            _FrmPersionSetting = new frmStockPersionalSetting();
            _FrmPersionSetting.ChangePersonalSetting += SavePersonalSetting;
            _FrmForceOrd = new frmForceOrder();
            _FrmOddLotBatchOrd = new frmOddLotBatchOrder();
            _FrmOddLotBatchDle = new frmOddLotBatchDelete();
            #endregion
            #region Heartbeat Timer
            _HeartBeat_Timer = new System.Timers.Timer(_HeartBtInt * 1000);
            _HeartBeat_Timer.Elapsed += SessionHeartbeat;
            _HeartBeat_Timer.Enabled = true;
            #endregion
            #region SendMessage Timer
            _SendMessage_Timer = new System.Timers.Timer(10000);
            _SendMessage_Timer.Elapsed += SendMessageTimer;
            #endregion
            Start_Date = DateTime.Now.ToShortDateString();
            Logger.Info("KeyIn登入日期: " + Start_Date);
            #region Close Timer
            _Close_Timer = new System.Timers.Timer();
            _Close_Timer.Interval = 600 * 1000;
            _Close_Timer.Elapsed += Close_Check;
            _Close_Timer.Enabled = true;
            _Close_Timer.Start();
            #endregion
            if (_SOrderSession.ClientConnectState == ConnectState.Connected)
            {
                Logger.Info($"[frmMain] 此時還是連線成功的狀態 IP:{_ServerIP}");
                Logger.Info($"[frmMain] 送出交易時間基本資料檔電文");
                _SOrderSession.SendMessage("35=403\n");
                RL_LabOrdErrMsg.Visible = false;
                OD_LabOrdErrMsg.Visible = false;
                FP_LabOrdErrMsg.Visible = false;
                SB_LabOrdErrMsg.Visible = false;
                tslSOrderSend.Text = "上市櫃下單連線成功";
                tslSOrderSend.ForeColor = Color.Green;
                tslPushServer.Text = "回報連線成功";
                tslPushServer.ForeColor = Color.Green;
                EmTradingCheck.ForeColor = Color.Green;
                EmTradingCheck.Text = "興櫃連線成功";
            }
            else
            {
                tslSOrderSend.ForeColor = Color.Red;
                tslPushServer.ForeColor = Color.Red;
                EmTradingCheck.ForeColor = Color.Red;
                tslSOrderSend.Text = "上市櫃下單連線失敗";
                tslPushServer.Text = "回報連線失敗";
                EmTradingCheck.Text = "興櫃連線失敗";
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // 連結Gateway
            // ConnectGateway();
            if (_SOrderSession.ClientConnectState != ConnectState.Connected && _SOrderSession.ClientConnectState != ConnectState.Connecting)
            {
                _SOrderSession.DoConnect();
                Logger.Debug("_SOrderSession.DoConnect");
            }
            else
            {
                Logger.Info($"[frmMain] 送出註冊電文");
                SendToSocket(SocketSessionHandler.ComposeSubscribeMessage("88"));
                Logger.Info($"[frmMain] 送出回補電文");
                SendToSocket(_TradingSystemHandler.Recover($"845{UserInfo._BHNO}", UserInfo._EMTERM));//送出回補電文
            }
            #region 個人化設定值取得
            PersonalSetting setting = null;
            try
            {
                using (StreamReader reader = new StreamReader($@"{Environment.CurrentDirectory}/PersonalSetting.json"))
                {
                    setting = JsonConvert.DeserializeObject<PersonalSetting>(reader.ReadToEnd());
                }
                if (setting != null)
                {
                    _Setting = setting;
                    ChangeEnableVisible();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[Init] 取得個人設定檔異常: {ex}");
                ConcordLogger.Alert("999", "取得個人設定檔異常", ex.ToString());
            }
            #endregion

            CultureInfo culture = new CultureInfo("zh-TW");
            culture.DateTimeFormat.Calendar = new TaiwanCalendar();
            string TDate = DateTime.Now.ToString("yyyMMdd", culture);
            string[] tab_name = { "RoundLot",       //普通交易
                                  "OddLot",         //零股交易
                                  "FixedPrice",     //定價交易
                                  "StockBorrow",    //股票標借
                                  "StockPurchase",  //股票標購
                                  "StockAuction",   //股票拍賣
                                  "ErrAccount",     //錯帳
                                  "StockPurchase2", //證金標購
                                  "Emst",           //興櫃
                                  "EmstErrAccount"  //興櫃錯帳
                                };
            for (int i = 0; i < 10; i++) // 新增tab分頁時需調整
            {
                var pageInfo = _ViewControlInfoStore.GetTabPageInfo(tab_name[i]);
                pageInfo.TDATE = TDate;
                pageInfo.BHNO = (i == 6 || i == 9) ? "8450" : $"845{UserInfo._BHNO}";
                // KeyIn人員櫃號 (普通,零股,定價)  
                // 標借,標購,拍賣 固定為 Z
                switch (i)
                {
                    case 0:
                    case 1:
                    case 2:
                        pageInfo.TERM = UserInfo._TRAM;
                        pageInfo.DSEQ = _OrderHandler.DSEQ.ToString();
                        break;
                    case 3:
                    case 4:
                    case 5:
                    case 7:
                        pageInfo.TERM = "Z";
                        break;
                    case 6:
                        pageInfo.TERM = "Q";
                        break;
                    case 8:
                        pageInfo.TERM = UserInfo._EMTERM;
                        pageInfo.DSEQ = _OrderStore.興櫃委託書號.ToString();
                        break;
                    case 9:
                        pageInfo.TERM = "X";
                        pageInfo.CSEQ = _ERRORACCOUNT;
                        break;
                }
                pageInfo.CSEQ_Name = " ";
                pageInfo.Symbol_Name = " ";
                pageInfo.Symbol_State = " ";
                pageInfo.FinanceState = " ";
                pageInfo.Symbol_MType = " ";
                pageInfo.StockWarnInfo = "";
                pageInfo.CCODE_Text = "";
            }
            if (_Model == 2)
            {   // 自營無標借/標購/拍賣/錯帳功能
                StockAuction.Parent = null;
                StockBorrow.Parent = null;
                StockPurchase.Parent = null;
                ErrAccount.Parent = null;
                Emst.Parent = null;
                EmstErrAccount.Parent = null;
                // EmTradingCheck.Hide();
            }
            // if (_OrderHandler.DSEQ == 0)
            //     _ViewControlInfoStore.GetTabPageInfo("RoundLot").DSEQ = "";
            // 判斷是否有拆單權限並顯示控制項
            if (UserInfo._IsSplitLot)
                ChKSplitLot.Visible = true;
            // 初始時觸發頁面切換初始化數值
            tab_Order_SelectedIndexChanged(sender, e);
            Thread RefreshDatagriview = new Thread(DoRefreshDatagridview);
            RefreshDatagriview.Start();
        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            _FrmCloseSYS.ShowDialog(this);
            if (_FrmCloseSYS.DialogResult == DialogResult.OK)
            {
                //_PushGWSession.Dispose();
                _SOrderSession.Dispose();
                // _TradingSystemSession.Dispose();
                EventArgs eaMsg = new EventArgs();
                _CloseMainFormEvent(sender, eaMsg);
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void 委託設定ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _FrmPersionSetting.Init(_Setting);
            _FrmPersionSetting.ShowDialog();
        }
        /// <summary>
        /// 開啟分時分量form
        /// </summary>
        private void btn_OpenFrmTimeSharing_Click(object sender, EventArgs e)
        {
            #region 股票現買/賣 (F1/F16(-))
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            //限制使用權限
            if (!_RiskControlHandler.TimeSharingPermissions(order_ViewModel.CSEQ))
            {
                return;
            }
            var stock_info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
            #region 若價格欄位為空白，取漲跌停價格                                         
            if (string.IsNullOrWhiteSpace(order_ViewModel.OrderPrice))
            {
                order_ViewModel.OrderPrice = STMBStore.Get_Price(order_ViewModel.Symbol, Side.None);
            }
            #endregion
            if (order_ViewModel.OrderPrice == "0" && tab_Order.SelectedTab.Name == "RoundLot")
                order_ViewModel.OrdType = "1"; // 改為市價
            else
                order_ViewModel.OrdType = "2"; // 限價
            if (!_RiskControlHandler.Execute(order_ViewModel, Side.None))
                return;
            if (!_RiskControlHandler.CheckStockPrice(order_ViewModel, stock_info))
                return;
            Order order = ComposeNewObject(order_ViewModel, Side.None, false);
            if (order == null)
                return;
            #endregion
            _frmTimeSharing.Init(order);
            OrdControlClear();
            btn_OpenFrmTimeSharing.Visible = false;
            if (_frmTimeSharing.Visible)
            {
                _frmTimeSharing.WindowState = FormWindowState.Normal;
                _frmTimeSharing.Activate();
            }
            else
                _frmTimeSharing.Show();
        }
        private void 上傳LogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string FileName = $"{DateTime.Now.ToString("yyyyMMdd")}_845{UserInfo._BHNO}_{UserInfo._EMNO}.log";
            try
            {
                string path = "";
                if (_Environment == 1)
                    path = _LogUploadPath;
                else if (_Environment == 2)
                    path = _LogUploadPath_Test;
                else if (_Environment == 3 || _Environment == 4)
                    path = _LogUploadPath_Remote;
                File.Copy(@"C:\CONCORDS\KeyInLog\" + $"log_{DateTime.Now.ToString("yyyy-MM-dd")}.log", path + FileName, true);
                Logger.Debug("LogUpload 上傳Log檔成功");
                MessageBox.Show("Log 上傳成功");
            }
            catch (Exception ex)
            {
                Logger.Error($"LogUpload Err，錯誤原因：{ex}");
            }
        }
        /// <summary>
        /// 時間
        /// 取開收盤時程 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_Tick(object sender, EventArgs e)
        {
            int time_now = int.Parse(DateTime.Now.ToString("HHmm"));
            if (_OrderHandler.Get_Trade_Time(0, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(0, 1))
                panel_RoundLot.Visible = true;
            else
                panel_RoundLot.Visible = false;

            // 零股交易含盤中及盤後零股
            if ((_OrderHandler.Get_Trade_Time(2, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(2, 1))
                || (_OrderHandler.Get_Trade_Time(7, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(7, 1)))
                panel_OddLot.Visible = true;
            else
                panel_OddLot.Visible = false;

            if (_OrderHandler.Get_Trade_Time(3, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(3, 1))
                panel_FixedPrice.Visible = true;
            else
                panel_FixedPrice.Visible = false;

            if (_OrderHandler.Get_Trade_Time(4, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(4, 1))
                panel_StockBorrow.Visible = true;
            else
                panel_StockBorrow.Visible = false;

            if (_OrderHandler.Get_Trade_Time(6, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(6, 1))
                panel_StockPurchase.Visible = true;
            else
                panel_StockPurchase.Visible = false;

            if (_OrderHandler.Get_Trade_Time(5, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(5, 1))
                panel_StockAuction.Visible = true;
            else
                panel_StockAuction.Visible = false;

            if (_OrderHandler.Get_Trade_Time(-1, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(-1, 1))
                panel_ErrAccout.Visible = true;
            else
                panel_ErrAccout.Visible = false;

            if (_OrderHandler.Get_Trade_Time(8, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(8, 1))
                panel_StockPurchase2.Visible = true;
            else
                panel_StockPurchase2.Visible = false;
        }
        /// <summary>
        /// DataView 雙重緩衝設定
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="setting"></param>
        private new void DoubleBuffered(DataGridView dgv, bool setting)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered",
            BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, setting, null);
        }
        #endregion

        #region 跨日程式關閉檢查
        private void Close_Check(object obj, ElapsedEventArgs e)
        {
            if (Start_Date != DateTime.Now.ToShortDateString()) // 已經跨日
            {
                Logger.Info("已發生跨日，程式自動關閉!");
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }
            else
            {
                Logger.Info("跨日檢查正常");
            }
        }
        #endregion

        public static string ParseXML(String strXML, out String strRtnContent)
        {
            String strRtnCode, strRtnMsg = "";
            try
            {
                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.LoadXml(strXML);
                strRtnCode = XmlDoc.SelectSingleNode("//respcode").InnerText;

                if (strRtnCode == "000")
                {
                    XmlNodeList xnList = XmlDoc.SelectNodes("//l");

                    foreach (XmlNode xn in xnList)
                    {
                        strRtnMsg += xn.InnerText + (char)0x0a;
                    }
                    strRtnContent = strRtnMsg.TrimEnd((char)0x0a);
                }
                else
                {
                    strRtnContent = XmlDoc.SelectSingleNode("//respmsg").InnerText;
                }
            }
            catch (Exception ex)
            {
                strRtnCode = "999";
                strRtnContent = "非預期錯誤";
                Logger.Error("ParseXML Error", ex);
            }

            return strRtnCode;
        }

        #region DGV異常事件
        private void DGVKeyIn_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // KeyIn明細
            Logger.Error("KeyIn明細列表發生異常，錯誤原因: " + e.Context.ToString());
            MessageBox.Show("KeyIn明細列表發生異常，請通知資訊部!");
        }

        private void DGVRequest_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // 委託回報
            Logger.Error("委託回報列表發生異常，錯誤原因: " + e.Context.ToString());
            MessageBox.Show("委託回報列表發生異常，請通知資訊部!");
        }

        private void DGVCheckDeal_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // 勾單作業
            Logger.Error("勾單作業列表發生異常，錯誤原因: " + e.Context.ToString());
            MessageBox.Show("勾單作業列表發生異常，請通知資訊部!");
        }

        private void DGVPasRequest_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // 被動查詢
            Logger.Error("被動查詢列表發生異常，錯誤原因: " + e.Context.ToString());
            MessageBox.Show("被動查詢列表發生異常，請通知資訊部!");
        }
        #endregion

        private void DGVPasRequest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // if (e.CellStyle.SelectionForeColor != e.CellStyle.ForeColor)
            // {
            //     e.CellStyle.SelectionForeColor = e.CellStyle.ForeColor;
            // }
            // switch (DGVRequest.Columns[e.ColumnIndex].Name)
            // {
            //     case "colOrdQty":
            //     case "colCancelQty":
            //     case "colDealQty":
            //         if (!DGVRequest.Rows[e.RowIndex].Cells["col__ECODE"].EditedFormattedValue.ToString().Contains("零股") &&
            //              DGVRequest.Rows[e.RowIndex].Cells["col_Mtype"].EditedFormattedValue.ToString() != "E")
            //         {
            //             if (e.Value != null)
            //                 e.Value = int.Parse(e.Value.ToString()) * 1000;
            //         }
            //         break;
            // }
        }
    }
}

