﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region 回報 Tab

        /// <summary>
        /// 切換報頁籤索引事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_Request_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tab_Request.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    // if (IsAtEmstTab())
                    //     DGVEmstRequest_RowsUpdate();
                    // else
                    btnFilterOK_Click(null, null);
                    txbFilterCSEQ.Focus();
                    break;
                case 2:
                    Btn_QueryDeal_Click(sender, e); // 查詢
                    rdbRL.Checked = true;
                    DGVCheckDeal.Focus();
                    break;
            }
        }

        #region KeyIn明細畫面控制項
        private void DGVKeyIn_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null)
                e.Value = "";
            switch (DGVKeyIn.Columns[e.ColumnIndex].Name)
            {
                case "colCDI":
                    if (e.Value.ToString() == "I" || e.Value.ToString() == "8")
                        e.Value = "";
                    break;
                case "colSide_KeyIn":
                    if (e.Value.ToString() == "B")
                    {
                        DGVKeyIn.Rows[e.RowIndex].Cells["colSide_KeyIn"].Style.ForeColor = Color.Red;
                        DGVKeyIn.Rows[e.RowIndex].Cells["colSide_KeyIn"].Style.SelectionForeColor = Color.Red;
                    }
                    break;
                case "colBefChgQty_KeyIn":
                case "colOrdQty_KeyIn":
                    if (e.Value.ToString() == "0")
                        e.Value = "";
                    break;
                case "colDealQty_KeyIn":
                    if (e.Value.ToString() == "0")
                        e.Value = "";
                    else
                        e.Value = $"( {e.Value} )";
                    break;
                case "colStatus_KeyIn":
                    if (e.Value.ToString().Contains("失敗"))
                    {
                        DGVKeyIn.Rows[e.RowIndex].Cells["colStatus_KeyIn"].Style.ForeColor = Color.Red;
                        DGVKeyIn.Rows[e.RowIndex].Cells["colStatus_KeyIn"].Style.SelectionForeColor = Color.Red;
                    }
                    else if (e.Value.ToString().Contains("成功") || e.Value.ToString().Contains("成交"))
                    {
                        e.Value = "成功";
                    }
                    break;
            }
        }
        #endregion

        #region 委託回報畫面控制項
        /// <summary>
        /// 重繪回報畫面
        /// </summary>
        private void DGVRequest_RowsUpdate()
        {
            foreach (DataGridViewRow row in DGVRequest.Rows)
            {
                if (row == null)
                    continue;
                #region 更新 刪量價 按扭欄位
                if ((row.Cells["colStatus"].EditedFormattedValue.ToString() != "成功" &&
                     row.Cells["colStatus"].EditedFormattedValue.ToString() != "部份成交") ||
                     row.Cells["ColTimeInForce"].EditedFormattedValue.ToString() != "ROD")
                {
                    row.Cells["colDeleteOrder"].Dispose();
                    row.Cells["colDeleteOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["colChangeOrder"].Dispose();
                    row.Cells["colChangeOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["colChangePrice"].Dispose();
                    row.Cells["colChangePrice"] = new DataGridViewTextBoxCell();
                }
                else
                {
                    row.Cells["colDeleteOrder"].Dispose();
                    row.Cells["colDeleteOrder"] = new DataGridViewButtonCell();
                    row.Cells["colDeleteOrder"].Value = "刪";
                    row.Cells["colChangeOrder"].Dispose();
                    if (row.Cells["ColLaveQty"].EditedFormattedValue.ToString() == "1000" ||
                        row.Cells["ColLaveQty"].EditedFormattedValue.ToString() == "1")
                    {
                        row.Cells["colChangeOrder"].Dispose();
                        row.Cells["colChangeOrder"] = new DataGridViewTextBoxCell();
                    }
                    else
                    {
                        row.Cells["colChangeOrder"] = new DataGridViewButtonCell();
                        row.Cells["colChangeOrder"].Value = "量";
                    }
                    row.Cells["colChangePrice"].Dispose();
                    if (row.Cells["colECODE"].EditedFormattedValue.ToString() == "整股" &&
                        row.Cells["colOrdPrice"].EditedFormattedValue.ToString() != "市價")
                    {
                        row.Cells["colChangePrice"] = new DataGridViewButtonCell();
                        row.Cells["colChangePrice"].Value = "價";
                    }
                    else
                    {
                        row.Cells["colChangePrice"] = new DataGridViewTextBoxCell();
                    }
                }
                #endregion
            }
        }
        /// <summary>
        /// 委託畫面欄位點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
                return;
            string DSEQ = DGVRequest.CurrentRow.Cells["colDSEQ"].EditedFormattedValue.ToString();
            if (DSEQ.Trim() == "")
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            switch (e.ColumnIndex)
            {
                case 0: // 勾選欄位
                    bool IsChoice = (bool)DGVRequest.CurrentRow.Cells["colCheckDelete"].EditedFormattedValue;
                    DGVRequest.CurrentRow.Cells["colCheckDelete"].Value = !IsChoice;
                    break;
                case 1:
                    {
                        #region 刪單按鈕
                        if (DGVRequest.CurrentRow.Cells["colDeleteOrder"].EditedFormattedValue.ToString() != "刪")
                            return;
                        Logger.Info("[Order] 刪單扭按按下");
                        Report report = _OrderStore.GetReportInfoByDSEQ(DSEQ);
                        if (report != null && report.MType == "E")
                        {
                            SendEMCancel(DSEQ);
                        }
                        else
                        {
                            Order order = ComposeDeleteObject(DSEQ);
                            if (order != null)
                            {
                                _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                                SendOut(OrderHandler.DeleteOrder(order));
                            }
                        }
                        #endregion
                        break;
                    }
                case 2:
                    {
                        #region 改量按鈕
                        if (DGVRequest.CurrentRow.Cells["colChangeOrder"].EditedFormattedValue.ToString() != "量")
                            return;
                        Logger.Info("[Order] 改量扭按按下");
                        var report = _OrderStore.GetReportInfoByDSEQ(DSEQ);
                        if (report != null)
                            _FrmChangeCheck.Init("ChgQty", report);
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改量錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
                case 3:
                    {
                        #region 改價按扭
                        if (DGVRequest.CurrentRow.Cells["colChangePrice"].EditedFormattedValue.ToString() != "價")
                            return;
                        Logger.Info("[Order] 改價扭按按下");
                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null)
                            _FrmChangeCheck.Init("ChgPrice", report);
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改價錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
            }
        }
        private void DGVRequest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex < 0 || e.RowIndex < 0)
                return;
            if (e.CellStyle.SelectionForeColor != e.CellStyle.ForeColor)
            {
                e.CellStyle.SelectionForeColor = e.CellStyle.ForeColor;
            }
            DataGridViewRow thisRow = DGVRequest.Rows[e.RowIndex];
            switch (DGVRequest.Columns[e.ColumnIndex].Name)
            {
                case "colOrdQty":
                case "colCancelQty":
                case "colDealQty":
                    if (!thisRow.Cells["colECODE"].EditedFormattedValue.ToString().Contains("零股") &&
                         thisRow.Cells["colMtype"].EditedFormattedValue.ToString() != "E")
                    {
                        if (e.Value != null)
                            e.Value = int.Parse(e.Value.ToString()) * 1000;
                    }
                    break;
                case "colSide":
                    {
                        #region 更新買賣別顏色
                        if (e.Value != null && e.Value.ToString() == "B")
                        {
                            e.CellStyle.ForeColor = Color.Red;
                        }
                        else
                        {
                            e.CellStyle.ForeColor = Color.DodgerBlue;
                        }
                        break;
                        #endregion 更新買賣別顏色
                    }
            }
        }
        private void DGVEmstKeyIn_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null)
                e.Value = "";
            switch (DGVEmstOrder.Columns[e.ColumnIndex].Name)
            {
                case "dataGridViewTextBoxColumn2":
                    {
                        if (e.Value.ToString() == "I")
                            e.Value = "";
                        break;
                    }
                case "dataGridViewTextBoxColumn13"://失敗為紅色
                    {
                        if (e.Value.ToString().Contains("失敗"))
                        {
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn13"].Style.ForeColor = Color.Red;
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn13"].Style.SelectionForeColor = Color.Red;
                        }
                        else if (e.Value.ToString().Contains("成功") || e.Value.ToString().Contains("成交"))
                        {
                            e.Value = "成功";
                        }
                        break;
                    }
                case "dataGridViewTextBoxColumn12"://買賣顏色，B紅
                    {
                        if (e.Value.ToString() == "B")
                        {
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn12"].Style.ForeColor = Color.Red;
                            DGVEmstOrder.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn12"].Style.SelectionForeColor = Color.Red;
                        }
                        break;
                    }
                case "colDealQty_EMKeyIn":
                    {
                        if (e.Value.ToString() == "0")
                            e.Value = "";
                        else
                            e.Value = $"({String.Format("{0,8:N0}", e.Value)})";
                        break;
                    }
                case "colOrdQty_EMKeyIn":
                    {
                        if (e.Value.ToString() == "0")
                            e.Value = "";
                        break;
                    }
                case "dataGridViewTextBoxColumn11":
                    {
                        if (e.Value.ToString() == "0")
                            e.Value = "";
                        break;
                    }

            }
        }
        /// <summary>
        /// 委託回報畫面"篩選"按鈕按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFilterOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txbFilterDSEQ.Text) && string.IsNullOrEmpty(txbFilterCSEQ.Text))
                return;
            Predicate<Report> filter = r =>
            {
                bool result = true;
                if (!string.IsNullOrEmpty(txbFilterDSEQ.Text))
                    result = result && r.Stock == txbFilterDSEQ.Text;
                if (!string.IsNullOrEmpty(txbFilterCSEQ.Text))
                    result = result && r.CSEQ == txbFilterCSEQ.Text.PadLeft(7, '0');
                if (rbNoDeal.Checked)
                    result = result && r.DealQty == 0;
                else if (rbDeal.Checked)
                    result = result && r.DealQty > 0;
                return result;
            };
            回報View.ApplyFilter(filter);
            Update_DGVRequestFilter();
        }
        /// <summary>
        /// 委託回報畫面"清除"按鈕按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFilterClear_Click(object sender, EventArgs e)
        {
            txbFilterCSEQ.Text = "";
            txbFilterDSEQ.Text = "";
            labCount.Text = $"筆數：0";
            labRequestQty.Text = $"委託股數：0";
            labRequestAmt.Text = $"委託金額：0";
            labDealQty.Text = $"成交股數：0";
            labDealAmt.Text = $"成交金額：0";
            // DGVRequest.DataSource = null;
            回報View.ApplyFilter(item => false);
        }
        /// <summary>
        /// 更新委託回報畫面過濾條件
        /// </summary>
        /// <param name="filter"></param>
        private void Update_DGVRequestFilter()
        {
            if (tab_Request.SelectedIndex != 1 || (string.IsNullOrEmpty(txbFilterCSEQ.Text) && string.IsNullOrEmpty(txbFilterDSEQ.Text)))
                return;
            List<Report> newArray;
            lock (OrderStore._Lock)
            {
                newArray = OrderStore.回報List.Where(x => string.IsNullOrEmpty(txbFilterCSEQ.Text) ? x.CSEQ.Contains("") : x.CSEQ == txbFilterCSEQ.Text.PadLeft(7, '0'))
                                                                       .Where(x => string.IsNullOrEmpty(txbFilterDSEQ.Text) ? x.Stock.Contains("") : x.Stock == txbFilterDSEQ.Text)
                                                                       .Where(x => rbNoDeal.Checked ? x.DealQty == 0 : rbDeal.Checked ? x.DealQty > 0 : x.DealQty >= 0).ToList();
            }
            int 委託股數 = newArray.Where(r => r.Status != "失敗").Sum(report => report.ECode.Contains("零股") || report.MType == "E" ? report.OrdQty - report.CancelQty : (report.OrdQty - report.CancelQty) * 1000);
            int 委託金額 = (int)(newArray.Where(r => r.Status != "失敗").Sum(report => (report.OrdPrice == null ? 0 : report.OrdPrice == "市價" ? STMBStore.Get_SymbolInfo(report.Stock) != null ? STMBStore.Get_SymbolInfo(report.Stock).TPRICE : 0 : decimal.Parse(report.OrdPrice)) * (report.ECode.Contains("零股") || report.MType == "E" ? report.OrdQty - report.CancelQty : (report.OrdQty - report.CancelQty) * 1000)));
            int 成交股數 = newArray.Where(r => r.Status != "失敗").Sum(report => report.ECode.Contains("零股") || report.MType == "E" ? report.DealQty : report.DealQty * 1000);
            int 成交金額 = (int)(newArray.Where(r => r.Status != "失敗").Sum(report => report.DealPrice * (report.ECode.Contains("零股") || report.MType == "E" ? report.DealQty : report.DealQty * 1000)));
            labCount.Text = $"筆數：{newArray.Count.ToString("N0")}";
            labRequestQty.Text = $"委託股數：{委託股數.ToString("N0")}";
            labRequestAmt.Text = $"委託金額：{委託金額.ToString("N0")}";
            labDealQty.Text = $"成交股數：{成交股數.ToString("N0")}";
            labDealAmt.Text = $"成交金額：{成交金額.ToString("N0")}";
            DGVRequest_RowsUpdate();
        }
        /// <summary>
        /// 委託回報根據成交資訊過濾條件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rb_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
            btnFilterOK_Click(null, null);
        }
        /// <summary>
        /// 委託回報畫面"全選"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllSelect_Click(object sender, EventArgs e)
        {
            // if (IsAtEmstTab())
            //     _EMOrderStore.SetDeleSelectSwitch(true);
            // else
            _OrderStore.SetDeleSelectSwitch(true);
            DGVRequest.Refresh();
        }
        /// <summary>
        /// 委託回報畫面"取消"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllCancel_Click(object sender, EventArgs e)
        {
            // if (IsAtEmstTab())
            //     _EMOrderStore.SetDeleSelectSwitch(false);
            // else
            _OrderStore.SetDeleSelectSwitch(false);
            DGVRequest.Refresh();
        }
        /// <summary>
        /// 委託回報畫面"多筆刪單"按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultiDeleAllOK_Click(object sender, EventArgs e)
        {
            Logger.Info("[Order] 多筆刪單按鈕按下");
            DialogResult result = MessageBox.Show("確認是否刪除全選委託單", "多筆刪單確認", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                Logger.Info("[Order] 多筆刪單確認送出");
                var viewRows = DGVRequest.Rows.Cast<DataGridViewRow>()
                                          .Where(row => row.Cells["colCheckDelete"].EditedFormattedValue.Equals(true));
                foreach (DataGridViewRow row in viewRows)
                {
                    if (row.Cells["colMtype"].EditedFormattedValue.ToString() == "E")
                    {
                        string dseq = row.Cells["colDSEQ"].EditedFormattedValue.ToString();
                        var list = _OrderStore.GetReportInfoByDSEQ(dseq);
                        if (list != null)
                        {
                            Order order = _OrderStore.DataRowToEMOrder(list);
                            order.ExecType = "D";
                            int LaveQty = 0;
                            int.TryParse(list.LaveQty.ToString(), out LaveQty);
                            if (!_EMRiskControlHandler.CheckDelete(order, LaveQty))
                                return;
                            SendToSocket(_TradingSystemHandler.Order(order));
                        }
                    }
                    else
                    {
                        Order order = ComposeDeleteObject(row.Cells["colDSEQ"].EditedFormattedValue.ToString());
                        if (order != null)
                        {
                            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                            SendOut(OrderHandler.DeleteOrder(order));
                        }
                    }
                }
                _OrderStore.SetDeleSelectSwitch(false);
                DGVRequest.Refresh();
                // }

            }
            else
                Logger.Info("[Order] 多筆刪單取消送出");
        }
        /// <summary>
        /// 委託回報畫面欄位排序改變時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVRequest_Sorted(object sender, EventArgs e)
        {
            // if (IsAtEmstTab())
            //     DGVEmstRequest_RowsUpdate();
            // else
            DGVRequest_RowsUpdate();
        }
        /// <summary>
        /// 帳號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbFilterCSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txbFilterDSEQ.Focus();
        }
        /// <summary>
        /// 股票代號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbFilterDSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnFilterOK.Focus();
        }
        #endregion

        #region 成交回報勾單作業
        private void 更新勾單畫面()
        {
            if (tab_Request.SelectedIndex != 2)
                return;
            LabQueryDealTime.Text = $"查詢時間: {DateTime.Now.ToString("HH:mm:ss.fff")}";
            勾單View.ApplyFilter(r => r.ECode.Contains(_OrderStore.勾單篩選));
            if (勾單View.Count <= 0)
                return;
            勾單View.ApplySort("CheckStatus ASC,DSEQ DESC");
            Update_DGVCheckDealView();
        }
        /// <summary>
        /// 勾單畫面查詢功能
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_QueryDeal_Click(object sender, EventArgs e)
        {
            更新勾單畫面();
        }
        /// <summary>
        /// 勾單畫面DataGridView 按鍵事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVCheckDeal_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Y:
                case Keys.NumPad0:
                    #region Y鍵 / 數字鍵 0 (勾單作業)
                    {
                        DataGridViewRow row = ((DataGridView)sender).CurrentRow;
                        if (row == null)
                            return;
                        if (row.Index < 0)
                            return;
                        if (row.Cells["col_CheckStatus"].EditedFormattedValue.ToString() == "**")
                            return;
                        CheckDeal cd = _OrderStore.FindCheckDealBy勾單List(row.Cells["col_No"].EditedFormattedValue.ToString());
                        if (cd == null)
                            return;
                        string dseq = row.Cells["col_DSEQ"].EditedFormattedValue.ToString();
                        string no = row.Cells["col_No"].EditedFormattedValue.ToString();
                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(dseq)).Result;
                        if (report == null)
                        {
                            Logger.Error($"未查詢到對應委託- DSEQ: {dseq}");
                            return;
                        }
                        // 取得狀態
                        string status = "";
                        if (report.TimeInForce == "ROD")
                        {
                            status = report.Status == "完全成交" ? "**" : "*";
                        }
                        else
                        {
                            status = "**";
                        }
                        Logger.Debug("DSEQ=" + dseq + " status=" + report.Status);
                        row.Cells["col_CheckStatus"].Value = status;
                        // 資料庫作業
                        _SOrderSession.SendMessage($"35=40417={cd.tag17}54={cd.tag54}56={cd.tag56}60006={status}\n");
                        // string[] parameters = { no, report[0]["BHNO"].ToString(), dseq, status };
                        // HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_SCheckOrder", parameters);
                        // if (result.StatusCode != rCode.Success)
                        // {
                        //     Logger.Error($"勾單作業失敗: [{result.StatusCode}] {result.CodeDesc}");
                        //     ConcordLogger.Alert("9998", "勾單作業失敗", $"[{result.StatusCode}] {result.CodeDesc}");
                        // }
                        Btn_QueryDeal_Click(sender, e);
                        break;
                    }
                #endregion
                case Keys.F1:
                    #region 查詢回報數
                    {
                        ResetLabChkDealQCount();
                        DataGridViewRow row = ((DataGridView)sender).CurrentRow;
                        if (row == null)
                            return;
                        string dseq = row.Cells["col_DSEQ"].EditedFormattedValue.ToString();
                        string dprice = row.Cells["col_DPRICE"].EditedFormattedValue.ToString();
                        LabChkDealQDSEQ.Text = dseq;
                        LabChkDealQDSEQ.Visible = true;
                        LabChkDealQCount.Visible = true;
                        var rowCollection = _OrderStore.GetChkDealCount(dseq, dprice);
                        Logger.Info($"[DGVCheckDeal_KeyDown] 勾單查詢回報數:{rowCollection}筆");
                        if (rowCollection.Count == 0)
                        {
                            LabChkDealQCount.Text = "0";
                            return;
                        }
                        LabChkDealQCount.Text = rowCollection.Count.ToString();
                        for (int i = 0; i < rowCollection.Count; i++)
                        {
                            if (i == 5)
                                break;
                            var labList = _ChkDealQueryCountControls[i];
                            labList[0].Visible = true;
                            labList[1].Visible = true;
                            labList[1].Text = rowCollection[i].ToString();
                        }
                        LabCheckFinishInfo.Visible = GetCheckFinishStatus(dseq);
                        break;
                    }
                #endregion
                case Keys.Escape:
                    ResetLabChkDealQCount();
                    break;
            }
        }
        /// <summary>
        /// 勾單作業畫面盤別篩選功能
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVCheckDeal_radioButton_CheckedChanged(object sender, EventArgs e)
        {
            var rbtn = sender as RadioButton;
            if (!rbtn.Checked)
                return;
            _OrderStore.勾單篩選 = rbtn.Text;
            Logger.Info($"勾單篩選切換成: {_OrderStore.勾單篩選}");
            更新勾單畫面();
        }
        /// <summary>
        /// 更新勾單作業畫面
        /// </summary>
        private void Update_DGVCheckDealView()
        {
            foreach (DataGridViewRow row in DGVCheckDeal.Rows)
            {
                Color BackColor = row.Cells["col_BS"].EditedFormattedValue.ToString() == "買" ? Color.Red : Color.Blue;
                row.Cells["col_BS"].Style.BackColor = BackColor;
                row.Cells["col_DSEQ"].Style.BackColor = BackColor;
                row.Cells["col_DPRICE"].Style.BackColor = BackColor;
                row.Cells["col_DQTY"].Style.BackColor = BackColor;
            }
        }
        /// <summary>
        /// 確認勾單作業是否完成
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        private bool GetCheckFinishStatus(string DSEQ)
        {
            if (_OrderStore.查CheckStatus數量(DSEQ) == 0)
                return true;
            else
                return false;
        }
        private void ResetLabChkDealQCount()
        {
            LabChkDealQDSEQ.Visible = false;
            LabChkDealQCount.Visible = false;
            LabChkDealQT1.Visible = false;
            LabChkDealQR1.Visible = false;
            LabChkDealQT2.Visible = false;
            LabChkDealQR2.Visible = false;
            LabChkDealQT3.Visible = false;
            LabChkDealQR3.Visible = false;
            LabChkDealQT4.Visible = false;
            LabChkDealQR4.Visible = false;
            LabChkDealQT5.Visible = false;
            LabChkDealQR5.Visible = false;
            LabCheckFinishInfo.Visible = false;
        }
        #endregion

        #region 被動委託查詢畫面控制項
        public void PassiveSearch()
        {
            string cseq = "", symbol = "";
            Boolean check = false;
            if (!string.IsNullOrEmpty(txbPasFilterCSEQ.Text.Trim()))
                cseq = txbPasFilterCSEQ.Text.PadLeft(7, '0');
            if (!string.IsNullOrEmpty(txbPasFilterDSEQ.Text.Trim()))
                symbol = txbPasFilterDSEQ.Text;

            Customer cusInfo = CUMBStore.Get_CustomerInfo(cseq);
            if (cusInfo != null)
            {
                if ((!STMBStore.CheckContains(symbol)) && symbol != "")
                {
                    MessageBox.Show("無此股票代號");
                }
                else
                {
                    Logger.Debug($"[Query] 被動委託查詢-CSEQ: {cseq} Stock: {symbol}");
                    check = true;
                }
            }
            else
            {
                MessageBox.Show("未含有此帳號客戶");
            }

            if (check)
            {
                string[] parameters = { UserInfo._BHNO, cseq, symbol, "0" };
                HttpResponse result = HttpReqHandler.Get_HttpKeyInService("S_QTOrder2", parameters);

                if (result.StatusCode == rCode.Success)
                {
                    Logger.Debug(result.Deatils[0]);
                    _OrderStore.AddReport2(result.Deatils[0]);
                    DGVPasRequest_RowsUpdate();
                }
                else
                {
                    Logger.Error("載入被動委託查詢錯誤");
                }
                // _OrderStore.被動查詢List.Clear();
                // _SOrderSession.SendMessage($"35=2071={cseq}55={symbol}50002={UserInfo._EMNO}\n");
            }
        }


        private void btnPasFilterOK_Click(object sender, EventArgs e)
        {
            PassiveSearch();
        }

        private void btnPasFilterClear_Click(object sender, EventArgs e)
        {
            txbPasFilterDSEQ.Text = "";
            txbPasFilterCSEQ.Text = "";
            _OrderStore.被動查詢List.Clear();
            DGVPasRequest_RowsUpdate();
        }

        /// <summary>
        /// 委託查詢畫面"全選"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllSelect_Click(object sender, EventArgs e)
        {
            _OrderStore.SetPasDeleSelectSwitch(true);
            DGVPasRequest.Refresh();
        }
        /// <summary>
        /// 委託查詢畫面"取消"按扭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllCancel_Click(object sender, EventArgs e)
        {
            _OrderStore.SetPasDeleSelectSwitch(false);
            DGVPasRequest.Refresh();
        }
        /// <summary>
        /// 帳號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbPasFilterCSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txbPasFilterDSEQ.Focus();
        }
        /// <summary>
        /// 股票代號欄位輸入事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txbPasFilterDSEQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnPasFilterOK.Focus();
        }
        /// <summary>
        /// 鎖定打單畫面或KeyIn明細
        /// </summary>
        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F5:
                    {
                        if (currentFocus != 1)
                        {
                            tab_Order.Focus();
                            currentFocus = 1;
                        }
                    }
                    break;
                case Keys.PageUp:
                case Keys.PageDown:
                    {
                        if (currentFocus != 2)
                        {
                            tab_Request.Focus();
                            if (tab_Request.SelectedIndex == 0)
                            {
                                if (IsAtEmstTab())
                                    DGVEmstOrder.Focus();
                                else
                                    DGVKeyIn.Focus();
                            }
                            currentFocus = 2;
                        }
                    }
                    break;
                default:
                    currentFocus = 3;
                    break;
            }
        }
        /// <summary>
        /// 委託查詢畫面"多筆刪單"按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPasMultiDeleAllOK_Click(object sender, EventArgs e)
        {
            Logger.Info("[被動查詢] 多筆刪單按鈕按下");
            DialogResult result = MessageBox.Show("確認是否刪除全選委託單", "多筆刪單確認", MessageBoxButtons.OKCancel);
            Boolean check = false;
            if (result == DialogResult.OK)
            {
                Logger.Info("[被動查詢] 多筆刪單確認送出");
                var viewRows = DGVPasRequest.Rows.Cast<DataGridViewRow>()
                                          .Where(row => row.Cells["col_CheckDelete"].EditedFormattedValue.Equals(true));
                foreach (DataGridViewRow row in viewRows)
                {
                    Order order = PasComposeDeleteObject(row.Cells["col__DSEQ"].EditedFormattedValue.ToString());
                    if (order != null)
                    {
                        check = true;
                        _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                        SendOut(OrderHandler.DeleteOrder(order));
                    }
                }
                _OrderStore.SetPasDeleSelectSwitch(false);
                DGVPasRequest.Refresh();
                if (check)
                {
                    Thread.Sleep(1500);
                    PassiveSearch();
                }
            }
            else
                Logger.Info("[被動查詢] 多筆刪單取消送出");
        }
        /// <summary>
        /// 委託畫面欄位點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVPasRequest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == -1)
                return;
            string DSEQ = DGVPasRequest.CurrentRow.Cells["col__DSEQ"].EditedFormattedValue.ToString();
            if (DSEQ.Trim() == "")
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            switch (e.ColumnIndex)
            {
                case 0: // 勾選欄位
                    bool IsChoice = (bool)DGVPasRequest.CurrentRow.Cells["col_CheckDelete"].EditedFormattedValue;
                    DGVPasRequest.CurrentRow.Cells["col_CheckDelete"].Value = !IsChoice;
                    break;
                case 1:
                    {
                        #region 刪單按鈕
                        Logger.Info("[Order] 刪單扭按按下");
                        Order order = PasComposeDeleteObject(DSEQ);
                        if (order != null)
                        {
                            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                            SendOut(OrderHandler.DeleteOrder(order));
                            PassiveSearch();
                        }
                        #endregion
                        break;
                    }
                case 2:
                    {
                        #region 改量按鈕
                        Logger.Info("[Order] 改量扭按按下");
                        var report = Task.Run(() => _OrderStore.GetPasReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null)
                        {
                            _FrmChangeCheck.Init("ChgQty", report);
                        }
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改量錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
                case 3:
                    {
                        #region 改價按扭
                        Logger.Info("[Order] 改價扭按按下");
                        var report = Task.Run(() => _OrderStore.GetPasReportInfoByDSEQ(DSEQ)).Result;
                        if (report != null)
                        {
                            _FrmChangeCheck.Init("ChgPrice", report);
                        }
                        else
                        {
                            MessageBox.Show("未找到對應委託資訊", "改價錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            Logger.Error($"[frmChangeConfirm Init] 未找到對應委託單- DSEQ: {DSEQ}");
                        }
                        #endregion
                        break;
                    }
            }
        }

        private void rbPas_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
            if (rbPasNoDeal.Checked)
            {
                DGVPasRequest.DataSource = _OrderStore.被動查詢List.Where(x => x.DealQty == 0).ToList();
            }
            else if (rbPasDeal.Checked)
            {
                DGVPasRequest.DataSource = _OrderStore.被動查詢List.Where(x => x.DealQty > 0).ToList();
            }
            else
            {
                DGVPasRequest.DataSource = _OrderStore.被動查詢List;
            }
            // _PassiveRequestView.RowFilter = _DGVPasRequest_DealStatusFilter;
            DGVPasRequest_RowsUpdate();
        }

        /// <summary>
        /// 重繪委託查詢畫面
        /// </summary>
        private void DGVPasRequest_RowsUpdate()
        {
            int RequestQty = 0, DealQty = 0, Order = 0, Cancel = 0, Deal = 0;
            decimal RequestAmount = 0, DealAmount = 0, OrdPrice = 0, DealPrice = 0;

            foreach (DataGridViewRow row in DGVPasRequest.Rows)
            {
                if (row == null)
                    continue;
                #region 更新買賣別顏色
                if (row.Cells["col_Side"].EditedFormattedValue.ToString() == "B")
                    row.Cells["col_Side"].Style.ForeColor = Color.Red;
                else
                    row.Cells["col_Side"].Style.ForeColor = Color.DodgerBlue;

                #endregion
                #region 更新 刪量價 按扭欄位
                if ((row.Cells["col_STATUS"].EditedFormattedValue.ToString() != "成功" &&
                     row.Cells["col_STATUS"].EditedFormattedValue.ToString() != "部份成交") ||
                     row.Cells["Col__TimeInForce"].EditedFormattedValue.ToString() != "ROD")
                {
                    row.Cells["col_DeleteOrder"].Dispose();
                    row.Cells["col_DeleteOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["col_ChangeOrder"].Dispose();
                    row.Cells["col_ChangeOrder"] = new DataGridViewTextBoxCell();
                    row.Cells["col_ChangePrice"].Dispose();
                    row.Cells["col_ChangePrice"] = new DataGridViewTextBoxCell();
                }
                else
                {
                    row.Cells["col_DeleteOrder"].Dispose();
                    row.Cells["col_DeleteOrder"] = new DataGridViewButtonCell();
                    row.Cells["col_DeleteOrder"].Value = "刪";
                    row.Cells["col_ChangeOrder"].Dispose();
                    if (row.Cells["Col_LaveQty"].EditedFormattedValue.ToString() == "1000" ||
                        row.Cells["Col_LaveQty"].EditedFormattedValue.ToString() == "1")
                    {
                        row.Cells["col_ChangeOrder"].Dispose();
                        row.Cells["col_ChangeOrder"] = new DataGridViewTextBoxCell();
                    }
                    else
                    {
                        row.Cells["col_ChangeOrder"] = new DataGridViewButtonCell();
                        row.Cells["col_ChangeOrder"].Value = "量";
                    }
                    row.Cells["col_ChangePrice"].Dispose();
                    if (row.Cells["col__ECODE"].EditedFormattedValue.ToString() == "整股" &&
                        row.Cells["col_OrdPrice"].EditedFormattedValue.ToString() != "市價")
                    {
                        row.Cells["col_ChangePrice"] = new DataGridViewButtonCell();
                        row.Cells["col_ChangePrice"].Value = "價";
                    }
                    else
                    {
                        row.Cells["col_ChangePrice"] = new DataGridViewTextBoxCell();
                    }
                }
                #endregion
                if (row.Cells["col_STATUS"].EditedFormattedValue.ToString() == "失敗")
                    continue;
                if (row.Cells["col_OrdQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_OrdQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Order);
                if (row.Cells["col_CancelQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_CancelQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Cancel);
                if (row.Cells["col_DealQty"].EditedFormattedValue != null)
                    int.TryParse(row.Cells["col_DealQty"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands, null, out Deal);
                if (row.Cells["col_OrdPrice"].EditedFormattedValue != null)
                    decimal.TryParse(row.Cells["col_OrdPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out OrdPrice);
                if (row.Cells["col_DealPrice"].EditedFormattedValue != null)
                    decimal.TryParse(row.Cells["col_DealPrice"].EditedFormattedValue.ToString(), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint, null, out DealPrice);
                RequestQty += (Order - Cancel);
                DealQty += Deal;
                RequestAmount += (Order - Cancel) * OrdPrice; // RequestQty
                DealAmount += Deal * DealPrice;
            }
            labPasCount.Text = $"筆數：{DGVPasRequest.Rows.Count.ToString("N0")}";
            labPasRequestQty.Text = $"委託股數：{RequestQty.ToString("N0")}";
            labPasRequestAmt.Text = $"委託金額：{RequestAmount.ToString("N0")}";
            labPasDealQty.Text = $"成交股數：{DealQty.ToString("N0")}";
            labPasDealAmt.Text = $"成交金額：{DealAmount.ToString("N0")}";
        }

        /// <summary>
        /// 被動委託查詢畫面欄位排序改變時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DGVPasRequest_Sorted(object sender, EventArgs e)
        {
            DGVPasRequest_RowsUpdate();
        }

        #endregion

        #endregion

    }
}
