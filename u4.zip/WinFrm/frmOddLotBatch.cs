﻿using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmOddLotBatchOrder : Form
    {
        public int _OrderCount = 0;
        public bool _result = false;

        private bool _parser = false;

        public frmOddLotBatchOrder()
        {
            InitializeComponent();
        }

        private void frmOddLotBatchOrder_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    if (!int.TryParse(txtOrdCount.Text, out _OrderCount) || _OrderCount == 0)
                    {
                        MessageBox.Show("未輸入正確筆數，請重新輸入");
                        txtOrdCount.Focus();
                        txtOrdCount.SelectAll();
                    }
                    else
                    {
                        _result = true;
                        Hide();
                    }
                    break;
                case Keys.F5:
                    _result = false;
                    Hide();
                    break;
            }
        }

        private void frmOddLotBatchOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }

        private void txtOrdCount_TextChanged(object sender, System.EventArgs e)
        {
            if (!int.TryParse(txtOrdCount.Text, out _OrderCount))
            {
                txtOrdCount.Focus();
                txtOrdCount.SelectAll();
                return;
            }
            _parser = true;
        }

        private void frmOddLotBatchOrder_Shown(object sender, System.EventArgs e)
        {
            _parser = false;
            _result = false;
            _OrderCount = 0;
            txtOrdCount.Text = "0";
            txtOrdCount.Focus();
            txtOrdCount.SelectAll();
        }
    }
}
