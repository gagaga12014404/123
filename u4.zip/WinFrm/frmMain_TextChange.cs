﻿using Concord.SDK.Logging;
using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region 委託書號欄位相關事件
        private void TxbTERM_TextChanged(object sender, EventArgs e)
        {
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            order_ViewModel.TERM = ((TextBox)sender).Text;
        }
        private void TxbDSEQ_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (string.IsNullOrWhiteSpace(text))
                return;

            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            order_ViewModel.DSEQ = text;
        }
        #endregion
        #region 客戶帳號欄位相關事件
        /// <summary>
        /// 切換固定委託人帳號
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CkbFixedCSEQ_CheckedChanged(object sender, EventArgs e)
        {
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (((CheckBox)sender).Checked)
            {
                order_ViewModel.FixedCSEQ_Enable = true;
                EMRiskControlHandler._IsKeepCusAccount = true;
                RiskControlHandler._IsKeepCusAccount = true;
            }
            else
            {
                order_ViewModel.FixedCSEQ_Enable = false;
                EMRiskControlHandler._IsKeepCusAccount = false;
                RiskControlHandler._IsKeepCusAccount = false;
            }
        }
        /// <summary>
        /// 客戶帳號文字變動事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxbCSEQ_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            var viewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            // 相同值不做後續邏輯
            if (viewInfo.CSEQ == text)
                return;
            viewInfo.CSEQ = text;
            if (text.Length == 7)
            {
                if (_RiskControlHandler.TimeSharingPermissions(text))
                {
                    btn_OpenFrmTimeSharing.Visible = true;
                }
                Customer info = CUMBStore.Get_CustomerInfo(text);
                if (info != null)
                {
                    viewInfo.CSEQ = info.CSEQ;
                    viewInfo.CSEQ_Name = info.SNAME;
                    viewInfo.Sale = info.TSALE;
                    if (info.OType != "")
                    {
                        RiskControlHandler._CSEQChecked = false;
                        viewInfo.CCODE_Text = _CustomerStore.Get_CCODE_Text(info.OType);
                    }
                    else
                    {
                        RiskControlHandler._CSEQChecked = true;
                        viewInfo.CCODE_Text = "";
                    }
                    return;
                }
            }
            viewInfo.CCODE_Text = "";
            viewInfo.CSEQ_Name = "";
            viewInfo.Sale = "";
            btn_OpenFrmTimeSharing.Visible = false;
        }
        #endregion
        #region 委託類別欄位相關事件
        /// <summary>
        /// 委託類別資料異動事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxbOType_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            OrderTabViewModel order_Viewmodle = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (text == order_Viewmodle.OType)
                return;
            order_Viewmodle.OType = text;
            switch (order_Viewmodle.OType)
            {
                case "0":
                    order_Viewmodle.OType_Text = "現";
                    break;
                case "3":
                    order_Viewmodle.OType_Text = "資";
                    break;
                case "4":
                    order_Viewmodle.OType_Text = "券";
                    break;
                case "5":
                    order_Viewmodle.OType_Text = "借券5";
                    break;
                case "6":
                    order_Viewmodle.OType_Text = "借券6";
                    break;
                case "9":
                    if (order_Viewmodle.ECode == "0")
                        order_Viewmodle.OType_Text = "沖";
                    else
                    {
                        order_Viewmodle.OType = "0";
                        ((TextBox)sender).Focus();
                        ((TextBox)sender).SelectAll();
                    }
                    break;
                default:
                    order_Viewmodle.OType = "0";
                    ((TextBox)sender).Focus();
                    ((TextBox)sender).SelectAll();
                    return;
            }
            if (string.IsNullOrWhiteSpace(order_Viewmodle.CSEQ))
                return;
            MovedControlIndex(tab_Order.SelectedTab.Name, ((TextBox)sender).TabIndex, -1);
        }
        #endregion
        #region 股票代號欄位相關事件
        /// <summary>
        /// 股票代號輸入異動時事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxbStockNo_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            var viewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (viewInfo.Symbol == text)
                return;
            text = text.ToUpper();
            viewInfo.Symbol = text;
            if (text.Length >= 4)
            {
                OrderHandler.CheckStock(text, viewInfo.ECode);
                StockInfo info = new StockInfo();
                if (_RiskControlHandler.CheckSymbol(text, out info))
                {
                    // 將股票資訊寫入相關控制項
                    viewInfo.Symbol_MType = info.MTYPE;
                    viewInfo.Symbol_Name = info.CNAME;
                    switch (viewInfo.ECode)
                    {
                        case "0":
                        case "2":
                        case "3":
                        case "7":
                            viewInfo.Symbol_State = info.CreditTradeState;
                            viewInfo.StockWarnInfo = info.StockTradeState;
                            if (!_Setting.STOCK_DETAIL_INFO_ENABLE)
                                return;
                            HttpReqData data = new HttpReqData
                            {
                                ecode = viewInfo.ECode,
                                stock = info.STOCK
                            };
                            var result = HttpReqHandler.Get_CRDBQty_Service(data);
                            if (result[0].RespCode == "000")
                            {
                                //viewInfo.FinanceState = $"資張: {result[0].Crqty}   券張: {result[0].Dbqty}";
                                //viewInfo.FinanceState = JsonConvert.SerializeObject(result[0]);
                                var st = result[0];
                                var sb = new StringBuilder();
                                decimal iniCrdb;
                                if (!string.IsNullOrWhiteSpace(st.mark))
                                    sb.Append($"{st.mark.Trim()} ");
                                sb.Append("資");
                                if (!string.IsNullOrWhiteSpace(st.crmark1))
                                    sb.Append($"({st.crmark1.Trim()}%)");
                                sb.Append("：");
                                if (!string.IsNullOrWhiteSpace(st.crmark)
                                    && st.crmark.Trim() != "控"
                                    && !decimal.TryParse(st.crmark.Trim(), out iniCrdb))
                                    sb.Append($"{st.crmark.Trim()}");
                                else if (!string.IsNullOrWhiteSpace(st.Crqty))
                                {
                                    if (st.Crqty.Trim() == "999999")
                                        sb.Append("無限制");
                                    else
                                        sb.Append($"{st.Crqty.Trim()} 張");
                                    if (st.crmark.Trim() == "控")
                                        sb.Append("_控");
                                }
                                sb.Append("；");
                                sb.Append("券");
                                if (!string.IsNullOrWhiteSpace(st.dbmark1))
                                    sb.Append($"({st.dbmark1.Trim()}%)");
                                sb.Append("：");
                                if (!string.IsNullOrWhiteSpace(st.dbmark)
                                    && st.dbmark.Trim() != "控"
                                    && !decimal.TryParse(st.dbmark.Trim(), out iniCrdb))
                                    sb.Append($"{st.dbmark.Trim()}");
                                else if (!string.IsNullOrWhiteSpace(st.Dbqty))
                                {
                                    if (st.Dbqty.Trim() == "999999")
                                        sb.Append("無限制");
                                    else
                                        sb.Append($"{st.Dbqty.Trim()} 張");
                                    if (st.dbmark.Trim() == "控")
                                        sb.Append("_控");
                                }
                                viewInfo.FinanceState = sb.ToString();
                            }
                            else
                            {
                                Logger.Info($"[HttpReq-BOS] getcrdbQty 錯誤");
                                ConcordLogger.Alert("9999", "後台查詢剩餘資券張數服務錯誤", $"帶入參數- Stock: {info.STOCK} Ecode: {viewInfo.ECode}]");
                            }

                            #region 新後台查詢
                            #endregion
                            #region 帳中查詢
                            #endregion
                            break;
                    }
                    return;
                }
            }
            viewInfo.Symbol_MType = "";
            viewInfo.Symbol_Name = "";
            viewInfo.Symbol_State = "";
            viewInfo.FinanceState = "";
            viewInfo.StockWarnInfo = "";
        }
        #endregion
        /// <summary>
        /// 錯帳交易別欄位
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ER_TxbECode_TextChanged(object sender, EventArgs e)
        {
            TextBox this_Ctrol = (TextBox)sender;
            string text = this_Ctrol.Text;
            switch (text)
            {
                case "0":
                    ER_LabUnit.Text = "張";
                    ER_TxbOrdType.Enabled = true;
                    break;
                case "3":
                    ER_LabUnit.Text = "張";
                    ER_TxbPrice.Text = "收盤價";
                    ER_TxbOrdType.Enabled = false;
                    break;
                case "2":
                case "7":
                    ER_LabUnit.Text = "股";
                    ER_TxbOrdType.Enabled = false;
                    break;
                default:
                    this_Ctrol.Text = "0";
                    ER_LabUnit.Text = "張";
                    this_Ctrol.Focus();
                    this_Ctrol.SelectAll();
                    ER_TxbOrdType.Enabled = true;
                    return;
            }
            ER_LabECodeText.Text = StockInfoHandler.GetECodeText(text);
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            order_ViewModel.ECode = text;
            order_ViewModel.OType = "0";
        }
        #region 委託數量欄位相關事件
        private void TxbStockQty_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (order_ViewModel.OrderQty == text)
                return;
            order_ViewModel.OrderQty = ((TextBox)sender).Text;
            RiskControlHandler._OrdQtyChecked = false;
        }
        #endregion
        #region 委託價錢相關事件
        private void TxbPrice_TextChanged(object sender, EventArgs e)
        {
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (order_ViewModel.ECode == "3") // 定盤交易不驗證
                return;
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            order_ViewModel.OrderPrice = ((TextBox)sender).Text;
        }
        #endregion
        #region 委託條件相關事件
        private void TxbOrdType_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
            {
                ((TextBox)sender).Focus();
                ((TextBox)sender).SelectAll();
                return;
            }
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            order_ViewModel.TimeInForce = text;
            switch (order_ViewModel.TimeInForce)
            {
                case "0":
                    order_ViewModel.TimeInForce_Text = "ROD";
                    break;
                case "3":
                    order_ViewModel.TimeInForce_Text = "IOC";
                    break;
                case "4":
                    order_ViewModel.TimeInForce_Text = "FOK";
                    break;
                default:
                    order_ViewModel.TimeInForce = "0";
                    ((TextBox)sender).Focus();
                    ((TextBox)sender).SelectAll();
                    break;
            }
        }
        private void RL_TxbOrdType_Enter(object sender, EventArgs e)
        {
            Lab_OrdTypeInfo.Visible = true;
        }

        private void RL_TxbOrdType_Leave(object sender, EventArgs e)
        {
            Lab_OrdTypeInfo.Visible = false;
        }
        #endregion
        #region 營業員相關事件
        private void TxbSale_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            order_ViewModel.Sale = text;
        }
        #endregion
        #region 興櫃欄位輸入改變事件
        /// <summary>
        /// 興櫃股票異動事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EM_TxbStockNo_TextChanged(object sender, EventArgs e)
        {
            //利用textbox屬性CharacterCasing，轉大寫
            string text = ((TextBox)sender).Text;
            var viewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            viewInfo.Symbol = text;
            if (_EMRiskControlHandler.CheckStock(text.Trim()))
            {
                StockInfo stockInfo = STMBStore.Get_SymbolInfo(text.Trim());
                viewInfo.Symbol_Name = stockInfo.CNAME;
                viewInfo.Symbol_State = stockInfo.CreditTradeState;
                viewInfo.StockWarnInfo = stockInfo.StockTradeState;
                if (stockInfo.STYPE == "9")
                    viewInfo.Unit = "兩";
                else if (viewInfo.Unit == "兩")
                    viewInfo.Unit = "張";
                return;
            }
            viewInfo.Symbol_Name = "";
            viewInfo.Symbol_State = "";
            viewInfo.BasicPrice = "";
            viewInfo.StockWarnInfo = "";
        }
        private void EM_TxbStockQty_TextChanged(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            otvm.OrderQty = text;
            //EMRiskControlHandler._OrdQtyChecked = false;
        }
        private void EM_TxbStockPrice_TextChange(object sender, EventArgs e)
        {
            string text = ((TextBox)sender).Text;
            if (text.Length == 0)
                return;
            OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            otvm.OrderPrice = text;
        }
        #endregion 興櫃欄位輸入改變事件


    }
}
