﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmOddLotBatchDelete : Form
    {
        public int _Begin;
        public int _End;
        public bool _Result = false;

        private List<string> _DeleteDSEQ = new List<string>();

        public frmOddLotBatchDelete()
        {
            InitializeComponent();
        }

        private void frmOddLotBatchDelete_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    {
                        if (!int.TryParse(txtBegin.Text, out _Begin) || _Begin <= 0)
                        {
                            MessageBox.Show("起始未輸入正確序號，請重新輸入");
                            txtBegin.Focus();
                            txtBegin.SelectAll();
                            return;
                        }
                        if (!int.TryParse(txtEnd.Text, out _End) || _End <= 0)
                        {
                            MessageBox.Show("終止未輸入正確序號，請重新輸入");
                            txtEnd.Focus();
                            txtEnd.SelectAll();
                            return;
                        }
                        if (_Begin > _End)
                        {
                            MessageBox.Show("起始大於終止，請重新輸入");
                            return;
                        }
                        Hide();
                        break;
                    }
                case Keys.F5:
                    {
                        Hide();
                        break;
                    }
            }
        }

        // public List<string> GetDeleteDSEQ()
        // {
        //     if (_Result)
        //         return _DeleteDSEQ;
        //     else
        //         return null;
        // }

        private void frmOddLotBatchDelete_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }

        private void frmOddLotBatchDelete_Shown(object sender, System.EventArgs e)
        {
            _Begin = 0;
            _End = 0;
            txtBegin.Text = "0";
            txtEnd.Text = "0";
            txtBegin.Focus();
            txtBegin.SelectAll();
            _Result = false;
        }
    }
}
