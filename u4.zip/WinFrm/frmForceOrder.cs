﻿using Concord.SDK.Logging;
using Concord.SDK.Utility;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmForceOrder : Form
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        public Action<string> 驗證強制單密碼;
        /// <summary>
        /// 是否確認完成
        /// </summary>
        public bool _Command = false;

        public frmForceOrder()
        {
            InitializeComponent();
        }

        public void Init()
        {
            TxbPassword.Text = "";
            _Command = false;
        }

        private void BtnPasswordCheck_Click(object sender, EventArgs e)
        {
            驗證強制單密碼(TxbPassword.Text);
            // string[] parameters = { $"845{UserInfo._BHNO}", TxbPassword.Text };
            // HttpResponse result = HttpReqHandler.Get_HttpKeyInService("SYS_CheckPWD", parameters);
            // if (result.StatusCode != rCode.Success)
            // {
            //     MessageBox.Show(result.CodeDesc, "密碼錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //     Logger.Info($"[Order] 萬能強制確認視窗 確認失敗: {result.CodeDesc}");
            // }
            // else
            // {
            //     Logger.Info("[Order] 萬能強制確認視窗 確認送出");
            //     _Command = true; ;
            //     Hide();
            // }
        }
        public void 取得結果(string status)
        {
            Invoke((Action)(() =>
            {
                if (status != "0")
                {
                    MessageBox.Show(status, "密碼錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Logger.Info($"[Order] 萬能強制確認視窗 確認失敗: {status}");
                }
                else
                {
                    Logger.Info("[Order] 萬能強制確認視窗 確認送出");
                    _Command = true;
                    Hide();
                }
            }));
        }
        private void BtmCancel_Click(object sender, EventArgs e)
        {
            Logger.Info("[Order] 萬能強制確認視窗 取消委託");
            _Command = false;
            Hide();
        }
    }
}
