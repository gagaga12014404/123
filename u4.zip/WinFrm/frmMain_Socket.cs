﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        #region Socket

        #region Stock Order Gateway Session
        private void OnOrderConnected()
        {
            Logger.Info($"[OnOrderConnected] 連線成功 IP:{_ServerIP}");
            Logger.Info($"[Login OnOrderConnected] 送出註冊電文");
            string thisVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString();
            SendToSocket(SocketSessionHandler.ComposeSubscribeMessage("88"));
            Logger.Info($"[OnOrderConnected] 送出回補電文(理論上不會用到)");
            //送出回補
            SendToSocket(_TradingSystemHandler.Recover($"845{UserInfo._BHNO}", UserInfo._EMTERM));//送出回補電文
            //402是營業員，根本沒用到
            BeginInvoke((Action)(() =>
            {
                RL_LabOrdErrMsg.Visible = false;
                OD_LabOrdErrMsg.Visible = false;
                FP_LabOrdErrMsg.Visible = false;
                SB_LabOrdErrMsg.Visible = false;
                tslSOrderSend.Text = "上市櫃下單連線成功";
                tslSOrderSend.ForeColor = Color.Green;
                tslPushServer.Text = "回報連線成功";
                tslPushServer.ForeColor = Color.Green;
                EmTradingCheck.ForeColor = Color.Green;
                EmTradingCheck.Text = "興櫃連線成功";
            }));
        }
        private void OnOrderConnectFail(string failMsg)
        {
            Logger.Error($"[OnOrderConnectFail] 連線失敗 IP:{_ServerIP}");
            BeginInvoke((Action)(() =>
            {
                RL_LabOrdErrMsg.Visible = true;
                OD_LabOrdErrMsg.Visible = true;
                FP_LabOrdErrMsg.Visible = true;
                SB_LabOrdErrMsg.Visible = true;
                tslSOrderSend.Text = "上市櫃下單連線失敗";
                tslSOrderSend.ForeColor = Color.Red;
                tslPushServer.Text = "回報連線失敗";
                tslPushServer.ForeColor = Color.Red;
                EmTradingCheck.ForeColor = Color.Red;
                EmTradingCheck.Text = "興櫃連線失敗";
            }));
        }
        private int 取得回補數量(string message)
        {
            int total = 0;

            // 根據分隔符號進行分割
            string[] parts = message.Split('|');

            // 遍歷分割後的部分
            foreach (string part in parts)
            {
                Console.WriteLine(part);
                // 根據冒號進行分割
                string[] keyValue = part.Split(':');
                // 檢查是否有兩個部分
                if (keyValue.Length == 2)
                {
                    // 解析值並加總
                    int value = 0;
                    int.TryParse(keyValue[1], out value);
                    total += value;
                }
            }
            return total;
        }
        private Report 處理回報(Dictionary<int, string> fix_msg, string 市場別, string is假單)
        {
            //防呆
            if (!fix_msg.ContainsKey(117) || fix_msg[117].Trim() == "" || !fix_msg.ContainsKey(55))
            {
                Logger.Error($"[回報] 缺少(117委託書號)或(55股票代號)");
                return null;
            }
            Logger.Info($"===================={is假單} [{市場別}] 委託書號：{fix_msg[117]} 處理回報開始====================");
            Logger.Info($"{is假單} [{市場別}] 委託書號:{fix_msg[117]} Parse開始");
            Report report = _OrderStore.ParseReport(fix_msg);
            if (report == null)
            {
                Logger.Error($"{is假單} [{市場別}] 委託書號:{fix_msg[117]} Parse to Report失敗");
                return null;
            }
            if (is假單 != "假單" && !_OrderStore.TryAdd唯一值(report.唯一值))
            {
                Logger.Warn($"{is假單} [{市場別}] 唯一值:{report.唯一值} 重複回報 委託書號:{report.DSEQ}");
                return null;
            }
            Logger.Info($"{is假單} [{市場別}] Parse成功 新刪改?:{report.ExecType} 委託書號:{report.DSEQ} 狀態:{report.Status} 委託數量:{report.OrdQty} 委託價錢:{report.OrdPrice}");
            if (UserInfo._EMNO == fix_msg[50002].Trim())
                _OrderStore._OrdDSEQ.TryAdd(report.DSEQ, "");
            if ("市場別" != "E" && (UserInfo._TRAM == report.DSEQ.Substring(0, 1) || UserInfo._TRAM == "Z" || report.DSEQ.Substring(0, 1) == "Q"))
                _OrderStore._OrdDSEQ.TryAdd(report.DSEQ, "");
            Logger.Info($"{is假單} [{市場別}] 上市櫃Queue Enqueue");
            return report;
        }
        private void 風控錯誤(Dictionary<int, string> fix_msg)
        {
            _OrderStore.空的才能下單.TryRemove(fix_msg[117], out var removedValue);
            if (_OrderStore.分時分量的單.TryRemove(fix_msg[117], out var tmp))
            {
                return;
            }
            if (!_OrderStore._OrdDSEQ.ContainsKey(fix_msg[117]) && !fix_msg[117].Contains("Q"))//防呆，自己的單或錯帳再處理
                return;
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(fix_msg[55].Trim());
            if (fix_msg[80004] == "0")//假單電文，理論上只有我下的單才會假單
            {
                Report report = 處理回報(fix_msg, stockInfo.MTYPE, "假單");
                if (report == null)
                {
                    Logger.Error($"[假單] 處理失敗");
                    return;
                }
                if (_OrderStore.Get明細InfoByDSEQ(report.DSEQ + report.ClOrdID) != null)
                {
                    Logger.Error($"dseq = {report.DSEQ}, ClOrdID = {report.ClOrdID}, OrigClOrdID={report.OrigClOrdID} 重複訊息序號會造成程式死掉");
                    return;
                }
                if (report.ExecType == "I")
                    report.LaveQty = 0;
                report.Status = "送出";
                Logger.Info("[假單] Queue Enqueue");
                _OrderStore._OrdDSEQ.TryAdd(report.DSEQ, "");
                _OrderStore.下單Queue.Add(report);
                if (stockInfo.MTYPE == "E")//興櫃
                {
                    if (report.ExecType == "I" && report.CSEQ == "0003332")
                        _OrderStore.ErrAccountOrderNoAdd1(report.DSEQ);
                    else if (report.ExecType == "I")
                        _OrderStore.OrderNoAdd1(report.DSEQ);
                    BeginInvoke((Action)(() =>
                    {
                        if (IsAtEmstTab())
                            ResetEMOrder(false);//_Setting.ORDER_SUCCESS_CLEAR
                        if (EM_CkbFixedCSEQ.Checked)//固定委託人 && 客戶過風控
                        {
                            FocusTxb("TxbStockNo");
                        }
                        else if (tab_Order.SelectedTab.Name == "EmstErrAccount")
                        {
                            FocusTxb("TxbStockNo");
                        }
                        else if (_Setting.ORDER_SUCCESS_CLEAR)
                        {
                            FocusTxb("TxbDSEQ");
                        }
                    }));
                }
                else//上市櫃
                {
                    if (report.DSEQ.Substring(0, 1) == "Z")
                        _OrderHandler.FuncDSEQAdd1(report.DSEQ);
                    else
                        _OrderHandler.GetNowDSEQ(report.DSEQ);
                    BeginInvoke((Action)(() =>
                    {
                        if (!IsAtEmstTab() && !onControlClearDict.TryRemove(report.DSEQ, out var result))
                            OrdControlClear();//_Setting.ORDER_SUCCESS_CLEAR
                        btn_OpenFrmTimeSharing.Visible = false;
                    }));
                    送出拆單(report.ExecType);
                }
                return;
            }
            else if (stockInfo.MTYPE == "E" && _EMRiskControlHandler.systemError(fix_msg[80004]))//系統錯誤，特別處理
            {
                Report report = _OrderStore.ParseReport(fix_msg);
                if (report != null)
                {
                    _OrderStore._OrdDSEQ.TryAdd(report.DSEQ, "");
                    report.Status = "失敗";
                    report.LaveQty = 0;
                    if (_OrderStore._OrdDSEQ.ContainsKey(report.DSEQ))
                    {
                        _OrderStore.下單Queue.Add(report);
                    }
                    BeginInvoke((Action)(() =>
                   {
                       if (IsAtEmstTab())
                           ResetEMOrder(false);//_Setting.ORDER_SUCCESS_CLEAR
                   }));
                }
            }
            else//風控錯誤
            {
                BeginInvoke((Action)(() =>
                {
                    if (_ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name).ChageQtyModel)
                        FocusTxb("TxbStockQty");
                    else
                        FocusTxb("TxbPrice");
                    OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                    bool canBeForced = false;
                    if (stockInfo.MTYPE == "E")
                    {
                        canBeForced = _EMRiskControlHandler.CheckCanBeForced(fix_msg[80004], fix_msg[100]);
                        order_ViewModel.OrdInfoText = fix_msg[80014] + (canBeForced ? " SF8強行" : "");
                        order_ViewModel.ForceBtnVisable = canBeForced;
                    }
                    else
                    {
                        canBeForced = _RiskControlHandler.CheckCanBeForced(fix_msg[80004], fix_msg[100]);
                        order_ViewModel.OrdInfoText = fix_msg[80014] + (canBeForced ? " SF8強行" : "");
                        ShowLabInfo(tab_Order.SelectedTab.Name, true);
                        order_ViewModel.ForceBtnVisable = true;
                    }
                }));
            }
        }
        private void OnReceveivedOrdSendGW(string message)
        {
            Logger.Info($"[OnReceveivedOrdSendGW] 收到 花費時間：{_OrderStore.Test_Timer.Elapsed}");
            _SendMessage_Timer.Enabled = false;//收到就停止timer
            Dictionary<int, string> fix_msg = SocketSessionHandler.ParserMessageToDic(message, '\u0001');
            Logger.Info($"[frmMain OnReceveivedOrdSendGW] 收到:{message}");
            if (!fix_msg.ContainsKey(35))
            {
                if (message.Substring(0, 5) == "order")
                {
                    _OrderStore.回補數量 = 取得回補數量(message);
                    Logger.Info($"[frmMain OnReceveivedOrdSendGW] 回補數量:{_OrderStore.回補數量}");
                    //這裡是回補要判斷
                }
                else
                    Logger.Error($"[frmMain OnReceveivedOrdSendGW] 接收錯誤格式訊息: {message.Replace("\n", "")}");
                return;
            }
            try
            {
                switch (fix_msg[35])
                {
                    case "0": // 心跳訊息
                        break;
                    case "89":
                        {
                            _OrderHandler.DSEQ = int.Parse(fix_msg[116].Substring(1)) + 1;
                            _OrderStore.興櫃委託書號 = int.Parse(fix_msg[117].Substring(1)) + 1;
                            break;
                        }
                    case "90287":
                    case "90387":
                    case "902": // 委託回報相關電文
                    case "903":
                    case "820":
                    case "824":
                    case "840":
                        {
                            Report report = 處理回報(fix_msg, "OTC", "");
                            if (report == null)
                            {
                                Logger.Error($"====================[上市櫃] 處理失敗====================");
                                return;
                            }
                            _OrderStore.下單Queue.Add(report);
                            if (report.DSEQ.Substring(0, 1) == "Z")
                                _OrderHandler.FuncDSEQAdd1(report.DSEQ);
                            else
                                _OrderHandler.GetNowDSEQ(report.DSEQ);
                            break;
                        }
                    case "LastFill":
                        BeginInvoke((Action)(() => Lab_TodayLastFill.Visible = true));
                        break;
                    case "2087":
                    case "20": // 興櫃委託回報相關電文
                    case "2487":
                    case "24":
                        {
                            Report report = 處理回報(fix_msg, "E", "");
                            if (report == null)
                            {
                                Logger.Error($"====================[興櫃] 處理失敗====================");
                                return;
                            }
                            _OrderStore.下單Queue.Add(report);
                            if (report.ExecType == "I" && report.CSEQ == "0003332")
                                _OrderStore.ErrAccountOrderNoAdd1(report.DSEQ);
                            else if (report.ExecType == "I")
                                _OrderStore.OrderNoAdd1(report.DSEQ);
                            break;
                        }
                    case "40":
                        {
                            #region 風控錯誤
                            if (!fix_msg.ContainsKey(80004) || !fix_msg.ContainsKey(100) || !fix_msg.ContainsKey(55))
                                return;
                            風控錯誤(fix_msg);
                            break;
                            #endregion
                        }
                    case "301":
                        {
                            #region 股票委檢
                            BeginInvoke((Action)(() =>
                            {
                                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (fix_msg[80004] != "0")
                                {
                                    otvm.OrdInfoText = fix_msg[80014];
                                    FocusTxb("TxbStockNo");
                                }
                                else
                                {
                                    otvm.OrdInfoText = "";
                                    otvm.BasicPrice = fix_msg[67];
                                    // _EMRiskControlHandler.GetStockNoChecked = true;
                                }
                            }));
                            break;
                            #endregion
                        }
                    case "403":
                        {
                            string[] data = fix_msg[87].Split('|');
                            string open_time = data[1].Substring(0, 2) + data[1].Substring(3, 2);
                            string close_time = data[2].Substring(0, 2) + data[2].Substring(3, 2);
                            Logger.Debug($"{data[0]} {open_time} {close_time} {data[3]}");
                            _OrderHandler.Set_Trade_Time(data[0], open_time, close_time, "True");
                            break;
                        }
                    case "405":
                        {
                            回傳強制單密碼(fix_msg[80004]);
                            break;
                        }
                    default:
                        Logger.Warn($"[OnReceveivedOrdSendGW] 接收至不明類別訊息: {message.Replace("\n", "")}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[OnReceveivedOrdSendGW] {ex}");
            }

        }
        private void OnSendToOrdSendGW(string message)
        {
            Logger.Info($"[OnSendToOrdSendGW] 送出:{message.Replace("\n", "")}");
        }
        private void OnSendToOrdSendGWFail(string message)
        {
            Logger.Info($"[OnSendToOrdSendGWFail] 送出失敗:{message.Replace("\n", "")}");
        }
        #endregion

        #region Session Heart Beat(Timer call back event)
        private void SessionHeartbeat(object obj, ElapsedEventArgs e)
        {
            if (_SOrderSession.ClientConnectState == ConnectState.Connected)
            {
                _SOrderSession.SendMessage(SocketSessionHandler.ComposeHeartBeatMessage());
            }
        }
        #endregion

        #region SendMessage Timer
        private void SendMessageTimer(object obj, ElapsedEventArgs e)
        {
            _SendMessage_Timer.Enabled = false;
            // MessageBox.Show("興櫃接收訊息逾時，請通知資訊部", "系統異常", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        #endregion

        #endregion

    }
}
