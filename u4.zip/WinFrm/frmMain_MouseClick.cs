﻿using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region 滑鼠點擊事件
        private void panel_RoundLot_MouseClick(object sender, MouseEventArgs e)
        {
            RL_TxbCSEQ.Focus();
            RL_TxbCSEQ.SelectAll();
        }

        private void panel_OddLot_MouseClick(object sender, MouseEventArgs e)
        {
            OD_TxbCSEQ.Focus();
            OD_TxbCSEQ.SelectAll();
        }

        private void panel_FixedPrice_MouseClick(object sender, MouseEventArgs e)
        {
            FP_TxbCSEQ.Focus();
            FP_TxbCSEQ.SelectAll();
        }

        private void panel_StockBorrow_MouseClick(object sender, MouseEventArgs e)
        {
            SB_TxbCSEQ.Focus();
            SB_TxbCSEQ.SelectAll();
        }

        private void panel_StockPurchase_MouseClick(object sender, MouseEventArgs e)
        {
            SP_TxbCSEQ.Focus();
            SP_TxbCSEQ.SelectAll();
        }

        private void panel_StockPurchase2_MouseClick(object sender, MouseEventArgs e)
        {
            SP2_TxbCSEQ.Focus();
            SP2_TxbCSEQ.SelectAll();
        }

        private void panel_StockAuction_MouseClick(object sender, MouseEventArgs e)
        {
            SA_TxbCSEQ.Focus();
            SA_TxbCSEQ.SelectAll();
        }

        private void panel_ErrAccout_MouseClick(object sender, MouseEventArgs e)
        {
            ER_TxbECode.Focus();
            ER_TxbECode.SelectAll();
        }
        private void panel_Emst_MouseClick(object sender, MouseEventArgs e)
        {
            FocusTxb("TxbDSEQ");
        }
        private void panel_EmstErrAccount_MouseClick(object sender, MouseEventArgs e)
        {
            EMER_TxbStockNo.Focus();
            EMER_TxbStockNo.SelectAll();
        }
        #endregion

    }
}
