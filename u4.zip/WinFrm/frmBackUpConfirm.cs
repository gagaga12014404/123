﻿using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmBackUpConfirm : Form
    {
        public bool _Pass = false;

        public frmBackUpConfirm()
        {
            InitializeComponent();
        }

        private void frmBackUpConfirm_Load(object sender, EventArgs e)
        {
            Cob_BHNO.Items.AddRange(new string[] { "8450總公司", "8451延平", "8455台中", "8456新竹", "8458台南", "8459嘉義", "845A內湖", "845B永和", "845D板橋", "845E澎湖", "845F仁愛", "845J高雄", "845R石牌", "845S南崁", "845U台北", "845X屏東" });
            Cob_BHNO.SelectedIndex = 0;
        }

        private void Btn_OK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Cob_BHNO.SelectedItem.ToString()))
            {
                MessageBox.Show("請選擇預備援之分公司");
                return;
            }
            // 改寫原先分公司值
            string bhno = Cob_BHNO.SelectedItem.ToString().Split('|')[0];
            UserInfo._BHNO = bhno.Substring(3, 1);
            _Pass = true;
            Hide();
        }

        private void frmBackUpConfirm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
    }
}
