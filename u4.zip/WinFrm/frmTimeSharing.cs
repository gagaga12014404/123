﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Concord.SDK.Logging;
using System.Reflection;

namespace Concord.KeyIn.Client
{

    public partial class frmTimeSharing : Form
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        BindingList<Strategy> strategyList;
        BindingList<Details> detailsList;
        List<Order> orderList;
        Order tmp;
        List<Thread> threadList = new List<Thread>();
        private int previousLength = 0;
        private bool isOpen = false;
        /// <summary>
        /// 下單給main 參數:order,價格,數量,買賣別
        /// </summary>
        public Action<Order, string, string, string> _AskMainToSend;

        public frmTimeSharing()
        {
            InitializeComponent();
            strategyList = new BindingList<Strategy>();
            detailsList = new BindingList<Details>();
            tmp = new Order();
            dataGridView1.DataSource = strategyList;
            dataGridView2.DataSource = detailsList;
            DoubleBuffered(dataGridView1, true);
            DoubleBuffered(dataGridView2, true);
            orderList = new List<Order>();
            threadList = new List<Thread>();
        }

        public void Init(Order order)
        {
            tmp = order;
            txb_total.Text = order.OrdQty.ToString();
            isOpen = true;
            txb_cseq.Text = order.CSEQ;
            Customer info = CUMBStore.Get_CustomerInfo(order.CSEQ);
            lbl_cseqName.Text = info.SNAME;
            txb_stock.Text = order.Symbol;
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(order.Symbol);
            lbl_stockName.Text = stockInfo.CNAME;
            txb_ROD.Text = GetROD(order.TimeInForce);
            txb_price.Text = order.OrdPrice;
            switch (order.OType)
            {
                case "0":
                    if (order.DayTradeFlag == "Y")
                        txb_otype.Text = "9沖";
                    else
                        txb_otype.Text = "0現";
                    break;
                case "3":
                    txb_otype.Text = "3資";
                    break;
                case "4":
                    txb_otype.Text = "4券";
                    break;
                case "5":
                    txb_otype.Text = "借券5";
                    break;
                case "6":
                    txb_otype.Text = "借券6";
                    break;
                case "9":
                    if (order.ECode == "0")
                        txb_otype.Text = "9沖";
                    break;
            }
            txb_single.Select();
        }
        private string GetROD(string TimeInForce)
        {
            string result = "";
            switch (TimeInForce)
            {
                case "0":
                    result = "ROD";
                    break;
                case "3":
                    result = "IOC";
                    break;
                case "4":
                    result = "FOK";
                    break;
            }
            return result;
        }
        private void btn_buy_Click(object sender, EventArgs e)
        {
            if (!SimpleRiskControl())
                return;
            NewS(Side.BUY);
        }

        private void btn_sell_Click(object sender, EventArgs e)
        {
            if (!SimpleRiskControl())
                return;
            NewS(Side.SELL);
        }
        private void NewS(Side side)
        {
            Logger.Info($"分時分量新單 {(Side)side}按下");
            #region 筆數整除防呆
            //因為total % single不一定是整數，所以不用txb_totalDivideBySingle
            int single = 0;
            int.TryParse(txb_single.Text, out single);
            int total = 0;
            int.TryParse(txb_total.Text, out total);
            if (single == 0 || total == 0)
                return;
            if (total % single != 0)
            {
                Logger.Info($"單量:{single} 無法被 總量:{total} 整除");
                MessageBox.Show($"單量:{single} 無法被 總量:{total} 整除", "單量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            #endregion
            string title = side == Side.BUY ? "買進" : "賣出";
            string messagebox_price = txb_price.Text;
            if (txb_price.Text == "0")
                messagebox_price = "市價";
            DialogResult OK = MessageBox.Show($"確認是否新增策略\n股票：{txb_stock.Text} {lbl_stockName.Text}\n價格：{messagebox_price}\n總量：{txb_total.Text}\n開始時間：{txb_start.Text}", title, MessageBoxButtons.OKCancel, MessageBoxIcon.None, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
            if (OK == DialogResult.OK)
            {
                if (!SimpleRiskControl())//如果確認猶豫了很久，有可能時間已經過了
                    return;
                tmp.OrdPrice = txb_price.Text;
                tmp.OrdQty = int.Parse(txb_single.Text);
                tmp.Side = side;
                Strategy strategy = new Strategy();
                if (side == Side.BUY)
                    strategy.buySell = "買進";
                else if (side == Side.SELL)
                    strategy.buySell = "賣出";
                else
                    return;
                #region 新增策略
                strategy.Cancel = "取消";
                strategy.cseq = tmp.CSEQ;
                Customer info = CUMBStore.Get_CustomerInfo(strategy.cseq);
                strategy.cseqName = info.SNAME;
                strategy.stock = tmp.Symbol;
                StockInfo stockInfo = STMBStore.Get_SymbolInfo(strategy.stock);
                strategy.stockName = stockInfo.CNAME;
                if (txb_price.Text == "0")
                    strategy.orderPrice = "市價";
                else
                    strategy.orderPrice = txb_price.Text;
                strategy.submitCount = "0";
                strategy.total = txb_total.Text;
                strategy.deleteCount = "0";
                strategy.start = txb_start.Text;
                DateTime timeStart = DateTime.ParseExact(strategy.start, "HH:mm:ss", null);
                TimeSpan all = TimeSpan.FromSeconds(double.Parse(txb_each.Text) * (total / single));//結束時間，不需要-1
                strategy.end = (timeStart + all).ToString("HH:mm:ss");
                strategy.number = (strategyList.Count + 1).ToString();
                strategy.status = "執行中";
                strategy.ROD = GetROD(tmp.TimeInForce);
                strategyList.Add(strategy);
                orderList.Add(tmp);//這個order是按下分時分量時，跟F1一樣composeNewOrder出來的，這個畫面僅能更改"價格"、"委託量(是單量)、買或賣"
                Logger.Info($"分時分量新增策略{strategy.number}");
                #endregion
                #region 該策略的所有單
                int startNumber = detailsList.Count;
                for (int i = 0; i < total / single; i++)
                {
                    Details details = new Details();
                    details.number = (detailsList.Count + 1).ToString();
                    details.buySell = strategy.buySell;
                    details.cseq = strategy.cseq;
                    details.cseqName = strategy.cseqName;
                    details.stock = strategy.stock;
                    details.stockName = strategy.stockName;
                    details.orderPrice = strategy.orderPrice;//市價就填市價
                    details.orderQty = txb_single.Text;
                    TimeSpan timeSpan = TimeSpan.FromSeconds(double.Parse(txb_each.Text) * i);
                    details.orderTime = (timeStart + timeSpan).ToString("HH:mm:ss");
                    details.status = "未送單";
                    detailsList.Add(details);
                    Logger.Info($"分時分量新增委託單 編號={details.number} 帳號={details.cseq} 股票={details.stock} 價={details.orderPrice} 量={details.orderQty}");
                }
                int endNumber = detailsList.Count - 1;
                #endregion
                #region 新增thread
                Thread newThread = new Thread(() => prepareToSendOrder(startNumber, endNumber, strategyList.Count - 1));//strategyList.Count - 1=n，就是策略第n筆=thread的第n筆=orderList的第n筆
                threadList.Add(newThread);
                newThread.Start();
                Logger.Info($"Thread建立 策略：{strategyList.Count} Thread編號：{threadList.Count}");
                #endregion
            }
        }
        private void prepareToSendOrder(int startNumber, int endNumber, int n)
        {
            int start = startNumber;
            while (start <= endNumber)
            {
                DateTime now = DateTime.Now;
                DateTime d1 = DateTime.ParseExact(detailsList[start].orderTime, "HH:mm:ss", null);
                if (now > d1)
                {
                    _AskMainToSend(orderList[n], detailsList[start].orderPrice, detailsList[start].orderQty, detailsList[start].buySell);
                    detailsList[start].status = "已送出";
                    strategyList[n].submitCount = (int.Parse(strategyList[n].submitCount) + int.Parse(detailsList[start].orderQty)).ToString();
                    if (isOpen)
                    {
                        Invoke((Action)(() =>
                        {
                            dataGridView1.Refresh();
                            dataGridView2.Refresh();
                        }));
                    }
                    start++;
                }
                else
                    SpinWait.SpinUntil(() => false, 10);
            }
            strategyList[n].status = "結束";
            strategyList[n].Cancel = "";
            if (isOpen)
            {
                Invoke((Action)(() =>
                {
                    dataGridView1.Rows[n].Cells["colCancel"].Dispose();
                    dataGridView1.Rows[n].Cells["colCancel"] = new DataGridViewTextBoxCell();
                    dataGridView1.Refresh();
                }));
            }
        }
        /// <summary>
        /// 簡易下單風控
        /// </summary>
        /// <returns></returns>
        private bool SimpleRiskControl()
        {
            //1.時間格式有無錯誤
            DateTime result;
            if (!DateTime.TryParseExact(txb_start.Text, "HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out result))
            {
                Logger.Warn($"輸入時間格式有誤 輸入時間：{txb_start.Text}");
                MessageBox.Show($"輸入時間格式有誤 輸入時間：{txb_start.Text}", "時間風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            //2.可能要空開始時間?
            DateTime now = DateTime.Now;
            if (now > result)
            {
                Logger.Warn($"輸入時間需大於現在時間 輸入時間：{txb_start.Text}");
                MessageBox.Show($"輸入時間需大於現在時間", "時間風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            //3.欄位不能是空白
            if (txb_price.Text == "" || txb_single.Text == "" || txb_total.Text == "" || txb_totalDivideBySingle.Text == "" || txb_each.Text == "")
            {
                Logger.Warn($"有欄位是空白");
                MessageBox.Show($"有欄位是空白，請確認所有欄位均填入數值", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            //4.數量小於或等於0
            decimal price, each;
            int single_qty, total_qty;
            if (!decimal.TryParse(txb_price.Text, out price) || !int.TryParse(txb_single.Text, out single_qty) || !int.TryParse(txb_total.Text, out total_qty) || !decimal.TryParse(txb_each.Text, out each))
            {
                Logger.Warn($"數值有誤");
                MessageBox.Show($"欄位輸入錯誤", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (price < 0 || each <= 0 || single_qty <= 0 || total_qty <= 0)
            {
                Logger.Warn($"數值小於或等於0");
                MessageBox.Show($"欄位輸入錯誤", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void txb_start_TextChanged(object sender, EventArgs e)
        {
            int input = ((TextBox)sender).Text.Length;
            if (previousLength > input)
            {
                previousLength = input;
                return;
            }
            if (input == 2)
                txb_start.Text = txb_start.Text + ":";
            if (input == 5)
                txb_start.Text = txb_start.Text + ":";
            txb_start.Select(txb_start.Text.Length, 0);
            previousLength = txb_start.Text.Length;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            calculateCount();
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            calculateCount();
        }
        private void txb_totalDivideBySingle_TextChanged(object sender, EventArgs e)
        {

        }
        private void calculateCount()
        {
            int single = 0;
            int.TryParse(txb_single.Text, out single);
            int total = 0;
            int.TryParse(txb_total.Text, out total);
            if (single == 0 || total == 0)//防呆
                return;
            txb_totalDivideBySingle.Text = (total / single).ToString();
        }
        /// <summary>
        /// 取消事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                Logger.Info($"按下datagridview ColumnIndex:{e.ColumnIndex} RowIndex:{e.RowIndex}");
                if (strategyList[e.RowIndex].Cancel == "取消" && int.Parse(strategyList[e.RowIndex].submitCount) == 0)
                {
                    Logger.Info($"合法取消");
                    StopThread(e.RowIndex);
                }
                else if (strategyList[e.RowIndex].Cancel == "取消" && int.Parse(strategyList[e.RowIndex].submitCount) > 0)
                {
                    Logger.Info($"非法取消，確認中...");
                    DialogResult OK = MessageBox.Show("策略送出中，強制中斷可能造成系統異常", "取消確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, (MessageBoxOptions)0x40000);
                    if (OK == DialogResult.OK)
                    {
                        StopThread(e.RowIndex);
                        Logger.Info($"確認執行非法取消");
                    }
                }
            }
        }
        /// <summary>
        /// 取消(Abort)、後續畫面更新
        /// </summary>
        /// <param name="n"></param>
        private void StopThread(int n)
        {
            if (threadList[n] != null && threadList[n].IsAlive)
            {
                threadList[n].Abort();
                if (isOpen)
                {
                    Invoke((Action)(() =>
                    {
                        strategyList[n].Cancel = "";
                        strategyList[n].status = "已中斷";
                        strategyList[n].deleteCount = (int.Parse(strategyList[n].total) - int.Parse(strategyList[n].submitCount)).ToString();
                        dataGridView1.Rows[n].Cells["colCancel"].Dispose();
                        dataGridView1.Rows[n].Cells["colCancel"] = new DataGridViewTextBoxCell();
                        dataGridView1.Refresh();
                    }));
                }
            }
        }

        private void frmTimeSharing_FormClosing(object sender, FormClosingEventArgs e)
        {
            isOpen = false;
            //關閉視窗的方法
            e.Cancel = true;
            Hide();
        }

        private void lbl_getNow_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            txb_start.Text = (now + TimeSpan.FromSeconds(20)).ToString("HH:mm:ss");
        }

        private void txb_start_Click(object sender, EventArgs e)
        {
            txb_start.Text = "";
        }
        /// <summary>
        /// DataView 雙重緩衝設定
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="setting"></param>
        private new void DoubleBuffered(DataGridView dgv, bool setting)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered",
            BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, setting, null);
        }
    }
}
class Strategy
{
    public string Cancel { get; set; }
    public string buySell { get; set; }
    public string cseq { get; set; }
    public string cseqName { get; set; }
    public string stock { get; set; }
    public string stockName { get; set; }
    public string orderPrice { get; set; }

    public string submitCount { get; set; }
    public string total { get; set; }
    public string deleteCount { get; set; }
    public string start { get; set; }
    public string end { get; set; }
    public string number { get; set; }
    public string status { get; set; }
    public string ROD { get; set; }
}
class Details
{
    public string number { get; set; }
    public string buySell { get; set; }
    public string cseq { get; set; }
    public string cseqName { get; set; }
    public string stock { get; set; }
    public string stockName { get; set; }
    public string orderPrice { get; set; }
    public string orderQty { get; set; }
    public string orderTime { get; set; }
    public string status { get; set; }
}