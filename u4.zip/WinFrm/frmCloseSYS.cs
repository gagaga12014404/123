﻿using System;
using System.Windows.Forms;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Client
{
    public partial class frmCloseSYS : Form
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        public frmCloseSYS()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Logger.Info("關閉視窗確認鍵按下");
            Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Logger.Info("關閉視窗取消鍵按下");
            Hide();
        }
    }
}
