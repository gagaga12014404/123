﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using Equin.ApplicationFramework;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Init Data
        /// <summary>
        /// 初始化DataGridView
        /// </summary>
        public void Intit_DataView()
        {
            // _EMKeyInOrderDetailView = new DataView(_EMOrderStore._KeyInDetailStore);
            // DGVEmstOrder.AutoGenerateColumns = false;
            // DGVEmstOrder.Columns["colOrdQty_EMKeyIn"].DefaultCellStyle.Format = "N0";//委託股數是int，設定format N0，千位一個逗號
            // DGVEmstOrder.Columns["colDealQty_EMKeyIn"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVEmstOrder, true);

            // _EmstRequestView = new DataView(EMOrderStore._OrdReportStore, "CSEQ=''", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);//DESC=descending降序
            // DGVEmstRequest.AutoGenerateColumns = false;
            // DGVEmstRequest.Columns["colEmOrdPrice"].DefaultCellStyle.Format = "0.####";
            // DGVEmstRequest.Columns["colEmDealPrice"].DefaultCellStyle.Format = "0.####";
            // DGVEmstRequest.Columns["colEmOrdQty"].DefaultCellStyle.Format = "N0";
            // DGVEmstRequest.Columns["colEmCancelQty"].DefaultCellStyle.Format = "N0";
            // DGVEmstRequest.Columns["colEmDealQty"].DefaultCellStyle.Format = "N0";
            // DoubleBuffered(DGVEmstRequest, true);

            // _KeyInOrderDetailView = new DataView(_OrderStore._KeyInDetailStore, "ECode='0'", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            // DGVKeyIn.AutoGenerateColumns = false;
            // DGVKeyIn.Columns["colBefChgQty_KeyIn"].DefaultCellStyle.Format = "N0";
            // DGVKeyIn.Columns["colOrdQty_KeyIn"].DefaultCellStyle.Format = "N0";

            DoubleBuffered(DGVKeyIn, true);

            // _RequestView = new DataView(OrderStore._OrdReportStore, "CSEQ=''", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            // DGVRequest.AutoGenerateColumns = false;
            // DGVRequest.Columns["colOrdPrice"].DefaultCellStyle.Format = "0.####";
            // DGVRequest.Columns["colDealPrice"].DefaultCellStyle.Format = "0.####";
            // DGVRequest.Columns["colOrdQty"].DefaultCellStyle.Format = "N0";
            // DGVRequest.Columns["colCancelQty"].DefaultCellStyle.Format = "N0";
            // DGVRequest.Columns["colDealQty"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVRequest, true);

            DGVCheckDeal.AutoGenerateColumns = false;
            DGVCheckDeal.Columns["col_PRICE"].DefaultCellStyle.Format = "0.####";
            DGVCheckDeal.Columns["col_DPRICE"].DefaultCellStyle.Format = "0.####";
            DGVCheckDeal.Columns["col_OQTY"].DefaultCellStyle.Format = "N0";
            DGVCheckDeal.Columns["col_DQTY"].DefaultCellStyle.Format = "N0";
            DGVCheckDeal.Columns["col_AllDQTY"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVCheckDeal, true);

            // _PassiveRequestView = new DataView(_OrderStore._OrdPassiveReportStore, "", "TransactTime DESC ,DSEQ DESC", DataViewRowState.CurrentRows);
            // DGVPasRequest.AutoGenerateColumns = false;
            // DGVPasRequest.Columns["col_OrdPrice"].DefaultCellStyle.Format = "0.####";
            // DGVPasRequest.Columns["col_DealPrice"].DefaultCellStyle.Format = "0.####";
            // DGVPasRequest.Columns["col_OrdQty"].DefaultCellStyle.Format = "N0";
            // DGVPasRequest.Columns["col_CancelQty"].DefaultCellStyle.Format = "N0";
            // DGVPasRequest.Columns["col_DealQty"].DefaultCellStyle.Format = "N0";
            DoubleBuffered(DGVPasRequest, true);

            DGVEmstOrder.AutoGenerateColumns = false;//興櫃明細
            DGVRequest.AutoGenerateColumns = false;//委託回報
            DGVKeyIn.AutoGenerateColumns = false;//上市櫃明細
            DGVPasRequest.AutoGenerateColumns = false;//被動查詢
            OrderStore.明細List.RaiseListChangedEvents = false;//禁用listchange，Add就不需要invoke
            OrderStore.回報List.RaiseListChangedEvents = false;
            _OrderStore.勾單List.RaiseListChangedEvents = false;
            明細View = new BindingListView<Report>(OrderStore.明細List);
            回報View = new BindingListView<Report>(OrderStore.回報List);
            勾單View = new BindingListView<CheckDeal>(_OrderStore.勾單List);
            DGVKeyIn.DataSource = 明細View;
            DGVEmstOrder.DataSource = 明細View;
            DGVRequest.DataSource = 回報View;
            DGVCheckDeal.DataSource = 勾單View;
            // DGVKeyIn.DataSource = 明細View;
            // DGVKeyIn.ResumeLayout();

            // DGVEmstOrder.SuspendLayout();
            // DGVEmstOrder.DataSource = 明細View;
            // DGVEmstOrder.ResumeLayout();

            // DGVRequest.SuspendLayout();
            // OrderStore.回報List.RaiseListChangedEvents = false;
            // DGVRequest.ResumeLayout();

            DGVPasRequest.SuspendLayout();
            DGVPasRequest.DataSource = _OrderStore.被動查詢List;
            DGVPasRequest.ResumeLayout();

            // DGVCheckDeal.SuspendLayout();
            // DGVCheckDeal.DataSource = 勾單View;
            // DGVCheckDeal.ResumeLayout();
        }
        private void DoRefreshDatagridview()
        {
            while (true)
            {
                try
                {
                    Invoke((Action)(() =>
                    {
                        Refresh明細();
                        Refresh回報();
                        Refresh勾單();
                    }));
                    Thread.Sleep(200);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                }
            }
        }
        private void Refresh明細()
        {
            if (!_OrderStore.Refresh明細)
                return;
            _OrderStore.Refresh明細 = false;
            // lock (OrderStore._KeyInOrderLock)
            //     明細View = new BindingListView<Report>(OrderStore.明細List.ToList());
            明細Filter();
        }
        private void Refresh回報()
        {
            if (!_OrderStore.Refresh回報)
                return;
            _OrderStore.Refresh回報 = false;
            // lock (OrderStore._Lock)
            //     回報View = new BindingListView<Report>(OrderStore.回報List.ToList());
            btnFilterOK_Click(null, null);
        }
        private void Refresh勾單()
        {
            if (!_OrderStore.Refresh勾單)
                return;
            _OrderStore.Refresh勾單 = false;
            // lock (_OrderStore.勾單List鎖)
            //     勾單View = new BindingListView<CheckDeal>(_OrderStore.勾單List.ToList());
            更新勾單畫面();
        }

        #endregion

    }
}
