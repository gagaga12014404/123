﻿using Concord.SDK.Logging;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Order Control Event
        /// <summary>
        /// 組成新單委託物件
        /// </summary>
        /// <param name="order_ViewModel"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        private Order ComposeNewObject(OrderTabViewModel order_ViewModel, Side side, bool IsPriceCover)
        {
            Order order = new Order();
            order.Guid = Guid.NewGuid().ToString();
            order.ExecType = "I";
            order.BHNO = order_ViewModel.ErrAccount_Enable ? "0" : UserInfo._BHNO; // 若有啟動錯帳專戶，則帶入總公司公司別
            order.CSEQ = order_ViewModel.ErrAccount_Enable ? _ERRORACCOUNT : order_ViewModel.CSEQ; // 若有啟動錯帳專戶，則帶入錯帳專戶
            order.Sale = order_ViewModel.Sale;
            order.KeyIn = UserInfo._EMNO;
            order.Symbol = order_ViewModel.Symbol;
            order.MType = order_ViewModel.Symbol_MType;
            order.ECode = order_ViewModel.ECode;
            if (order_ViewModel.OType.Equals("9"))
            {
                order.OType = "0";       // 若為現賣沖，須改回一般現股
                order.DayTradeFlag = "Y";
            }
            else
            {
                order.OType = order_ViewModel.OType;
                order.DayTradeFlag = "N";
            }
            int OrderQty = 0;
            if (!int.TryParse(order_ViewModel.OrderQty, out OrderQty))
            {
                MessageBox.Show("委託數量欄位檢查錯誤，請重新輸入", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            order.Side = side;
            order.OrdQty = OrderQty;
            order.OrdPrice = order_ViewModel.OrderPrice;
            order.OrdType = order_ViewModel.OrdType;
            order.TimeInForce = order_ViewModel.TimeInForce;
            if (order.ECode == "6") // 若為標購則加入序號
                order.G_stk_seq_no = SP_TxbSerialNum.Text;
            if (order.ECode == "8") // 若為證金標購則加入序號
                order.G_stk_seq_no = SP2_TxbSerialNum.Text;
            if (IsPriceCover && _Setting.ORDER_PRICE_COVERED_ENABLE)
            {
                order.PriceRange_setting = side == Side.BUY ? _Setting.ORDER_PRICE_RISE_TICK_VALUE : _Setting.ORDER_PRICE_FALL_TICK_VALUE;
                int 檔數 = 0;
                int.TryParse(order.PriceRange_setting, out 檔數);
                if (檔數 <= 0 || 檔數 > 5)
                {
                    MessageBox.Show("檔數設定錯誤");
                    return null;
                }
            }

            if (UserInfo._IsSplitLot && ChKSplitLot.Checked && order.ECode == "0")
                order.SeqenceFlag = "Y";

            return order;
        }
        /// <summary>
        /// 因加入ConcurrentDictionary時若為class，則需要設定每一筆都是新的class，才不會出錯
        /// </summary>
        /// <param name="order_old"></param>
        /// <returns></returns>
        private Order ComposeNewOrder(Order order_old)
        {
            Order order = new Order();
            order.Guid = Guid.NewGuid().ToString();
            order.ExecType = order_old.ExecType;
            order.BHNO = order_old.BHNO;
            order.CSEQ = order_old.CSEQ;
            order.Sale = order_old.Sale;
            order.KeyIn = order_old.KeyIn;
            order.Symbol = order_old.Symbol;
            order.MType = order_old.MType;
            order.ECode = order_old.ECode;

            order.OType = order_old.OType;
            order.DayTradeFlag = order_old.DayTradeFlag;

            order.Side = order_old.Side;
            order.OrdQty = order_old.OrdQty;
            order.OrdPrice = order_old.OrdPrice;
            order.OrdType = order_old.OrdType;
            order.TimeInForce = order_old.TimeInForce;
            order.PriceRange_setting = order_old.PriceRange_setting;
            order.SeqenceFlag = order_old.SeqenceFlag;
            return order;
        }
        /// <summary>
        /// 組成刪單委託物件
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        private Order ComposeDeleteObject(string DSEQ)
        {
            var order = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
            Order deleteOrd = new Order();
            if (order == null)
            {
                Logger.Info("[ComposeDeleteObject] 未找到對應委託單");
                return null;
            }
            else if (order.LaveQty <= 0)
            {
                Logger.Info($"[ComposeDeleteObject] 委託書號:{order.DSEQ} 已無剩餘量");
                return null;
            }
            else
            {
                deleteOrd.ExecType = "D";
                deleteOrd.Guid = Guid.NewGuid().ToString();
                deleteOrd.OrigClOrdID = order.OrigClOrdID;
                deleteOrd.DSEQ = DSEQ;
                deleteOrd.BHNO = order.BHNO;
                deleteOrd.CSEQ = order.CSEQ;
                deleteOrd.MType = order.MType;
                deleteOrd.ECode = StockInfoHandler.GetECodeValue(order.ECode);
                deleteOrd.OType = StockInfoHandler.GetOrderTypeValue(order.OType);
                deleteOrd.Symbol = order.Stock;
                deleteOrd.Side = order.Side == "B" ? Side.BUY : Side.SELL;
                deleteOrd.OrdType = StockInfoHandler.GetOrdTypeValue(order.OrdType);
                deleteOrd.TimeInForce = StockInfoHandler.GetTimInForceValue(order.TimeInForce);
                deleteOrd.OrdQty = order.OrdQty;
                if (order.OrdType.Equals("限"))
                    deleteOrd.OrdPrice = order.OrdPrice;
                else
                    deleteOrd.OrdPrice = "0";
                deleteOrd.Sale = order.Sale;
                deleteOrd.DayTradeFlag = order.DayTradeFlag;
                deleteOrd.KeyIn = UserInfo._EMNO;
            }
            return deleteOrd;
        }
        /// <summary>
        /// 組成刪單委託物件
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        private Order PasComposeDeleteObject(string DSEQ)
        {
            var order = Task.Run(() => _OrderStore.GetPasReportInfoByDSEQ(DSEQ)).Result;
            Order deleteOrd = new Order();
            if (order == null)
            {
                Logger.Info("[PasComposeDeleteObject] 未找到對應委託單");
                return null;
            }
            else
            {
                deleteOrd.ExecType = "D";
                deleteOrd.Guid = Guid.NewGuid().ToString();
                deleteOrd.OrigClOrdID = order.OrigClOrdID;
                deleteOrd.DSEQ = DSEQ;
                deleteOrd.BHNO = order.BHNO;
                deleteOrd.CSEQ = order.CSEQ;
                deleteOrd.MType = order.MType;
                deleteOrd.ECode = StockInfoHandler.GetECodeValue(order.ECode);
                deleteOrd.OType = StockInfoHandler.GetOrderTypeValue(order.OType);
                deleteOrd.Symbol = order.Stock;
                deleteOrd.Side = order.Side == "B" ? Side.BUY : Side.SELL;
                deleteOrd.OrdType = StockInfoHandler.GetOrdTypeValue(order.OrdType);
                deleteOrd.TimeInForce = StockInfoHandler.GetTimInForceValue(order.TimeInForce);
                deleteOrd.OrdQty = order.OrdQty;
                if (order.OrdType.Equals("限"))
                    deleteOrd.OrdPrice = order.OrdPrice;
                else
                    deleteOrd.OrdPrice = "0";
                deleteOrd.Sale = order.Sale;
                deleteOrd.DayTradeFlag = order.DayTradeFlag;
                deleteOrd.KeyIn = UserInfo._EMNO;
            }
            return deleteOrd;
        }
        /// <summary>
        /// 組成改量委託物件
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="ChangeQty"></param>
        /// <returns></returns>
        private Order ComposeChangeQtyObject(Report report, int ChangeQty)
        {
            Order ChgeOrd = new Order();
            ChgeOrd.ExecType = "C";
            ChgeOrd.Guid = Guid.NewGuid().ToString();
            ChgeOrd.OrigClOrdID = report.OrigClOrdID;
            ChgeOrd.DSEQ = report.DSEQ;
            ChgeOrd.BHNO = report.BHNO;
            ChgeOrd.CSEQ = report.CSEQ;
            ChgeOrd.MType = report.MType;
            ChgeOrd.ECode = StockInfoHandler.GetECodeValue(report.ECode);
            ChgeOrd.OType = StockInfoHandler.GetOrderTypeValue(report.OType);
            ChgeOrd.Symbol = report.Stock;
            ChgeOrd.Side = report.Side == "B" ? Side.BUY : Side.SELL;
            ChgeOrd.OrdType = StockInfoHandler.GetOrdTypeValue(report.OrdType);
            ChgeOrd.TimeInForce = StockInfoHandler.GetTimInForceValue(report.TimeInForce);
            ChgeOrd.OrdQty = ChangeQty;
            if (report.OrdType.Equals("限"))
                ChgeOrd.OrdPrice = report.OrdPrice;
            else
                ChgeOrd.OrdPrice = "0";
            ChgeOrd.Sale = report.Sale;
            ChgeOrd.DayTradeFlag = report.DayTradeFlag;
            ChgeOrd.KeyIn = UserInfo._EMNO;
            return ChgeOrd;
        }
        /// <summary>
        /// 組成改價委託物件
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <param name="price"></param>
        /// <returns></returns>
        private Order ComposeChangePriceObject(Report report, decimal price)
        {
            Order ChgePrice = new Order();
            ChgePrice.ExecType = "P";
            ChgePrice.Guid = Guid.NewGuid().ToString();
            ChgePrice.OrigClOrdID = report.OrigClOrdID.ToString();
            ChgePrice.DSEQ = report.DSEQ.ToString();
            ChgePrice.BHNO = report.BHNO.ToString();
            ChgePrice.CSEQ = report.CSEQ.ToString();
            ChgePrice.MType = report.MType.ToString();
            ChgePrice.ECode = StockInfoHandler.GetECodeValue(report.ECode.ToString());
            ChgePrice.OType = StockInfoHandler.GetOrderTypeValue(report.OType.ToString());
            ChgePrice.Symbol = report.Stock.ToString();
            ChgePrice.Side = report.Side.ToString() == "B" ? Side.BUY : Side.SELL;
            ChgePrice.OrdType = StockInfoHandler.GetOrdTypeValue(report.OrdType.ToString());
            ChgePrice.TimeInForce = StockInfoHandler.GetTimInForceValue(report.TimeInForce.ToString());
            ChgePrice.OrdQty = report.LaveQty;
            ChgePrice.OrdPrice = price.ToString();
            ChgePrice.Sale = report.Sale.ToString();
            ChgePrice.KeyIn = UserInfo._EMNO;
            return ChgePrice;
        }
        /// <summary>
        /// 強制下單模式
        /// </summary>
        private void OnForceOrder(string text)
        {
            var ViewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            ViewInfo.ForceBtnVisable = true;
            ViewInfo.OrdInfoText = text;
            OnForceBtnVisableChange(tab_Order.SelectedTab.Name, true);
        }
        /// <summary>
        /// 強制下單相關控制項顯示
        /// </summary>
        /// <param name="index"></param>
        /// <param name="visable"></param>
        private void OnForceBtnVisableChange(string index, bool visable)
        {
            switch (index)
            {
                case "RoundLot":
                    RL_LabInfo.Visible = visable;
                    RL_BtnForceClear.Visible = visable;
                    RL_BtnForceOrder.Visible = visable;
                    RL_BtnForceReturn.Visible = visable;
                    RL_BtnForceChangeQty.Visible = visable;
                    break;
                case "OddLot":
                    OD_LabInfo.Visible = visable;
                    OD_BtnForceClear.Visible = visable;
                    OD_BtnForceOrder.Visible = visable;
                    OD_BtnForceReturn.Visible = visable;
                    OD_BtnForceChangeQty.Visible = visable;
                    break;
                case "FixedPrice":
                    FP_LabInfo.Visible = visable;
                    FP_BtnForceClear.Visible = visable;
                    FP_BtnForceOrder.Visible = visable;
                    FP_BtnForceReturn.Visible = visable;
                    FP_BtnForceChangeQty.Visible = visable;
                    break;
                case "ErrAccount":
                    ER_LabInfo.Visible = visable;
                    ER_BtnForceClear.Visible = visable;
                    ER_BtnForceOrder.Visible = visable;
                    ER_BtnForceReturn.Visible = visable;
                    ER_BtnForceChangeQty.Visible = visable;
                    break;
            }
        }
        /// <summary>
        /// 儲存個人委託設定
        /// </summary>
        /// <param name="setting"></param>
        private void SavePersonalSetting(PersonalSetting setting)
        {
            _Setting = setting;
            ChangeEnableVisible();

            bool Rewrite = File.Exists($@"{Environment.CurrentDirectory}/PersonalSetting.json") ? false : true;
            using (StreamWriter writer = new StreamWriter($@"{Environment.CurrentDirectory}/PersonalSetting.json", Rewrite))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Formatting = Newtonsoft.Json.Formatting.Indented;
                serializer.Serialize(writer, setting);
            }
        }
        /// <summary>
        /// 改變個人委託設定功能顯示
        /// </summary>
        private void ChangeEnableVisible()
        {
            #region 改變功能顯示
            // 顯示 委託價格上下多檔 與否
            RL_BtnBuyRiseTick.Visible = _Setting.ORDER_PRICE_COVERED_ENABLE;
            RL_BtnSellFallTick.Visible = _Setting.ORDER_PRICE_COVERED_ENABLE;
            // 顯示 固定委託人帳號功能 與否
            RL_CkbFixedCSEQ.Visible = _Setting.FIXED_CSEQ_ENABLE;
            RL_CkbFixedCSEQ.Checked = _Setting.FIXED_CSEQ_ENABLE;
            _ViewControlInfoStore.GetTabPageInfo("RoundLot").FixedCSEQ_Enable = _Setting.FIXED_CSEQ_ENABLE;
            OD_CkbFixedCSEQ.Visible = _Setting.FIXED_CSEQ_ENABLE;
            OD_CkbFixedCSEQ.Checked = _Setting.FIXED_CSEQ_ENABLE;
            _ViewControlInfoStore.GetTabPageInfo("OddLot").FixedCSEQ_Enable = _Setting.FIXED_CSEQ_ENABLE;
            FP_CkbFixedCSEQ.Visible = _Setting.FIXED_CSEQ_ENABLE;
            FP_CkbFixedCSEQ.Checked = _Setting.FIXED_CSEQ_ENABLE;
            _ViewControlInfoStore.GetTabPageInfo("FixedPrice").FixedCSEQ_Enable = _Setting.FIXED_CSEQ_ENABLE;
            EM_CkbFixedCSEQ.Visible = _Setting.FIXED_CSEQ_ENABLE;
            EM_CkbFixedCSEQ.Checked = _Setting.FIXED_CSEQ_ENABLE;
            _ViewControlInfoStore.GetTabPageInfo("Emst").FixedCSEQ_Enable = _Setting.FIXED_CSEQ_ENABLE;
            // 顯示 股票信用諮群額資訊顯示 與否
            RL_LabStockState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            RL_LabMType.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            RL_LabFinanceState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            OD_LabStockState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            OD_LabMType.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            OD_LabFinanceState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            FP_LabStockState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            FP_LabMType.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            FP_LabFinanceState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            EM_LabStockState.Visible = _Setting.STOCK_DETAIL_INFO_ENABLE;
            #endregion
        }
        private void ShowLabInfo(string index, bool visable)
        {
            switch (index)
            {
                case "RoundLot":
                    #region 整股頁面
                    RL_LabInfo.Visible = visable;
                    break;
                #endregion
                case "OddLot":
                    #region 零股頁面
                    OD_LabInfo.Visible = visable;
                    break;
                #endregion
                case "FixedPrice":
                    #region 定價頁面
                    FP_LabInfo.Visible = visable;
                    break;
                #endregion
                case "StockBorrow":
                    StockBorrow_LabInfo.Visible = visable;
                    break;
                case "StockPurchase":
                    StockPurchase_LabInfo.Visible = visable;
                    break;
                case "StockAuction":
                    StockAuction_LabInfo.Visible = visable;
                    break;
                case "ErrAccount":
                    ER_LabInfo.Visible = visable;
                    break;
                case "StockPurchase2":
                    StockPurchase2_LabInfo.Visible = visable;
                    break;
            }
        }
        /// <summary>
        /// 查詢後控制項調整
        /// </summary>
        /// <param name="index"></param>
        /// <param name="visible"></param>
        /// <param name="side"></param>
        /// <param name="cancelQty"></param>
        private void ChangeOrderInfoVisible(string index, bool visible, string side, string cancelledQty)
        {
            Color BackColor = visible ? side == "B" ? Color.Red : Color.Blue : Color.Black;
            Color ForeColor = visible ? Color.White : Color.Lime;
            switch (index)
            {
                case "RoundLot":
                    #region 整股頁面
                    RL_LabInfo.Visible = visible;
                    RL_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    RL_LabCancelQty.BackColor = side == "B" ? Color.Blue : Color.Red;
                    RL_TxbStockNo.BackColor = BackColor;
                    RL_TxbStockNo.ForeColor = ForeColor;
                    RL_LabStockName.BackColor = BackColor;
                    RL_LabStockName.ForeColor = ForeColor;
                    RL_TxbStockQty.BackColor = BackColor;
                    RL_TxbStockQty.ForeColor = ForeColor;
                    RL_TxbPrice.BackColor = BackColor;
                    RL_TxbPrice.ForeColor = ForeColor;
                    RL_LabQueryLaveQty.BackColor = BackColor;
                    RL_LabQueryLaveQty.ForeColor = ForeColor;
                    RL_LabQueryDealQty.BackColor = BackColor;
                    RL_LabQueryDealQty.ForeColor = ForeColor;
                    RL_TxbOrdType.BackColor = BackColor;
                    RL_TxbOrdType.ForeColor = ForeColor;
                    RL_LabOrdType.BackColor = BackColor;
                    RL_LabOrdType.ForeColor = ForeColor;
                    break;
                #endregion
                case "OddLot":
                    #region 零股頁面
                    OD_LabInfo.Visible = visible;
                    OD_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    OD_LabCancelQty.BackColor = side == "B" ? Color.Blue : Color.Red;
                    OD_TxbStockNo.BackColor = BackColor;
                    OD_TxbStockNo.ForeColor = ForeColor;
                    OD_LabStockName.BackColor = BackColor;
                    OD_LabStockName.ForeColor = ForeColor;
                    OD_TxbStockQty.BackColor = BackColor;
                    OD_TxbStockQty.ForeColor = ForeColor;
                    OD_TxbPrice.BackColor = BackColor;
                    OD_TxbPrice.ForeColor = ForeColor;
                    OD_LabQueryLaveQty.BackColor = BackColor;
                    OD_LabQueryLaveQty.ForeColor = ForeColor;
                    break;
                #endregion
                case "FixedPrice":
                    #region 定價頁面
                    FP_LabInfo.Visible = visible;
                    FP_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    FP_LabCancelQty.BackColor = side == "B" ? Color.Blue : Color.Red;
                    FP_TxbStockNo.BackColor = BackColor;
                    FP_TxbStockNo.ForeColor = ForeColor;
                    FP_LabStockName.BackColor = BackColor;
                    FP_LabStockName.ForeColor = ForeColor;
                    FP_TxbStockQty.BackColor = BackColor;
                    FP_TxbStockQty.ForeColor = ForeColor;
                    FP_TxbPrice.BackColor = BackColor;
                    FP_TxbPrice.ForeColor = ForeColor;
                    FP_LabQueryLaveQty.BackColor = BackColor;
                    FP_LabQueryLaveQty.ForeColor = ForeColor;
                    FP_LabQueryDealQty.BackColor = BackColor;
                    FP_LabQueryDealQty.ForeColor = ForeColor;
                    break;
                #endregion
                case "StockBorrow":
                    SB_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    SB_LabCancelQty.BackColor = Color.Red;
                    StockBorrow_LabInfo.Visible = visible;
                    break;
                case "StockPurchase":
                    SP_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    SP_LabCancelQty.BackColor = Color.Red;
                    StockPurchase_LabInfo.Visible = visible;
                    break;
                case "StockPurchase2":
                    SP2_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    SP2_LabCancelQty.BackColor = Color.Red;
                    StockPurchase2_LabInfo.Visible = visible;
                    break;
                case "StockAuction":
                    SA_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    SA_LabCancelQty.BackColor = Color.Blue;
                    StockAuction_LabInfo.Visible = visible;
                    break;
                case "ErrAccount":
                    #region 錯帳頁面
                    ER_LabInfo.Visible = visible;
                    ER_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    ER_LabCancelQty.BackColor = side == "B" ? Color.Blue : Color.Red;
                    ER_TxbECode.BackColor = BackColor;
                    ER_TxbECode.ForeColor = ForeColor;
                    ER_LabECodeText.BackColor = BackColor;
                    ER_LabECodeText.ForeColor = ForeColor;
                    ER_TxbStockNo.BackColor = BackColor;
                    ER_TxbStockNo.ForeColor = ForeColor;
                    ER_LabStockName.BackColor = BackColor;
                    ER_LabStockName.ForeColor = ForeColor;
                    ER_TxbStockQty.BackColor = BackColor;
                    ER_TxbStockQty.ForeColor = ForeColor;
                    ER_TxbPrice.BackColor = BackColor;
                    ER_TxbPrice.ForeColor = ForeColor;
                    ER_LabQueryLaveQty.BackColor = BackColor;
                    ER_LabQueryLaveQty.ForeColor = ForeColor;
                    ER_LabQueryDealQty.BackColor = BackColor;
                    ER_LabQueryDealQty.ForeColor = ForeColor;
                    break;
                #endregion 錯帳頁面
                case "Emst":
                    #region 興櫃頁面
                    EM_LabCancelQty.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    EM_LabCancelQty.BackColor = side == "B" ? Color.Blue : Color.Red;
                    EM_TxbStockNo.BackColor = BackColor;
                    EM_TxbStockNo.ForeColor = ForeColor;
                    EM_LabStockName.BackColor = BackColor;
                    EM_LabStockName.ForeColor = ForeColor;
                    EM_TxbStockQty.BackColor = BackColor;
                    EM_TxbStockQty.ForeColor = ForeColor;
                    EM_TxbPrice.BackColor = BackColor;
                    EM_TxbPrice.ForeColor = ForeColor;
                    break;
                #endregion
                case "EmstErrAccount":
                    label168.Visible = visible ? cancelledQty != "0" ? true : false : false;
                    label168.BackColor = side == "B" ? Color.Blue : Color.Red;
                    EMER_TxbStockNo.BackColor = BackColor;
                    EMER_TxbStockNo.ForeColor = ForeColor;
                    EMER_LabStockName.BackColor = BackColor;
                    EMER_LabStockName.ForeColor = ForeColor;
                    EMER_TxbStockQty.BackColor = BackColor;
                    EMER_TxbStockQty.ForeColor = ForeColor;
                    EMER_TxbPrice.BackColor = BackColor;
                    EMER_TxbPrice.ForeColor = ForeColor;
                    EMER_LabQueryLaveQty.BackColor = BackColor;
                    EMER_LabQueryLaveQty.ForeColor = ForeColor;
                    EMER_LabQueryDealQty.BackColor = BackColor;
                    EMER_LabQueryDealQty.ForeColor = ForeColor;
                    break;
            }
        }
        #endregion

    }
}
