﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region 委託 Tab
        /// <summary>
        /// 委託Tab Key Down 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_Order_KeyUp(object sender, KeyEventArgs e)
        {
            // 解除鍵盤事件(以免連續觸發)
            tab_Order.KeyUp -= new KeyEventHandler(tab_Order_KeyUp);
            OrderKeyInEvent(e);
            tab_Order.KeyUp += new KeyEventHandler(tab_Order_KeyUp);
        }
        /// <summary>
        /// 處理委託Tab KeyIn事件
        /// </summary>
        /// <param name="e"></param>
        private void OrderKeyInEvent(KeyEventArgs e)
        {
            try
            {
                if (e.Shift) // 按壓Shift鈕
                {
                    #region Shift 組合
                    switch (e.KeyCode)
                    {
                        case Keys.F11:
                            {
                                if (OrderStore.GF == "")
                                {
                                    DialogResult result = MessageBox.Show("緊急狀態-一律強制單，請務必確認下單內容及庫存", "警告", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                                    if (result != DialogResult.OK)
                                        return;
                                    _FrmForceOrd.Init();
                                    回傳強制單密碼 = _FrmForceOrd.取得結果;
                                    _FrmForceOrd.驗證強制單密碼 = 傳送強制單密碼;
                                    _FrmForceOrd.ShowDialog();
                                    if (!_FrmForceOrd._Command)
                                        return;
                                    OrderStore.GF = "Garfield";
                                }
                                else
                                {
                                    OrderStore.GF = "";
                                    MessageBox.Show("強制功能已關閉", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                break;
                            }
                        case Keys.F2:
                            {
                                if (IsAtEmstTab())
                                    return;
                                Shift_F2();
                                break;
                            }
                        case Keys.F4:
                            {
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "Emst":
                                    case "EmstErrAccount":
                                        {
                                            #region 興櫃刪單快捷
                                            Logger.Info($"[{tab_Order.SelectedTab.Name}] 刪單快捷按下");
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;//直接用原本的風控，控正式環境下單
                                            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            if (order_ViewModel.QueryModel)
                                            {
                                                string dseq = order_ViewModel.TERM + order_ViewModel.DSEQ.PadLeft(4, '0');
                                                SendEMCancel(dseq);
                                            }
                                            #endregion
                                            break;
                                        }
                                    case "RoundLot":
                                    case "OddLot":
                                    case "FixedPrice":
                                    case "StockBorrow":
                                    case "StockPurchase":
                                    case "StockPurchase2":
                                    case "StockAuction":
                                    case "ErrAccount":
                                        {
                                            Shift_F4();
                                            break;
                                        }
                                }
                                break;
                            }
                        case Keys.F5:
                            {
                                _OrderStore.空的才能下單.Clear();
                                break;
                            }

                        case Keys.F6:
                            {
                                if (IsAtEmstTab())
                                    return;
                                Shift_F6();
                                break;
                            }
                        case Keys.F7:
                            {
                                if (IsAtEmstTab())
                                {
                                    OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (order_ViewModel.QueryModel)
                                    {
                                        MessageBox.Show("現在不能切換股數", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                    else
                                    {
                                        if (order_ViewModel.Unit == "張")
                                        {
                                            order_ViewModel.Unit = "股";
                                        }
                                        else if (order_ViewModel.Unit == "股")
                                        {
                                            order_ViewModel.Unit = "張";
                                        }
                                    }
                                }
                                break;
                            }
                        case Keys.F8:
                            {
                                if (IsAtEmstTab())
                                {
                                    OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (order_ViewModel.ForceBtnVisable)
                                    {
                                        Order order = _EMRiskControlHandler.GetForceOrderObject();
                                        if (order.CSEQ == _ERRORACCOUNT && order.ExecType == "I")//強制單會扣著前一筆失敗單的所有資訊，如果此時錯帳委託書號有異動，將會發生委託書號重複的問題
                                            order.DSEQ = "X" + _OrderStore.興櫃錯帳委託書號.ToString().PadLeft(4, '0');
                                        order.AllForceFlag = "Y";
                                        if (!SendEmOrder(order))
                                            return;
                                    }
                                }
                                else
                                {
                                    Shift_F8();
                                }
                                break;
                            }
                        case Keys.F9:
                            {
                                if (IsAtEmstTab())
                                    return;
                                Shift_F9();
                                break;
                            }
                    }
                    #endregion
                }
                else if (e.Control)
                {
                    #region Control 組合
                    switch (e.KeyCode)
                    {
                        case Keys.D1:
                            #region 切換整股頁面
                            //tab_Order.SelectedIndex = 0;
                            tab_Order.SelectedTab = tab_Order.TabPages["RoundLot"];
                            break;
                        #endregion
                        case Keys.D2:
                            #region 切換零股頁面
                            //tab_Order.SelectedIndex = 1;
                            tab_Order.SelectedTab = tab_Order.TabPages["OddLot"];
                            break;
                        #endregion
                        case Keys.D3:
                            #region 切換定盤頁面
                            //tab_Order.SelectedIndex = 2;
                            tab_Order.SelectedTab = tab_Order.TabPages["FixedPrice"];
                            break;
                        #endregion
                        case Keys.D4:
                            #region 切換股票標借頁面
                            //tab_Order.SelectedIndex = 3;
                            tab_Order.SelectedTab = tab_Order.TabPages["StockBorrow"];
                            break;
                        #endregion
                        case Keys.D5:
                            #region 切換股票標購頁面
                            //tab_Order.SelectedIndex = 4;
                            tab_Order.SelectedTab = tab_Order.TabPages["StockPurchase"];
                            break;
                        #endregion
                        case Keys.D7:
                            #region 切換股票拍賣頁面
                            //tab_Order.SelectedIndex = 5;
                            tab_Order.SelectedTab = tab_Order.TabPages["StockAuction"];
                            break;
                        #endregion
                        case Keys.D8:
                            #region 切換錯帳頁面
                            //tab_Order.SelectedIndex = 6;
                            tab_Order.SelectedTab = tab_Order.TabPages["ErrAccount"];
                            break;
                        #endregion
                        case Keys.D6:
                            #region 切換證金標購頁面
                            tab_Order.SelectedTab = tab_Order.TabPages["StockPurchase2"];
                            break;
                        #endregion
                        case Keys.D9:
                            #region 切換證金標購頁面
                            tab_Order.SelectedTab = tab_Order.TabPages["Emst"];
                            break;
                        #endregion
                        case Keys.D0:
                            #region 切換證金標購頁面
                            tab_Order.SelectedTab = tab_Order.TabPages["EmstErrAccount"];
                            break;
                            #endregion
                    }
                    #endregion
                }
                else
                {
                    switch (e.KeyCode)
                    {
                        case Keys.F1:
                        case Keys.Subtract:
                            {
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "RoundLot":
                                    case "OddLot":
                                    case "FixedPrice":
                                        {
                                            #region 股票現買/賣 (F1/F16(-))
                                            _OrderStore.Test_Timer.Start();
                                            Logger.Info($"[Order {tab_Order.SelectedTab.Name}] {e.KeyCode}快捷按下");
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;
                                            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            Side side = e.KeyCode == Keys.F1 ? Side.BUY : Side.SELL;
                                            var stock_info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
                                            if (tab_Order.SelectedTab.Name == "FixedPrice")
                                            {
                                                order_ViewModel.OrdType = "2";
                                                order_ViewModel.OrderPrice = "0";
                                            }
                                            else
                                            {
                                                #region 若價格欄位為空白，取漲跌停價格                                         
                                                if (string.IsNullOrWhiteSpace(order_ViewModel.OrderPrice))
                                                {
                                                    order_ViewModel.OrderPrice = STMBStore.Get_Price(order_ViewModel.Symbol, side);
                                                }
                                                #endregion
                                                if (order_ViewModel.OrderPrice == "0" && tab_Order.SelectedTab.Name == "RoundLot")
                                                    order_ViewModel.OrdType = "1"; // 改為市價
                                                else
                                                    order_ViewModel.OrdType = "2"; // 限價
                                            }
                                            if (!_RiskControlHandler.Execute(order_ViewModel, side))
                                                return;
                                            if (!_RiskControlHandler.CheckStockPrice(order_ViewModel, stock_info))
                                                return;
                                            Order order = ComposeNewObject(order_ViewModel, side, false);
                                            if (order == null)
                                                return;
                                            if (!_RiskControlHandler.CheckResult(order)) // 在下單送出前先送到後台風控檢查輸入的資料 checkAll
                                                return;
                                            拆單Queue.Clear();
                                            if (order.SeqenceFlag == "Y")
                                            {
                                                foreach (int qty in _OrderHandler.GetShipments(order.OrdQty))
                                                {
                                                    Order order1 = ComposeNewOrder(order);
                                                    order1.Guid = Guid.NewGuid().ToString();
                                                    order1.OrdQty = qty;
                                                    拆單Queue.Enqueue(order1);
                                                }
                                                送出拆單("I");
                                            }
                                            else
                                            {
                                                if (!DoSend(order, order_ViewModel))
                                                    return;
                                            }
                                            break;
                                            #endregion
                                        }
                                    case "StockBorrow":
                                    case "StockPurchase":
                                    case "StockAuction":
                                    case "StockPurchase2":
                                        {
                                            #region 標借,標購,拍賣
                                            // 自營不開發該功能
                                            if (_Model == 2)
                                                return;
                                            Logger.Info($"[Order {tab_Order.SelectedTab.Name}] {e.KeyCode}快捷按下");
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;
                                            Side side = tab_Order.SelectedTab.Name == "StockAuction" ? Side.BUY : Side.SELL;
                                            if (_SOrderSession.ClientConnectState != ConnectState.Connected)
                                                return;
                                            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            Order order = ComposeNewObject(order_ViewModel, side, false);
                                            if (order == null)
                                                return;
                                            // if (!_RiskControlHandler.ChexFunc(order)) // 後台風控的下單資料檢查  
                                            //     return;
                                            if (!DoSend(order, order_ViewModel))
                                                return;
                                            break;
                                            #endregion
                                        }
                                    case "ErrAccount":
                                        {
                                            #region 錯帳功能
                                            // 自營不開放該功能
                                            if (_Model == 2)
                                                return;
                                            Logger.Info($"[Order 錯帳功能快捷按下");
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;
                                            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            order_ViewModel.ErrAccount_Enable = true;
                                            if (_SOrderSession.ClientConnectState != ConnectState.Connected)
                                                return;
                                            Side side = e.KeyCode == Keys.F1 ? Side.BUY : Side.SELL;
                                            RiskControlHandler._CSEQChecked = true;
                                            order_ViewModel.ECode = ER_TxbECode.Text;
                                            order_ViewModel.OType = "0";
                                            order_ViewModel.CSEQ = _ERRORACCOUNT;
                                            order_ViewModel.Sale = "98";
                                            if (!_RiskControlHandler.Execute(order_ViewModel, side))
                                                return;
                                            var stock_info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
                                            if (order_ViewModel.ECode == "3")
                                            {
                                                order_ViewModel.OrdType = "2";
                                                order_ViewModel.OrderPrice = "0";
                                            }
                                            else
                                            {
                                                #region 若價格欄位為空白，取漲跌停價格                                         
                                                if (string.IsNullOrWhiteSpace(order_ViewModel.OrderPrice))
                                                {
                                                    order_ViewModel.OrderPrice = STMBStore.Get_Price(order_ViewModel.Symbol, side);
                                                }
                                                #endregion
                                                if (order_ViewModel.OrderPrice == "0" && order_ViewModel.ECode == "0")
                                                    order_ViewModel.OrdType = "1"; // 改為市價
                                                else
                                                    order_ViewModel.OrdType = "2"; // 限價
                                            }
                                            if (!_RiskControlHandler.CheckStockPrice(order_ViewModel, stock_info))
                                                return;
                                            Order order = ComposeNewObject(order_ViewModel, side, false);
                                            if (order == null)
                                                return;
                                            if (!_RiskControlHandler.CheckResult(order))
                                                return;
                                            if (!DoSend(order, order_ViewModel))
                                                return;
                                            break;
                                            #endregion
                                        }
                                    case "Emst":
                                        {
                                            #region 興櫃F1
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;//直接用原本的風控，控正式環境下單
                                            Logger.Info($"[{tab_Order.SelectedTab.Name}] {e.KeyCode}快捷按下");
                                            if (_ViewControlInfoStore.GetTabPageInfo("Emst").QueryModel)
                                            {
                                                MessageBox.Show("查詢中，請先F5再下單", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                Logger.Info("[Emst] 查詢中，請先F5再下單");
                                                return;
                                            }
                                            Side side = e.KeyCode == Keys.F1 ? Side.BUY : Side.SELL;
                                            OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            Order order = ComposeEMNewOrder(otvm, side, "I");
                                            if (order == null)
                                                return;
                                            string nowOrderNo = UserInfo._EMTERM + _OrderStore.興櫃委託書號.ToString().PadLeft(4, '0');
                                            order.DSEQ = nowOrderNo;
                                            if (!_EMRiskControlHandler.CheckNewOrder(order))
                                                return;
                                            if (!SendEmOrder(order))
                                                return;
                                            break;
                                            #endregion
                                        }
                                    case "EmstErrAccount":
                                        {
                                            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                                return;//直接用原本的風控，控正式環境下單
                                            Logger.Info($"[{tab_Order.SelectedTab.Name}] {e.KeyCode}快捷按下");
                                            if (_ViewControlInfoStore.GetTabPageInfo("EmstErrAccount").QueryModel)
                                            {
                                                MessageBox.Show("查詢中，請先F5再下單", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                Logger.Info("[Emst] 查詢中，請先F5再下單");
                                                return;
                                            }
                                            // if (!_EMRiskControlHandler.CheckAllIsPassed())
                                            //     return;
                                            Side side = e.KeyCode == Keys.F1 ? Side.BUY : Side.SELL;
                                            OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                            otvm.BHNO = "8450";
                                            otvm.CSEQ = _ERRORACCOUNT;
                                            otvm.TERM = "X";
                                            otvm.DSEQ = _OrderStore.興櫃錯帳委託書號.ToString();
                                            Order order = ComposeEMNewOrder(otvm, side, "I");
                                            if (order == null)
                                                return;
                                            if (!_EMRiskControlHandler.CheckNewOrder(order))
                                                return;
                                            if (!SendEmOrder(order))
                                                return;
                                            break;
                                        }
                                }
                                break;
                            }
                        case Keys.F11:
                            {
                                DialogResult dialogResult = MessageBox.Show($"現在序號為: {_OrderHandler.GetNowDSEQ("", "")}確定要跳號?", "跳號確認", MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button2);
                                if (dialogResult == DialogResult.Yes)
                                {
                                    _OrderHandler.GetNowDSEQ();
                                    OrderTabViewModel order_Viewmodle = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    order_Viewmodle.DSEQ = _OrderHandler.DSEQ.ToString();
                                }
                                break;
                            }
                        case Keys.F2:
                        case Keys.Multiply:
                            {
                                // 排除一般交易種類頁籤
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "RoundLot":
                                    case "OddLot":
                                    case "FixedPrice":
                                        break;
                                    case "Emst":
                                        if (e.KeyCode == Keys.Multiply)//*強行跳號
                                        {
                                            DialogResult dialogResult = MessageBox.Show($"現在序號為: {_OrderStore.興櫃委託書號}確定要跳號?", "跳號確認", MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button2);
                                            if (dialogResult == DialogResult.Yes)
                                                BeginInvoke((Action)(() => EM_TxbDSEQ.Text = (++_OrderStore.興櫃委託書號).ToString()));
                                        }
                                        return;
                                    case "EmstErrAccount":
                                        if (e.KeyCode == Keys.Multiply)//*強行跳號
                                        {
                                            DialogResult dialogResult = MessageBox.Show($"現在序號為: {_OrderStore.興櫃錯帳委託書號}確定要跳號?", "跳號確認", MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button2);
                                            if (dialogResult == DialogResult.Yes)
                                                BeginInvoke((Action)(() => ++_OrderStore.興櫃錯帳委託書號));
                                        }
                                        return;
                                    default:
                                        return;
                                }
                                //if (ChangeIndex(tab_Order.SelectedTab.Name) > 2)
                                //    return;
                                #region 向上買進/向下賣出
                                Logger.Info($"[Order] {e.KeyCode}快捷按下");
                                if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                    return;
                                if (!_Setting.ORDER_PRICE_COVERED_ENABLE)
                                {
                                    Logger.Debug("委託設定, 未開啟委託價格上下多檔交易功能");
                                    return;
                                }
                                Side side = e.KeyCode == Keys.F2 ? Side.BUY : Side.SELL;
                                // 取得畫面控制項物件數值
                                OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                order_ViewModel.OrderPrice = STMBStore.Get_Price(order_ViewModel.Symbol, side);
                                if (!_RiskControlHandler.Execute(order_ViewModel, side))
                                    return;
                                Order order = ComposeNewObject(order_ViewModel, side, true);
                                if (order == null)
                                    return;
                                if (!_RiskControlHandler.CheckResult(order))
                                    return;
                                拆單Queue.Clear();
                                if (UserInfo._IsSplitLot && ChKSplitLot.Checked)
                                {
                                    foreach (int qty in _OrderHandler.GetShipments(order.OrdQty))
                                    {
                                        Order order1 = ComposeNewOrder(order);
                                        order1.Guid = Guid.NewGuid().ToString();
                                        order1.OrdQty = qty;
                                        拆單Queue.Enqueue(order1);
                                    }
                                    送出拆單("I");
                                }
                                else
                                {
                                    if (!DoSend(order, order_ViewModel))
                                        return;
                                }
                                break;
                                #endregion
                            }
                        case Keys.F3:
                        case Keys.Divide:
                            {
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "OddLot":
                                        #region 零股取 999 股
                                        Logger.Info($"零股取 999 股快捷按下");
                                        OD_TxbStockQty.Text = "999";
                                        OD_TxbStockQty.Focus();
                                        OD_TxbStockQty.SelectAll();
                                        break;
                                    #endregion
                                    case "RoundLot":
                                    case "FixedPrice":
                                    case "ErrAccount":
                                        #region 取得漲停跌停價格
                                        Logger.Info($"取得漲停跌停價格快捷按下");
                                        // 取得畫面控制項物件數值
                                        OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                        StockInfo info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
                                        if (info != null)
                                        {
                                            var TxbPrice = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                                                                   .Where(ctrl => ctrl.Value.Name.Contains("TxbPrice"))
                                                                                   .FirstOrDefault();
                                            order_ViewModel.OrderPrice = e.KeyCode == Keys.F3 ? info.TPRICE.ToString() : info.BPRICE.ToString();
                                            TxbPrice.Value.Focus();
                                            ((TextBox)TxbPrice.Value).SelectAll();
                                            Application.DoEvents();
                                        }
                                        break;
                                        #endregion
                                }
                                break;
                            }
                        case Keys.F5:
                            {
                                Keys_F5();
                                break;
                            }
                        case Keys.F7:
                            {
                                #region 取得平盤價
                                Logger.Info($"取得平盤價快捷按下");
                                // 僅在 (普通,零股,定盤)交易介面可用
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "RoundLot":
                                    case "OddLot":
                                    case "FixedPrice":
                                        break;
                                    default:
                                        return;
                                }
                                //if (ChangeIndex(tab_Order.SelectedTab.Name) > 2)
                                //    return;
                                OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                StockInfo info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
                                if (info != null)
                                {
                                    var TxbPrice = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                           .Where(ctrl => ctrl.Value.Name.Contains("TxbPrice"))
                                           .FirstOrDefault();
                                    order_ViewModel.OrderPrice = info.CPRICE.ToString();
                                    TxbPrice.Value.Focus();
                                    ((TextBox)TxbPrice.Value).SelectAll();
                                    Application.DoEvents();
                                }
                                break;
                                #endregion
                            }
                        case Keys.F8:
                            {
                                #region 改量快捷
                                Logger.Info("[Order] 改量快捷按下");
                                if (IsAtEmstTab())
                                {
                                    #region 興櫃改量快捷
                                    OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (order_ViewModel.ChagePriceModel)
                                        return;
                                    string dseq = order_ViewModel.TERM + order_ViewModel.DSEQ.PadLeft(4, '0');
                                    Report report = OrderStore.回報List.FirstOrDefault(x => x.DSEQ == dseq);
                                    if (report == null)
                                        return;
                                    if (order_ViewModel.QueryModel && !order_ViewModel.ChageQtyModel)
                                    {
                                        int remain = 0;
                                        int.TryParse(report.LaveQty.ToString(), out remain);
                                        if (remain <= 0)
                                        {
                                            MessageBox.Show($"{dseq} 無庫存不能改量", "改量風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            Logger.Info($"[{tab_Order.SelectedTab.Name}] {dseq} 無庫存不能改量");
                                            return;
                                        }
                                        order_ViewModel.OrderQty = "0";
                                        FocusTxb("TxbStockQty");
                                        order_ViewModel.OrdInfoText = "部分取消,請輸入欲取消數量,F8送出,F5清除";
                                        order_ViewModel.ChageQtyModel = true;
                                    }
                                    else if (order_ViewModel.ChageQtyModel)
                                    {
                                        int int_ordQty = 0;
                                        int.TryParse(order_ViewModel.OrderQty, out int_ordQty);
                                        SendOutChangeQty(report, int_ordQty);
                                    }
                                    #endregion 興櫃改量快捷
                                }
                                else
                                {
                                    Keys_F8();
                                }
                                #endregion
                                break;
                            }
                        case Keys.F9:
                            {
                                if (IsAtEmstTab())
                                {
                                    #region 興櫃改價快捷
                                    Logger.Info($"[{tab_Order.SelectedTab.Name}] 改價快捷");
                                    OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (order_ViewModel.ChageQtyModel)
                                        return;
                                    string dseq = order_ViewModel.TERM + order_ViewModel.DSEQ.PadLeft(4, '0');
                                    Report dr = OrderStore.回報List.FirstOrDefault(x => x.DSEQ == dseq);
                                    if (dr == null)
                                        return;
                                    if (order_ViewModel.QueryModel && !order_ViewModel.ChagePriceModel)
                                    {
                                        int remain = 0;
                                        int.TryParse(dr.LaveQty.ToString(), out remain);
                                        if (remain <= 0)
                                        {
                                            MessageBox.Show($"{dseq} 無庫存不能改價", "改價風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            Logger.Info($"[Emst] {dseq} 無庫存不能改價");
                                            return;
                                        }
                                        FocusTxb("TxbPrice");
                                        order_ViewModel.OrdInfoText = "請輸入欲改後價格,F9送出,F5清除";
                                        order_ViewModel.ChagePriceModel = true;
                                    }
                                    else if (order_ViewModel.ChagePriceModel)
                                    {
                                        SendOutChangePrice(dr, decimal.Parse(order_ViewModel.OrderPrice));
                                    }
                                    #endregion 興櫃改價快捷
                                }
                                else
                                {
                                    var ViewControlInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (tab_Order.SelectedTab.Name == "OddLot" || tab_Order.SelectedTab.Name == "FixedPrice")
                                        return;
                                    if (ViewControlInfo.ForceBtnVisable)
                                    {
                                        #region 風控踢回改量
                                        OnForceBtnVisableChange(tab_Order.SelectedTab.Name, false);
                                        ViewControlInfo.ForceBtnVisable = false;
                                        var TxbOrdQty = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                                                             .Where(ctrl => ctrl.Value.Name.Contains("TxbStockQty"))
                                                                             .FirstOrDefault();
                                        TxbOrdQty.Value.Focus();
                                        ((TextBox)TxbOrdQty.Value).SelectAll();
                                        break;
                                        #endregion
                                    }
                                    else
                                    {
                                        #region 改價快捷
                                        Logger.Info("[Order] 改價快捷按下");
                                        OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                        if (!order_ViewModel.QueryModel && order_ViewModel.ECode == "0")
                                        {
                                            Logger.Debug("order_ViewModel.QueryModel=" + order_ViewModel.QueryModel);
                                            return;
                                        }
                                        if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                                            return;

                                        var TxbPrice = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                            .Where(ctrl => ctrl.Value.Name.Contains("TxbPrice"))
                                            .FirstOrDefault();

                                        #region 顯示改價訊息
                                        if (!order_ViewModel.ChagePriceModel)
                                        {
                                            Logger.Info("[Order] 改價訊息顯示");
                                            if (order_ViewModel.OrdType == "1")
                                            {
                                                order_ViewModel.OrdInfoText = $"[市價單 不可改價]";
                                            }
                                            else if (order_ViewModel.ECode == "3")
                                            {
                                                order_ViewModel.OrdInfoText = $"[定盤交易 不可改價]";
                                            }
                                            else
                                            {
                                                order_ViewModel.OrderPrice = "0";
                                                order_ViewModel.ChagePriceModel = true;
                                                order_ViewModel.OrdInfoText = $"[請輸入欲改後價格,F5清除]";

                                                TxbPrice.Value.Focus();
                                                ((TextBox)TxbPrice.Value).SelectAll();
                                            }
                                            return;
                                        }
                                        else
                                        {
                                            Logger.Debug("order_ViewModel.ChagePriceModel=" + order_ViewModel.ChagePriceModel);
                                        }
                                        #endregion

                                        string DSEQ = order_ViewModel.TERM + order_ViewModel.DSEQ;
                                        if (string.IsNullOrEmpty(DSEQ))
                                        {
                                            MessageBox.Show("未輸入正確委託書號");
                                            Logger.Error($"[Order] 改價失敗: 未輸入正確委託書號 - {DSEQ}");
                                            return;
                                        }
                                        StockInfo info = STMBStore.Get_SymbolInfo(order_ViewModel.Symbol);
                                        if (info == null ||
                                            !_RiskControlHandler.CheckStockPrice(order_ViewModel, info))
                                        {
                                            TxbPrice.Value.Text = "0";
                                            TxbPrice.Value.Focus();
                                            ((TextBox)TxbPrice.Value).SelectAll();
                                            return;
                                        }
                                        var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
                                        if (report != null)
                                        {
                                            if (order_ViewModel.OrderPrice == report.OrdPrice.ToString())
                                            {
                                                Logger.Debug("[Order] 改價不可等於原價，改價失敗");
                                                order_ViewModel.OrdInfoText = "改價不可等於原價";
                                                ShowLabInfo(tab_Order.SelectedTab.Name, true);
                                                return;
                                            }
                                            SendOutChangePrice(report, decimal.Parse(order_ViewModel.OrderPrice));
                                        }
                                        order_ViewModel.ChagePriceModel = false;
                                        ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, false, "", "");
                                    }
                                }
                                break;
                                #endregion

                            }
                        case Keys.F10:
                            {
                                #region 委託類別欄位鎖定
                                {
                                    var ViewControlInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (ViewControlInfo.ForceBtnVisable)
                                    {
                                        OnForceBtnVisableChange(tab_Order.SelectedTab.Name, false);
                                        ViewControlInfo.ForceBtnVisable = false;
                                    }

                                    switch (tab_Order.SelectedTab.Name)
                                    {
                                        case "RoundLot": // 普通交易頁面
                                            RL_TxbOType.Focus();
                                            RL_TxbOType.SelectAll();
                                            break;
                                        case "FixedPrice": // 定價交易頁面
                                            FP_TxbOType.Focus();
                                            FP_TxbOType.SelectAll();
                                            break;
                                    }
                                    e.SuppressKeyPress = true;
                                    break;
                                }
                                #endregion
                            }
                        case Keys.F12:
                            {
                                #region 查詢
                                if (IsAtEmstTab())
                                {
                                    if (EmstSearch() == 1)
                                        return;
                                }
                                else
                                {
                                    var pageInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    string dseq = pageInfo.TERM + pageInfo.DSEQ.PadLeft(4, '0');
                                    var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(dseq)).Result;
                                    Logger.Debug($"[Query] 按下 F12查詢- Index: {tab_Order.SelectedTab.Name} DSEQ: {dseq}");
                                    if (report == null)
                                    {
                                        Logger.Debug("[Query] 未查到結果");
                                        pageInfo.OrdInfoText = "無此委託資訊";
                                        ShowLabInfo(tab_Order.SelectedTab.Name, true);
                                        return;
                                    }
                                    if (report.MType == "E" || StockInfoHandler.GetECodeValue(report.ECode) != pageInfo.ECode)
                                    {
                                        Logger.Debug("[Query] 未查到結果");
                                        pageInfo.OrdInfoText = "非同盤別委託資訊";
                                        ShowLabInfo(tab_Order.SelectedTab.Name, true);
                                        return;
                                    }
                                    InputOrderInfo(pageInfo, report);
                                    ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, true, report.Side, pageInfo.CancelledQty);
                                }
                                break;
                                #endregion
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                ConcordLogger.Alert("999", $"OrderKeyInEvent-[{e.KeyCode}] Err", $"User: {UserInfo._EMNO}; Exception: {ex}");
                Logger.Error($"OrderKeyInEvent-[{e.KeyCode}] Err: {ex}");
            }
        }
        #region 各個key event
        private void Shift_F2()
        {
            #region 零股批次下單功能
            if (!UserInfo._IsBatchOddLot)
                return;
            var ViewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            _FrmOddLotBatchOrd.ShowDialog();
            if (!_FrmOddLotBatchOrd._result)
                return;
            Logger.Debug($"[Order] {ViewInfo.TERM + ViewInfo.DSEQ}");

            var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(ViewInfo.TERM + ViewInfo.DSEQ)).Result;
            Side side = report.Side == "B" ? Side.BUY : Side.SELL;
            Order order = ComposeNewObject(ViewInfo, side, false);
            if (order == null)
                return;
            ViewInfo.TERM = UserInfo._TRAM;
            ViewInfo.DSEQ = _OrderHandler.DSEQ.ToString();
            Task.Run(() =>
            {
                for (int i = 0; i < _FrmOddLotBatchOrd._OrderCount; i++)
                {
                    Order order1 = ComposeNewOrder(order);
                    order1.Guid = Guid.NewGuid().ToString();
                    order1.DSEQ = _OrderHandler.GetNowDSEQ();
                    if (!_RiskControlHandler.CheckResult(order1))
                        return;
                    Logger.Debug($"[Order] 批次下單{i + 1}/{_FrmOddLotBatchOrd._OrderCount}, 委託書號: {order1.DSEQ}" + " order1.Guid=" + order1.Guid);
                    SendOut(OrderHandler.NewOrder(order1));
                }
            });
            #endregion
        }
        private void Shift_F4()
        {
            #region 刪單快捷
            Logger.Info("[Order] 刪單快捷按下");
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            var ViewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (ViewInfo.QueryModel)
            {
                string CurrentDSEQ = ViewInfo.DSEQ;
                Order order = ComposeDeleteObject(ViewInfo.TERM + CurrentDSEQ);
                if (order != null)
                {
                    _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                    SendOut(OrderHandler.DeleteOrder(order));
                }
                ViewInfo.QueryModel = false;
                #region  連續刪單功能
                string NextDSEQ = (int.Parse(CurrentDSEQ) + 1).ToString().PadLeft(4, '0');
                var NextOrder = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(ViewInfo.TERM + NextDSEQ)).Result;
                if (NextOrder != null &&
                    NextOrder.LaveQty != 0)
                {
                    ViewInfo.CancelModel = true;
                    ViewInfo.OrdInfoText = $"F5清除畫面 SF9刪下一序號";
                    onControlClearDict.TryAdd(ViewInfo.TERM + CurrentDSEQ, ViewInfo.TERM + CurrentDSEQ);
                }
                else
                {
                    ViewInfo.CancelModel = false;
                    ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, false, "", "");
                }
                #endregion
            }
            else
            {
                string dseq = ViewInfo.TERM + ViewInfo.DSEQ.PadLeft(4, '0');
                Logger.Info($"[Order] 刪單快捷按下- 未進查詢模式,先進行查詢 DSEQ:{dseq}");
                //var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(dseq)).Result;
                var report = _OrderStore.GetReportInfoByDSEQ(dseq);
                Logger.Debug("GetReportInfoByDSEQ結束");
                if (report != null)
                {
                    if (StockInfoHandler.GetECodeValue(report.ECode) != ViewInfo.ECode)
                    {
                        Logger.Debug("[Query] 未查到結果");
                        ViewInfo.OrdInfoText = "非同盤別委託資訊";
                        ShowLabInfo(tab_Order.SelectedTab.Name, true);
                        return;
                    }
                    InputOrderInfo(ViewInfo, report);
                    ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, true, report.Side, ViewInfo.CancelledQty);
                }
                else
                {
                    Logger.Debug("[Query] report is null");
                }
            }
            #endregion
        }
        private void Shift_F6()
        {
            #region 零股批次刪單功能
            if (!UserInfo._IsBatchOddLot)
                return;
            _FrmOddLotBatchDle.ShowDialog();
            Logger.Info($"[Shift_F6] 零股批次刪單功能，開始:{_FrmOddLotBatchDle._Begin} 結束:{_FrmOddLotBatchDle._End}");
            string 錯誤的單 = "";
            for (int i = _FrmOddLotBatchDle._Begin; i <= _FrmOddLotBatchDle._End; i++)
            {
                string 委託書號 = UserInfo._TRAM + i.ToString().PadLeft(4, '0');
                Order order = ComposeDeleteObject(委託書號);
                if (order != null)
                {
                    _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                    SendOut(OrderHandler.DeleteOrder(order));
                }
                else
                {
                    錯誤的單 += 委託書號 + ",";
                }
            }
            if (錯誤的單 != "")
            {
                MessageBox.Show($"委託書號:{錯誤的單} 已無剩餘量或錯誤，請確認");
            }
            #endregion
        }
        private void 傳送強制單密碼(string pwd)
        {
            SendToSocket($"35=40560007={pwd}\n");
        }
        private void 送出拆單(string action)
        {
            if (action != "I")
            {
                拆單Queue.Clear();
                return;
            }
            if (拆單Queue.Count <= 0) return;
            Order order = 拆單Queue.Dequeue();
            _RiskControlHandler.CheckResult(order);
            order.DSEQ = _OrderHandler.GetNowDSEQ("", "");
            Logger.Info($"[送出拆單] {order.DSEQ}");
            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
            _OrderStore.空的才能下單.TryAdd(order.DSEQ, order.DSEQ);
            SendOut(OrderHandler.NewOrder(order));
        }
        private void Shift_F8()
        {
            #region 強制單委託
            Logger.Info("[Order] 強制單委託捷按下");
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (!order_ViewModel.ForceBtnVisable)
            {
                Logger.Debug("[Order] 非強制單模式 退出");
                return;
            }
            Order order = _RiskControlHandler.GetForceOrderObject();
            if (order == null) return;
            if (order.AllForceFlag == "Y")
            {
                _FrmForceOrd.Init();
                回傳強制單密碼 = _FrmForceOrd.取得結果;
                _FrmForceOrd.驗證強制單密碼 = 傳送強制單密碼;
                _FrmForceOrd.ShowDialog();
                if (!_FrmForceOrd._Command)
                    return;
                order.f100 = "999";
            }
            if (order.SeqenceFlag == "Y")
            {
                foreach (var i in 拆單Queue)
                {
                    i.f100 = order.f100;
                }
                _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
                SendOut(OrderHandler.NewOrder(order));
            }
            else
            {
                if (!DoSend(order, order_ViewModel))
                    return;
            }
            OnForceBtnVisableChange(tab_Order.SelectedTab.Name, false);
            #endregion
        }
        private void Shift_F9()
        {
            var ViewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (ViewInfo.CancelModel)
            {
                #region 連續取消功能
                Logger.Info("連續取消快捷按下");
                string NextDSEQ = (int.Parse(ViewInfo.DSEQ) + 1).ToString().PadLeft(4, '0');
                var NextReport = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(ViewInfo.TERM + NextDSEQ)).Result;
                if (NextReport != null)
                {
                    ViewInfo.QueryModel = true;
                    ViewInfo.TERM = NextReport.DSEQ.Substring(0, 1);
                    ViewInfo.DSEQ = NextReport.DSEQ.Remove(0, 1);
                    ViewInfo.CSEQ = NextReport.CSEQ;
                    ViewInfo.OType = StockInfoHandler.GetOrderTypeValue(NextReport.OType);
                    ViewInfo.OType_Text = NextReport.OType;
                    ViewInfo.Symbol = NextReport.Stock;
                    ViewInfo.Symbol_Name = NextReport.StockName;
                    if (ViewInfo.ECode == "2" || ViewInfo.ECode == "7")
                    {
                        ViewInfo.OrderQty = NextReport.OrdQty.ToString();
                        ViewInfo.CancelledQty = NextReport.CancelQty.ToString();
                        ViewInfo.QueryLaveQty = NextReport.LaveQty.ToString();
                        ViewInfo.QueryDealQty = NextReport.DealQty.ToString();
                    }
                    else
                    {
                        ViewInfo.OrderQty = (NextReport.OrdQty / 1000).ToString();
                        ViewInfo.CancelledQty = (NextReport.CancelQty / 1000).ToString();
                        ViewInfo.QueryLaveQty = (NextReport.LaveQty / 1000).ToString();
                        ViewInfo.QueryDealQty = (NextReport.DealQty / 1000).ToString();
                    }
                    ViewInfo.OrderPrice = NextReport.OrdPrice;
                    ViewInfo.Sale = NextReport.Sale;
                    ViewInfo.TimeInForce = StockInfoHandler.GetTimInForceValue(NextReport.TimeInForce);
                    ViewInfo.CancelModel = false;
                    ViewInfo.QueryModel = true;
                    ViewInfo.OrdInfoText = $"F5清除畫面 SF4刪單";
                }
                #endregion
            }
            else
            {
                #region 更改櫃號
                Logger.Info("更改櫃號快捷按下");
                int tabIndex = 0;
                switch (tab_Order.SelectedTab.Name)
                {
                    case "RoundLot":
                        tabIndex = 9;
                        break;
                    case "OddLot":
                        tabIndex = 17;
                        break;
                    case "FixedPrice":
                        tabIndex = 28;
                        break;
                }
                var TxbTREM = _ViewControlInfoStore.GetOrderTabPageControl(tab_Order.SelectedTab.Name, tabIndex);
                if (TxbTREM != null)
                {
                    TxbTREM.Focus();
                    ((TextBox)TxbTREM).SelectAll();
                }
                #endregion
            }
        }
        private void Keys_F5()
        {
            #region 清除畫面
            Logger.Info($"[{tab_Order.SelectedTab.Name}] 清除畫面");
            if (IsAtEmstTab())
            {
                ResetEMOrder(true);
            }
            else
            {
                btn_OpenFrmTimeSharing.Visible = false;
                var ViewControlInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                if (ViewControlInfo.ForceBtnVisable)
                {
                    OnForceBtnVisableChange(tab_Order.SelectedTab.Name, false);
                    ViewControlInfo.ForceBtnVisable = false;
                }
                ViewControlInfo.CancelModel = false;
                ViewControlInfo.QueryModel = false;
                ViewControlInfo.ChageQtyModel = false;
                ViewControlInfo.ChagePriceModel = false;

                string str = tab_Order.SelectedTab.Name;
                ViewControlInfo.TERM = (str == "RoundLot" || str == "OddLot" || str == "FixedPrice") ? UserInfo._TRAM : str == "ErrAccount" ? "Q" : "Z";
                ViewControlInfo.DSEQ = (str == "RoundLot" || str == "OddLot" || str == "FixedPrice") ? _OrderHandler.DSEQ.ToString() : str == "ErrAccount" ? "" : _OrderHandler.FuncDSEQ.ToString();
                if (!ViewControlInfo.FixedCSEQ_Enable)
                {
                    ViewControlInfo.CSEQ = "";
                    ViewControlInfo.CSEQ_Name = "";
                }
                if (tab_Order.SelectedTab.Name == "ErrAccount")
                {
                    ViewControlInfo.CSEQ = _ERRORACCOUNT;
                    ViewControlInfo.ECode = "0";
                }
                ViewControlInfo.OType = "0";
                ViewControlInfo.OType_Text = "現";
                ViewControlInfo.Symbol = "";
                ViewControlInfo.Symbol_Name = "";
                ViewControlInfo.Symbol_State = "";
                ViewControlInfo.Symbol_MType = "";
                ViewControlInfo.FinanceState = "";
                ViewControlInfo.StockWarnInfo = "";
                ViewControlInfo.OrderQty = "";
                ViewControlInfo.OrderPrice = "";
                ViewControlInfo.QueryDealQty = "";
                ViewControlInfo.QueryLaveQty = "";
                ViewControlInfo.Sale = "";
                ViewControlInfo.TimeInForce = "0";
                ViewControlInfo.TimeInForce_Text = "ROD";

                if (tab_Order.SelectedTab.Name == "StockPurchase")  // 選購畫面中的序號值
                    SP_TxbSerialNum.Text = "";
                if (tab_Order.SelectedTab.Name == "StockPurchase2")  // 證金標購畫面中的序號值
                    SP2_TxbSerialNum.Text = "";
                _RiskControlHandler.Reset();

                ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, false, "", "");
                if (tab_Order.SelectedTab.Name == "ErrAccount")
                {
                    var TxbStockNo = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                       .Where(ctrl => ctrl.Value.Name.Contains("TxbStockNo"))
                       .FirstOrDefault();
                    TxbStockNo.Value.Focus();
                    ((TextBox)TxbStockNo.Value).SelectAll();
                }
                else
                {
                    var TxbDSEQ = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                                       .Where(ctrl => ctrl.Value.Name.Contains("TxbDSEQ"))
                                                       .FirstOrDefault();
                    TxbDSEQ.Value.Focus();
                    ((TextBox)TxbDSEQ.Value).SelectAll();
                }
            }
            #endregion
        }
        private void Keys_F8()
        {
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (!order_ViewModel.QueryModel)
                return;
            if (!_RiskControlHandler.CheckUserOrderAuthority(_Environment))
                return;

            var TxbOrdQty = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                        .Where(ctrl => ctrl.Value.Name.Contains("TxbStockQty"))
                        .FirstOrDefault();

            #region 顯示改量訊息
            if (!order_ViewModel.ChageQtyModel)
            {
                Logger.Info("[Order] 改量訊息顯示");
                order_ViewModel.OrderQty = "0";
                order_ViewModel.ChageQtyModel = true;
                order_ViewModel.OrdInfoText = $"[部分取消,請輸入欲取銷數量,F5清除]";
                TxbOrdQty.Value.Focus();
                ((TextBox)TxbOrdQty.Value).SelectAll();
                return;
            }
            #endregion

            string DSEQ = order_ViewModel.TERM + order_ViewModel.DSEQ;
            if (string.IsNullOrEmpty(DSEQ))
                return;
            if (!_RiskControlHandler.CheckStockQty(order_ViewModel.OrderQty, order_ViewModel.ECode))
                return;
            var report = Task.Run(() => _OrderStore.GetReportInfoByDSEQ(DSEQ)).Result;
            if (report != null)
            {
                int cancelQty = int.Parse(order_ViewModel.OrderQty);
                int laveQty = report.LaveQty;
                if (cancelQty > laveQty)
                {
                    Logger.Debug("[Order] 改量數量大於剩餘數量，改量失敗");
                    order_ViewModel.OrdInfoText = $"欲改量數量: {cancelQty} 大於可刪數量: {laveQty}，請重新確認";
                    ShowLabInfo(tab_Order.SelectedTab.Name, true);
                    TxbOrdQty.Value.Focus();
                    ((TextBox)TxbOrdQty.Value).SelectAll();
                    return;
                }
                SendOutChangeQty(report, cancelQty);
            }
            order_ViewModel.ChageQtyModel = false;
            ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, false, "", "");
        }
        #endregion

        /// <summary>
        /// 填入委託單資訊
        /// </summary>
        /// <param name="info"></param>
        /// <param name="report"></param>
        private void InputOrderInfo(OrderTabViewModel info, Report report)
        {
            info.QueryModel = true;
            info.DSEQ = report.DSEQ.Remove(0, 1);
            info.CSEQ = report.CSEQ;
            info.CSEQ_Name = report.CusName;
            info.OrdType = StockInfoHandler.GetOrdTypeValue(report.OrdType);
            info.OType = StockInfoHandler.GetOrderTypeValue(report.OType);
            info.OType_Text = report.OType;
            info.Symbol = report.Stock;
            info.Symbol_Name = report.StockName;
            info.ECode = StockInfoHandler.GetECodeValue(report.ECode);
            info.OrderQty = report.OrdQty.ToString();
            info.CancelledQty = report.CancelQty.ToString();
            info.QueryLaveQty = report.LaveQty.ToString();
            info.QueryDealQty = report.DealQty.ToString();
            info.OrderPrice = report.OrdPrice;
            info.Sale = report.Sale;
            info.TimeInForce = StockInfoHandler.GetTimInForceValue(report.TimeInForce);
            info.TimeInForce_Text = report.TimeInForce;
            if (info.QueryLaveQty == "0" || report.Status == "失敗")
            {
                info.OrdInfoText = $"[ 此筆資料 {report.Status} ]";
                info.QueryModel = false;
            }
            else
            {
                if (UserInfo._IsBatchOddLot && (info.ECode == "2" || info.ECode == "7"))
                    info.OrdInfoText = "SF4刪單 SF2連下 SF6連刪 F8部份取消 F5清除  F12再查";
                else if (info.ECode == "2" || info.ECode == "7" || info.ECode == "3")
                    info.OrdInfoText = "SF4刪單 F8部份取消 F5清除  F12再查";
                else
                    info.OrdInfoText = "SF4刪單 F8部份取消 F9改價 F5清除  F12再查";
            }
            FocusTxb("TxbDSEQ");
        }
        public void 明細Filter()
        {
            switch (tab_Order.SelectedTab.Name)
            {
                case "RoundLot":
                    明細View.ApplyFilter(x => x.ECode == "整股" && x.CSEQ != _ERRORACCOUNT && x.MType != "E");
                    break;
                case "OddLot":
                    明細View.ApplyFilter(x => (x.ECode == "零股" || x.ECode == "盤中零股") && x.CSEQ != _ERRORACCOUNT && x.MType != "E");
                    break;
                case "FixedPrice":
                    明細View.ApplyFilter(x => x.ECode == "定價" && x.CSEQ != _ERRORACCOUNT && x.MType != "E");
                    break;
                case "StockBorrow":
                    明細View.ApplyFilter(x => x.ECode == "標借" && x.MType != "E");
                    break;
                case "StockPurchase":
                    明細View.ApplyFilter(x => x.ECode == "標購" && x.MType != "E");
                    break;
                case "StockAuction":
                    明細View.ApplyFilter(x => x.ECode == "拍賣" && x.MType != "E");
                    break;
                case "ErrAccount":
                    明細View.ApplyFilter(x => x.CSEQ == _ERRORACCOUNT && x.MType != "E");
                    break;
                case "StockPurchase2":
                    明細View.ApplyFilter(x => x.ECode == "證金標購" && x.MType != "E");
                    break;
                case "Emst":
                    明細View.ApplyFilter(x => x.CSEQ != _ERRORACCOUNT && x.MType == "E");
                    break;
                case "EmstErrAccount":
                    明細View.ApplyFilter(x => x.CSEQ == _ERRORACCOUNT && x.MType == "E");
                    break;
            }
        }
        /// <summary>
        /// 切換Order Tab 頁面時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_Order_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DGVKeyIn_RowUpdate();
            // 當頁面切換改變ECode數值
            OrderTabViewModel order_Viewmodle = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            DGVHideOrShow();
            明細Filter();
            switch (tab_Order.SelectedTab.Name)
            {
                case "RoundLot":
                    order_Viewmodle.DSEQ = _OrderHandler.DSEQ.ToString();
                    order_Viewmodle.ECode = "0";
                    RL_TxbDSEQ.Focus();
                    RL_TxbDSEQ.Select();
                    break;
                case "OddLot":
                    order_Viewmodle.DSEQ = _OrderHandler.DSEQ.ToString();
                    int time_now = int.Parse(DateTime.Now.ToString("HHmm"));
                    // 若為盤中零股交易時段則ECode為7，盤後零股ECode為2
                    if (_OrderHandler.Get_Trade_Time(7, 0) <= time_now && time_now < _OrderHandler.Get_Trade_Time(7, 1))
                        order_Viewmodle.ECode = "7";
                    else
                        order_Viewmodle.ECode = "2";
                    OD_TxbDSEQ.Focus();
                    OD_TxbDSEQ.SelectAll();
                    break;
                case "FixedPrice":
                    order_Viewmodle.DSEQ = _OrderHandler.DSEQ.ToString();
                    order_Viewmodle.ECode = "3";
                    FP_TxbPrice.Text = "收盤價";
                    FP_TxbDSEQ.Focus();
                    FP_TxbDSEQ.SelectAll();
                    break;
                case "StockBorrow":
                    order_Viewmodle.DSEQ = _OrderHandler.FuncDSEQ.ToString();
                    order_Viewmodle.ECode = "4";
                    SB_TxbDSEQ.Focus();
                    SB_TxbDSEQ.SelectAll();
                    break;
                case "StockPurchase":
                    order_Viewmodle.DSEQ = _OrderHandler.FuncDSEQ.ToString();
                    order_Viewmodle.ECode = "6";
                    SP_TxbDSEQ.Focus();
                    SP_TxbDSEQ.SelectAll();
                    break;
                case "StockAuction":
                    order_Viewmodle.DSEQ = _OrderHandler.FuncDSEQ.ToString();
                    order_Viewmodle.ECode = "5";
                    SA_TxbDSEQ.Focus();
                    SA_TxbDSEQ.SelectAll();
                    break;
                case "ErrAccount":
                    order_Viewmodle.CSEQ = _ERRORACCOUNT; // 設定錯帳專戶帳號
                    ER_TxbECode.Focus();
                    ER_TxbECode.SelectAll();
                    ER_TxbECode.Text = "0";
                    break;
                case "StockPurchase2":
                    order_Viewmodle.DSEQ = _OrderHandler.FuncDSEQ.ToString();
                    order_Viewmodle.ECode = "8";
                    SP2_TxbDSEQ.Focus();
                    SP2_TxbDSEQ.SelectAll();
                    break;
                case "Emst":
                    EM_TxbDSEQ.Focus();
                    EM_TxbDSEQ.SelectAll();
                    break;
                case "EmstErrAccount":
                    order_Viewmodle.ECode = "0";
                    EMER_TxbStockNo.Focus();
                    EMER_TxbStockNo.SelectAll();
                    break;
            }
        }
        /// <summary>
        /// 切換頁面時，顯示或隱藏DGV
        /// </summary>
        private void DGVHideOrShow()
        {
            switch (tab_Order.SelectedTab.Name)
            {
                case "RoundLot":
                case "OddLot":
                case "FixedPrice":
                case "StockBorrow":
                case "StockPurchase":
                case "StockAuction":
                case "ErrAccount":
                case "StockPurchase2":
                    {
                        DGVEmstOrder.Hide();
                        DGVKeyIn.Show();
                        break;
                    }
                case "Emst":
                case "EmstErrAccount":
                    {
                        DGVEmstOrder.Show();
                        DGVKeyIn.Hide();
                        break;
                    }
            }
        }
        /// <summary>
        /// 當輸入控制項按下按鈕事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OrderPageControl_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox this_Ctrl = (TextBox)sender;
            switch (e.KeyCode)
            {
                case Keys.Left:
                    {
                        if (this_Ctrl.SelectionStart == 0)
                            MovedControlIndex(tab_Order.SelectedTab.Name, this_Ctrl.TabIndex, 1);
                    }
                    break;
                case Keys.Up:
                    {
                        MovedControlIndex(tab_Order.SelectedTab.Name, this_Ctrl.TabIndex, 1);
                    }
                    break;
                case Keys.Right:
                    {
                        if (this_Ctrl.SelectionStart == this_Ctrl.Text.Length)
                            MovedControlIndex(tab_Order.SelectedTab.Name, this_Ctrl.TabIndex, -1);
                    }
                    break;
                case Keys.Down:
                case Keys.Enter:
                    {
                        string compare = "";
                        if (tab_Order.SelectedTab.Name == "StockPurchase2")
                        {
                            compare = this_Ctrl.Name.Remove(0, 4);
                        }
                        else if (tab_Order.SelectedTab.Name == "EmstErrAccount")
                        {
                            compare = this_Ctrl.Name.Remove(0, 5);
                        }
                        else
                        {
                            compare = this_Ctrl.Name.Remove(0, 3);
                        }

                        switch (compare)
                        {
                            case "TxbTERM":
                                #region 櫃號
                                _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name).TERM = this_Ctrl.Text;
                                #endregion
                                break;
                            case "TxbStockNo":
                                #region 股票代號邏輯
                                if (!STMBStore.CheckContains(this_Ctrl.Text.Trim()))
                                {
                                    MessageBox.Show("無此股票代號", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    this_Ctrl.Focus();
                                    this_Ctrl.SelectAll();
                                    return;
                                }
                                if (UserInfo._UserIP != _richIP)
                                {
                                    switch (tab_Order.SelectedTab.Name)
                                    {   // 標借標購拍賣不控
                                        case "RoundLot":
                                        case "OddLot":
                                        case "FixedPrice":
                                        case "ErrAccount":
                                            if (!_RiskControlHandler.CheckBOSSymbol(_ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name)))
                                            {
                                                this_Ctrl.Focus();
                                                this_Ctrl.SelectAll();
                                                return;
                                            }
                                            break;
                                    }
                                }
                                if (IsAtEmstTab())
                                {
                                    OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                    if (otvm.QueryModel)
                                        break;
                                    if (!_EMRiskControlHandler.CheckStock(this_Ctrl.Text.Trim()))
                                    {
                                        this_Ctrl.Focus();
                                        this_Ctrl.SelectAll();
                                        return;
                                    }
                                    SendToSocket(_TradingSystemHandler.CheckStock(this_Ctrl.Text.Trim(), (otvm.Unit == "張" || otvm.Unit == "兩") ? 0 : 2));
                                }
                                break;
                            #endregion
                            case "TxbSerialNum":
                                #region 股票序號邏輯
                                uint num = 0;
                                if (UserInfo._UserIP != _richIP)
                                {
                                    if (this_Ctrl.Text.Trim() == "")
                                    {
                                        MessageBox.Show("股票序號不可為空", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        this_Ctrl.Focus();
                                        this_Ctrl.SelectAll();
                                        return;
                                    }
                                    else if (!uint.TryParse(this_Ctrl.Text.Trim(), out num))
                                    {
                                        MessageBox.Show("股票序號須為整數", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        this_Ctrl.Focus();
                                        this_Ctrl.SelectAll();
                                        return;
                                    }
                                }
                                break;
                            #endregion
                            case "TxbCSEQ":
                                #region 客戶帳號邏輯
                                string text = ((TextBox)sender).Text;
                                Customer cusInfo = CUMBStore.Get_CustomerInfo(text.PadLeft(7, '0'));
                                var viewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                if (cusInfo == null)
                                {
                                    viewInfo.CSEQ = "";
                                    viewInfo.CSEQ_Name = "";
                                    viewInfo.Sale = "";
                                    viewInfo.CCODE_Text = "[ 未含有此帳號客戶 ]";
                                    return;
                                }
                                viewInfo.CSEQ = cusInfo.CSEQ;
                                viewInfo.CSEQ_Name = cusInfo.SNAME;
                                viewInfo.Sale = cusInfo.TSALE;
                                viewInfo.CCODE_Text = "";
                                RiskControlHandler._CSEQChecked = true;
                                break;
                            #endregion
                            case "TxbStockQty":
                                #region 委託數量邏輯
                                var ViewInfo = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                                // 內湖分公司 排除驗證
                                switch (tab_Order.SelectedTab.Name)
                                {
                                    case "Emst":
                                    case "EmstErrAccount":
                                        {
                                            if (ViewInfo.QueryModel)
                                                break;
                                            // EMRiskControlHandler._OrdQtyChecked = false;
                                            if (tab_Order.SelectedTab.Name == "EmstErrAccount")
                                            {
                                                ViewInfo.CSEQ = _ERRORACCOUNT;
                                                // _EMRiskControlHandler.CheckCseq = true;
                                            }
                                            // if (!_EMRiskControlHandler.CheckCseq)
                                            // {
                                            //     MessageBox.Show("客戶帳號未確認", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            //     FocusTxb("TxbCSEQ");
                                            //     return;
                                            // }
                                            // if (!_EMRiskControlHandler.GetStockNoChecked)
                                            // {
                                            //     MessageBox.Show("股票未確認", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            //     FocusTxb("TxbStockNo");
                                            //     return;
                                            // }
                                            string ecode = (ViewInfo.Unit == "張" || ViewInfo.Unit == "兩") ? "0" : "2";
                                            string qty = this_Ctrl.Text.Trim();
                                            if (!_EMRiskControlHandler.CheckQty(qty, ecode))
                                                return;
                                            if (ViewInfo.Unit == "張")//整股
                                            {
                                                StockInfo stockInfo = STMBStore.Get_SymbolInfo(ViewInfo.Symbol.Trim());
                                                int int_unit = 1000;
                                                if (stockInfo != null)
                                                    int.TryParse(stockInfo.UNIT, out int_unit);
                                                int int_qty = 0;
                                                int.TryParse(qty, out int_qty);
                                                qty = (int_qty * int_unit).ToString();
                                            }
                                            // SendToSocket(_TradingSystemHandler.CheckOrderQty(ViewInfo.CSEQ, ViewInfo.BHNO, ViewInfo.Symbol.Trim(), qty, ecode));
                                            break;
                                        }
                                    default:
                                        {
                                            if (UserInfo._UserIP == _richIP)
                                            {
                                                if (_RiskControlHandler.CheckStockQty(this_Ctrl.Text, ViewInfo.ECode))
                                                    RiskControlHandler._OrdQtyChecked = true;
                                                else
                                                    return;
                                            }
                                            else
                                            {
                                                // ||!_RiskControlHandler.CheckBOSOrdQty(ViewInfo)
                                                if (!_RiskControlHandler.CheckStockQty(this_Ctrl.Text, ViewInfo.ECode))
                                                    return;
                                            }
                                            break;
                                        }
                                }
                                break;
                            #endregion
                            case "TxbDSEQ":
                                #region 興櫃委託序號邏輯(查詢)
                                if (tab_Order.SelectedTab.Name == "Emst")
                                {
                                    if (EmstSearch() == 1)
                                        return;
                                }
                                #endregion
                                break;
                        }
                        MovedControlIndex(tab_Order.SelectedTab.Name, this_Ctrl.TabIndex, -1);
                    }
                    break;
            }
        }

        #region 委託欄位相關事件
        #endregion

        /// <summary>
        /// 控制項輸入移動事件
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="currentIndex"></param>
        /// <param name="movedCount"></param>
        private void MovedControlIndex(string pageIndex, int currentIndex, int movedCount)
        {
            var Ctrl = _ViewControlInfoStore.GetOrderTabPageControl(pageIndex, currentIndex + movedCount);
            if (Ctrl == null)
                return;
            if (string.IsNullOrWhiteSpace(Ctrl.Text))
                Ctrl.Text = " ";
            Ctrl.Focus();
            ((TextBox)Ctrl).SelectAll();
        }
        /// <summary>
        /// 排除非主畫面控制項取得 '/', '-' 鍵盤事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals('/') || e.KeyChar.Equals('-') || e.KeyChar.Equals('*') || e.KeyChar.Equals(' '))
                e.Handled = true;
        }
        /// <summary>
        /// 下單列TextBox控制項 空白鍵刪除字元事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Control_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                TextBox this_Ctrl = (TextBox)sender;
                int origSelecStartIndex = this_Ctrl.SelectionStart;
                if (origSelecStartIndex == this_Ctrl.Text.Length)
                    return;
                this_Ctrl.Text = this_Ctrl.Text.Remove(origSelecStartIndex, 1);
                this_Ctrl.Select(origSelecStartIndex, 0);
            }
        }
        /// <summary>
        /// 委託條件控制項清空
        /// </summary>
        public void OrdControlClear()
        {
            string str = tab_Order.SelectedTab.Name;
            var ViewControlInfo = _ViewControlInfoStore.GetTabPageInfo(str);
            ViewControlInfo.TERM = (str == "RoundLot" || str == "OddLot" || str == "FixedPrice") ? UserInfo._TRAM : str == "ErrAccount" ? "Q" : "Z";
            ViewControlInfo.DSEQ = (str == "RoundLot" || str == "OddLot" || str == "FixedPrice") ? _OrderHandler.DSEQ.ToString() : str == "ErrAccount" ? "" : _OrderHandler.FuncDSEQ.ToString();
            if (_Setting.ORDER_SUCCESS_CLEAR)
            {
                if (!ViewControlInfo.FixedCSEQ_Enable)
                {
                    ViewControlInfo.CSEQ = "";
                    ViewControlInfo.CSEQ_Name = "";
                }
                if (tab_Order.SelectedTab.Name == "ErrAccount")
                {
                    ViewControlInfo.CSEQ = _ERRORACCOUNT;
                    ViewControlInfo.ECode = "0";
                }
                ViewControlInfo.OType = "0";
                ViewControlInfo.OType_Text = "現";
                ViewControlInfo.Symbol = "";
                ViewControlInfo.Symbol_Name = "";
                ViewControlInfo.Symbol_State = "";
                ViewControlInfo.Symbol_MType = "";
                ViewControlInfo.FinanceState = "";
                ViewControlInfo.StockWarnInfo = "";
                ViewControlInfo.OrderQty = "";
                ViewControlInfo.OrderPrice = "";
                ViewControlInfo.TimeInForce = "0";
                ViewControlInfo.OrdType = "2";
                ViewControlInfo.QueryDealQty = "";
                ViewControlInfo.QueryLaveQty = "";
                if (!RiskControlHandler._IsKeepCusAccount)
                    ViewControlInfo.Sale = "";
                ViewControlInfo.QueryModel = false;
                ViewControlInfo.CancelModel = false;
                ViewControlInfo.ChageQtyModel = false;
                ViewControlInfo.ChagePriceModel = false;
                ViewControlInfo.ForceBtnVisable = false;

                if (tab_Order.SelectedTab.Name == "StockPurchase")  // 選購畫面中的序號值
                    SP_TxbSerialNum.Text = "";

                if (tab_Order.SelectedTab.Name == "StockPurchase2")  // 證金標購畫面中的序號值
                    SP2_TxbSerialNum.Text = "";

                OnForceBtnVisableChange(tab_Order.SelectedTab.Name, false);
                ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, false, "", "");
                _RiskControlHandler.Reset();

                // 清空畫面後 輸入指向控制項調整
                if ((ViewControlInfo.FixedCSEQ_Enable && (str == "RoundLot" || str == "OddLot" || str == "FixedPrice")) || str == "ErrAccount")
                {
                    string InitControl = "";
                    if (tab_Order.SelectedTab.Name == "RoundLot" || tab_Order.SelectedTab.Name == "FixedPrice")
                        InitControl = _Setting.FIXED_CSEQ_INIT_OTYPE ? "TxbOType" : "TxbStockNo";
                    else
                        InitControl = "TxbStockNo";

                    var TxbStockNo = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                   .Where(ctrl => ctrl.Value.Name.Contains(InitControl))
                                   .FirstOrDefault();
                    TxbStockNo.Value.Focus();
                    ((TextBox)TxbStockNo.Value).SelectAll();
                }
                else
                {
                    var TxbDSEQ = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                                       .Where(ctrl => ctrl.Value.Name.Contains("TxbDSEQ"))
                                                       .FirstOrDefault();
                    TxbDSEQ.Value.Focus();
                    ((TextBox)TxbDSEQ.Value).SelectAll();
                }
            }
        }
        /// <summary>
        /// 整股拆單功能啟動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChKSplitLot_CheckedChanged(object sender, EventArgs e)
        {
            RiskControlHandler._SplitLotEnable = ChKSplitLot.Checked;
        }
        #endregion

    }
}
