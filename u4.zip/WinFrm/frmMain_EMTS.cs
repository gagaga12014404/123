﻿using Concord.SDK.IOCPHelper;
using Concord.SDK.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmMain : Form
    {
        #region Trading System Event
        /// <summary>
        /// 組興櫃新單
        /// </summary>
        private Order ComposeEMNewOrder(OrderTabViewModel otvm, Side side, string orderAction)
        {
            Order order = new Order();
            order.CSEQ = otvm.CSEQ;//客戶帳號
            order.BHNO = otvm.BHNO;//分公司別
            order.DSEQ = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');//委託書號
            order.Side = side;//買or賣
            order.Symbol = otvm.Symbol.Trim();//股票
            // int qty = 0;
            // int.TryParse(EM_TxbStockQty.Text, out qty);
            int ordQty = 0;
            int.TryParse(otvm.OrderQty, out ordQty);
            order.OrdQty = ordQty;//委託數量
            if (otvm.Unit == "股")
                order.ECode = "2";
            else if (otvm.Unit == "兩")
                order.ECode = "0";
            else
            {
                order.ECode = "0";
                int unit = 1000;
                StockInfo stock = STMBStore.Get_SymbolInfo(order.Symbol.Trim());
                if (stock != null)
                {
                    int.TryParse(stock.UNIT, out unit);
                    if (stock.STYPE == "9")
                        unit = 1;
                }
                order.OrdQty *= unit;
            }
            order.Sale = otvm.Sale;//營業員
            order.OrdPrice = otvm.OrderPrice;//委託價
            order.ExecType = orderAction;//新、刪、改
            order.AllForceFlag = "N";//強行Y or N
            return order;
        }
        /// <summary>
        /// 送出興櫃刪單
        /// </summary>
        private void SendEMCancel(string dseq)
        {
            var list = _OrderStore.GetReportInfoByDSEQ(dseq);
            if (list == null)
            {
                MessageBox.Show($"未找到對應委託單{dseq}", "刪單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Order order = _OrderStore.DataRowToEMOrder(list);
            order.ExecType = "D";
            int LaveQty = 0;
            int.TryParse(list.LaveQty.ToString(), out LaveQty);
            if (!_EMRiskControlHandler.CheckDelete(order, LaveQty))
                return;
            if (!SendEmOrder(order))
                return;
            _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name).CancelModel = true;
        }
        /// <summary>
        /// 送出下單電文
        /// </summary>
        private bool SendEmOrder(Order order)
        {
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            if (_OrderStore.空的才能下單.Count == 0)
                _OrderStore.空的才能下單.TryAdd(order.DSEQ, order.DSEQ);
            else
            {
                order_ViewModel.OrdInfoText = "請稍後再試";
                ShowLabInfo(tab_Order.SelectedTab.Name, true);
                return false;
            }
            _OrderStore._OrdDSEQ.TryAdd(order.DSEQ, order.DSEQ);
            return SendToSocket(_TradingSystemHandler.Order(order));
        }
        /// <summary>
        /// 確認與交易系統連線後送出委託
        /// </summary>
        private bool SendToSocket(string message)
        {
            if (_SOrderSession.ClientConnectState != ConnectState.Connected)
            {
                Logger.Error("[TradingSystem] 斷線，送單失敗");
                var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                otvm.OrdInfoText = "後台交易系統連線失敗";
                return false;
            }
            if (!_SendMessage_Timer.Enabled)
                _SendMessage_Timer.Enabled = true;
            _SOrderSession.SendMessage(message);
            return true;
        }
        private int EmstSearch()
        {
            int ret = 0;
            var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            string dseq = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');
            Logger.Debug($"[Query] 按下 F12查詢- Index: {tab_Order.SelectedTab.Name} DSEQ: {dseq}");
            var report = OrderStore.回報List.FirstOrDefault(x => x.DSEQ == dseq);
            if (report != null && report.MType != "E")
            {
                otvm.OrdInfoText = $"非同盤別委託資訊";
                ret = 1;
            }
            else if (report != null)
            {
                Logger.Debug($"[{tab_Order.SelectedTab.Name}] 查詢{dseq}");
                ShowEMstSearchInfo(report);
            }
            else if (otvm.TERM == UserInfo._EMTERM)//同櫃當作新單、如果有成功下單紀錄，卻沒有回報代表狀態未明
            {
                Logger.Debug($"[Emst] 新單");
            }
            else
            {
                EmstSearchNone();
                ret = 1;
            }
            return ret;
        }
        /// <summary>
        /// 選取指定欄位
        /// </summary>
        private void FocusTxb(string fieldName)
        {
            var Txb = _ViewControlInfoStore.GetOrderTabPageControlCollection(tab_Order.SelectedTab.Name)
                                        .Where(ctrl => ctrl.Value.Name.Contains(fieldName))
                                        .FirstOrDefault();
            Txb.Value.Focus();
            ((TextBox)Txb.Value).SelectAll();
        }
        /// <summary>
        /// 是否在興櫃頁面上
        /// </summary>
        private bool IsAtEmstTab()
        {
            if (tab_Order.SelectedTab.Name == "Emst" ||
                tab_Order.SelectedTab.Name == "EmstErrAccount")
                return true;
            return false;
        }
        /// <summary>
        /// F5清空興櫃畫面
        /// </summary>
        private void ResetEMOrder(bool clearAll)
        {
            string tabName = tab_Order.SelectedTab.Name;
            OrderTabViewModel order_ViewModel = _ViewControlInfoStore.GetTabPageInfo(tabName);
            order_ViewModel.TERM = tabName == "Emst" ? UserInfo._EMTERM : "X";
            order_ViewModel.DSEQ = tabName == "Emst" ? _OrderStore.興櫃委託書號.ToString() : "";
            order_ViewModel.ForceBtnVisable = false;
            order_ViewModel.OrdInfoText = "";//錯誤訊息
            if (order_ViewModel.QueryModel)//刪、改、價完固定全清除
                clearAll = true;
            if (clearAll || _Setting.ORDER_SUCCESS_CLEAR)
            {
                order_ViewModel.StockWarnInfo = "";
                order_ViewModel.CancelModel = false;
                order_ViewModel.ChagePriceModel = false;
                order_ViewModel.ChageQtyModel = false;
                order_ViewModel.QueryModel = false;
                order_ViewModel.Symbol = "";        //股票代號
                order_ViewModel.Symbol_Name = "";   //股票名稱
                order_ViewModel.BasicPrice = "";    //基準價
                order_ViewModel.OrderQty = "";
                order_ViewModel.OrderPrice = "";
                EM_BuySell.Text = "";               //買or賣
                order_ViewModel.SearchResult = "";   //查詢結果
                order_ViewModel.Unit = "張";
                order_ViewModel.CCODE_Text = "";
                order_ViewModel.QueryLaveQty = "";
                order_ViewModel.QueryDealQty = "";
                ChangeOrderInfoVisible(tabName, false, "B", "0");
                _EMRiskControlHandler.ResetRiskControl();
            }
            #region 固定委託人帳號
            if (order_ViewModel.FixedCSEQ_Enable && !clearAll)//1.固定不清客戶2.F5一定清
                FocusTxb("TxbStockNo");
            else if (_Setting.ORDER_SUCCESS_CLEAR || clearAll)
            {
                order_ViewModel.Sale = "";//營業員
                order_ViewModel.CSEQ = "";//客戶帳號
                order_ViewModel.CSEQ_Name = "";//客戶名稱
                FocusTxb(tabName == "Emst" ? "TxbDSEQ" : "TxbStockNo");
            }
            #endregion 固定委託人帳號
        }
        /// <summary>
        /// 使用DataRow將搜尋到的回報顯示在畫面
        /// </summary>
        private void ShowEMstSearchInfo(Report report)
        {
            if (report == null)
                return;
            BeginInvoke((Action)(() =>
            {
                OrderTabViewModel otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
                otvm.DSEQ = report.DSEQ.Substring(1, 4);
                otvm.CSEQ = report.CSEQ;
                otvm.CSEQ_Name = report.CusName;
                otvm.Symbol = report.Stock;
                int stockQty = 0;
                int.TryParse(report.OrdQty.ToString(), out stockQty);
                int cancelQty = 0;
                int.TryParse(report.CancelQty.ToString(), out cancelQty);
                StockInfo stockInfo = STMBStore.Get_SymbolInfo(report.Stock.Trim());
                int unit = 1000;
                string stype = "";
                string string_unit = "股";
                if (stockInfo != null)
                {
                    int.TryParse(stockInfo.UNIT, out unit);
                    stype = stockInfo.STYPE;
                }
                if (report.ECode == "整股")
                {
                    if (stype == "9")
                    {
                        otvm.Unit = "兩";
                        otvm.CancelledQty = cancelQty.ToString();
                        otvm.OrderQty = stockQty.ToString();
                        string_unit = "兩";
                    }
                    else
                    {
                        otvm.Unit = "張";
                        otvm.CancelledQty = (cancelQty / unit).ToString();
                        otvm.OrderQty = (stockQty / unit).ToString();
                    }
                }
                else
                {
                    otvm.OrderQty = stockQty.ToString();
                    otvm.Unit = "股";
                    otvm.CancelledQty = report.CancelQty.ToString();
                }
                otvm.OrderPrice = report.OrdPrice;
                if (tab_Order.SelectedTab.Name == "Emst")
                    EM_BuySell.Text = report.Side;
                int LaveQty = 0, dealQty = 0;
                int.TryParse(report.LaveQty.ToString(), out LaveQty);
                int.TryParse(report.DealQty.ToString(), out dealQty);
                if (report.Status == "失敗")
                    otvm.OrdInfoText = report.Text;
                else if (LaveQty <= 0 && dealQty > 0)
                    otvm.OrdInfoText = "此筆單已完全成交  F5取消  F12再查";
                else if (LaveQty <= 0 && dealQty <= 0)
                    otvm.OrdInfoText = "此筆已刪單  F5取消  F12再查";
                else
                    otvm.OrdInfoText = "[SF4 刪單  F8部份取消  F9改價  F5取消  F12再查]";
                otvm.SearchResult = "[此單已成交" + dealQty.ToString("#,0").PadLeft(10, ' ') + $"{string_unit}, 剩餘" + LaveQty.ToString("#,0").PadLeft(10, ' ') + $"{string_unit}]";
                otvm.QueryModel = true;
                otvm.QueryLaveQty = String.Format("{0:N0}", report.LaveQty);
                otvm.QueryDealQty = String.Format("{0:N0}", report.DealQty);
                ChangeOrderInfoVisible(tab_Order.SelectedTab.Name, true, report.Side, report.CancelQty.ToString());
                FocusTxb("TxbDSEQ");
            }));
        }
        /// <summary>
        /// 興櫃沒有查到跨櫃委託書號資訊
        /// </summary>
        private void EmstSearchNone()
        {
            var otvm = _ViewControlInfoStore.GetTabPageInfo(tab_Order.SelectedTab.Name);
            string dseq = otvm.TERM + otvm.DSEQ.PadLeft(4, '0');
            MessageBox.Show($"{dseq}無此單資料", "查詢風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Logger.Info($"[Emst] {dseq}無此單資料");
            BeginInvoke((Action)(() => FocusTxb("TxbDSEQ")));
        }
        #endregion Trading System Event
    }
}
