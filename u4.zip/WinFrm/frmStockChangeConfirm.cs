﻿using Concord.SDK.Logging;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public partial class frmStockChangeConfirm : Form
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        /// <summary>
        /// 送出改量電文
        /// </summary>
        public Action<Report, int> SendChangeQtyOrd;
        /// <summary>
        /// 送出改價電文
        /// </summary>
        public Action<Report, decimal> SendChangePriceOrd;

        /// <summary>
        /// 股票資訊
        /// </summary>
        private StockInfo _StockInfo = new StockInfo();

        private Report _ReportInfo;
        /// <summary>
        /// 可改數量
        /// </summary>
        private int _NoDealQty = 0;
        /// <summary>
        /// 原委託價
        /// </summary>
        private decimal _OrigOrdPrice = 0;

        public frmStockChangeConfirm()
        {
            InitializeComponent();
        }

        public void Init(string mode, Report report)
        {
            switch (mode)
            {
                case "ChgQty":
                    tabControl.SelectedIndex = 0;
                    nudChangeQTY.Text = "1";
                    break;
                case "ChgPrice":
                    tabControl.SelectedIndex = 1;
                    break;
            }
            _ReportInfo = report;
            labStockNo.Text = report.Stock;
            _StockInfo = STMBStore.Get_SymbolInfo(labStockNo.Text.Trim());
            int order_qty = report.OrdQty;
            int deal_qty = report.DealQty;
            int cancel_qty = report.CancelQty;
            if (report.ECode.Contains("零股"))
            {
                _NoDealQty = order_qty - deal_qty - cancel_qty;
                labUnit.Text = "股";
            }
            else
            {
                int unit = int.Parse(_StockInfo.UNIT);
                _NoDealQty = order_qty - deal_qty - cancel_qty;
                labUnit.Text = (_StockInfo.STYPE == "9") ? "兩" : "張";
            }
            txbDSEQ.Text = report.DSEQ;
            labStockName.Text = _StockInfo.CNAME;
            labMType.Text = _StockInfo.MTYPE;
            nudChangePrice.Maximum = _StockInfo.TPRICE == 0 ? 9999.95m : _StockInfo.TPRICE;
            nudChangePrice.Minimum = _StockInfo.BPRICE == 0 ? 0.01m : _StockInfo.BPRICE;
            nudChangePrice.Text = report.OrdPrice.ToString();
            decimal ChangePrice = 0;
            decimal.TryParse(nudChangePrice.Text, out ChangePrice);
            _OrigOrdPrice = ChangePrice;
            nudChangePrice.Increment = StockInfoHandler.GetStockPriceTick(_StockInfo.STYPE, ChangePrice);
            labOrderType.Text = report.OType;
            labPrice.Text = report.OrdPrice.ToString();
            labRequestAmount.Text = report.OrdQty.ToString();
            labSale.Text = report.Sale;
            labNoDealQty.Text = _NoDealQty.ToString();

            Show();
            if (tabControl.SelectedIndex == 0)
            {
                nudChangeQTY.Focus();
                nudChangeQTY.Select(0, nudChangeQTY.Text.Length);
            }
            else if (tabControl.SelectedIndex == 1)
            {
                nudChangePrice.Focus();
                nudChangePrice.Select(0, nudChangePrice.Text.Length);
            }
        }
        /// <summary>
        /// 取消扭按下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Hide();
            Logger.Info("[Order] 改量確認取消");
        }
        /// <summary>
        /// 改量鈕按下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChangeOrder_Click(object sender, EventArgs e)
        {
            Logger.Info("[Order] 改量確認鍵按下");

            if (!CheckChangeQty())
                return;

            int changeQty = Convert.ToInt32(nudChangeQTY.Value);
            SendChangeQtyOrd(_ReportInfo, changeQty);
            Hide();
        }
        /// <summary>
        /// 確認改量數量是否合法
        /// </summary>
        /// <returns></returns>
        private bool CheckChangeQty()
        {
            if (nudChangeQTY.Value == 0)
            {
                MessageBox.Show($"部分取消量不可為0，請重新輸入");
                nudChangeQTY.Focus();
                nudChangeQTY.Select();
                return false;
            }
            if (nudChangeQTY.Value > _NoDealQty)
            {
                MessageBox.Show($"超過可改數量: {_NoDealQty}，請重新輸入");
                nudChangeQTY.Focus();
                nudChangeQTY.Select();
                return false;
            }
            return true;
        }
        /// <summary>
        /// 改價扭按下時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChangePrice_Click(object sender, EventArgs e)
        {
            Logger.Info("[Order] 改價確認鍵按下");
            if (_OrigOrdPrice == nudChangePrice.Value)
            {
                MessageBox.Show("改價不可等於原價", "下單風控", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SendChangePriceOrd(_ReportInfo, nudChangePrice.Value);
            Hide();
        }
        /// <summary>
        /// 鍵盤事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmStockChangeOrder_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    Hide();
                    Logger.Info("[Order] 改價/量視窗 確認取消");
                    break;
                case Keys.F8:
                    btnChangeOrder_Click(sender, e);
                    break;
                case Keys.F9:
                    btnChangePrice_Click(sender, e);
                    break;
            }
        }

        private void frmStockChangeConfirm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
    }
}
