﻿using System.Collections.Generic;

namespace Concord.KeyIn.Client
{
    /// <summary>
    /// HTTP 服務回應結果
    /// </summary>
    public class HttpResponse
    {
        public HttpResponse()
        {
            this.StatusCode = rCode.Non;
            this.CodeDesc = "";
            Deatils = new List<string>();
        }

        /// <summary>
        /// 狀態碼
        /// </summary>
        public rCode StatusCode { get; set; }
        /// <summary>
        /// 狀態說明
        /// </summary>
        public string CodeDesc { get; set; }
        /// <summary>
        /// 查詢明細
        /// </summary>
        public List<string> Deatils { get; set; }
    }

    public enum rCode
    {
        /// <summary>
        /// 初始
        /// </summary>
        Non = -1,
        /// <summary>
        /// 成功
        /// </summary>
        Success = 000,
        /// <summary>
        /// DB作業失敗
        /// </summary>
        DB_Error = 201,
        /// <summary>
        /// 此功能暫停服務
        /// </summary>
        Suspend = 900,
        /// <summary>
        /// 自訂訊息
        /// </summary>
        Customize = 901,
        /// <summary>
        /// 查詢條件數目不符
        /// </summary>
        Parameters_Not_Match = 902,
        /// <summary>
        /// 要求資訊錯誤
        /// </summary>
        Request_Error = 903,
        /// <summary>
        /// 尚未提供此服務
        /// </summary>
        Unavailable = 904,
        /// <summary>
        /// 無符合之資料
        /// </summary>
        Non_compliant = 925,
        /// <summary>
        /// 非預期錯誤
        /// </summary>
        Unhandled_Error = 999
    }
}
