﻿namespace Concord.KeyIn.Client
{
    public class PersonalSetting
    {
        /// <summary>
        /// 下單成功後,是否清空下單Bar上之資料
        /// </summary>
        public bool ORDER_SUCCESS_CLEAR { get; set; }
        /// <summary>
        /// 委託價格為現價漲/跌兩檔開關
        /// </summary>
        public bool ORDER_PRICE_COVERED_ENABLE { get; set; }
        /// <summary>
        /// 委託價格為現價漲兩檔
        /// </summary>
        public string ORDER_PRICE_RISE_TICK_VALUE { get; set; }
        /// <summary>
        /// 委託價格為現價跌兩檔
        /// </summary>
        public string ORDER_PRICE_FALL_TICK_VALUE { get; set; }
        /// <summary>
        /// 固定委託人帳號開關
        /// </summary>
        public bool FIXED_CSEQ_ENABLE { get; set; }
        /// <summary>
        /// 固定委託人帳號初始位置於委託類別
        /// </summary>
        public bool FIXED_CSEQ_INIT_OTYPE { get; set; }
        /// <summary>
        /// 固定委託人帳號初始位置於股票代號
        /// </summary>
        public bool FIXED_CSEQ_INIT_STOCK { get; set; }
        /// <summary>
        /// 股票信用資券詳細資訊顯示開關
        /// </summary>
        public bool STOCK_DETAIL_INFO_ENABLE { get; set; }

    }
}
