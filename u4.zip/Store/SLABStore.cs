﻿using Concord.SDK.Logging;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Concord.KeyIn.Client
{

    public class SLABStore
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        private static ConcurrentDictionary<string, SaleInfo> _SalesInfo = new ConcurrentDictionary<string, SaleInfo>();

        /// <summary>
        /// 取得營業員資訊
        /// </summary>
        /// <param name="sale">營業員代號</param>
        /// <returns></returns>
        public SaleInfo Get_SaleInfo(string sale)
        {
            SaleInfo info = new SaleInfo();
            _SalesInfo.TryGetValue(sale, out info);
            return info;
        }

        public static void Parser(string SLAB)
        {
            Logger.Info(SLAB);
            SaleInfo saleInfo = new SaleInfo();
            string[] info = SLAB.Split('|');
            saleInfo.SALE = info[0];
            saleInfo.NAME = info[1];
            saleInfo.LCN = info[2];

            if (!_SalesInfo.TryAdd(saleInfo.SALE, saleInfo))
            {
                Logger.Error($"新增營業員資料檔錯誤 SALE: {saleInfo.SALE} {saleInfo.NAME}");
            }
        }
    }
}
