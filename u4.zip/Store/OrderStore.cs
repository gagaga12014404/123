﻿using Concord.SDK.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel;
using System.Net.Http.Headers;
using System.Runtime.Remoting.Proxies;
using System.Runtime.InteropServices;
using System.Diagnostics;
namespace Concord.KeyIn.Client
{
    public class OrderStore
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        public Queue<Dictionary<int, string>> 回補Queue;
        public bool Refresh勾單 = false, Refresh回報 = false, Refresh明細 = false;
        // /// <summary>
        // /// KeyIn本身委託明細
        // /// </summary>
        // public DataTable _KeyInDetailStore;
        /// <summary>
        /// 成交回報明細資料表，只是用來GetChkDealCount用
        /// </summary>
        private List<Report> _OrdDealDetailStore;
        // /// <summary>
        // /// 委託回報紀錄資料表 (彙總)
        // /// </summary>
        // public static DataTable _OrdReportStore;
        /// <summary>
        /// 被動委託查詢紀錄資料表
        /// </summary>
        public BindingList<Report> 被動查詢List;
        public static BindingList<Report> 回報List;
        private ConcurrentDictionary<string, Report> 回報Dictionary;
        public static BindingList<Report> 明細List;
        private ConcurrentDictionary<string, Report> 明細Dictionary;
        public static Dictionary<string, Report> MyDic;
        public BindingList<CheckDeal> 勾單List;
        /// <summary>
        /// 網單回報儲存序列
        /// </summary>
        private BlockingCollection<Report> _DealDetailQueue;
        /// <summary>
        /// 委託回報儲存序列
        /// </summary>
        public BlockingCollection<Report> 下單Queue;
        /// <summary>
        /// 紀錄本機送單委託序號，供委託回報mapping使用
        /// Key: DSEQ
        /// Value: DSEQ
        /// </summary>
        public ConcurrentDictionary<string, string> _OrdDSEQ;
        /// <summary>
        /// key:委託書號，value:委託書號
        /// </summary>
        public ConcurrentDictionary<string, string> 空的才能下單;
        /// <summary>
        /// 記錄當天所有Push Server回報電文(過濾用)
        /// </summary>
        private ConcurrentDictionary<string, string> _PushMessage;
        /// <summary>
        /// 回補完成註記
        /// </summary>
        private bool _RecoverCompleted = false;
        /// <summary>
        /// 更新KeyIn明細委託鎖
        /// </summary>
        public readonly static object _KeyInOrderLock = new object();
        /// <summary>
        /// 更新委託鎖
        /// </summary>
        public readonly static object _Lock = new object();
        /// <summary>
        /// 更新被動委託鎖
        /// </summary>
        public readonly static object _PasLock = new object();
        /// <summary>
        /// 新增成交明細鎖
        /// </summary>
        private readonly static object _DealDetailLock = new object();
        public object 勾單List鎖 = new Object();
        public int 回補數量 = 0;
        public string 勾單篩選 = "整股";
        public int 興櫃委託書號 = 0;
        public int 興櫃錯帳委託書號 = 1;
        public ConcurrentDictionary<string, string> 分時分量的單;
        public static string GF = "";
        public Stopwatch Test_Timer;
        public OrderStore()
        {
            _OrdDSEQ = new ConcurrentDictionary<string, string>();
            _PushMessage = new ConcurrentDictionary<string, string>();
            下單Queue = new BlockingCollection<Report>();
            _DealDetailQueue = new BlockingCollection<Report>();
            _OrdDealDetailStore = new List<Report>();
            #region 建立並初始化回報紀錄資料表欄位
            被動查詢List = new BindingList<Report>();
            回報List = new BindingList<Report>();
            回報Dictionary = new ConcurrentDictionary<string, Report>();
            明細List = new BindingList<Report>();
            明細Dictionary = new ConcurrentDictionary<string, Report>();
            勾單List = new BindingList<CheckDeal>();
            MyDic = new Dictionary<string, Report>();
            空的才能下單 = new ConcurrentDictionary<string, string>();
            回補Queue = new Queue<Dictionary<int, string>>();
            分時分量的單 = new ConcurrentDictionary<string, string>();
            Test_Timer = new Stopwatch();
            #endregion
        }

        /// <summary>
        /// 更新回補數量並開始接收回報
        /// </summary>
        /// <param name="count"></param>
        public void Start_ProcessReport()
        {
            Logger.Info("[OrderStore 上市櫃Start_ProcessReport]");
            // 處理委託回報 Task
            Task.Factory.StartNew(() => 處理回報_明細Task(下單Queue, "下單"), TaskCreationOptions.LongRunning);
            // 處理成交明細 Task
            Task.Factory.StartNew(() => 處理成交Task(), TaskCreationOptions.LongRunning);
        }
        /// <summary>
        /// 處理成交明細序列資料
        /// </summary>
        private void 處理成交Task()
        {
            Logger.Info("[OrderStore 處理成交明細 Task Start]");
            Thread.CurrentThread.Name = "T_D";
            while (true)
            {
                try
                {
                    Report report = _DealDetailQueue.Take();
                    lock (_DealDetailLock)
                    {
                        Report report_OrdDealDetailStore = new Report();
                        report_OrdDealDetailStore.Seq = report.Seq;
                        report_OrdDealDetailStore.DSEQ = report.DSEQ;
                        report_OrdDealDetailStore.CSEQ = report.CSEQ;
                        report_OrdDealDetailStore.Stock = report.Stock;
                        report_OrdDealDetailStore.DealQty = report.DealQty;
                        report_OrdDealDetailStore.DealPrice = report.DealPrice;
                        _OrdDealDetailStore.Add(report_OrdDealDetailStore);
                    }
                    lock (勾單List鎖)
                    {
                        CheckDeal cd = new CheckDeal();
                        Report originReport = Get明細InfoByDSEQ(report.DSEQ + report.ClOrdID);
                        if (originReport == null)
                            continue;
                        CheckDeal originCD = GetCheckDealByDSEQandDPRICE(report.DSEQ, report.DealPrice.ToString());
                        if (originCD == null)
                        {
                            cd.ECode = report.ECode;
                            cd.No = int.Parse(report.成交序號);
                            cd.BHNO = report.BHNO;
                            cd.CSEQ = report.CSEQ;
                            cd.DSEQ = report.DSEQ;
                            cd.TimeInForce = report.TimeInForce;
                            cd.PRICE = originReport.OrdPrice;
                            cd.OQTY = originReport.OrdQty.ToString();
                            cd.OTYPE = report.OType;
                            cd.STOCK = report.Stock;
                            cd.STOCKNAME = report.StockName;
                            cd.BS = report.Side == "B" ? "買" : "賣";
                            cd.CheckStatus = report.Sale.Trim();
                            cd.DPRICE = report.DealPrice.ToString();
                            cd.DQTY = report.DealQty.ToString();
                            string[] s17_54_56 = report.Seq.Split(report.Side[0]);
                            cd.tag17 = s17_54_56[0];
                            cd.tag54 = report.Side;
                            cd.tag56 = s17_54_56[1];
                            Logger.Info($"[OrderStore 處理成交task] 勾單List插入 成交序號:{report.成交序號}");
                            lock (勾單List鎖)
                                勾單List.Insert(0, cd);
                        }
                        else
                        {
                            originCD.DQTY = (int.Parse(originCD.DQTY) + report.DealQty).ToString();
                        }
                        int alldqty = GetCheckDealAllDQTY(report.DSEQ);
                        foreach (var item in GetCheckDealByDSEQ(report.DSEQ))
                        {
                            item.AllDQTY = alldqty.ToString();
                        }
                        Refresh勾單 = true;
                    }
                }
                catch (Exception ex)
                {
                    ConcordLogger.Alert("9999", "[OrderStore] Client端 Task_ProcessDealDetail 異常", ex.ToString());
                    Logger.Error("[OrderStore] Task_ProcessDealDetail 發生異常: " + ex.ToString());
                }

            }
        }
        /// <summary>
        /// 更新回報資訊
        /// </summary>
        /// <param name="report"></param>
        public void UpdateReport(Report originReport, Report report)
        {
            Logger.Debug("[OrderStore UpdateReport] 開始，report.ExecType=" + report.ExecType + " report.DSEQ=" + report.DSEQ);
            try
            {
                if (originReport == null)
                    return;
                if (!string.IsNullOrWhiteSpace(originReport.Origin))
                    originReport.Origin = report.Origin;
                if (!string.IsNullOrWhiteSpace(report.Sale))
                    originReport.Sale = report.Sale;
                switch (report.ExecType)
                {
                    case "I": // 新單
                        {
                            originReport.DSEQ = report.DSEQ;
                            originReport.ClOrdID = report.ClOrdID;
                            originReport.OrdQty = report.OrdQty;
                            originReport.OrdPrice = report.OrdPrice;
                            // originReport.LaveQty = report.OrdQty + originReport.LaveQty;
                            break;
                        }
                    case "D": // 刪單成功
                        {
                            originReport.CancelQty = originReport.CancelQty + report.CancelQty;
                            originReport.LaveQty = originReport.LaveQty - report.CancelQty;
                            break;
                        }
                    case "C": // 改量成功
                        {
                            originReport.CancelQty = originReport.CancelQty + report.CancelQty;
                            originReport.LaveQty = originReport.LaveQty - report.CancelQty;
                            break;
                        }
                    case "P": // 改價成功
                        originReport.OrdPrice = report.OrdPrice;
                        break;
                    case "F": // 成交回報
                        {
                            originReport.DealQty = originReport.DealQty + report.DealQty;
                            originReport.DealPrice = report.DealPrice;
                            originReport.LaveQty = originReport.LaveQty - report.DealQty;
                            originReport.Seq = report.Seq;
                            break;
                        }
                    case "8": // 失敗單
                        {
                            originReport.Status = report.Status;
                            originReport.DSEQ = report.DSEQ;
                            originReport.ClOrdID = report.ClOrdID;
                            originReport.OrdPrice = report.OrdPrice;
                            originReport.LaveQty = 0;
                            originReport.Text = report.Text;
                            break;
                        }
                }
                UpdateStatus(originReport);
            }
            catch (Exception ex)
            {
                ConcordLogger.Alert("9999", "[OrderStore] Client端 UpdateReport 異常", ex.ToString());
                Logger.Error("[OrderStore UpdateReport] 發生異常: ", ex);
            }

        }
        /// <summary>
        /// 更新委託狀態
        /// </summary>
        private void UpdateStatus(Report originReport)
        {
            string Status = "";
            Logger.Debug($"[OrderStore UpdateStatus] {originReport.DSEQ} {originReport.Status}");
            if (originReport.Status == "失敗")//code不是0代表失敗，變成失敗後其他狀態就不是數字了
                return;
            else if (originReport.DealQty == 0 && originReport.CancelQty == 0)
            {
                if (!string.IsNullOrEmpty(originReport.Text))
                    Status = "失敗";
                else if (string.IsNullOrEmpty(originReport.DSEQ) || originReport.DSEQ == "00000")
                    Status = "送出";
                else
                    Status = "成功";
            }
            else if (originReport.CancelQty > 0 && originReport.CancelQty == originReport.OrdQty)
                Status = "刪單成功";
            else if (originReport.DealQty > 0)
            {
                if (originReport.OrdQty == originReport.DealQty + originReport.CancelQty)
                    Status = "完全成交";
                else
                    Status = "部份成交";
            }
            else
                Status = "成功";
            originReport.Status = Status;
            Logger.Debug("[OrderStore UpdateStatus] " + "Ord_Qty=" + originReport.OrdQty + " Deal_Qty=" + originReport.DealQty + " Cancel_Qty=" + originReport.CancelQty + " Status=" + Status + " DSEQ=" + originReport.DSEQ);

        }
        /// <summary>
        /// 啟動與否委託回報畫面選定欄位
        /// </summary>
        /// <param name="enable"></param>
        public void SetDeleSelectSwitch(bool enable)
        {
            lock (_Lock)
            {
                foreach (Report r in 回報List)
                {
                    if (enable)//全選要有條件
                    {
                        if ((r.Status == "成功" || r.Status == "部份成交") && r.LaveQty > 0)
                        {
                            r.CheckDelete = enable;
                        }
                    }
                    else//取消全部取消
                    {
                        r.CheckDelete = enable;
                    }
                }
            }
        }
        /// <summary>
        /// 啟動與否被動查詢畫面選定欄位
        /// </summary>
        /// <param name="enable"></param>
        public void SetPasDeleSelectSwitch(bool enable)
        {
            lock (_PasLock)
            {
                foreach (Report r in 被動查詢List)
                {
                    if ((r.Status == "成功" || r.Status == "部份成交") && r.LaveQty > 0)
                    {
                        r.CheckDelete = enable;
                    }
;
                }
            }
        }
        public bool TryAdd唯一值(string 唯一值)
        {
            return _PushMessage.TryAdd(唯一值, "");
        }
        /// <summary>
        /// 判斷是否含有相符電文
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool ContainsMessage(string key)
        {
            if (key == null)
                return false;

            return _PushMessage.ContainsKey(key);
        }
        /// <summary>
        /// 取得回報資訊 by 委託書號
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        public Report GetReportInfoByDSEQ(string DSEQ)
        {
            Logger.Debug($"[OrderStore GetReportInfoByDSEQ]開始 委託書號：{DSEQ}");
            if (回報Dictionary.TryGetValue(DSEQ, out var report))
                return report;
            return null;
        }
        private CheckDeal GetCheckDealByDSEQandDPRICE(String dseq, string deal_price)
        {
            lock (勾單List鎖)
                return 勾單List.FirstOrDefault(x => x.DSEQ == dseq && x.DPRICE == deal_price);
        }
        private IEnumerable<CheckDeal> GetCheckDealByDSEQ(String dseq)
        {
            lock (勾單List鎖)
                return 勾單List.Where(x => x.DSEQ == dseq);
        }
        private int GetCheckDealAllDQTY(String dseq)
        {
            lock (勾單List鎖)
                return 勾單List.Where(x => x.DSEQ == dseq).Select(x => int.TryParse(x.DQTY, out var dqty) ? dqty : 0).Sum();
        }
        /// <summary>
        /// 取得明細資訊 by 委託書號+網單
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        public Report Get明細InfoByDSEQ(string DSEQ)
        {
            Logger.Debug($"[OrderStore Get明細InfoByDSEQ]開始 委託書號：{DSEQ}");
            if (明細Dictionary.TryGetValue(DSEQ, out var report))
                return report;
            return null;
        }
        /// <summary>
        /// 取得被動查詢資訊 by 委託書號
        /// </summary>
        /// <param name="DSEQ"></param>
        /// <returns></returns>
        public Report GetPasReportInfoByDSEQ(string DSEQ)
        {
            lock (_PasLock)
            {
                return 被動查詢List.FirstOrDefault(x => x.DSEQ == DSEQ);
            }
        }
        /// <summary>
        /// 新增被動查詢資訊
        /// </summary>
        public void AddReport2(string report)
        {
            Customer cusInfo;

            int count = 1;
            try
            {
                lock (_PasLock)
                {
                    被動查詢List.Clear();
                    string[] row = report.Split('~');
                    Logger.Debug("AddReport2 開始存入委託查詢資料到DataTable");
                    foreach (string Temp in row)
                    {
                        string[] strArr = Temp.Split(',');
                        Logger.Debug($"[AddReport2] {strArr}");
                        if (strArr[11] == "E")
                        {
                            continue;
                        }
                        Report r = new Report();
                        r.Seq = count.ToString();
                        r.CheckDelete = false;
                        r.TransactTime = strArr[4] == "" ? strArr[4] : strArr[4].Substring(0, 2) + ":" + strArr[4].Substring(2, 2) + ":" + strArr[4].Substring(4, 2);
                        r.DSEQ = strArr[3];
                        r.CSEQ = strArr[9];
                        r.BHNO = $"845{strArr[8]}";
                        cusInfo = CUMBStore.Get_CustomerInfo(strArr[9]);
                        if (cusInfo != null) r.CusName = cusInfo.SNAME;
                        r.Stock = strArr[14];
                        r.StockName = strArr[15].Trim();
                        r.Side = strArr[17];
                        r.ECode = StockInfoHandler.GetECodeText(strArr[13]);
                        r.OType = strArr[12] == "0" ? "現" : strArr[12] == "3" ? "資" : strArr[12] == "4" ? "券" : strArr[12] == "1" ? "代資" : strArr[12] == "2" ? "代券" : "未知";
                        r.OrdPrice = strArr[22];
                        r.OrdQty = strArr[24] == "8" ? 0 : Int32.Parse(strArr[18]);
                        r.CancelQty = Int32.Parse(strArr[20]);
                        r.DealPrice = decimal.Parse(strArr[23]);
                        r.DealQty = Int32.Parse(strArr[21]);
                        r.LaveQty = Int32.Parse(strArr[19]);
                        r.OrdType = StockInfoHandler.GetOrdTypeText(strArr[32]);
                        r.TimeInForce = StockInfoHandler.GetTimeInForceText(strArr[33]);
                        r.MType = strArr[11];
                        r.Text = strArr[29];
                        r.ClOrdID = strArr[1];
                        r.OrigClOrdID = strArr[1];
                        r.Status = strArr[24] == "0" ? "委託成功" : strArr[24] == "1" ? "部份成交" : strArr[24] == "2" ? "完全成交" : strArr[24] == "4" ? "委託取消" : strArr[24] == "8" ? "委託失敗" : "送出";
                        r.Origin = strArr[26];
                        r.Sale = strArr[25];
                        UpdateStatus(r);
                        被動查詢List.Add(r);
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("存入委託查詢資料到DataTable發生錯誤 ", ex);
            }
        }

        public bool PasContainsDSEQ(string dseq)
        {
            lock (_PasLock)
            {
                return 被動查詢List.Any(x => x.DSEQ == dseq);
            }
        }
        /// <summary>
        /// 勾單作業取得回報數查詢
        /// </summary>
        /// <param name="DSeq"></param>
        /// <returns></returns>
        public List<int> GetChkDealCount(string DSEQ, string DPRICE)
        {
            List<int> list = new List<int>();
            lock (_DealDetailLock)
            {
                var result = _OrdDealDetailStore.Where(r => r.DSEQ == DSEQ.Trim()).Select(r => r.DealQty).ToList();
                foreach (var item in result)
                {
                    list.Add(item);
                }
            }
            list.Sort((x, y) => { return -x.CompareTo(y); });
            return list;
        }
        public CheckDeal FindCheckDealBy勾單List(string col_no)
        {
            lock (勾單List鎖)
                return 勾單List.FirstOrDefault(r => r.No.ToString() == col_no);
        }
        public int 查CheckStatus數量(string DSEQ)
        {
            lock (勾單List鎖)
                return 勾單List.Where(r => r.DSEQ == DSEQ && r.CheckStatus == "").ToList().Count;
        }
        /// <summary>
        /// 興櫃Parse委託回報
        /// </summary>
        public Report ParseReport(Dictionary<int, string> fix_msg)
        {
            //興櫃收到:35=20871=98270143=000000010=Q11=1446536=037=100038=100040=244=2754=B55=1260  56=3059=-176=8450100=0117=G0001118=20610000=110001=020002=K0000020003=K0000050001=0850002=11010150003= 50004=N50005=N50009=079= 80004=080014=80023=2024081915332935180024=2024081915333180080025=2024081915333180081008=I
            //上市收到:35=902871=98244573=000000010=N11=9     36=237=2   38=2   40=244=1554=B55=2303  56=1059=076=8450100=0117=B0004118=20610000=110001=020002=ABIg0520003=ABIg0550001=02350002=      50003=450004=N50005=N50009=079= 80004=080014=80023=2024081909500008780024=2024081909500008780025=2024081909500008781008=I
            try
            {
                Report report = new Report();
                string dealTag = fix_msg.ContainsKey(17) ? fix_msg[17] : "";
                report.唯一值 = fix_msg[76] + fix_msg[117] + fix_msg[10] + fix_msg[11];
                report.ExecType = fix_msg[81008];
                report.ClOrdID = fix_msg[20002];
                report.OrigClOrdID = fix_msg[20003];
                report.DSEQ = fix_msg[117];
                report.BHNO = fix_msg[76];
                report.CSEQ = fix_msg[1];
                if (fix_msg.ContainsKey(10001))
                    report.OType = StockInfoHandler.GetOrderTypeText(fix_msg[10001].Trim());
                report.Stock = fix_msg[55].Trim();

                StockInfo info = STMBStore.Get_SymbolInfo(report.Stock);
                if (info != null)
                {
                    report.MType = info.MTYPE;
                    report.StockName = info.CNAME;
                }
                report.Side = (fix_msg[54].Trim() == "1" || fix_msg[54].Trim() == "B") ? "B" : "S";
                report.TimeInForce = fix_msg.ContainsKey(59) ? StockInfoHandler.GetTimeInForceText(fix_msg[59].Trim()) : "ROD";
                string time = fix_msg[80025].PadLeft(17);//避免substring錯誤
                if (fix_msg[80025].Trim() == "")
                    time = fix_msg[80024].PadRight(15);
                report.TransactTime = time.Substring(8, 2) + ":" + time.Substring(10, 2) + ":" + time.Substring(12, 2);
                report.Origin = fix_msg[50002];//委託來源存keyin人員員編
                report.Sale = fix_msg[50001];
                Customer customer = CUMBStore.Get_CustomerInfo(report.CSEQ.Trim());
                if (customer != null)
                    report.CusName = customer.SNAME;
                report.OrdPrice = fix_msg[44];
                report.ECode = StockInfoHandler.GetECodeText(fix_msg[50009].Trim());

                int int_bfqty = int.Parse(fix_msg[37]);//改前
                int int_ordQty = int.Parse(fix_msg[38]);//改後
                report.原始委託價格 = fix_msg[44];
                report.Text = fix_msg.ContainsKey(80014) ? fix_msg[80014] : "";
                if (report.ExecType == "I" || report.ExecType == "8")//委回只有新單需要ordQty，之後都不會變
                {
                    report.Status = fix_msg[80004] == "0" ? "成功" : "失敗";
                    int qtytag36 = 0;
                    if (fix_msg.ContainsKey(36) && int.TryParse(fix_msg[36], out qtytag36) && qtytag36 > 0)//有可能會被交易所刪掉，只有上市會遇到吧
                    {
                        report.OrdQty = qtytag36;
                        report.CancelQty = qtytag36 - int_ordQty;
                    }
                    else
                    {
                        report.OrdQty = int_ordQty;
                    }
                    report.LaveQty = report.OrdQty;
                }
                else if (fix_msg[81008] == "P")
                {
                    report.Status = fix_msg[80004] == "0" ? "成功" : "失敗";
                    report.OrdQty = int_bfqty;
                }
                else if (fix_msg[81008] == "C" || fix_msg[81008] == "D")
                {
                    report.Status = fix_msg[80004] == "0" ? "成功" : "失敗";
                    report.OrdQty = int_bfqty - int_ordQty;//C、D委託 = 刪
                    report.BeforeChangeQty = int_bfqty;
                }
                else if (fix_msg[81008] == "F")
                {
                    report.Status = "成功";
                    report.DealQty = int_ordQty;
                    decimal deal_price = 0;
                    decimal.TryParse(fix_msg[44], out deal_price);
                    report.DealPrice = deal_price;
                    report.成交序號 = fix_msg[11];
                    report.Sale = fix_msg.ContainsKey(60006) ? fix_msg[60006] : "";//成交的sale等於是**,*勾單作業用
                    if (fix_msg.ContainsKey(17) && fix_msg.ContainsKey(56))
                        report.Seq = fix_msg[17].Trim() + report.Side.Trim() + fix_msg[56].Trim();
                }
                else
                {
                    report.Status = "失敗";
                    //失敗
                }
                //上市櫃需要
                if (fix_msg.ContainsKey(40))
                {
                    if (fix_msg[40] == "1")
                    {
                        report.OrdPrice = "市價";
                        report.原始委託價格 = "市價";
                    }
                    report.OrdType = StockInfoHandler.GetOrdTypeText(fix_msg[40].Trim());
                }
                if (fix_msg.ContainsKey(50004))
                    report.DayTradeFlag = fix_msg[50004].Trim();
                if (fix_msg.ContainsKey(79) && (fix_msg[79].ToLower() == "w" || fix_msg[79] == " "))
                    report.Status = "成功";
                else if (fix_msg.ContainsKey(79) && fix_msg[79].ToLower() == "E")
                {
                    report.Status = "失敗";
                }
                //上市櫃需要
                return report;
            }
            catch (Exception ex)
            {
                Logger.Error($"ParseReport Err，錯誤原因：{ex}");
                ConcordLogger.Alert("9999", $"ParseReport Err，錯誤原因：{ex}");
            }
            return null;
        }
        private void 處理回報_明細Task(BlockingCollection<Report> reportQueue, string threadName)
        {
            Logger.Info($"[處理回報_明細Task] ThreadName:{threadName} 開始");
            Thread.CurrentThread.Name = threadName;
            while (true)
            {
                try
                {
                    Report report = reportQueue.Take();
                    //防呆
                    if (report.DSEQ == null || report.OrigClOrdID == null)
                        return;
                    Logger.Info($"[處理回報_明細Task] 委託書號:{report.DSEQ} 委託狀態:{report.Status}");
                    處理回報(report);
                    處理明細(report);
                    Logger.Info($"======================[處理回報_明細Task] 委託書號:{report.DSEQ} 結束======================");
                }
                catch (Exception ex)
                {
                    Logger.Error("[OrderStore] Task_ProcessReport 發生異常: " + ex.ToString());
                    ConcordLogger.Alert("9999", "[OrderStore] Client端 Task_ProcessReport 異常", ex.ToString());
                }
            }
        }
        public void 處理回報(Report report)
        {
            if (回報Dictionary.TryGetValue(report.DSEQ, out var tmp))
            {
                UpdateReport(report);//假單的不處理
                if (report.ExecType == "F" && report.MType != "E")
                {
                    _DealDetailQueue.Add(report);
                }
                Refresh回報 = true;
            }
            else
            {
                回報Dictionary.TryAdd(report.DSEQ, report);
                lock (OrderStore._Lock)
                    OrderStore.回報List.Insert(0, report);
                Refresh回報 = true;
                Logger.Info($"[處理回報] 委託書號:{report.DSEQ} 新增");
            }
        }
        public void 處理明細(Report report)
        {
            //明細任何人為操作(新刪改量改價)都會插入，用"委託書號"+"網單"來判斷
            if (!_OrdDSEQ.ContainsKey(report.DSEQ))
                return;
            Report report1 = Get明細InfoByDSEQ(report.DSEQ + report.ClOrdID);
            if (report1 != null)
            {
                if (report.ExecType == "F")// 防止跨櫃操作後收到成交回報，顯示於畫面上問題
                {
                    Refresh明細 = true;
                    return;
                }
                report1.Status = report.Status;
                report1.Text = report.Text;
                if (report.ExecType == "C")
                {
                    report1.原始委託價格 = report.OrdPrice;
                    report1.BeforeChangeQty = report.BeforeChangeQty;
                }
                else if (report.ExecType == "P")
                    report1.OrdQty = report.OrdQty;
                else if (report.ExecType == "D")
                {
                    report1.原始委託價格 = report.OrdPrice;
                    report1.OrdQty = report.OrdQty;
                }
                Refresh明細 = true;
                Logger.Info($"[處理明細] 委託書號:{report.DSEQ} 更新");
                Logger.Info($"[處理明細] 委託書號:{report.DSEQ} 更新 花費時間：{Test_Timer.Elapsed}");
                Test_Timer.Reset();
            }
            else
            {
                明細Dictionary.TryAdd(report.DSEQ + report.ClOrdID, report);
                lock (OrderStore._KeyInOrderLock)
                    OrderStore.明細List.Insert(0, report);
                Refresh明細 = true;
                Logger.Info($"[處理明細] 委託書號:{report.DSEQ} 新增");
                Logger.Info($"[處理明細] 委託書號:{report.DSEQ} 新增 花費時間：{Test_Timer.Elapsed}");
            }
        }
        /// <summary>
        /// 彙總:更新回報
        /// </summary>
        public void UpdateReport(Report report)
        {
            if (report.Status == "成功" || report.Status == "失敗")//假單不插入
            {
                if (report.ExecType == "F")
                    UpdateDealReport(report);//成回
                else
                    UpdateOrdReport(report);//委回
            }
        }
        /// <summary>
        /// 彙總:更新委託回報
        /// </summary>
        private void UpdateOrdReport(Report report)
        {
            lock (OrderStore._Lock)
            {
                Logger.Debug($"[UpdateOrdReport] 更新委託回報 新刪改?:{report.ExecType} 委託書號：{report.DSEQ} 狀態:{report.Status} 委託數量:{report.OrdQty} 委託價錢:{report.OrdPrice}");
                Report originReport = GetReportInfoByDSEQ(report.DSEQ);
                if (originReport == null)
                    return;
                // originReport.ExecType = report.ExecType;
                // originReport.OrdQty = report.OrdQty;刪單、改量、改價不需要更新
                if (report.ExecType == "P" || report.ExecType == "I")
                    originReport.OrdPrice = report.OrdPrice;
                if (report.ExecType == "I")
                {
                    originReport.OrdQty = report.OrdQty;
                    if (report.CancelQty > 0)
                    {
                        originReport.CancelQty = report.CancelQty;
                    }
                }
                if (report.ExecType == "C" || report.ExecType == "D")
                    originReport.CancelQty = originReport.CancelQty + report.OrdQty;//C、D刪除數量 = 委託
                int laveQty = (report.ExecType == "C" || report.ExecType == "D") ? originReport.OrdQty - originReport.CancelQty - originReport.DealQty : originReport.OrdQty - originReport.CancelQty - originReport.DealQty;//剩餘數量 = 原委託-已刪-成交
                originReport.LaveQty = laveQty;
                if (laveQty == 0 && originReport.DealQty > 0)
                    originReport.Status = "完全成交";
                else if (laveQty == 0)
                    originReport.Status = "刪單成功";
                else if (report.Status == "失敗" && report.ExecType == "I")
                {
                    originReport.LaveQty = 0;
                    originReport.Status = "失敗";
                }
                Logger.Info($"[UpdateOrdReport] 更新委託回報 委託書號:{originReport.DSEQ}");
            }
        }
        /// <summary>
        /// 彙總:更新成交回報
        /// </summary>
        private void UpdateDealReport(Report report)
        {
            lock (OrderStore._Lock)
            {
                Logger.Debug($"[UpdateDealReport] 委託書號：{report.DSEQ} 更新成交回報 新刪改?:{report.ExecType} 狀態:{report.Status} 成交數量:{report.DealQty} 成交價錢:{report.OrdPrice}");
                Report originReport = GetReportInfoByDSEQ(report.DSEQ);
                if (originReport == null)
                    return;
                originReport.LaveQty = originReport.OrdQty - originReport.CancelQty - (originReport.DealQty + report.DealQty);
                int totalDealQty = originReport.DealQty + report.DealQty;
                originReport.DealQty = totalDealQty;
                originReport.DealPrice = report.DealPrice;
                if (originReport.OrdQty - originReport.CancelQty - totalDealQty <= 0)
                    originReport.Status = "完全成交";
                else
                    originReport.Status = "部份成交";
                Logger.Info($"[UpdateDealReport] 委託書號:{originReport.DSEQ} 更新成交回報結束");
            }
        }
        /// <summary>
        /// 將委回的彙總組合成order
        /// </summary>
        public Order DataRowToEMOrder(Report report)
        {
            Order order = new Order();
            order.CSEQ = report.CSEQ;
            order.BHNO = report.BHNO;
            order.DSEQ = report.DSEQ;
            order.Side = report.Side == "B" ? Side.BUY : Side.SELL;
            order.Symbol = report.Stock;
            order.OrdQty = report.OrdQty;
            order.OrdPrice = report.OrdPrice.ToString();
            order.ECode = report.ECode == "零股" ? "2" : "0";
            order.Sale = report.Sale;
            order.OrigClOrdID = report.OrigClOrdID.ToString();//原網單
            return order;
        }
        /// <summary>
        /// 用委託數量和類別判斷Ecode
        /// </summary>
        private string GetEcode(int orderQty, string stock)
        {
            StockInfo stockInfo = STMBStore.Get_SymbolInfo(stock);
            if (stockInfo == null)
            {
                Logger.Error($"找不到Ecode stock:{stock}");
                return orderQty >= 1000 ? "0" : "2";
            }
            int unit = 1000;
            int.TryParse(stockInfo.UNIT, out unit);
            if (stockInfo.STYPE == "9" || orderQty >= unit)
                return "0";
            return "2";
        }
        public void ErrAccountOrderNoAdd1(string orderNo)
        {
            int newErrAccountOrderNo = int.Parse(orderNo.PadRight(5, '0').Substring(1, 4));
            if (newErrAccountOrderNo >= 興櫃錯帳委託書號)
                興櫃錯帳委託書號 = newErrAccountOrderNo + 1;
        }
        public void OrderNoAdd1(string orderNo)
        {
            int newOrderNo = int.Parse(orderNo.PadRight(5, '0').Substring(1, 4));
            if (newOrderNo >= 興櫃委託書號)
                興櫃委託書號 = newOrderNo + 1;
        }
    }
}
