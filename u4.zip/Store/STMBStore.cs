﻿using Concord.SDK.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Concord.KeyIn.Client
{
    public class STMBStore
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        private static ConcurrentDictionary<string, StockInfo> _STMB = new ConcurrentDictionary<string, StockInfo>();
        private static ConcurrentDictionary<string, string> _RelatedCompanyStock = new ConcurrentDictionary<string, string>();

        /// <summary>
        /// 解析股票基本資料檔並儲存
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public static void ParserSTMB(string datas)
        {
            try
            {
                StockInfo symbol = new StockInfo();
                decimal CPrice = 0, TPrice = 0, BPrice = 0;
                string[] info = datas.Split('|');
                symbol.STOCK = info[0].Trim();//股票代號
                symbol.CNAME = info[1].Trim();//股票名稱
                symbol.MTYPE = info[2].Trim();//市場別
                symbol.STYPE = info[3].Trim();//股票類別 0:停止交易 1:第一類 2:第二類 3:全額 4:基金 5:可轉換公司債 6:認股權證 Z:OTC類
                decimal.TryParse(info[4], out CPrice);
                symbol.CPRICE = CPrice;//平盤價
                decimal.TryParse(info[5], out TPrice);
                symbol.TPRICE = TPrice;//漲停價
                decimal.TryParse(info[6], out BPrice);
                symbol.BPRICE = BPrice;//跌停價
                symbol.UNIT = info[7].Trim();//單位股數
                symbol.DTCODE = info[8].Trim();//現股當沖註記 空白: 不可現沖 Y:僅先買後賣 X:可雙向
                symbol.CRMARK = info[9].Trim();//融資註記 O:可融資 空白:不可融資
                symbol.DBMARK = info[10].Trim();//融券註記 X:可融券 空白:不可融券
                symbol.TMMARK = info[11].Trim();//豁免平盤下融券賣出註記
                symbol.CreditTradeState = info[12].Trim();//信用交易狀態
                symbol.FTState = info[13].Trim();//資券配額狀態
                symbol.StockTradeState = info[14].Trim();//股票交易狀態
                symbol.FT98State = info[15].Trim();//98戶配額成數
                _STMB.TryAdd(symbol.STOCK, symbol);
                AddRelatedCompanyStock(symbol.STOCK);
            }
            catch (Exception ex)
            {
                Logger.Error($"{ex}");
            }
        }
        /// <summary>
        /// 加入關係企業股票
        /// </summary>
        /// <param name="stock"></param>
        public static void AddRelatedCompanyStock(string stock)
        {
            switch (stock)
            {
                case "1101":
                case "1409":
                case "1419":
                case "2884":
                case "3483":
                case "4933":
                case "4938":
                case "5703":
                case "9908":
                case "9925":
                case "2850":
                    _RelatedCompanyStock.TryAdd(stock, stock);
                    break;
            }
        }
        /// <summary>
        /// 確認是否為關係企業股票
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public static bool CheckRelatedCompanyStock(string stock, Side side, string ordType)
        {
            if (stock == null)
                return false;

            return ((side == Side.BUY && (ordType == "0" || ordType == "3"))
                || (side == Side.SELL && ordType == "4"))
                && _RelatedCompanyStock.ContainsKey(stock);
        }
        /// <summary>
        /// 取得股票商品資訊
        /// </summary>
        /// <param name="key">股票代號</param>
        /// <returns>股票商品資訊</returns>
        public static StockInfo Get_SymbolInfo(string stock)
        {
            if (string.IsNullOrWhiteSpace(stock))
                return null;

            StockInfo info = new StockInfo();
            if (!_STMB.ContainsKey(stock) || !_STMB.TryGetValue(stock, out info))
                return null;
            return info;
        }
        /// <summary>
        /// 取得商品價格
        /// </summary>
        /// <param name="symbol"></param>
        /// <returns></returns>
        public static string Get_Price(string symbol, Side side)
        {
            if (string.IsNullOrWhiteSpace(symbol))
            {
                MessageBox.Show("錯誤之股票代號，請重新輸入");
                return "";
            }
            StockInfo info;
            _STMB.TryGetValue(symbol, out info);
            if (info == null)
            {
                MessageBox.Show("取價錯誤，請手動輸入價格");
                return "";
            }

            return side == Side.BUY ? info.TPRICE.ToString("0.####") : info.BPRICE.ToString("0.####");
        }
        /// <summary>
        /// 確認是否有該股票資訊
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public static bool CheckContains(string stock)
        {
            if (stock == null)
                return false;

            return _STMB.ContainsKey(stock);
        }
    }
}
