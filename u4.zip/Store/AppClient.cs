﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Concord.SDK.Logging;

namespace Concord.KeyIn.Client
{
    public abstract class AppClient : IDisposable
    {
        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        /// <summary>
        /// Socket 通訊端介面
        /// </summary>
        private Socket socket = null;
        /// <summary>
        /// 連線用同步Flag物件
        /// </summary>
        private object lockRef = new object();
        /// <summary>
        /// Server連線狀態
        /// </summary>
        public ConnectState ClientConnectState { get; set; }
        /// <summary>
        /// 自動重連線註記
        /// </summary>
        private bool AutoReConnect { get; set; }
        /// <summary>
        /// 遠端連線目標位址
        /// </summary>
        private DnsEndPoint RemoteEndPoint { get; set; }
        /// <summary>
        /// Nagle演算法啟動註記，預設打開 (false)
        /// </summary>
        public bool NoDelay = false;
        /// <summary>
        /// 電文編碼名稱，預設：Big5
        /// </summary>
        public string ClientEncoding { get; set; }
        /// <summary>
        /// 收取訊息完成通知事件
        /// 參數一：收到的訊息字串
        /// </summary>
        public Action<string> OnReceiveMsg = null;
        /// <summary>
        /// 收取訊息失敗通知事件
        /// 參數一：收到的訊息字串
        /// </summary>
        public Action<string> OnReceiveFailMsg = null;
        /// <summary>
        /// 送出訊息完成通知事件
        /// 參數一：送出的訊息字串
        /// </summary>
        public Action<string> OnSendMsg = null;
        /// <summary>
        /// 送出訊息失敗通知事件
        /// 參數一：送出的訊息字串
        /// </summary>
        public Action<string> OnSendFailMsg = null;
        /// <summary>
        /// Socket連接完成通知事件
        /// </summary>
        public Action OnConnect = null;
        /// <summary>
        /// Socket連接失敗通知事件
        /// 參數一：失敗原因字串
        /// </summary>
        public Action<string> OnConnectFail = null;

        /// <summary>
        /// 建構式
        /// </summary>
        /// <param name="remoteEndPoint">遠端連線目標位址</param>
        /// <param name="autoReConnect">自動重連線註記</param>
        public AppClient(DnsEndPoint remoteEndPoint, bool autoReConnect = true)
        {
            this.ClientEncoding = "Big5";
            this.RemoteEndPoint = remoteEndPoint;
            this.ClientConnectState = ConnectState.None;
            this.AutoReConnect = autoReConnect;
        }

        /// <summary>
        /// 執行連線作業
        /// </summary>
        /// <param name="reconnect">自動重連線註記</param>
        public void DoConnect()
        {
            lock (lockRef)
            {
                if (!AutoReConnect || ClientConnectState == ConnectState.Connecting || ClientConnectState == ConnectState.Connected)
                    return;
                if (socket != null)
                {
                    try
                    {
                        socket.Close();
                        socket.Dispose();
                    }
                    catch { }
                    socket = null;
                }
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.NoDelay = NoDelay;
                ClientConnectState = ConnectState.Connecting;
            }
            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            args.RemoteEndPoint = RemoteEndPoint;
            args.Completed += new EventHandler<SocketAsyncEventArgs>(OnSocketConnectCompleted);
            Action(ClientAction.Connect, args);
        }

        /// <summary>
        /// 執行Socket動作
        /// </summary>
        /// <param name="action">動作</param>
        /// <param name="args">參數</param>
        private void Action(ClientAction action, SocketAsyncEventArgs args)
        {
            lock (lockRef)
            {
                if (socket != null)
                {
                    switch (action)
                    {
                        case ClientAction.Connect:
                            ClientConnectState = ConnectState.Connecting;
                            if (!socket.ConnectAsync(args))
                            {
                                ProcessConnect(args);
                            }
                            break;
                        case ClientAction.Receive:
                            if (!socket.ReceiveAsync(args))
                            {
                                ProcessReceive(args);
                            }
                            break;
                        case ClientAction.Send:
                            if (!socket.SendAsync(args))
                            {
                                ProcessSend(args);
                            }
                            break;
                    }
                }
                else 
                {
                    ClientConnectState = ConnectState.Disconnected;
                    OnConnectFail?.Invoke("Client已斷線");
                }
            }
        }

        /// <summary>
        /// Connect Socket IOCP完成通知執行事件
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">參數</param>
        private void OnSocketConnectCompleted(object sender, SocketAsyncEventArgs e)
        {
            ProcessConnect(e);
        }

        /// <summary>
        /// Connect Socket事件
        /// </summary>
        /// <param name="e"></param>
        private void ProcessConnect(SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {
                SocketAsyncEventArgs args = new SocketAsyncEventArgs();
                args.SetBuffer(new Byte[Int16.MaxValue], 0, Int16.MaxValue);
                args.Completed += new EventHandler<SocketAsyncEventArgs>(OnReceiveCompleted);
                Action(ClientAction.Receive, args);
                // Thread.Sleep(3500);
                if (ClientConnectState == ConnectState.Connecting)
                {
                    e.Completed -= new EventHandler<SocketAsyncEventArgs>(OnSocketConnectCompleted);
                    ClientConnectState = ConnectState.Connected;
                    OnConnect?.Invoke();
                }
            }
            else if (e.SocketError != SocketError.ConnectionAborted)
            {
                OnConnectFail?.Invoke(e.SocketError.ToString());

                if (AutoReConnect)
                {
                    Thread.Sleep(5000);
                    OnRetryConnectTimeCallback(e);
                }
            }
        }

        /// <summary>
        /// 重試連線事件通知處理
        /// </summary>
        /// <param name="state">非同步狀態物件</param>
        private void OnRetryConnectTimeCallback(object obj)
        {
            SocketAsyncEventArgs args = obj as SocketAsyncEventArgs;
            if (args != null)
            {
                Action(ClientAction.Connect, args);
            }
        }

        /// <summary>
        /// Socket Receive IOCP完成通知執行事件
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">參數</param>
        private void OnReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            try
            {
                ProcessReceive(e);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

        /// <summary>
        /// 處理Socket Receive事件
        /// </summary>
        /// <param name="e"></param>
        private void ProcessReceive(SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                byte[] buffer = new byte[e.BytesTransferred];
                Array.Copy(e.Buffer, e.Offset, buffer, 0, buffer.Length);
                Array.Clear(e.Buffer, 0, e.Buffer.Length);
                HandleReceive(buffer);
                Action(ClientAction.Receive, e);
            }
            else if (e.BytesTransferred == 0 || e.SocketError == SocketError.ConnectionReset || e.SocketError == SocketError.ConnectionAborted)
            {
                ClientConnectState = ConnectState.Disconnected;
                OnConnectFail?.Invoke($"遠端已關閉連線:{e.SocketError}");
                if (AutoReConnect)
                {
                    Thread.Sleep(5000);
                    DoConnect();
                }
                else
                {
                    Dispose();
                }
            }
            else
            {
                OnReceiveFailMsg?.Invoke($"Unhandle Status:{e.SocketError.ToString()}");
            }
        }

        /// <summary>
        /// Socket Send IOCP完成通知執行事件
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">參數</param>
        private void OnSendCompleted(object sender, SocketAsyncEventArgs e)
        {
            ProcessSend(e);
        }

        /// <summary>
        /// 處理Socket Send事件
        /// </summary>
        /// <param name="e"></param>
        private void ProcessSend(SocketAsyncEventArgs e)
        {
            e.Completed -= new EventHandler<SocketAsyncEventArgs>(OnSendCompleted);
            if (e.SocketError == SocketError.Success)
            {
                OnSendMsg?.Invoke(e.UserToken.ToString());
            }
            else 
            {
                OnSendFailMsg?.Invoke(e.UserToken.ToString()); ;
                if (e.SocketError == SocketError.ConnectionReset || e.SocketError == SocketError.ConnectionAborted)
                {
                    ClientConnectState = ConnectState.Disconnected;
                    if (AutoReConnect)
                    {
                        Thread.Sleep(5000);
                        DoConnect();
                    }
                }
            }
            e.Dispose();
        }

        /// <summary>
        /// 送出訊息方法
        /// </summary>
        /// <param name="message">送出電文字串</param>
        public void SendMessage(string message)
        {
            byte[] data = Encoding.GetEncoding(ClientEncoding).GetBytes(message);
            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            args.SetBuffer(data, 0, data.Length);
            args.UserToken = message;
            args.Completed += new EventHandler<SocketAsyncEventArgs>(OnSendCompleted);
            Action(ClientAction.Send, args);
        }

        /// <summary>
        /// 處理收到電文方法
        /// </summary>
        /// <param name="data">收到Byte Array</param>
        public abstract void HandleReceive(byte[] data);

        #region Implement IDisposable.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    lock (lockRef)
                    {
                        if (socket != null)
                        {
                            AutoReConnect = false;
                            socket.Close();
                            socket.Dispose();
                            socket = null;
                        }
                    }
                }
                disposed = true;
            }
        }

        ~AppClient()
        {
            Dispose(false);
        }
        #endregion
    }

    /// <summary>
    /// ClientSocket動作
    /// </summary>
    enum ClientAction
    {
        /// <summary>
        /// 連線
        /// </summary>
        Connect,
        /// <summary>
        /// 傳送資料
        /// </summary>
        Send,
        /// <summary>
        /// 接收資料
        /// </summary>
        Receive
    }

    /// <summary>
    /// Server連線狀態
    /// </summary>
    public enum ConnectState
    {
        /// <summary>
        /// 未連線
        /// </summary>
        None,
        /// <summary>
        /// 連線中
        /// </summary>
        Connecting,
        /// <summary>
        /// 連線完成
        /// </summary>
        Connected,
        /// <summary>
        /// 斷線完成
        /// </summary>
        Disconnected
    }
}
